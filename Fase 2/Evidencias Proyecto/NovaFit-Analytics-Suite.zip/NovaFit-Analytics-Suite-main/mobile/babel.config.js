/**
 * Babel config for Expo + NativeWind v4.
 * The 'nativewind/babel' preset handles the className → StyleSheet transform.
 */
module.exports = function (api) {
  api.cache(true);
  return {
    presets: [
      ['babel-preset-expo', { jsxImportSource: 'nativewind' }],
      'nativewind/babel',
    ],
    plugins: [
      'react-native-reanimated/plugin',
    ],
  };
};
