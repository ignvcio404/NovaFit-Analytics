import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet, KeyboardAvoidingView, Platform, ScrollView } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import apiClient from '../api/client';
import { useAuth } from '../context/AuthContext';

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  primary: '#00e5ff',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  danger: '#ef4444',
};

const RegisterScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { login } = useAuth();
  
  const [form, setForm] = useState({
    firstName: '',
    lastName: '',
    email: '',
    phone: '',
    password: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleRegister = async () => {
    if (!form.firstName || !form.lastName || !form.email || !form.password) {
      setError('Por favor, completa los campos obligatorios (Nombre, Apellidos, Correo, Contraseña).');
      return;
    }

    setLoading(true);
    setError('');

    try {
      // Registrar al usuario
      await apiClient.post('/api/v1/auth/register', {
        first_name: form.firstName.trim(),
        last_name: form.lastName.trim(),
        email: form.email.trim(),
        username: form.email.trim(), // username defaults to email
        phone_number: form.phone.trim() || null,
        password: form.password,
        role: 'member'
      });
      
      // Auto login después del registro
      await login(form.email.trim(), form.password);
    } catch (err: any) {
      const msg = err.response?.data?.detail || 'Error al registrar la cuenta. Inténtalo nuevamente.';
      setError(msg);
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView contentContainerStyle={styles.scrollContent} showsVerticalScrollIndicator={false}>
        <View style={styles.headerBox}>
          <TouchableOpacity onPress={() => navigation.goBack()} style={styles.backBtn}>
            <MaterialCommunityIcons name="arrow-left" size={24} color={C.textMain} />
          </TouchableOpacity>
          <Text style={styles.title}>Crear Cuenta</Text>
        </View>

        <Text style={styles.subtitle}>Únete a NovaFit y empieza a entrenar más inteligente.</Text>

        <View style={styles.formContainer}>
          <View style={styles.row}>
            <View style={[styles.inputContainer, { flex: 1, marginRight: 8 }]}>
              <MaterialCommunityIcons name="account-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
              <TextInput
                style={styles.input}
                placeholder="Nombre *"
                placeholderTextColor={C.textMuted}
                value={form.firstName}
                onChangeText={(text) => { setForm({...form, firstName: text}); setError(''); }}
              />
            </View>
            <View style={[styles.inputContainer, { flex: 1, marginLeft: 8 }]}>
              <TextInput
                style={styles.input}
                placeholder="Apellidos *"
                placeholderTextColor={C.textMuted}
                value={form.lastName}
                onChangeText={(text) => { setForm({...form, lastName: text}); setError(''); }}
              />
            </View>
          </View>

          <View style={styles.inputContainer}>
            <MaterialCommunityIcons name="email-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Correo electrónico *"
              placeholderTextColor={C.textMuted}
              keyboardType="email-address"
              autoCapitalize="none"
              value={form.email}
              onChangeText={(text) => { setForm({...form, email: text}); setError(''); }}
            />
          </View>
          
          <View style={styles.inputContainer}>
            <MaterialCommunityIcons name="phone-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Teléfono (Opcional)"
              placeholderTextColor={C.textMuted}
              keyboardType="phone-pad"
              value={form.phone}
              onChangeText={(text) => { setForm({...form, phone: text}); setError(''); }}
            />
          </View>

          <View style={styles.inputContainer}>
            <MaterialCommunityIcons name="lock-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
            <TextInput
              style={styles.input}
              placeholder="Contraseña *"
              placeholderTextColor={C.textMuted}
              secureTextEntry
              value={form.password}
              onChangeText={(text) => { setForm({...form, password: text}); setError(''); }}
            />
          </View>

          {error ? <Text style={styles.errorText}>{error}</Text> : null}

          <TouchableOpacity
            style={styles.btn}
            onPress={handleRegister}
            disabled={loading}
            activeOpacity={0.85}
          >
            {loading ? (
              <ActivityIndicator color={C.bgBase} />
            ) : (
              <Text style={styles.btnText}>Registrarse</Text>
            )}
          </TouchableOpacity>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  scrollContent: {
    flexGrow: 1,
    paddingHorizontal: 32,
    paddingTop: 60,
    paddingBottom: 40,
    justifyContent: 'center'
  },
  headerBox: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  backBtn: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: C.bgPanel,
    alignItems: 'center',
    justifyContent: 'center',
    marginRight: 12,
  },
  title: {
    fontSize: 28,
    fontWeight: '900',
    color: C.textMain,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 14,
    color: C.textMuted,
    marginBottom: 32,
    lineHeight: 20,
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.bgPanel,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 14,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 54,
    color: C.textMain,
    fontSize: 16,
  },
  errorText: {
    color: C.danger,
    fontSize: 13,
    marginBottom: 16,
    textAlign: 'center',
  },
  btn: {
    backgroundColor: C.primary,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 6,
  },
  btnText: {
    fontSize: 16,
    fontWeight: '800',
    color: C.bgBase,
  },
});

export default RegisterScreen;
