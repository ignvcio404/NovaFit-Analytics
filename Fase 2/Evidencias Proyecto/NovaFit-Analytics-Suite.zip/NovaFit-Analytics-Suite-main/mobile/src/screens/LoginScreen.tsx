import React, { useState } from 'react';
import { View, Text, TextInput, TouchableOpacity, ActivityIndicator, StyleSheet, KeyboardAvoidingView, Platform, Image } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useNavigation } from '@react-navigation/native';
import { useAuth } from '../context/AuthContext';

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  primary: '#00e5ff',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  danger: '#ef4444',
};

const LoginScreen: React.FC = () => {
  const navigation = useNavigation<any>();
  const { login } = useAuth();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');

  const handleLogin = async () => {
    if (!email || !password) {
      setError('Por favor, ingresa tu correo y contraseña.');
      return;
    }

    setLoading(true);
    setError('');

    try {
      await login(email.trim(), password);
    } catch (err: any) {
      setError(err.response?.data?.detail || 'Error de conexión. Inténtalo nuevamente.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <KeyboardAvoidingView 
      style={styles.container} 
      behavior={Platform.OS === 'ios' ? 'padding' : 'height'}
    >
      <View style={styles.logoBox}>
        <Image 
          source={require('../../assets/logo-login.png')} 
          style={{ width: 80, height: 80, resizeMode: 'contain', marginBottom: 12, borderRadius: 16 }} 
        />
        <Text style={styles.logoText}>
          Nova<Text style={{ color: C.primary }}>Fit</Text>
        </Text>
        <Text style={styles.tagline}>Entrena más inteligente, no más duro.</Text>
      </View>

      <View style={styles.formContainer}>
        <View style={styles.inputContainer}>
          <MaterialCommunityIcons name="email-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Correo electrónico"
            placeholderTextColor={C.textMuted}
            keyboardType="email-address"
            autoCapitalize="none"
            value={email}
            onChangeText={(text) => { setEmail(text); setError(''); }}
          />
        </View>

        <View style={styles.inputContainer}>
          <MaterialCommunityIcons name="lock-outline" size={20} color={C.textMuted} style={styles.inputIcon} />
          <TextInput
            style={styles.input}
            placeholder="Contraseña"
            placeholderTextColor={C.textMuted}
            secureTextEntry
            value={password}
            onChangeText={(text) => { setPassword(text); setError(''); }}
          />
        </View>

        {error ? <Text style={styles.errorText}>{error}</Text> : null}

        <TouchableOpacity
          style={styles.btn}
          onPress={handleLogin}
          disabled={loading}
          activeOpacity={0.85}
        >
          {loading ? (
            <ActivityIndicator color={C.bgBase} />
          ) : (
            <Text style={styles.btnText}>Iniciar Sesión</Text>
          )}
        </TouchableOpacity>
        
        <TouchableOpacity style={styles.forgotBtn}>
          <Text style={styles.forgotText}>¿Olvidaste tu contraseña?</Text>
        </TouchableOpacity>

        <TouchableOpacity 
          style={styles.registerBtn}
          onPress={() => navigation.navigate('Register')}
        >
          <Text style={styles.registerText}>¿No tienes cuenta? <Text style={styles.registerTextBold}>Regístrate aquí</Text></Text>
        </TouchableOpacity>
      </View>
    </KeyboardAvoidingView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  logoBox: {
    alignItems: 'center',
    marginBottom: 48,
  },
  logoText: {
    fontSize: 42,
    fontWeight: '900',
    color: C.textMain,
    letterSpacing: -1,
    marginTop: 12,
  },
  tagline: {
    fontSize: 14,
    color: C.textMuted,
    marginTop: 6,
  },
  formContainer: {
    width: '100%',
    maxWidth: 400,
    alignSelf: 'center',
  },
  inputContainer: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.bgPanel,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 14,
    marginBottom: 16,
    paddingHorizontal: 16,
  },
  inputIcon: {
    marginRight: 12,
  },
  input: {
    flex: 1,
    height: 54,
    color: C.textMain,
    fontSize: 16,
  },
  errorText: {
    color: C.danger,
    fontSize: 13,
    marginBottom: 16,
    textAlign: 'center',
  },
  btn: {
    backgroundColor: C.primary,
    borderRadius: 14,
    paddingVertical: 16,
    alignItems: 'center',
    marginTop: 8,
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 6,
  },
  btnText: {
    fontSize: 16,
    fontWeight: '800',
    color: C.bgBase,
  },
  forgotBtn: {
    marginTop: 24,
    alignItems: 'center',
  },
  forgotText: {
    color: C.primary,
    fontSize: 14,
    fontWeight: '600',
  },
  registerBtn: {
    marginTop: 24,
    alignItems: 'center',
    padding: 12,
  },
  registerText: {
    color: C.textMuted,
    fontSize: 15,
  },
  registerTextBold: {
    color: C.primary,
    fontWeight: 'bold',
  },
});

export default LoginScreen;
