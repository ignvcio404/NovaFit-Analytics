/**
 * NovaFit Analytics Suite — AthleteDashboardScreen
 * ==================================================
 *
 * Panel de bienvenida del atleta. Muestra:
 *  - Greeting con nombre del usuario
 *  - Estado de membresía real (desde /api/v1/auth/me)
 *  - Card de fatiga sistémica (desde /api/v1/analytics/fatigue/me)
 *  - Sesiones pendientes del día
 *  - Invitaciones de entrenadores pendientes (accept/reject)
 *  - Accesos rápidos a entrenamiento e historial
 *
 * Sin emojis — iconos de vector únicamente.
 * Diseño: dark mode premium, glassmorphism via bgPanel + opacity.
 */

import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useFocusEffect } from '@react-navigation/native';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

import { useAuth } from '../context/AuthContext';
import apiClient from '../api/client';
import { getMySessions, RoutineSessionSummary, getMyAlerts, checkInGym, PredictiveAlert } from '../api/trainingService';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase:   '#0f172a',
  bgPanel:  '#1e293b',
  primary:  '#00e5ff',
  textMain: '#f8fafc',
  textMuted:'#94a3b8',
  border:   '#334155',
  emerald:  '#10b981',
  danger:   '#ef4444',
  amber:    '#f59e0b',
  violet:   '#8b5cf6',
};

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

interface FatigueData {
  fatigue_level: 'low' | 'moderate' | 'high' | 'critical';
  fatigue_score: number;
  systemic_fatigue_score: number;
  recommend_deload: boolean;
  acwr: number;
}

interface Invitation {
  trainer_id: string;
  trainer_name: string;
  trainer_email?: string;
  invited_at?: string;
}

const FATIGUE_CONFIG = {
  low:      { color: '#10b981', bg: '#10b98115', border: '#10b98130', label: 'Óptimo',   icon: 'check-circle-outline' as const },
  moderate: { color: '#f59e0b', bg: '#f59e0b15', border: '#f59e0b30', label: 'Moderado', icon: 'alert-circle-outline' as const },
  high:     { color: '#fb923c', bg: '#fb923c15', border: '#fb923c30', label: 'Alto',     icon: 'alert-outline' as const },
  critical: { color: '#ef4444', bg: '#ef444415', border: '#ef444430', label: 'Crítico',  icon: 'alert-octagon-outline' as const },
};

// ─────────────────────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────────────────────

const SectionHeader: React.FC<{ icon: string; title: string }> = ({ icon, title }) => (
  <View style={sh.row}>
    <MaterialCommunityIcons name={icon as any} size={18} color={C.primary} />
    <Text style={sh.title}>{title}</Text>
  </View>
);
const sh = StyleSheet.create({
  row:   { flexDirection: 'row', alignItems: 'center', marginBottom: 12, gap: 8 },
  title: { fontSize: 14, fontWeight: '700', color: C.textMuted, letterSpacing: 0.8, textTransform: 'uppercase' },
});

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

const AthleteDashboardScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { user, logout } = useAuth();
  const [loading, setLoading] = useState(true);
  const [fatigueData, setFatigueData]   = useState<FatigueData | null>(null);
  const [membership, setMembership]     = useState<any>(null);
  const [pendingSessions, setPendingSessions] = useState<RoutineSessionSummary[]>([]);
  const [invitations, setInvitations]   = useState<Invitation[]>([]);
  const [acceptingId, setAcceptingId]   = useState<string | null>(null);
  const [alerts, setAlerts]             = useState<PredictiveAlert[]>([]);
  const [isCheckingIn, setIsCheckingIn] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [fatigueRes, profileRes, sessions, invitationsRes, alertsRes] = await Promise.all([
        apiClient.get('/api/v1/analytics/fatigue/me').catch(() => ({ data: null })),
        apiClient.get('/api/v1/auth/me').catch(() => ({ data: {} })),
        getMySessions(20).catch(() => []),
        apiClient.get('/api/v1/athlete/invitations').catch(() => ({ data: [] })),
        getMyAlerts().catch(() => []),
      ]);
      if (fatigueRes.data) setFatigueData(fatigueRes.data);
      setMembership(profileRes.data?.membership ?? null);
      const pending = Array.isArray(sessions)
        ? sessions.filter(s => s.status === 'pending' || s.status === 'planned')
        : [];
      setPendingSessions(pending);
      setInvitations(Array.isArray(invitationsRes.data) ? invitationsRes.data : []);
      setAlerts(Array.isArray(alertsRes) ? alertsRes : []);
    } catch (err) {
      console.error('[Dashboard] fetchAll error:', err);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchAll(); }, []));

  const handleAccept = async (trainerId: string) => {
    setAcceptingId(trainerId);
    try {
      await apiClient.post(`/api/v1/athlete/accept-trainer/${trainerId}`);
      Alert.alert('Entrenador aceptado', 'Ya puedes ver tus rutinas asignadas.');
      fetchAll();
    } catch {
      Alert.alert('Error', 'No se pudo aceptar al entrenador.');
    } finally {
      setAcceptingId(null);
    }
  };

  const handleDecline = async (trainerId: string) => {
    try {
      await apiClient.post(`/api/v1/athlete/decline-trainer/${trainerId}`).catch(() => null);
      fetchAll();
    } catch {
      console.warn('Decline not supported by server yet');
    }
  };

  const handleCheckIn = async () => {
    try {
      setIsCheckingIn(true);
      await checkInGym();
      Alert.alert('Check-in exitoso', 'Tu acceso ha sido registrado.');
    } catch (err: any) {
      const msg = err.response?.data?.detail ?? 'No se pudo registrar el check-in';
      Alert.alert('Error', msg);
    } finally {
      setIsCheckingIn(false);
    }
  };

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Buenos días';
    if (h < 19) return 'Buenas tardes';
    return 'Buenas noches';
  };

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator color={C.primary} size="large" />
        <Text style={styles.loadingText}>Cargando tu panel...</Text>
      </View>
    );
  }

  const fatCfg = fatigueData
    ? FATIGUE_CONFIG[fatigueData.fatigue_level] ?? FATIGUE_CONFIG.low
    : null;

  const membershipStatusColor = membership?.status === 'active' ? C.emerald : C.amber;
  const membershipLabel = membership?.status === 'active' ? 'Activa' : (membership?.status ?? 'Sin membresía');

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0f172a', '#111827']} style={StyleSheet.absoluteFillObject} />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <FlatList
          data={[{ key: 'dashboard' }]}
          keyExtractor={item => item.key}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scroll}
          renderItem={() => (
            <>
              {/* ── Header ──────────────────────────────────────────────── */}
              <View style={styles.header}>
                <View>
                  <Text style={styles.greeting}>{greeting()},</Text>
                  <Text style={styles.name}>{user?.first_name ?? 'Atleta'}</Text>
                </View>
                <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
                  <MaterialCommunityIcons name="logout-variant" size={20} color={C.textMuted} />
                </TouchableOpacity>
              </View>

              {/* ── Predictive Alerts Banner ────────────────────────────── */}
              {alerts.length > 0 && (
                <View style={styles.alertsContainer}>
                  {alerts.map(alert => (
                    <LinearGradient
                      key={alert.id}
                      colors={
                        alert.severity === 'critical' ? ['#7f1d1d', '#991b1b'] :
                        alert.severity === 'high'     ? ['#9a3412', '#c2410c'] :
                        ['#1e1b4b', '#312e81']
                      }
                      start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                      style={styles.alertBanner}
                    >
                      <View style={styles.alertIconWrap}>
                        <MaterialCommunityIcons 
                          name={alert.severity === 'critical' || alert.severity === 'high' ? 'alert-octagon' : 'information'} 
                          size={24} 
                          color="#fff" 
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.alertTitle}>Alerta Predictiva</Text>
                        <Text style={styles.alertMessage}>{alert.message}</Text>
                      </View>
                    </LinearGradient>
                  ))}
                </View>
              )}

              {/* ── Invitations ─────────────────────────────────────────── */}
              {invitations.length > 0 && (
                <View style={styles.section}>
                  <SectionHeader icon="account-plus-outline" title="Invitaciones pendientes" />
                  {invitations.map(inv => (
                    <View key={inv.trainer_id} style={styles.invitationCard}>
                      <View style={styles.invitationLeft}>
                        <View style={styles.avatarCircle}>
                          <MaterialCommunityIcons name="account" size={22} color={C.primary} />
                        </View>
                        <View>
                          <Text style={styles.invitationName}>
                            {inv.first_name} {inv.last_name}
                          </Text>
                          <Text style={styles.invitationSub}>Solicitud de entrenador</Text>
                        </View>
                      </View>
                      <View style={styles.invitationActions}>
                        <TouchableOpacity
                          style={[styles.invBtn, styles.invBtnAccept]}
                          onPress={() => handleAccept(inv.trainer_id)}
                          disabled={acceptingId === inv.trainer_id}
                        >
                          {acceptingId === inv.trainer_id
                            ? <ActivityIndicator size={14} color={C.bgBase} />
                            : <Ionicons name="checkmark" size={16} color={C.bgBase} />
                          }
                        </TouchableOpacity>
                        <TouchableOpacity
                          style={[styles.invBtn, styles.invBtnDecline]}
                          onPress={() => handleDecline(inv.trainer_id)}
                        >
                          <Ionicons name="close" size={16} color={C.danger} />
                        </TouchableOpacity>
                      </View>
                    </View>
                  ))}
                </View>
              )}

              {/* ── Membership ──────────────────────────────────────────── */}
              <View style={styles.section}>
                <SectionHeader icon="card-account-details-outline" title="Membresía" />
                <View style={[styles.card, { borderColor: membershipStatusColor + '40' }]}>
                  <View style={styles.cardRow}>
                    <View style={[styles.statusDot, { backgroundColor: membershipStatusColor }]} />
                    <Text style={[styles.membershipStatus, { color: membershipStatusColor }]}>
                      {membershipLabel}
                    </Text>
                  </View>
                  {membership?.end_date && (
                    <Text style={styles.membershipSub}>
                      Vence: {new Date(membership.end_date).toLocaleDateString('es-CL', { day: '2-digit', month: 'long', year: 'numeric' })}
                    </Text>
                  )}
                </View>
              </View>

              {/* ── Fatigue Card ─────────────────────────────────────────── */}
              {fatigueData && fatCfg && (
                <View style={styles.section}>
                  <SectionHeader icon="lightning-bolt-outline" title="Estado de Fatiga" />
                  <View style={[styles.card, { borderColor: fatCfg.border, backgroundColor: fatCfg.bg }]}>
                    <View style={styles.fatigueRow}>
                      <View>
                        <Text style={[styles.fatigueLevel, { color: fatCfg.color }]}>
                          {fatCfg.label}
                        </Text>
                        <Text style={styles.fatigueSub}>
                          Fatiga sistémica: {Math.round(fatigueData.systemic_fatigue_score ?? fatigueData.fatigue_score ?? 0)}/100
                        </Text>
                        {fatigueData.recommend_deload && (
                          <View style={styles.deloadBadge}>
                            <MaterialCommunityIcons name="sync-alert" size={13} color={C.amber} />
                            <Text style={styles.deloadText}>Descarga recomendada</Text>
                          </View>
                        )}
                      </View>
                      <View style={[styles.fatigueMeter, { borderColor: fatCfg.color + '50' }]}>
                        <MaterialCommunityIcons name={fatCfg.icon} size={32} color={fatCfg.color} />
                      </View>
                    </View>
                    {fatigueData.acwr != null && (
                      <View style={styles.acwrRow}>
                        <Text style={styles.acwrLabel}>ACWR</Text>
                        <Text style={[styles.acwrValue, {
                          color: fatigueData.acwr > 1.5 ? C.danger
                            : fatigueData.acwr < 0.8 ? C.amber
                            : C.emerald
                        }]}>
                          {Number(fatigueData.acwr).toFixed(2)}
                        </Text>
                      </View>
                    )}
                  </View>
                </View>
              )}

              {/* ── Pending Sessions ─────────────────────────────────────── */}
              <View style={styles.section}>
                <SectionHeader icon="calendar-check-outline" title="Rutinas de hoy" />
                {pendingSessions.length === 0 ? (
                  <View style={styles.emptyCard}>
                    <MaterialCommunityIcons name="check-all" size={28} color={C.border} />
                    <Text style={styles.emptyText}>No tienes rutinas pendientes</Text>
                  </View>
                ) : (
                  pendingSessions.slice(0, 3).map(session => (
                    <TouchableOpacity
                      key={session.id}
                      style={styles.sessionCard}
                      onPress={() => navigation.navigate('Training', { sessionId: session.id })}
                      activeOpacity={0.8}
                    >
                      <View style={styles.sessionIconBox}>
                        <MaterialCommunityIcons name="dumbbell" size={20} color={C.primary} />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.sessionName}>{session.name ?? 'Rutina pendiente'}</Text>
                        <Text style={styles.sessionDate}>
                          {session.scheduled_date
                            ? new Date(session.scheduled_date).toLocaleDateString('es-CL')
                            : 'Hoy'}
                        </Text>
                      </View>
                      <MaterialCommunityIcons name="chevron-right" size={20} color={C.textMuted} />
                    </TouchableOpacity>
                  ))
                )}
              </View>

              {/* ── Marcar Asistencia ────────────────────────────────────────── */}
              <View style={styles.section}>
                <SectionHeader icon="calendar-check" title="Control de Asistencia" />
                <TouchableOpacity
                  style={styles.checkInButton}
                  onPress={handleCheckIn}
                  activeOpacity={0.8}
                  disabled={isCheckingIn}
                >
                  <LinearGradient
                    colors={['#00e5ff', '#0077ff']}
                    start={{ x: 0, y: 0 }} end={{ x: 1, y: 1 }}
                    style={styles.checkInGradient}
                  >
                    {isCheckingIn ? (
                      <ActivityIndicator color="#fff" size="large" />
                    ) : (
                      <>
                        <MaterialCommunityIcons name="qrcode-scan" size={32} color="#fff" />
                        <Text style={styles.checkInText}>Marcar Asistencia a Entrenar</Text>
                      </>
                    )}
                  </LinearGradient>
                </TouchableOpacity>
              </View>

              {/* Bottom padding for tab bar */}
              <View style={{ height: 100 }} />
            </>
          )}
        />
      </SafeAreaView>
    </View>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  loadingContainer: {
    flex: 1,
    backgroundColor: C.bgBase,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  loadingText: {
    color: C.textMuted,
    fontSize: 14,
  },
  scroll: {
    padding: 20,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
    marginBottom: 28,
    paddingTop: 4,
  },
  greeting: {
    fontSize: 15,
    color: C.textMuted,
    fontWeight: '500',
    marginBottom: 2,
  },
  name: {
    fontSize: 28,
    fontWeight: '800',
    color: C.textMain,
    letterSpacing: -0.5,
  },
  logoutBtn: {
    padding: 10,
    backgroundColor: C.bgPanel,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: C.border,
  },
  alertsContainer: {
    marginBottom: 24,
    gap: 12,
  },
  alertBanner: {
    flexDirection: 'row',
    borderRadius: 16,
    padding: 16,
    alignItems: 'center',
    gap: 12,
  },
  alertIconWrap: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: 'rgba(255,255,255,0.15)',
    alignItems: 'center',
    justifyContent: 'center',
  },
  alertTitle: {
    color: '#fff',
    fontSize: 15,
    fontWeight: '700',
    marginBottom: 2,
  },
  alertMessage: {
    color: 'rgba(255,255,255,0.9)',
    fontSize: 13,
    lineHeight: 18,
  },
  section: {
    marginBottom: 24,
  },
  card: {
    backgroundColor: C.bgPanel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 20,
  },
  cardRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 10,
    marginBottom: 4,
  },
  statusDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  membershipStatus: {
    fontSize: 20,
    fontWeight: '700',
  },
  membershipSub: {
    fontSize: 13,
    color: C.textMuted,
    marginTop: 4,
  },
  fatigueRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-start',
  },
  fatigueLevel: {
    fontSize: 22,
    fontWeight: '800',
    marginBottom: 4,
  },
  fatigueSub: {
    fontSize: 13,
    color: C.textMuted,
    marginBottom: 8,
  },
  deloadBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: '#f59e0b15',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    alignSelf: 'flex-start',
  },
  deloadText: {
    fontSize: 12,
    color: C.amber,
    fontWeight: '600',
  },
  fatigueMeter: {
    width: 56,
    height: 56,
    borderRadius: 28,
    borderWidth: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  acwrRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginTop: 16,
    paddingTop: 14,
    borderTopWidth: 1,
    borderTopColor: C.border,
  },
  acwrLabel: {
    fontSize: 13,
    color: C.textMuted,
    fontWeight: '600',
    letterSpacing: 0.5,
  },
  acwrValue: {
    fontSize: 18,
    fontWeight: '800',
  },
  emptyCard: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 20,
    alignItems: 'center',
    gap: 10,
  },
  emptyText: {
    color: C.textMuted,
    fontSize: 14,
  },
  sessionCard: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 16,
    marginBottom: 10,
    gap: 14,
  },
  sessionIconBox: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: C.primary + '15',
    alignItems: 'center',
    justifyContent: 'center',
  },
  sessionName: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textMain,
    marginBottom: 2,
  },
  sessionDate: {
    fontSize: 12,
    color: C.textMuted,
  },
  checkInButton: {
    borderRadius: 20,
    overflow: 'hidden',
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 10,
    elevation: 8,
  },
  checkInGradient: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 20,
    gap: 12,
  },
  checkInText: {
    fontSize: 18,
    fontWeight: '800',
    color: '#ffffff',
    letterSpacing: 0.5,
  },
  invitationCard: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.primary + '30',
    padding: 16,
    marginBottom: 10,
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
  },
  invitationLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    flex: 1,
  },
  avatarCircle: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: C.primary + '20',
    alignItems: 'center',
    justifyContent: 'center',
  },
  invitationName: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textMain,
  },
  invitationSub: {
    fontSize: 12,
    color: C.textMuted,
    marginTop: 2,
  },
  invitationActions: {
    flexDirection: 'row',
    gap: 8,
  },
  invBtn: {
    width: 36,
    height: 36,
    borderRadius: 10,
    alignItems: 'center',
    justifyContent: 'center',
  },
  invBtnAccept: {
    backgroundColor: C.primary,
  },
  invBtnDecline: {
    backgroundColor: C.danger + '20',
    borderWidth: 1,
    borderColor: C.danger + '50',
  },
});

export default AthleteDashboardScreen;
