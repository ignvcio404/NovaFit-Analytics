import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity, ActivityIndicator } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { useAuth } from '../context/AuthContext';
import apiClient from '../api/client';

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  primary: '#00e5ff',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  emerald: '#10b981',
  danger: '#ef4444',
  amber: '#f59e0b',
};

const DashboardScreen: React.FC<{ navigation: any }> = ({ navigation }) => {
  const { user, logout } = useAuth();
  const [loading, setLoading] = useState(true);
  const [fatigueData, setFatigueData] = useState<any>(null);

  useEffect(() => {
    const fetchDashboardData = async () => {
      try {
        const res = await apiClient.get('/api/v1/analytics/fatigue/me');
        setFatigueData(res.data);
      } catch (err) {
        console.error('Error fetching fatigue data', err);
      } finally {
        setLoading(false);
      }
    };
    fetchDashboardData();
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <ScrollView contentContainerStyle={styles.scrollContent}>
        {/* Header */}
        <View style={styles.header}>
          <View>
            <Text style={styles.greeting}>Hola, {user?.first_name || 'Atleta'}</Text>
            <Text style={styles.subtitle}>Tu resumen de hoy</Text>
          </View>
          <TouchableOpacity onPress={logout} style={styles.logoutBtn}>
            <MaterialCommunityIcons name="logout" size={24} color={C.textMuted} />
          </TouchableOpacity>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color={C.primary} style={{ marginTop: 40 }} />
        ) : (
          <>
            {/* Membresía Status */}
            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <Ionicons name="card-outline" size={20} color={C.primary} />
                <Text style={styles.cardTitle}>Estado de Membresía</Text>
              </View>
              <View style={styles.cardContent}>
                <Text style={styles.cardBigText}>Activa</Text>
                <Text style={styles.cardSubText}>Mantente al día con tus pagos.</Text>
              </View>
            </View>

            {/* Fatigue & Deload */}
            {fatigueData && (
              <View style={[styles.card, fatigueData.recommend_deload ? styles.cardWarning : null]}>
                <View style={styles.cardHeader}>
                  <MaterialCommunityIcons name="lightning-bolt-outline" size={20} color={fatigueData.recommend_deload ? C.amber : C.emerald} />
                  <Text style={styles.cardTitle}>Estado de Fatiga</Text>
                </View>
                <View style={styles.cardContent}>
                  <Text style={[styles.cardBigText, { color: fatigueData.recommend_deload ? C.amber : C.emerald }]}>
                    {fatigueData.recommend_deload ? 'Descarga Recomendada' : 'Óptimo'}
                  </Text>
                  <Text style={styles.cardSubText}>
                    Fatiga sistémica actual: {Math.round(fatigueData.systemic_fatigue_score)}/10
                  </Text>
                </View>
              </View>
            )}

            {/* Quick Actions */}
            <View style={styles.actionsGrid}>
              <TouchableOpacity 
                style={styles.actionBtn}
                onPress={() => navigation.navigate('Training')}
              >
                <MaterialCommunityIcons name="weight-lifter" size={32} color={C.primary} />
                <Text style={styles.actionText}>Ir a Entrenar</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={styles.actionBtn}
              >
                <MaterialCommunityIcons name="chart-line" size={32} color={C.primary} />
                <Text style={styles.actionText}>Mi Progreso</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  scrollContent: {
    padding: 24,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 32,
  },
  greeting: {
    fontSize: 28,
    fontWeight: '800',
    color: C.textMain,
  },
  subtitle: {
    fontSize: 16,
    color: C.textMuted,
    marginTop: 4,
  },
  logoutBtn: {
    padding: 8,
    backgroundColor: C.bgPanel,
    borderRadius: 12,
    borderWidth: 1,
    borderColor: C.border,
  },
  card: {
    backgroundColor: C.bgPanel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 20,
    marginBottom: 20,
  },
  cardWarning: {
    borderColor: C.amber + '50',
    backgroundColor: C.amber + '10',
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 16,
  },
  cardTitle: {
    fontSize: 16,
    fontWeight: '600',
    color: C.textMuted,
    marginLeft: 8,
  },
  cardContent: {
    gap: 4,
  },
  cardBigText: {
    fontSize: 24,
    fontWeight: '700',
    color: C.textMain,
  },
  cardSubText: {
    fontSize: 14,
    color: C.textMuted,
  },
  actionsGrid: {
    flexDirection: 'row',
    gap: 16,
    marginTop: 8,
  },
  actionBtn: {
    flex: 1,
    backgroundColor: C.bgPanel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 20,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 12,
  },
  actionText: {
    color: C.textMain,
    fontWeight: '600',
    fontSize: 14,
  },
});

export default DashboardScreen;
