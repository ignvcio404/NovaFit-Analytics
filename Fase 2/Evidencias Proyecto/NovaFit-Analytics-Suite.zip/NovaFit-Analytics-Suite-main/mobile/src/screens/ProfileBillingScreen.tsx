/**
 * NovaFit Analytics Suite — ProfileBillingScreen
 * ================================================
 *
 * Perfil del atleta + facturación. Muestra:
 *  - Avatar con iniciales + gradiente
 *  - Datos del usuario (nombre, email, teléfono)
 *  - Estado de membresía con días restantes y barra de progreso
 *  - Historial de facturas con botón de pago
 *  - Botón de cerrar sesión
 *
 * Sin emojis — iconos de vector únicamente.
 * Datos 100% reales de la base de datos.
 */

import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Alert,
  FlatList,
  Linking,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';

import { useAuth } from '../context/AuthContext';
import apiClient from '../api/client';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase:    '#0f172a',
  bgPanel:   '#1e293b',
  primary:   '#00e5ff',
  textMain:  '#f8fafc',
  textMuted: '#94a3b8',
  border:    '#334155',
  emerald:   '#10b981',
  danger:    '#ef4444',
  amber:     '#f59e0b',
  violet:    '#8b5cf6',
};

// ─────────────────────────────────────────────────────────────────────────────
// Invoice status helpers
// ─────────────────────────────────────────────────────────────────────────────

const statusColor = (status: string) => {
  switch (status) {
    case 'paid':    return C.emerald;
    case 'overdue': return C.danger;
    case 'pending': return C.amber;
    default:        return C.textMuted;
  }
};

const statusLabel = (status: string) => {
  switch (status) {
    case 'paid':    return 'PAGADA';
    case 'overdue': return 'VENCIDA';
    case 'pending': return 'PENDIENTE';
    case 'draft':   return 'BORRADOR';
    default:        return status.toUpperCase();
  }
};

// ─────────────────────────────────────────────────────────────────────────────
// Row components
// ─────────────────────────────────────────────────────────────────────────────

const ProfileRow: React.FC<{ icon: string; label: string; value: string }> = ({
  icon, label, value,
}) => (
  <View style={rowStyles.row}>
    <View style={rowStyles.iconWrap}>
      <MaterialCommunityIcons name={icon as any} size={18} color={C.primary} />
    </View>
    <View style={{ flex: 1 }}>
      <Text style={rowStyles.label}>{label}</Text>
      <Text style={rowStyles.value}>{value}</Text>
    </View>
  </View>
);

const rowStyles = StyleSheet.create({
  row: {
    flexDirection: 'row', alignItems: 'center', gap: 14,
    paddingVertical: 12, borderBottomWidth: 1, borderBottomColor: C.border,
  },
  iconWrap: {
    width: 36, height: 36, borderRadius: 10,
    backgroundColor: C.primary + '15',
    alignItems: 'center', justifyContent: 'center',
  },
  label: { fontSize: 11, color: C.textMuted, fontWeight: '600', marginBottom: 2, letterSpacing: 0.4 },
  value: { fontSize: 15, color: C.textMain, fontWeight: '600' },
});

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

const ProfileBillingScreen: React.FC = () => {
  const { user, logout } = useAuth();
  const [membership, setMembership] = useState<any>(null);
  const [invoices, setInvoices]     = useState<any[]>([]);
  const [loading, setLoading]       = useState(true);

  const loadData = useCallback(async () => {
    try {
      const [meRes, invRes] = await Promise.all([
        apiClient.get('/api/v1/auth/me').catch(() => ({ data: {} })),
        apiClient.get('/api/v1/billing/my-invoices').catch(() => ({ data: [] })),
      ]);
      setMembership(meRes.data?.membership ?? null);
      setInvoices(Array.isArray(invRes.data) ? invRes.data : []);
    } catch (error) {
      // Ignorar
    } finally {
      setLoading(false);
    }
  }, []);

  useFocusEffect(
    useCallback(() => {
      loadData();
    }, [loadData])
  );

  const handleRenewMembership = () => {
    const unpaidInvoice = invoices.find(inv => inv.status === 'pending' || inv.status === 'overdue');
    if (unpaidInvoice && unpaidInvoice.payment_url) {
      Linking.openURL(unpaidInvoice.payment_url);
    } else {
      Alert.alert('Atención', 'No tienes una factura pendiente con enlace de pago. Solicita a tu entrenador la emisión de tu nueva cuota.');
    }
  };

  const handlePay = (url: string) => {
    if (url) Linking.openURL(url);
    else Alert.alert('Sin enlace', 'Esta factura no tiene un enlace de pago disponible.');
  };

  const handleLogout = () => {
    Alert.alert(
      'Cerrar Sesión',
      '¿Seguro que quieres salir de tu cuenta?',
      [
        { text: 'Cancelar', style: 'cancel' },
        { text: 'Salir', style: 'destructive', onPress: logout },
      ],
    );
  };

  const initials = `${user?.first_name?.[0] ?? ''}${user?.last_name?.[0] ?? ''}`.toUpperCase();
  const fullName = `${user?.first_name ?? ''} ${user?.last_name ?? ''}`.trim();

  // Membership progress bar (days remaining / total days)
  const daysTotal = membership?.plan?.duration_days ?? 30;
  const daysLeft  = membership?.days_remaining ?? 0;
  const progress  = Math.max(0, Math.min(1, daysLeft / daysTotal));
  const memColor  = membership?.status === 'active' ? C.emerald : C.danger;
  const memLabel  = membership?.status === 'active' ? 'Activa' : (membership?.status ?? 'Sin membresía');

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={C.primary} />
        <Text style={styles.loadingText}>Cargando perfil...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <LinearGradient colors={['#0f172a', '#111827']} style={StyleSheet.absoluteFillObject} />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>

        {/* Header */}
        <View style={styles.header}>
          <Text style={styles.title}>Perfil</Text>
          <View style={styles.headerIcon}>
            <MaterialCommunityIcons name="account-circle-outline" size={22} color={C.primary} />
          </View>
        </View>

        <FlatList
          data={[{ key: 'content' }]}
          keyExtractor={item => item.key}
          showsVerticalScrollIndicator={false}
          contentContainerStyle={styles.scroll}
          renderItem={() => (
            <>
              {/* ── Avatar ──────────────────────────────────────────── */}
              <View style={styles.avatarSection}>
                <LinearGradient
                  colors={[C.primary, C.violet]}
                  start={{ x: 0, y: 0 }}
                  end={{ x: 1, y: 1 }}
                  style={styles.avatarGrad}
                >
                  <Text style={styles.avatarText}>{initials || '?'}</Text>
                </LinearGradient>
                <Text style={styles.avatarName}>{fullName || 'Atleta NovaFit'}</Text>
                <Text style={styles.avatarEmail}>{user?.email ?? ''}</Text>
              </View>

              {/* ── Info personal ────────────────────────────────────── */}
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <MaterialCommunityIcons name="account-outline" size={18} color={C.primary} />
                  <Text style={styles.cardTitle}>Información Personal</Text>
                </View>
                <ProfileRow icon="account-outline"   label="Nombre"   value={fullName || '—'} />
                <ProfileRow icon="email-outline"      label="Email"    value={user?.email ?? '—'} />
                <ProfileRow icon="phone-outline"      label="Teléfono" value={user?.phone_number ?? 'No registrado'} />
                <View style={[rowStyles.row, { borderBottomWidth: 0 }]}>
                  <View style={rowStyles.iconWrap}>
                    <MaterialCommunityIcons name="shield-account-outline" size={18} color={C.violet} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <Text style={rowStyles.label}>Rol</Text>
                    <Text style={rowStyles.value}>
                      {user?.user_roles?.[0]?.role?.name ?? 'Atleta'}
                    </Text>
                  </View>
                </View>
              </View>

              {/* ── Membresía ────────────────────────────────────────── */}
              <View style={[styles.card, { borderColor: memColor + '30' }]}>
                <View style={styles.cardHeader}>
                  <MaterialCommunityIcons name="card-account-details-outline" size={18} color={memColor} />
                  <Text style={styles.cardTitle}>Membresía</Text>
                </View>

                {membership ? (
                  <>
                    <View style={styles.membershipBanner}>
                      <View>
                        <Text style={styles.membershipPlanName}>
                          {membership.plan_name ?? 'Plan NovaFit'}
                        </Text>
                        <Text style={{ fontSize: 12, color: C.textMuted, marginTop: 2 }}>
                          Vence: {membership.end_date
                            ? new Date(membership.end_date).toLocaleDateString('es-CL', {
                                day: '2-digit', month: 'long', year: 'numeric',
                              })
                            : 'N/A'}
                        </Text>
                      </View>
                      <View style={[styles.statusBadge, { backgroundColor: memColor + '20', borderColor: memColor + '40' }]}>
                        <View style={[styles.statusDot, { backgroundColor: memColor }]} />
                        <Text style={[styles.statusText, { color: memColor }]}>{memLabel}</Text>
                      </View>
                    </View>

                    {/* Progress bar */}
                    <View style={{ marginTop: 16 }}>
                      <View style={styles.progressHeader}>
                        <Text style={styles.progressLabel}>Días restantes</Text>
                        <Text style={[styles.progressDays, { color: memColor }]}>
                          {daysLeft > 0 ? `${daysLeft} días` : 'Vencida'}
                        </Text>
                      </View>
                      <View style={styles.progressTrack}>
                        <View style={[styles.progressFill, {
                          width: `${Math.round(progress * 100)}%` as any,
                          backgroundColor: memColor,
                        }]} />
                      </View>
                    </View>
                  </>
                ) : (
                  <View style={styles.emptyMembership}>
                    <MaterialCommunityIcons name="card-remove-outline" size={32} color={C.border} />
                    <Text style={styles.emptyMembershipText}>Sin membresía activa</Text>
                    <TouchableOpacity
                      style={styles.renewButton}
                      activeOpacity={0.8}
                      onPress={handleRenewMembership}
                    >
                      <MaterialCommunityIcons name="credit-card-fast-outline" size={20} color="#fff" />
                      <Text style={styles.renewButtonText}>Renovar Membresía</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>

              {/* ── Facturas ─────────────────────────────────────────── */}
              <View style={styles.card}>
                <View style={styles.cardHeader}>
                  <MaterialCommunityIcons name="receipt-outline" size={18} color={C.violet} />
                  <Text style={styles.cardTitle}>Historial de Pagos</Text>
                </View>

                {invoices.length === 0 ? (
                  <View style={styles.emptyInvoices}>
                    <MaterialCommunityIcons name="file-document-outline" size={32} color={C.border} />
                    <Text style={styles.emptyInvoiceText}>Sin facturas disponibles</Text>
                  </View>
                ) : (
                  invoices.slice(0, 5).map((inv: any, idx) => (
                    <View
                      key={inv.id ?? idx}
                      style={[
                        styles.invoiceRow,
                        idx === invoices.length - 1 && { borderBottomWidth: 0 },
                      ]}
                    >
                      <View style={styles.invoiceIconBox}>
                        <MaterialCommunityIcons
                          name={inv.status === 'paid' ? 'check-circle-outline' : 'clock-alert-outline'}
                          size={18}
                          color={statusColor(inv.status)}
                        />
                      </View>
                      <View style={{ flex: 1 }}>
                        <Text style={styles.invoiceDate}>
                          {inv.due_date
                            ? new Date(inv.due_date).toLocaleDateString('es-CL', {
                                day: '2-digit', month: 'long', year: 'numeric',
                              })
                            : 'Fecha N/A'}
                        </Text>
                        <Text style={styles.invoiceTotal}>
                          $ {typeof inv.total === 'number'
                            ? inv.total.toLocaleString('es-CL')
                            : inv.total ?? '—'}
                        </Text>
                      </View>
                      {inv.status === 'pending' || inv.status === 'overdue' ? (
                        <TouchableOpacity
                          style={styles.payBtn}
                          onPress={() => handlePay(inv.payment_url ?? '')}
                        >
                          <Ionicons name="wallet-outline" size={14} color="#fff" />
                          <Text style={styles.payBtnText}>Pagar</Text>
                        </TouchableOpacity>
                      ) : (
                        <View style={[styles.statusBadge, {
                          backgroundColor: statusColor(inv.status) + '20',
                          borderColor: statusColor(inv.status) + '40',
                        }]}>
                          <Text style={[styles.statusText, { color: statusColor(inv.status) }]}>
                            {statusLabel(inv.status)}
                          </Text>
                        </View>
                      )}
                    </View>
                  ))
                )}
              </View>

              {/* ── Logout ───────────────────────────────────────────── */}
              <TouchableOpacity style={styles.logoutBtn} onPress={handleLogout} activeOpacity={0.8}>
                <MaterialCommunityIcons name="logout-variant" size={18} color={C.danger} />
                <Text style={styles.logoutText}>Cerrar Sesión</Text>
              </TouchableOpacity>

              <View style={{ height: 100 }} />
            </>
          )}
        />
      </SafeAreaView>
    </View>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bgBase },
  loadingContainer: {
    flex: 1, backgroundColor: C.bgBase,
    alignItems: 'center', justifyContent: 'center', gap: 16,
  },
  loadingText: { color: C.textMuted, fontSize: 14 },

  header: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center',
    paddingHorizontal: 20, paddingVertical: 16,
    borderBottomWidth: 1, borderBottomColor: C.border,
  },
  title: { fontSize: 26, fontWeight: '800', color: C.textMain, letterSpacing: -0.5 },
  headerIcon: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: C.primary + '15', borderWidth: 1, borderColor: C.primary + '30',
    alignItems: 'center', justifyContent: 'center',
  },
  scroll: { padding: 20 },

  // Avatar
  avatarSection: { alignItems: 'center', marginBottom: 28 },
  avatarGrad: {
    width: 88, height: 88, borderRadius: 44,
    alignItems: 'center', justifyContent: 'center', marginBottom: 16,
    shadowColor: C.primary, shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.4, shadowRadius: 12, elevation: 10,
  },
  avatarText:  { fontSize: 32, fontWeight: '900', color: '#fff' },
  avatarName:  { fontSize: 20, fontWeight: '800', color: C.textMain, letterSpacing: 0.3 },
  avatarEmail: { fontSize: 13, color: C.textMuted, marginTop: 4 },

  // Card
  card: {
    backgroundColor: C.bgPanel, borderRadius: 20,
    borderWidth: 1, borderColor: C.border, padding: 18, marginBottom: 20,
  },
  cardHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 16,
  },
  cardTitle: { fontSize: 16, fontWeight: '700', color: C.textMain },

  // Membership
  membershipBanner: {
    flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-start',
    backgroundColor: C.bgBase, borderRadius: 14, padding: 14,
    borderWidth: 1, borderColor: C.border,
  },
  membershipPlanName: { fontSize: 16, fontWeight: '700', color: C.textMain },
  statusBadge: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    paddingHorizontal: 10, paddingVertical: 5, borderRadius: 10, borderWidth: 1,
  },
  statusDot:  { width: 6, height: 6, borderRadius: 3 },
  statusText: { fontSize: 11, fontWeight: '800', letterSpacing: 0.5 },
  progressHeader: {
    flexDirection: 'row', justifyContent: 'space-between', marginBottom: 8,
  },
  progressLabel: { fontSize: 12, color: C.textMuted, fontWeight: '600' },
  progressDays:  { fontSize: 12, fontWeight: '700' },
  progressTrack: {
    height: 6, backgroundColor: C.border, borderRadius: 3, overflow: 'hidden',
  },
  progressFill: { height: '100%', borderRadius: 3 },
  emptyMembership: {
    alignItems: 'center', paddingVertical: 24, gap: 8,
  },
  emptyMembershipText: {
    color: C.textMain,
    fontSize: 15,
    fontWeight: '600',
    marginTop: 12,
    marginBottom: 4,
  },
  renewButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: C.primary,
    paddingHorizontal: 20,
    paddingVertical: 12,
    borderRadius: 12,
    marginTop: 16,
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.3,
    shadowRadius: 8,
    elevation: 4,
  },
  renewButtonText: {
    color: '#fff',
    fontSize: 14,
    fontWeight: 'bold',
  },

  // Invoices
  invoiceRow: {
    flexDirection: 'row', alignItems: 'center', gap: 12,
    paddingVertical: 14, borderBottomWidth: 1, borderBottomColor: C.border,
  },
  invoiceIconBox: {
    width: 36, height: 36, borderRadius: 10, backgroundColor: C.bgBase,
    borderWidth: 1, borderColor: C.border, alignItems: 'center', justifyContent: 'center',
  },
  invoiceDate:  { fontSize: 12, color: C.textMuted, marginBottom: 2 },
  invoiceTotal: { fontSize: 16, fontWeight: '700', color: C.textMain },
  payBtn: {
    flexDirection: 'row', alignItems: 'center', gap: 6,
    backgroundColor: C.violet, paddingHorizontal: 14,
    paddingVertical: 8, borderRadius: 10,
    shadowColor: C.violet, shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.3, shadowRadius: 4, elevation: 4,
  },
  payBtnText: { color: '#fff', fontWeight: '700', fontSize: 13 },
  emptyInvoices: { alignItems: 'center', paddingVertical: 20, gap: 8 },
  emptyInvoiceText: { fontSize: 14, color: C.textMuted },

  // Logout
  logoutBtn: {
    flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10,
    backgroundColor: C.danger + '12', borderWidth: 1,
    borderColor: C.danger + '35', borderRadius: 16, padding: 16, marginTop: 4,
  },
  logoutText: { color: C.danger, fontWeight: '700', fontSize: 16 },
});

export default ProfileBillingScreen;
