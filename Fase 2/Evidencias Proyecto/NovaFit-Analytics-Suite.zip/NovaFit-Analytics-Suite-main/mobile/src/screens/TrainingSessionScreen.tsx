/**
 * NovaFit Analytics Suite — Mobile
 * ==================================
 * TrainingSessionScreen
 * ==================================
 *
 * Pantalla principal del atleta. Desde aquí el usuario:
 *   1. Ve la rutina del día (instanciada desde el template asignado)
 *   2. Registra peso y reps en vivo por cada serie
 *   3. Marca series como "al fallo" o "calentamiento"
 *   4. Recibe feedback del modelo de fatiga (ACWR + score ML)
 *   5. Finaliza y envía la sesión al backend (Critical Flow #1)
 *
 * Diseño: Dark mode nativo, glassmorphism simulado con colores sólidos
 * semi-transparentes (BlurView disponible en Expo SDK 51+).
 * Typography: Sistema + Inter via expo-font.
 * Paleta: idéntica a la web (--color-primary: #00e5ff, etc.)
 */

import React, {
  useCallback,
  useEffect,
  useMemo,
  useRef,
  useState,
} from 'react';
import { Image } from 'expo-image';
import {
  ActivityIndicator,
  View,
  Alert,
  Animated,
  KeyboardAvoidingView,
  Platform,
  Pressable,
  RefreshControl,
  ScrollView,
  StatusBar,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';


import {
  createTrainingSession,
  ExerciseSetCreate,
  FatigueAnalysisResponse,
  FatigueLevel,
  getMyFatigueAnalysis,
  getTemplates,
  instantiateTemplate,
  RoutineSessionResponse,
  RoutineTemplateResponse,
  SessionExerciseCreate,
  getSessionById,
  completeSession,
  deleteSession,
} from '../api/trainingService';
import { useAuth } from '../context/AuthContext';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens (mirrors index.css CSS vars)
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  bgPanelHover: '#334155',
  primary: '#00e5ff',
  primaryDark: '#00b3cc',
  accent: '#f43f5e',
  success: '#10b981',
  warning: '#f59e0b',
  danger: '#ef4444',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  borderLight: '#475569',
};

const FATIGUE_CONFIG: Record<
  FatigueLevel,
  { color: string; bg: string; border: string; label: string; icon: string }
> = {
  low: { color: C.success, bg: '#10b98115', border: '#10b98130', label: 'Óptimo', icon: 'checkmark-circle' },
  moderate: { color: C.warning, bg: '#f59e0b15', border: '#f59e0b30', label: 'Moderado', icon: 'warning' },
  high: { color: '#fb923c', bg: '#fb923c15', border: '#fb923c30', label: 'Alto', icon: 'alert-circle' },
  critical: { color: C.danger, bg: '#ef444415', border: '#ef444430', label: 'CRÍTICO', icon: 'nuclear' },
};

// ─────────────────────────────────────────────────────────────────────────────
// Types (local UI state)
// ─────────────────────────────────────────────────────────────────────────────

interface LiveSet {
  set_number: number;
  weight: string;     // string for TextInput, parsed to number on submit
  reps: string;
  rpe: string;        // optional
  is_warmup: boolean;
  is_failure: boolean;
  logged: boolean;
  id?: number;
}

interface LiveExercise {
  exercise_id: number;
  order_index: number;
  exercise_name: string;
  category: string;
  equipment?: string;
  target_sets: number;
  reps_target: string;   // e.g. "8-12"
  rest_seconds: number;
  sets: LiveSet[];
  superset_group?: number;
  notes?: string;
  collapsed: boolean;
  video_url?: string;
  thumbnail_url?: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

const todayISO = (): string => new Date().toISOString().slice(0, 10);

const buildInitialSets = (count: number): LiveSet[] =>
  Array.from({ length: count }, (_, i) => ({
    set_number: i + 1,
    weight: '',
    reps: '',
    rpe: '1',
    is_warmup: false,
    is_failure: false,
    logged: false,
  }));

const templateToLiveExercises = (template: RoutineTemplateResponse): LiveExercise[] => {
  const exercises = template.template_data?.exercises ?? [];
  return exercises.map((ex) => ({
    exercise_id: ex.exercise_id,
    order_index: ex.order_index,
    exercise_name: `Ejercicio #${ex.exercise_id}`, // se enriquece al cargar catálogo
    category: 'general',
    target_sets: ex.sets,
    reps_target: ex.reps_target,
    rest_seconds: ex.rest_seconds ?? 90,
    sets: buildInitialSets(ex.sets),
    superset_group: ex.superset_group ?? undefined,
    notes: ex.notes ?? undefined,
    collapsed: false,
    video_url: undefined, // Enriched later
    thumbnail_url: undefined,
  }));
};

const sessionToLiveExercises = (session: RoutineSessionResponse): LiveExercise[] => {
  return session.exercises.map((ex) => ({
    exercise_id: ex.exercise_id,
    order_index: ex.order_index,
    exercise_name: ex.exercise_name || `Ejercicio #${ex.exercise_id}`,
    category: ex.exercise?.category || 'general',
    target_sets: ex.sets.length > 0 ? ex.sets.length : 3,
    reps_target: '8-12',
    rest_seconds: 90,
    sets: ex.sets.length > 0 ? ex.sets.map((s, idx) => ({
      id: s.id,
      set_number: idx + 1,
      weight: s.weight_kg ? String(s.weight_kg) : '',
      reps: s.reps ? String(s.reps) : '',
      rpe: s.rpe ? String(s.rpe) : '1',
      is_warmup: s.is_warmup || false,
      is_failure: s.is_failure || false,
      logged: false,
    })) : buildInitialSets(3),
    superset_group: ex.superset_group ?? undefined,
    notes: ex.notes ?? undefined,
    collapsed: false,
    video_url: ex.exercise?.video_url ?? undefined,
    thumbnail_url: ex.exercise?.thumbnail_url ?? undefined,
  }));
};

// Enrich exercise names from a completed session response
const enrichFromSession = (
  lives: LiveExercise[],
  session: RoutineSessionResponse,
): LiveExercise[] =>
  lives.map((live) => {
    const match = session.exercises.find((e) => e.exercise_id === live.exercise_id);
    if (match && match.exercise_name !== 'Unknown Exercise') {
      return { 
        ...live, 
        exercise_name: match.exercise_name, 
        category: match.exercise?.category ?? 'general',
        video_url: match.exercise?.video_url ?? live.video_url,
        thumbnail_url: match.exercise?.thumbnail_url ?? live.thumbnail_url,
      };
    }
    return live;
  });

const computeVolumeKg = (exercises: LiveExercise[]): number =>
  exercises.reduce((total, ex) =>
    total + ex.sets.reduce((s, set) =>
      set.logged
        ? s + (parseFloat(set.weight || '0') * parseInt(set.reps || '0', 10))
        : s,
    0), 0);

const loggedSetsCount = (exercises: LiveExercise[]): number =>
  exercises.reduce((total, ex) => total + ex.sets.filter((s) => s.logged).length, 0);

// ─────────────────────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────────────────────

/** Animated fatigue gauge bar */
const FatigueGauge: React.FC<{ score: number; level: FatigueLevel }> = ({ score, level }) => {
  const anim = useRef(new Animated.Value(0)).current;
  const parsedLevel = (level || 'low').toLowerCase() as FatigueLevel;
  const cfg = FATIGUE_CONFIG[parsedLevel] || FATIGUE_CONFIG.low;

  useEffect(() => {
    Animated.spring(anim, {
      toValue: Math.min(score, 100) / 100,
      useNativeDriver: false,
      tension: 50,
      friction: 8,
    }).start();
  }, [score]);

  const width = anim.interpolate({ inputRange: [0, 1], outputRange: ['0%', '100%'] });

  return (
    <View style={styles.gaugeTrack}>
      <Animated.View
        style={[
          styles.gaugeFill,
          { width, backgroundColor: cfg.color },
        ]}
      />
    </View>
  );
};

/** Collapsible fatigue card at the top of the screen */
const FatigueCard: React.FC<{ fatigue: FatigueAnalysisResponse | null; loading: boolean }> = ({
  fatigue,
  loading,
}) => {
  const [expanded, setExpanded] = useState(false);

  if (loading) {
    return (
      <View style={[styles.fatigueCard, { justifyContent: 'center', alignItems: 'center', minHeight: 72 }]}>
        <ActivityIndicator color={C.primary} size="small" />
        <Text style={[styles.mutedText, { marginTop: 6, fontSize: 12 }]}>Calculando fatiga...</Text>
      </View>
    );
  }

  if (!fatigue) return null;

  const level = (fatigue.fatigue_level || 'low').toLowerCase() as FatigueLevel;
  const cfg = FATIGUE_CONFIG[level] || FATIGUE_CONFIG.low;

  return (
    <Pressable
      style={[styles.fatigueCard, { borderColor: cfg.border, backgroundColor: cfg.bg }]}
      onPress={() => setExpanded((v) => !v)}
      accessibilityRole="button"
      accessibilityLabel="Expandir análisis de fatiga"
    >
      {/* Header row */}
      <View style={styles.fatigueHeader}>
        <View style={styles.fatigueHeaderLeft}>
          <Ionicons name={cfg.icon as any} size={20} color={cfg.color} />
          <View style={{ marginLeft: 10 }}>
            <Text style={[styles.fatigueLabel, { color: cfg.color }]}>
              Fatiga: {cfg.label}
            </Text>
            <Text style={styles.mutedText}>
              Score {Math.round(fatigue.fatigue_score)}/100 · ACWR{' '}
              {fatigue.acwr ? Number(fatigue.acwr).toFixed(2) : '—'}
            </Text>
          </View>
        </View>
        <View style={styles.fatigueHeaderRight}>
          {fatigue.deload_recommended && (
            <View style={[styles.deloadBadge, { borderColor: cfg.border, backgroundColor: cfg.bg }]}>
              <MaterialCommunityIcons name="sync-alert" size={13} color={cfg.color} />
              <Text style={[styles.deloadBadgeText, { color: cfg.color }]}>
                Deload
              </Text>
            </View>
          )}
          <Ionicons
            name={expanded ? 'chevron-up' : 'chevron-down'}
            size={16}
            color={C.textMuted}
            style={{ marginLeft: 8 }}
          />
        </View>
      </View>

      {/* Gauge bar */}
      <View style={{ marginTop: 10 }}>
        <FatigueGauge score={fatigue.fatigue_score} level={fatigue.fatigue_level} />
      </View>

      {/* Expanded detail */}
      {expanded && (
        <View style={styles.fatigueDetail}>
          <View style={styles.fatigueDetailGrid}>
            <FatigueStat label="Sesiones" value={`${fatigue.sessions_completed}/${fatigue.sessions_planned}`} />
            <FatigueStat label="Volumen" value={`${Math.round(fatigue.volume_load_kg)} kg`} />
            <FatigueStat label="RPE prom." value={fatigue.avg_rpe ? Number(fatigue.avg_rpe).toFixed(1) : '—'} />
            <FatigueStat label="Al fallo" value={String(fatigue.failure_sets_count)} />
          </View>
          {fatigue.deload_reason && (
            <View style={styles.deloadReason}>
              <Ionicons name="information-circle-outline" size={14} color={C.warning} />
              <Text style={[styles.deloadReasonText, { color: C.warning }]}>
                {fatigue.deload_reason}
              </Text>
            </View>
          )}
          <Text style={[styles.mutedText, { fontSize: 10, marginTop: 6, textAlign: 'right' }]}>
            Confianza: {(fatigue.recommendation_confidence * 100).toFixed(0)}% · v{fatigue.algorithm_version}
          </Text>
        </View>
      )}
    </Pressable>
  );
};

const FatigueStat: React.FC<{ label: string; value: string }> = ({ label, value }) => (
  <View style={styles.fatigueStatItem}>
    <Text style={styles.fatigueStatValue}>{value}</Text>
    <Text style={styles.fatigueStatLabel}>{label}</Text>
  </View>
);

/** Single set row with inline inputs */
const SetRow: React.FC<{
  set: LiveSet;
  exerciseIdx: number;
  setIdx: number;
  onUpdate: (exerciseIdx: number, setIdx: number, field: keyof LiveSet, value: any) => void;
  onLog: (exerciseIdx: number, setIdx: number) => void;
}> = ({ set, exerciseIdx, setIdx, onUpdate, onLog }) => {
  const pulseAnim = useRef(new Animated.Value(1)).current;

  const handleLog = () => {
    Animated.sequence([
      Animated.timing(pulseAnim, { toValue: 0.95, duration: 80, useNativeDriver: true }),
      Animated.timing(pulseAnim, { toValue: 1, duration: 120, useNativeDriver: true }),
    ]).start();
    onLog(exerciseIdx, setIdx);
  };

  const rowBg = set.logged
    ? '#10b98110'
    : set.is_warmup
    ? '#f59e0b08'
    : 'transparent';

  const rowBorder = set.logged
    ? '#10b98125'
    : set.is_warmup
    ? '#f59e0b20'
    : C.border;

  return (
    <Animated.View
      style={[
        styles.setRow,
        { backgroundColor: rowBg, borderColor: rowBorder, transform: [{ scale: pulseAnim }] },
      ]}
    >
      {/* Set number */}
      <View style={styles.setNumber}>
        <Text style={[styles.setNumberText, set.is_warmup && { color: C.warning }, set.logged && { color: C.success }]}>
          {set.is_warmup ? 'W' : set.set_number}
        </Text>
      </View>

      {/* Weight input */}
      <View style={styles.setInputWrapper}>
        <TextInput
          style={[styles.setInput, set.logged && styles.setInputLogged]}
          value={set.weight}
          onChangeText={(v) => onUpdate(exerciseIdx, setIdx, 'weight', v)}
          keyboardType="decimal-pad"
          placeholder="0"
          placeholderTextColor={C.textMuted}
          editable={!set.logged}
          accessibilityLabel={`Peso serie ${set.set_number}`}
        />
        <Text style={styles.setInputUnit}>kg</Text>
      </View>

      {/* × separator */}
      <Text style={styles.setSeparator}>×</Text>

      {/* Reps input */}
      <View style={styles.setInputWrapper}>
        <TextInput
          style={[styles.setInput, set.logged && styles.setInputLogged]}
          value={set.reps}
          onChangeText={(v) => onUpdate(exerciseIdx, setIdx, 'reps', v)}
          keyboardType="number-pad"
          placeholder="0"
          placeholderTextColor={C.textMuted}
          editable={!set.logged}
          accessibilityLabel={`Repeticiones serie ${set.set_number}`}
        />
        <Text style={styles.setInputUnit}>reps</Text>
      </View>

      {/* RPE input */}
      <View style={[styles.setInputWrapper, { flex: 0.7 }]}>
        <TextInput
          style={[styles.setInput, set.logged && styles.setInputLogged]}
          value={set.rpe}
          onChangeText={(v) => onUpdate(exerciseIdx, setIdx, 'rpe', v)}
          keyboardType="decimal-pad"
          placeholder="1"
          placeholderTextColor={C.textMuted}
          editable={!set.logged}
          accessibilityLabel={`RPE serie ${set.set_number}`}
        />
      </View>

      {/* Failure toggle */}
      <TouchableOpacity
        onPress={() => !set.logged && onUpdate(exerciseIdx, setIdx, 'is_failure', !set.is_failure)}
        style={[styles.failureToggle, set.is_failure && { backgroundColor: C.danger + '20', borderColor: C.danger + '40' }]}
        accessibilityLabel="Marcar al fallo"
        accessibilityRole="checkbox"
        disabled={set.logged}
      >
        <MaterialCommunityIcons
          name="lightning-bolt"
          size={15}
          color={set.is_failure ? C.danger : C.border}
        />
      </TouchableOpacity>

      {/* Log / check button */}
      <TouchableOpacity
        onPress={handleLog}
        style={[
          styles.logButton,
          set.logged
            ? { backgroundColor: C.success + '20', borderColor: C.success + '40' }
            : { backgroundColor: C.primary + '15', borderColor: C.primary + '30' },
        ]}
        accessibilityLabel={set.logged ? 'Serie registrada' : 'Registrar serie'}
        accessibilityRole="button"
      >
        <Ionicons
          name={set.logged ? 'checkmark-circle' : 'checkmark-circle-outline'}
          size={22}
          color={set.logged ? C.success : C.primary}
        />
      </TouchableOpacity>
    </Animated.View>
  );
};

/** Collapsible exercise card */

const ExerciseCard: React.FC<{
  exercise: LiveExercise;
  exerciseIdx: number;
  onAddSet: (idx: number) => void;
  onUpdateSet: (exerciseIdx: number, setIdx: number, field: keyof LiveSet, value: any) => void;
  onLogSet: (exerciseIdx: number, setIdx: number) => void;
  onStartRest: (seconds: number) => void;
}> = ({ exercise, exerciseIdx, onAddSet, onUpdateSet, onLogSet, onStartRest }) => {
  const loggedCount = exercise.sets.filter((s) => s.logged).length;
  const totalCount = exercise.sets.length;
  const progressPct = totalCount > 0 ? (loggedCount / totalCount) * 100 : 0;
  const allLogged = loggedCount === totalCount;

  const categoryColors: Record<string, string> = {
    chest: '#f43f5e',
    back: '#3b82f6',
    legs: '#8b5cf6',
    shoulders: '#f59e0b',
    arms: '#06b6d4',
    core: '#10b981',
    general: C.textMuted,
  };
  const catColor = categoryColors[exercise.category.toLowerCase()] ?? C.primary;

  return (
    <View style={[styles.exerciseCard, allLogged && { borderColor: C.success + '40' }]}>
      {/* Exercise header */}
      <View style={styles.exerciseHeader}>
        <View style={[styles.exerciseCategoryDot, { backgroundColor: catColor }]} />
        <View style={{ flex: 1, marginLeft: 12 }}>
          <Text style={styles.exerciseName} numberOfLines={1}>
            {exercise.exercise_name}
          </Text>
          <Text style={styles.exerciseMeta}>
            {exercise.target_sets} series · {exercise.reps_target} reps
            {exercise.rest_seconds ? ` · ${exercise.rest_seconds}s rest` : ''}
          </Text>
        </View>
        {/* Progress pill */}
        <View style={styles.exerciseProgressPill}>
          <Text style={[styles.exerciseProgressText, allLogged && { color: C.success }]}>
            {loggedCount}/{totalCount}
          </Text>
        </View>
      </View>

      {/* Mini progress bar */}
      <View style={styles.exerciseProgressBar}>
        <View
          style={[
            styles.exerciseProgressFill,
            {
              width: `${progressPct}%` as any,
              backgroundColor: allLogged ? C.success : C.primary,
            },
          ]}
        />
      </View>
      
      {/* Media Display */}
      <View style={{ width: '100%', height: 200, backgroundColor: '#FFFFFF', borderRadius: 12, overflow: 'hidden', marginBottom: 16 }}>
        
        {exercise.video_url ? (
          <Image source={{ uri: exercise.video_url }} style={{ width: '100%', height: '100%' }} contentFit="contain" />
        ) : (
          <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
             <MaterialCommunityIcons name="image-outline" size={48} color={C.textMuted} />
          </View>
        )}
      </View>
      <View style={{ paddingHorizontal: 16, paddingTop: 12 }}>
        {/* Exercise info row */}
        <View style={{ flexDirection: 'row', alignItems: 'center', marginBottom: 14, gap: 12 }}>
          <View style={{ width: 52, height: 52, backgroundColor: C.primary + '12', borderRadius: 12, borderWidth: 1, borderColor: C.primary + '25', justifyContent: 'center', alignItems: 'center' }}>
            <MaterialCommunityIcons name="dumbbell" size={22} color={C.primary} />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ color: C.textMain, fontSize: 13, fontWeight: '700' }}>
              Descanso recomendado: {exercise.rest_seconds || 90}s
            </Text>
            <Text style={{ color: C.textMuted, fontSize: 12, marginTop: 2 }}>
              {exercise.equipment || 'Equipo estándar'}
            </Text>
          </View>
        </View>
        
        {/* Timer button */}
        <TouchableOpacity 
          style={{ backgroundColor: C.primary + '10', borderRadius: 10, padding: 10, alignItems: 'center', marginBottom: 12, borderWidth: 1, borderColor: C.primary + '30', flexDirection: 'row', justifyContent: 'center', gap: 8 }}
          onPress={() => onStartRest(exercise.rest_seconds || 90)}
        >
          <MaterialCommunityIcons name="timer-outline" size={16} color={C.primary} />
          <Text style={{ color: C.primary, fontWeight: '700', fontSize: 13, letterSpacing: 0.5 }}>
            INICIAR CRONÓMETRO DE DESCANSO
          </Text>
        </TouchableOpacity>
      </View>

      {/* Sets */}
      <View style={styles.setsContainer}>
        {/* Column headers */}

          <View style={styles.setHeaders}>
            <Text style={[styles.setHeaderText, { flex: 0.4 }]}>Set</Text>
            <Text style={[styles.setHeaderText, { flex: 1 }]}>Peso</Text>
            <Text style={[styles.setHeaderText, { flex: 0.2, textAlign: 'center' }]}>x</Text>
            <Text style={[styles.setHeaderText, { flex: 1 }]}>Reps</Text>
            <Text style={[styles.setHeaderText, { flex: 0.7 }]}>RPE</Text>
            <Text style={[styles.setHeaderText, { flex: 0.5, textAlign: 'center' }]}>Fallo</Text>
            <Text style={[styles.setHeaderText, { flex: 0.7, textAlign: 'center' }]}>OK</Text>
          </View>

          {exercise.sets.map((set, sIdx) => (
            <SetRow
              key={sIdx}
              set={set}
              exerciseIdx={exerciseIdx}
              setIdx={sIdx}
              onUpdate={onUpdateSet}
              onLog={onLogSet}
            />
          ))}

          {/* Add set button */}
          <TouchableOpacity
            style={styles.addSetBtn}
            onPress={() => onAddSet(exerciseIdx)}
            accessibilityLabel="Agregar serie"
          >
            <Ionicons name="add-circle-outline" size={16} color={C.primary} />
            <Text style={[styles.addSetText, { color: C.primary }]}>Agregar serie</Text>
          </TouchableOpacity>
        </View>

      {/* Notes */}
      {exercise.notes && !exercise.collapsed && (
        <View style={styles.exerciseNotes}>
          <Ionicons name="document-text-outline" size={12} color={C.textMuted} />
          <Text style={[styles.mutedText, { fontSize: 12, marginLeft: 4 }]}>
            {exercise.notes}
          </Text>
        </View>
      )}
    </View>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

const TrainingSessionScreen: React.FC<any> = ({ route }) => {
  const { user } = useAuth();
  const sessionId = route?.params?.sessionId;

  // ── Data state ─────────────────────────────────────────────────────────────
  const [templates, setTemplates] = useState<RoutineTemplateResponse[]>([]);
  const [selectedTemplate, setSelectedTemplate] = useState<RoutineTemplateResponse | null>(null);
  const [exercises, setExercises] = useState<LiveExercise[]>([]);
  const [fatigue, setFatigue] = useState<FatigueAnalysisResponse | null>(null);
  const [sessionName, setSessionName] = useState('');
  const [memberNotes, setMemberNotes] = useState('');
  const [overallRpe, setOverallRpe] = useState('');

  // ── UI state ───────────────────────────────────────────────────────────────
  const [phase, setPhase] = useState<'select' | 'active' | 'finish'>('select');
  
  // ── Stepper & Timer state ─────────────────────────────────────────────────────────────
  const [currentStep, setCurrentStep] = useState(0);
  const [restRemaining, setRestRemaining] = useState(0);

  useEffect(() => {
    let interval: any;
    if (restRemaining > 0) {
      interval = setInterval(() => {
        setRestRemaining((prev) => prev - 1);
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [restRemaining]);

  const canGoNext = useMemo(() => {
    if (currentStep >= exercises.length) return true;
    const currentEx = exercises[currentStep];
    if (!currentEx) return false;
    return currentEx.sets.every((s) => s.logged);
  }, [currentStep, exercises]);

  const handleStartRest = useCallback((seconds: number) => {
    setRestRemaining(seconds);
  }, []);

  const [loadingTemplates, setLoadingTemplates] = useState(true);
  const [loadingFatigue, setLoadingFatigue] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [sessionStart, setSessionStart] = useState<Date | null>(null);
  const [elapsed, setElapsed] = useState(0); // seconds

  // ── Timer ──────────────────────────────────────────────────────────────────
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (phase === 'active' && sessionStart) {
      timerRef.current = setInterval(() => {
        setElapsed(Math.floor((Date.now() - sessionStart.getTime()) / 1000));
      }, 1000);
    }
    return () => { if (timerRef.current) clearInterval(timerRef.current); };
  }, [phase, sessionStart]);

  const formatElapsed = (s: number) => {
    const m = Math.floor(s / 60);
    const sec = s % 60;
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  };

  // ── Data loading ───────────────────────────────────────────────────────────
  const loadFatigue = useCallback(async () => {
    setLoadingFatigue(true);
    try {
      const data = await getMyFatigueAnalysis();
      setFatigue(data);
    } catch {
      // Silently fail — fatigue is optional, session can proceed
    } finally {
      setLoadingFatigue(false);
    }
  }, []);

  const loadTemplates = useCallback(async () => {
    setLoadingTemplates(true);
    try {
      const data = await getTemplates();
      setTemplates(data);
    } catch {
      Alert.alert('Error', 'No se pudo cargar las rutinas. Verifica tu conexión.');
    } finally {
      setLoadingTemplates(false);
    }
  }, []);

  useEffect(() => {
    loadTemplates();
    loadFatigue();
  }, []);

  useEffect(() => {
    const fetchPendingSession = async () => {
      if (sessionId) {
        try {
          const session = await getSessionById(sessionId);
          setSessionName(session.name);
          const liveExercises = sessionToLiveExercises(session);
          setExercises(liveExercises);
          setPhase('active');
          setSessionStart(new Date());
        } catch (e) {
          Alert.alert('Error', 'No se pudo cargar la sesión pendiente.');
        }
      }
    };
    
    if (sessionId) {
      fetchPendingSession();
    }
  }, [sessionId]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.allSettled([loadTemplates(), loadFatigue()]);
    setRefreshing(false);
  }, [loadTemplates, loadFatigue]);

  // ── Template selection → build live exercises ──────────────────────────────
  const handleSelectTemplate = useCallback(async (template: RoutineTemplateResponse) => {
    setSelectedTemplate(template);
    setSessionName(template.name);

    const liveExercises = templateToLiveExercises(template);

    // Try to enrich exercise names by instantiating (read-only preview)
    try {
      const session = await instantiateTemplate(template.id, todayISO());
      setExercises(sessionToLiveExercises(session));
    } catch {
      setExercises(templateToLiveExercises(template));
    }

    setCurrentStep(0);
    setPhase('active');
    setSessionStart(new Date());
    setElapsed(0);
  }, []);

  // ── Set mutation handlers ──────────────────────────────────────────────────
  const handleUpdateSet = useCallback(
    (exerciseIdx: number, setIdx: number, field: keyof LiveSet, value: any) => {
      setExercises((prev) => {
        const next = [...prev];
        const ex = { ...next[exerciseIdx] };
        const sets = [...ex.sets];
        sets[setIdx] = { ...sets[setIdx], [field]: value };
        ex.sets = sets;
        next[exerciseIdx] = ex;
        return next;
      });
    },
    [],
  );

  const handleLogSet = useCallback((exerciseIdx: number, setIdx: number) => {
    setExercises((prev) => {
      const next = [...prev];
      const ex = { ...next[exerciseIdx] };
      const sets = [...ex.sets];
      const set = { ...sets[setIdx] };

      if (set.logged) {
        // Un-log
        set.logged = false;
      } else {
        if (!set.weight || !set.reps || !set.rpe) {
          Alert.alert('Datos incompletos', 'Debes ingresar el peso, las repeticiones y el RPE para registrar la serie.');
          return prev;
        }
        set.logged = true;

        // Auto-Fill Inteligente: Copiar peso y reps a la siguiente serie
        if (setIdx + 1 < sets.length) {
          const nextSet = { ...sets[setIdx + 1] };
          if (!nextSet.weight && !nextSet.reps && !nextSet.logged) {
            nextSet.weight = set.weight;
            nextSet.reps = set.reps;
            sets[setIdx + 1] = nextSet;
          }
        }
      }

      sets[setIdx] = set;
      ex.sets = sets;
      next[exerciseIdx] = ex;
      return next;
    });
  }, []);

  const handleAddSet = useCallback((exerciseIdx: number) => {
    setExercises((prev) => {
      const next = [...prev];
      const ex = { ...next[exerciseIdx] };
      const newSetNumber = ex.sets.length + 1;
      ex.sets = [...ex.sets, {
        set_number: newSetNumber,
        weight: '',
        reps: '',
        rpe: '1',
        is_warmup: false,
        is_failure: false,
        logged: false,
      }];
      next[exerciseIdx] = ex;
      return next;
    });
  }, []);

  const handleToggleCollapse = useCallback((exerciseIdx: number) => {
    setExercises((prev) => {
      const next = [...prev];
      next[exerciseIdx] = { ...next[exerciseIdx], collapsed: !next[exerciseIdx].collapsed };
      return next;
    });
  }, []);

  // ── Stats derived from live state ──────────────────────────────────────────
  const totalLogged = useMemo(() => loggedSetsCount(exercises), [exercises]);
  const totalSets = useMemo(() => exercises.reduce((n, ex) => n + ex.sets.length, 0), [exercises]);
  const volumeKg = useMemo(() => computeVolumeKg(exercises), [exercises]);

  // ── Submit session — Critical Flow #1 ────────────────────────────────────
  const handleFinishSession = useCallback(async () => {
    if (totalLogged === 0) {
      Alert.alert('Sin series', 'Registra al menos una serie antes de finalizar.');
      return;
    }

    Alert.alert(
      'Finalizar sesión',
      `¿Finalizar con ${totalLogged} series y ${volumeKg.toFixed(1)} kg de tonelaje?`,
      [
        { text: 'Cancelar', style: 'cancel' },
        {
          text: 'Finalizar',
          style: 'default',
          onPress: async () => {
            setSubmitting(true);
            try {
              if (sessionId) {
                // Flow for completing an already existing pending session
                const flatSets: any[] = [];
                exercises.forEach(ex => {
                  ex.sets.filter(s => s.logged && s.id).forEach(s => {
                    flatSets.push({
                      id: s.id,
                      reps: parseInt(s.reps, 10) || 0,
                      weight: parseFloat(s.weight) || 0,
                      rpe: s.rpe ? parseFloat(s.rpe) : undefined,
                    });
                  });
                });
                
                await completeSession(
                  sessionId,
                  overallRpe ? parseFloat(overallRpe) : undefined,
                  flatSets
                );
              } else {
                // Flow for creating a new session from scratch
                const exercisesPayload: SessionExerciseCreate[] = exercises
                  .filter((ex) => ex.sets.some((s) => s.logged))
                  .map((ex, eIdx) => ({
                    exercise_id: ex.exercise_id,
                    order_index: ex.order_index,
                    superset_group: ex.superset_group,
                    notes: ex.notes,
                    sets: ex.sets
                      .filter((s) => s.logged)
                      .map((s): ExerciseSetCreate => ({
                        set_number: s.set_number,
                        weight: parseFloat(s.weight) || 0,
                        reps: parseInt(s.reps, 10) || 0,
                        weight_unit: 'kg',
                        rpe: s.rpe ? parseFloat(s.rpe) : undefined,
                        is_warmup: s.is_warmup,
                        is_failure: s.is_failure,
                      })),
                  }));

                await createTrainingSession({
                  name: sessionName || `Sesión ${todayISO()}`,
                  scheduled_date: todayISO(),
                  status: 'completed',
                  exercises: exercisesPayload,
                  perceived_effort: overallRpe ? parseFloat(overallRpe) : undefined,
                  template_id: selectedTemplate?.id,
                  member_notes: memberNotes || undefined,
                });
              }

              setPhase('finish');
              // Refresh fatigue after completing session
              loadFatigue();
            } catch (err: any) {
              const msg =
                err?.response?.data?.detail?.message ??
                err?.response?.data?.detail ??
                'Error al guardar la sesión. Intenta de nuevo.';
              Alert.alert('Error', msg);
            } finally {
              setSubmitting(false);
            }
          },
        },
      ],
    );
  }, [exercises, totalLogged, volumeKg, sessionName, overallRpe, memberNotes, selectedTemplate, sessionId]);

  // ─────────────────────────────────────────────────────────────────────────
  // RENDER
  // ─────────────────────────────────────────────────────────────────────────

  // ── Phase: FINISH ──────────────────────────────────────────────────────────
  if (phase === 'finish') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor={C.bgBase} />
        <View style={styles.finishContainer}>
          <View style={styles.finishIcon}>
            <Ionicons name="trophy" size={64} color={C.warning} />
          </View>
          <Text style={styles.finishTitle}>¡Sesión Completada!</Text>
          <Text style={styles.finishSub}>{sessionName}</Text>

          <View style={styles.finishStats}>
            <View style={styles.finishStatItem}>
              <Text style={styles.finishStatValue}>{totalLogged}</Text>
              <Text style={styles.finishStatLabel}>Series</Text>
            </View>
            <View style={styles.finishStatDivider} />
            <View style={styles.finishStatItem}>
              <Text style={styles.finishStatValue}>{volumeKg.toFixed(0)}</Text>
              <Text style={styles.finishStatLabel}>kg tonelaje</Text>
            </View>
            <View style={styles.finishStatDivider} />
            <View style={styles.finishStatItem}>
              <Text style={styles.finishStatValue}>{formatElapsed(elapsed)}</Text>
              <Text style={styles.finishStatLabel}>Duración</Text>
            </View>
          </View>

          {fatigue?.deload_recommended && (
            <View style={[styles.finishDeloadAlert, { borderColor: FATIGUE_CONFIG[fatigue.fatigue_level].border }]}>
              <Ionicons name="warning" size={16} color={FATIGUE_CONFIG[fatigue.fatigue_level].color} />
              <Text style={[styles.finishDeloadText, { color: FATIGUE_CONFIG[fatigue.fatigue_level].color }]}>
                Tu modelo de fatiga recomienda una semana de descarga.
              </Text>
            </View>
          )}

          <TouchableOpacity
            style={styles.primaryBtn}
            onPress={() => {
              setPhase('select');
              setExercises([]);
              setSelectedTemplate(null);
              setSessionName('');
              setMemberNotes('');
              setOverallRpe('');
              setElapsed(0);
            }}
          >
            <Ionicons name="refresh" size={18} color={C.bgBase} style={{ marginRight: 8 }} />
            <Text style={styles.primaryBtnText}>Nueva Sesión</Text>
          </TouchableOpacity>
        </View>
      </SafeAreaView>
    );
  }

  // ── Phase: SELECT TEMPLATE ─────────────────────────────────────────────────
  if (phase === 'select') {
    return (
      <SafeAreaView style={styles.container}>
        <StatusBar barStyle="light-content" backgroundColor={C.bgBase} />
        <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>
          <ScrollView
            style={{ flex: 1 }}
            contentContainerStyle={styles.scrollContent}
            refreshControl={<RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={C.primary} />}
          >
            {/* Header */}
            <View style={styles.pageHeader}>
              <View>
                <Text style={styles.greeting}>
                  ¡Hola, {user?.first_name ?? 'Atleta'}!
                </Text>
                <Text style={styles.pageTitle}>Sesión de Hoy</Text>
                <Text style={styles.pageSubtitle}>
                  {new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long' })}
                </Text>
              </View>
            </View>

            {/* Fatigue card */}
            <FatigueCard fatigue={fatigue} loading={loadingFatigue} />

            {/* Template selection */}
            <Text style={styles.sectionTitle}>Selecciona una Rutina</Text>

            {loadingTemplates ? (
              <View style={styles.loadingBox}>
                <ActivityIndicator color={C.primary} size="large" />
                <Text style={[styles.mutedText, { marginTop: 12 }]}>Cargando rutinas...</Text>
              </View>
            ) : templates.length === 0 ? (
              <View style={styles.emptyBox}>
                <Ionicons name="barbell-outline" size={48} color={C.border} />
                <Text style={[styles.mutedText, { marginTop: 12, textAlign: 'center' }]}>
                  Tu entrenador aún no ha asignado rutinas.
                </Text>
              </View>
            ) : (
              templates.map((tpl) => (
                <TouchableOpacity
                  key={tpl.id}
                  style={styles.templateCard}
                  onPress={() => handleSelectTemplate(tpl)}
                  activeOpacity={0.85}
                  accessibilityRole="button"
                  accessibilityLabel={`Seleccionar rutina ${tpl.name}`}
                >
                  <View style={styles.templateCardInner}>
                    <View style={[styles.templateGoalBadge]}>
                      <MaterialCommunityIcons name="dumbbell" size={18} color={C.primary} />
                    </View>
                    <View style={{ flex: 1, marginLeft: 14 }}>
                      <Text style={styles.templateName}>{tpl.name}</Text>
                      {tpl.description && (
                        <Text style={styles.templateDesc} numberOfLines={1}>{tpl.description}</Text>
                      )}
                      <View style={styles.templateMeta}>
                        <Text style={styles.templateMetaTag}>{tpl.goal}</Text>
                        <Text style={styles.templateMetaTag}>{tpl.difficulty}</Text>
                        {tpl.estimated_duration_min && (
                          <Text style={styles.templateMetaTag}>~{tpl.estimated_duration_min} min</Text>
                        )}
                      </View>
                    </View>
                    <Ionicons name="play-circle" size={28} color={C.primary} />
                  </View>
                </TouchableOpacity>
              ))
            )}
          </ScrollView>
        </KeyboardAvoidingView>
      </SafeAreaView>
    );
  }

  // ── Phase: ACTIVE SESSION ──────────────────────────────────────────────────
  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="light-content" backgroundColor={C.bgBase} />
      <KeyboardAvoidingView behavior={Platform.OS === 'ios' ? 'padding' : undefined} style={{ flex: 1 }}>

        {/* Session top bar */}
        <View style={styles.sessionTopBar}>
          <TouchableOpacity
            onPress={() => {
              Alert.alert('Abandonar sesión', '¿Seguro? Perderás el progreso actual.', [
                { text: 'Continuar', style: 'cancel' },
                { 
                  text: 'Abandonar', 
                  style: 'destructive', 
                  onPress: async () => { 
                    if (sessionId) {
                      try {
                        await deleteSession(sessionId);
                      } catch (err: any) {
                        if (err.response?.status === 403) {
                          Alert.alert('Aviso', 'No tienes permiso para eliminar esta sesión asignada por el coach. Quedará en estado pendiente.');
                        } else {
                          console.log('Error deleting session:', err);
                        }
                      }
                    }
                    setPhase('select'); 
                    setExercises([]); 
                  } 
                },
              ]);
            }}
            style={styles.backBtn}
            accessibilityLabel="Volver"
          >
            <Ionicons name="arrow-back" size={20} color={C.textMuted} />
          </TouchableOpacity>

          <View style={styles.sessionTopCenter}>
            <Text style={styles.sessionTopName} numberOfLines={1}>{sessionName}</Text>
            <View style={styles.timerRow}>
              <Ionicons name="time-outline" size={12} color={C.primary} />
              <Text style={[styles.timerText, { color: C.primary }]}>{formatElapsed(elapsed)}</Text>
            </View>
          </View>

          {/* Live stats pill */}
          <View style={styles.liveStatsPill}>
            <Text style={styles.liveStatsText}>
              {totalLogged}/{totalSets} · {volumeKg.toFixed(0)} kg
            </Text>
          </View>
        </View>

        {/* Progress bar across top */}
        <View style={styles.sessionProgressBar}>
          <View
            style={[
              styles.sessionProgressFill,
              { width: `${totalSets > 0 ? (totalLogged / totalSets) * 100 : 0}%` as any },
            ]}
          />
        </View>

        <ScrollView
          style={{ flex: 1 }}
          contentContainerStyle={styles.scrollContent}
          keyboardShouldPersistTaps="handled"
        >
          

          {/* Exercises */}
          
          {/* Exercises Stepper */}
          {currentStep < exercises.length ? (
            <ExerciseCard
              key={`${exercises[currentStep].exercise_id}-${currentStep}`}
              exercise={exercises[currentStep]}
              exerciseIdx={currentStep}
              onAddSet={handleAddSet}
              onUpdateSet={handleUpdateSet}
              onLogSet={(eIdx, sIdx) => {
                handleLogSet(eIdx, sIdx);
                // Auto-start rest timer based on exercise config
                const rest = exercises[currentStep]?.rest_seconds || 90;
                setRestRemaining(rest);
              }}
              onStartRest={handleStartRest}
            />
          ) : (
            <View style={styles.feedbackContainer}>
              <View style={{ alignItems: 'center', marginBottom: 20 }}>
                <MaterialCommunityIcons name="check-decagram" size={64} color={C.success} />
                <Text style={{ fontSize: 24, fontWeight: 'bold', color: C.textMain, marginTop: 12 }}>¡Rutina Completada!</Text>
                <Text style={{ color: C.textMuted, textAlign: 'center', marginTop: 8 }}>Has terminado todos los ejercicios. Cuéntanos cómo te pareció la sesión.</Text>
              </View>
              
              <View style={styles.cardSection}>
                <Text style={styles.sectionTitle}>RPE Global (Esfuerzo Percibido)</Text>
                <Text style={styles.mutedText}>
                  ¿Qué tan dura fue la sesión en general del 1 al 10?
                </Text>
                <View style={{ flexDirection: 'row', flexWrap: 'wrap', gap: 8, marginTop: 12 }}>
                  {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((val) => (
                    <TouchableOpacity
                      key={`overall-${val}`}
                      style={[
                        styles.rpeButton,
                        overallRpe === String(val) && { backgroundColor: C.primary, borderColor: C.primary },
                      ]}
                      onPress={() => setOverallRpe(String(val))}
                    >
                      <Text style={[styles.rpeText, overallRpe === String(val) && { color: C.bgBase }]}>
                        {val}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>
              <View style={styles.cardSection}>
                <Text style={styles.sectionTitle}>Notas para tu entrenador</Text>
                <TextInput
                  style={styles.textArea}
                  placeholder="Ej: Me dolió un poco el hombro..."
                  placeholderTextColor={C.textMuted}
                  multiline
                  value={memberNotes}
                  onChangeText={setMemberNotes}
                />
              </View>
              
              <TouchableOpacity
                style={[styles.finishButton, { marginTop: 12 }]}
                onPress={handleFinishSession}
                disabled={submitting}
              >
                {submitting ? (
                  <ActivityIndicator color={C.bgBase} />
                ) : (
                  <>
                    <Ionicons name="checkmark-done" size={20} color={C.bgBase} />
                    <Text style={styles.finishButtonText}>Finalizar y Guardar Sesión</Text>
                  </>
                )}
              </TouchableOpacity>
            </View>
          )}

          {/* Stepper Navigation */}
          {currentStep < exercises.length && (
            <View style={{ flexDirection: 'row', justifyContent: 'space-between', paddingHorizontal: 16, marginTop: 24, marginBottom: 40, gap: 12 }}>
              <TouchableOpacity 
                style={{ flex: 1, paddingVertical: 14, backgroundColor: C.border, borderRadius: 12, alignItems: 'center' }}
                onPress={() => setCurrentStep(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
              >
                <Text style={{ color: currentStep === 0 ? C.borderLight : C.textMain, fontWeight: '600' }}>Anterior</Text>
              </TouchableOpacity>
              
              <TouchableOpacity 
                style={{ flex: 1, paddingVertical: 14, backgroundColor: canGoNext ? C.primary : C.primary + '40', borderRadius: 12, alignItems: 'center' }}
                onPress={() => setCurrentStep(currentStep + 1)}
                disabled={!canGoNext}
              >
                <Text style={{ color: canGoNext ? C.bgBase : C.bgBase + '90', fontWeight: 'bold' }}>Siguiente</Text>
              </TouchableOpacity>
            </View>
          )}

          {/* Rest Timer Overlay */}
          {restRemaining > 0 && (
            <View style={{ position: 'absolute', bottom: 100, alignSelf: 'center', backgroundColor: C.primary, paddingHorizontal: 24, paddingVertical: 12, borderRadius: 30, flexDirection: 'row', alignItems: 'center', elevation: 10, shadowColor: C.primary, shadowOffset: { width: 0, height: 4 }, shadowOpacity: 0.4, shadowRadius: 10 }}>
              <MaterialCommunityIcons name="timer" size={24} color={C.bgBase} />
              <Text style={{ color: C.bgBase, fontWeight: '900', fontSize: 18, marginLeft: 8 }}>
                {Math.floor(restRemaining / 60)}:{(restRemaining % 60).toString().padStart(2, '0')}
              </Text>
              <TouchableOpacity onPress={() => setRestRemaining(0)} style={{ marginLeft: 16, padding: 4, backgroundColor: 'rgba(0,0,0,0.1)', borderRadius: 12 }}>
                <Ionicons name="close" size={16} color={C.bgBase} />
              </TouchableOpacity>
            </View>
          )}


          
        </ScrollView>
      </KeyboardAvoidingView>
    </SafeAreaView>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  cardSection: {
    paddingVertical: 12,
    borderBottomWidth: 1,
    borderBottomColor: C.borderLight,
  },
  rpeButton: {
    width: 44,
    height: 44,
    borderRadius: 22,
    borderWidth: 1,
    borderColor: C.borderLight,
    justifyContent: 'center',
    alignItems: 'center',
    backgroundColor: C.bgPanelHover,
  },
  rpeText: {
    color: C.textMain,
    fontWeight: 'bold',
    fontSize: 16,
  },
  textArea: {
    backgroundColor: C.bgBase,
    borderColor: C.borderLight,
    borderWidth: 1,
    borderRadius: 8,
    padding: 12,
    color: C.textMain,
    minHeight: 100,
    marginTop: 8,
    textAlignVertical: 'top',
  },
  finishButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.success,
    paddingVertical: 16,
    borderRadius: 12,
    gap: 8,
  },
  finishButtonText: {
    color: C.bgBase,
    fontWeight: 'bold',
    fontSize: 18,
  },
  feedbackContainer: { padding: 16, backgroundColor: C.bgPanel, margin: 16, borderRadius: 16, borderWidth: 1, borderColor: C.borderLight },
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  scrollContent: {
    paddingHorizontal: 16,
    paddingBottom: 32,
  },

  // ── Typography ──────────────────────────────────────────────────────────────
  greeting: {
    fontSize: 14,
    color: C.textMuted,
    marginBottom: 2,
  },
  pageTitle: {
    fontSize: 26,
    fontWeight: '800',
    color: C.textMain,
    letterSpacing: -0.5,
  },
  pageSubtitle: {
    fontSize: 13,
    color: C.textMuted,
    marginTop: 2,
    textTransform: 'capitalize',
  },
  sectionTitle: {
    fontSize: 13,
    fontWeight: '700',
    color: C.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 1,
    marginVertical: 14,
  },
  mutedText: {
    fontSize: 13,
    color: C.textMuted,
  },

  // ── Layout ──────────────────────────────────────────────────────────────────
  pageHeader: {
    marginTop: 12,
    marginBottom: 16,
  },
  loadingBox: {
    alignItems: 'center',
    paddingVertical: 48,
  },
  emptyBox: {
    alignItems: 'center',
    paddingVertical: 48,
  },

  // ── Fatigue Card ────────────────────────────────────────────────────────────
  fatigueCard: {
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 14,
    marginBottom: 4,
    backgroundColor: C.bgPanel,
  },
  fatigueHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
  fatigueHeaderLeft: {
    flexDirection: 'row',
    alignItems: 'center',
    flex: 1,
  },
  fatigueHeaderRight: {
    flexDirection: 'row',
    alignItems: 'center',
  },
  fatigueLabel: {
    fontSize: 14,
    fontWeight: '700',
  },
  fatigueDetail: {
    marginTop: 14,
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: C.border,
  },
  fatigueDetailGrid: {
    flexDirection: 'row',
    justifyContent: 'space-around',
  },
  fatigueStatItem: {
    alignItems: 'center',
  },
  fatigueStatValue: {
    fontSize: 16,
    fontWeight: '800',
    color: C.textMain,
  },
  fatigueStatLabel: {
    fontSize: 11,
    color: C.textMuted,
    marginTop: 2,
  },
  deloadBadge: {
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 20,
    borderWidth: 1,
  },
  deloadBadgeText: {
    fontSize: 11,
    fontWeight: '700',
  },
  deloadReason: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    marginTop: 10,
    gap: 6,
  },
  deloadReasonText: {
    fontSize: 12,
    flex: 1,
    lineHeight: 17,
  },

  // ── Gauge ───────────────────────────────────────────────────────────────────
  gaugeTrack: {
    height: 5,
    borderRadius: 3,
    backgroundColor: C.border,
    overflow: 'hidden',
  },
  gaugeFill: {
    height: '100%',
    borderRadius: 3,
  },

  // ── Template Cards ──────────────────────────────────────────────────────────
  templateCard: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    marginBottom: 10,
    overflow: 'hidden',
  },
  templateCardInner: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 16,
  },
  templateGoalBadge: {
    width: 44,
    height: 44,
    borderRadius: 12,
    backgroundColor: C.primary + '15',
    borderWidth: 1,
    borderColor: C.primary + '30',
    alignItems: 'center',
    justifyContent: 'center',
  },
  templateName: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textMain,
    marginBottom: 3,
  },
  templateDesc: {
    fontSize: 12,
    color: C.textMuted,
    marginBottom: 6,
  },
  templateMeta: {
    flexDirection: 'row',
    gap: 6,
    flexWrap: 'wrap',
  },
  templateMetaTag: {
    fontSize: 10,
    color: C.primary,
    backgroundColor: C.primary + '15',
    borderColor: C.primary + '30',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 2,
    textTransform: 'capitalize',
    fontWeight: '600',
  },

  // ── Session Top Bar ─────────────────────────────────────────────────────────
  sessionTopBar: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingVertical: 12,
    backgroundColor: C.bgPanel,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  backBtn: {
    padding: 4,
  },
  sessionTopCenter: {
    flex: 1,
    marginHorizontal: 12,
    alignItems: 'center',
  },
  sessionTopName: {
    fontSize: 14,
    fontWeight: '700',
    color: C.textMain,
  },
  timerRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 2,
  },
  timerText: {
    fontSize: 12,
    fontWeight: '600',
    fontVariant: ['tabular-nums'],
  },
  liveStatsPill: {
    backgroundColor: C.primary + '15',
    borderColor: C.primary + '30',
    borderWidth: 1,
    borderRadius: 20,
    paddingHorizontal: 10,
    paddingVertical: 4,
  },
  liveStatsText: {
    fontSize: 11,
    color: C.primary,
    fontWeight: '700',
  },
  sessionProgressBar: {
    height: 3,
    backgroundColor: C.border,
  },
  sessionProgressFill: {
    height: '100%',
    backgroundColor: C.primary,
  },

  // ── Exercise Card ───────────────────────────────────────────────────────────
  exerciseCard: {
    backgroundColor: 'rgba(30, 41, 59, 0.7)',
    borderRadius: 24,
    borderWidth: 1,
    borderColor: 'rgba(255, 255, 255, 0.05)',
    marginBottom: 16,
    overflow: 'hidden',
  },
  exerciseHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: 14,
  },
  exerciseCategoryDot: {
    width: 10,
    height: 10,
    borderRadius: 5,
  },
  exerciseName: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textMain,
  },
  exerciseMeta: {
    fontSize: 12,
    color: C.textMuted,
    marginTop: 2,
  },
  exerciseProgressPill: {
    backgroundColor: C.bgPanelHover,
    borderRadius: 20,
    paddingHorizontal: 8,
    paddingVertical: 3,
  },
  exerciseProgressText: {
    fontSize: 12,
    color: C.textMuted,
    fontWeight: '700',
  },
  exerciseProgressBar: {
    height: 3,
    backgroundColor: C.border,
    marginHorizontal: 14,
    marginBottom: 0,
    borderRadius: 2,
    overflow: 'hidden',
  },
  exerciseProgressFill: {
    height: '100%',
    borderRadius: 2,
  },
  exerciseNotes: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    paddingHorizontal: 14,
    paddingBottom: 12,
    marginTop: 4,
  },

  // ── Sets ────────────────────────────────────────────────────────────────────
  setsContainer: {
    paddingHorizontal: 10,
    paddingTop: 10,
    paddingBottom: 10,
  },
  setHeaders: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingHorizontal: 4,
    marginBottom: 6,
  },
  setHeaderText: {
    flex: 1,
    fontSize: 10,
    fontWeight: '700',
    color: C.textMuted,
    textTransform: 'uppercase',
    letterSpacing: 0.5,
  },
  setRow: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 10,
    borderWidth: 1,
    paddingVertical: 7,
    paddingHorizontal: 4,
    marginBottom: 5,
  },
  setNumber: {
    flex: 0.4,
    alignItems: 'center',
  },
  setNumberText: {
    fontSize: 13,
    fontWeight: '800',
    color: C.textMuted,
  },
  setInputWrapper: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.bgBase,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: C.border,
    marginHorizontal: 3,
    paddingHorizontal: 6,
    paddingVertical: 5,
  },
  setInput: {
    flex: 1,
    color: C.textMain,
    fontSize: 14,
    fontWeight: '600',
    padding: 0,
    fontVariant: ['tabular-nums'],
  },
  setInputLogged: {
    color: C.success,
  },
  setInputUnit: {
    fontSize: 10,
    color: C.textMuted,
    marginLeft: 2,
  },
  setSeparator: {
    color: C.textMuted,
    fontSize: 12,
    marginHorizontal: 2,
  },
  failureToggle: {
    flex: 0.5,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 6,
    marginHorizontal: 2,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: 'transparent',
  },
  logButton: {
    flex: 0.7,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 4,
    borderRadius: 10,
    borderWidth: 1,
  },
  addSetBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    paddingVertical: 8,
    marginTop: 2,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: C.primary + '30',
    borderStyle: 'dashed',
    gap: 6,
  },
  addSetText: {
    fontSize: 13,
    fontWeight: '600',
  },

  // ── Session Footer ──────────────────────────────────────────────────────────
  sessionFooter: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 16,
    marginTop: 6,
    marginBottom: 12,
  },
  notesInput: {
    height: 80,
    textAlignVertical: 'top',
    paddingTop: 8,
  },

  // ── Buttons ─────────────────────────────────────────────────────────────────
  primaryBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: C.primary,
    borderRadius: 14,
    paddingVertical: 14,
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.35,
    shadowRadius: 12,
    elevation: 6,
  },
  finishBtn: {
    marginTop: 8,
  },
  primaryBtnText: {
    fontSize: 15,
    fontWeight: '800',
    color: C.bgBase,
    letterSpacing: 0.3,
  },

  // ── Finish Screen ───────────────────────────────────────────────────────────
  finishContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  finishIcon: {
    width: 100,
    height: 100,
    borderRadius: 50,
    backgroundColor: C.warning + '15',
    borderWidth: 2,
    borderColor: C.warning + '30',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    shadowColor: C.warning,
    shadowOffset: { width: 0, height: 0 },
    shadowOpacity: 0.4,
    shadowRadius: 20,
  },
  finishTitle: {
    fontSize: 28,
    fontWeight: '900',
    color: C.textMain,
    textAlign: 'center',
    letterSpacing: -0.5,
  },
  finishSub: {
    fontSize: 15,
    color: C.textMuted,
    textAlign: 'center',
    marginTop: 6,
    marginBottom: 28,
  },
  finishStats: {
    flexDirection: 'row',
    alignItems: 'center',
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 20,
    width: '100%',
    marginBottom: 20,
    justifyContent: 'space-around',
  },
  finishStatItem: {
    alignItems: 'center',
  },
  finishStatValue: {
    fontSize: 22,
    fontWeight: '900',
    color: C.textMain,
    fontVariant: ['tabular-nums'],
  },
  finishStatLabel: {
    fontSize: 12,
    color: C.textMuted,
    marginTop: 3,
  },
  finishStatDivider: {
    width: 1,
    height: 36,
    backgroundColor: C.border,
  },
  finishDeloadAlert: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    backgroundColor: C.bgPanel,
    borderRadius: 12,
    borderWidth: 1,
    padding: 12,
    width: '100%',
    marginBottom: 20,
    gap: 8,
  },
  finishDeloadText: {
    flex: 1,
    fontSize: 13,
    lineHeight: 18,
  },
});

export default TrainingSessionScreen;

