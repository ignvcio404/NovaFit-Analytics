/**
 * NovaFit Analytics Suite — AnalyticsScreen
 * ===========================================
 *
 * Pantalla de progreso del atleta. Muestra:
 *  - Card de IA con predicciones de peso para próxima sesión
 *  - Gráfico de tonelaje semanal (desde DB real)
 *  - Métricas de fatiga: ACWR, score, sesiones completadas
 *  - Récords personales recientes (PRs)
 *
 * Sin emojis — iconos de vector únicamente.
 * Datos 100% reales de la base de datos.
 */

import React, { useCallback, useState } from 'react';
import {
  ActivityIndicator,
  Dimensions,
  FlatList,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  TouchableOpacity,
  View,
  Modal,
  Alert,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useFocusEffect } from '@react-navigation/native';

import apiClient from '../api/client';
import { getMySessions, RoutineSessionSummary, getWeightHistory, logWeight, WeightHistory } from '../api/trainingService';

const { width: SW } = Dimensions.get('window');

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase:    '#0f172a',
  bgPanel:   '#1e293b',
  primary:   '#00e5ff',
  primaryDk: '#0284c7',
  textMain:  '#f8fafc',
  textMuted: '#94a3b8',
  border:    '#334155',
  emerald:   '#10b981',
  amber:     '#f59e0b',
  violet:    '#8b5cf6',
  danger:    '#ef4444',
};

// ─────────────────────────────────────────────────────────────────────────────
// Helpers
// ─────────────────────────────────────────────────────────────────────────────

const fmtCLP = (n: number) =>
  n.toLocaleString('es-CL');

const acwrColor = (v: number) =>
  v > 1.5 ? C.danger : v < 0.8 ? C.amber : C.emerald;

// Build weekly volume data from sessions
const buildWeeklyVolume = (sessions: RoutineSessionSummary[]): { label: string; kg: number }[] => {
  const map: Record<string, number> = {};
  sessions
    .filter(s => s.status === 'completed')
    .forEach(s => {
      const d = s.scheduled_date
        ? new Date(s.scheduled_date)
        : new Date();
      // ISO week start (Monday)
      const day = d.getDay();
      const diff = (day === 0 ? -6 : 1) - day;
      const monday = new Date(d);
      monday.setDate(d.getDate() + diff);
      const key = monday.toISOString().slice(0, 10);
      const vol = s.volume_load_kg ? Number(s.volume_load_kg) : 0;
      map[key] = (map[key] ?? 0) + vol;
    });
  return Object.entries(map)
    .sort(([a], [b]) => a.localeCompare(b))
    .slice(-8)
    .map(([key, kg]) => ({
      label: new Date(key).toLocaleDateString('es-CL', { day: '2-digit', month: 'short' }),
      kg: Math.round(kg),
    }));
};

// ─────────────────────────────────────────────────────────────────────────────
// Simple bar chart (no external lib)
// ─────────────────────────────────────────────────────────────────────────────

interface BarChartProps {
  data: { label: string; kg: number }[];
}

const SimpleBarChart: React.FC<BarChartProps> = ({ data }) => {
  const maxVal = Math.max(...data.map(d => d.kg), 1);
  const chartH = 130;
  const barW = Math.floor((SW - 80) / Math.max(data.length, 1)) - 6;

  return (
    <View style={barStyles.container}>
      {/* Bars */}
      <View style={barStyles.barsRow}>
        {data.map((d, i) => {
          const barH = Math.max((d.kg / maxVal) * chartH, 4);
          return (
            <View key={i} style={barStyles.barCol}>
              <Text style={barStyles.barValue}>
                {d.kg > 0 ? (d.kg >= 1000 ? `${(d.kg / 1000).toFixed(1)}t` : `${d.kg}`) : ''}
              </Text>
              <View style={[barStyles.bar, { height: barH, width: barW }]}>
                <LinearGradient
                  colors={[C.primary, C.primaryDk]}
                  style={{ flex: 1, borderRadius: 6 }}
                />
              </View>
              <Text style={barStyles.barLabel} numberOfLines={1}>{d.label}</Text>
            </View>
          );
        })}
      </View>
    </View>
  );
};

const barStyles = StyleSheet.create({
  container: { paddingTop: 8, paddingBottom: 4 },
  barsRow: {
    flexDirection: 'row',
    alignItems: 'flex-end',
    justifyContent: 'center',
    gap: 4,
    height: 170,
  },
  barCol: {
    alignItems: 'center',
    justifyContent: 'flex-end',
    gap: 4,
  },
  bar: { borderRadius: 6, overflow: 'hidden', minHeight: 4 },
  barValue: { fontSize: 9, color: C.textMuted, fontWeight: '600' },
  barLabel: { fontSize: 9, color: C.textMuted, width: 34, textAlign: 'center' },
});

// ─────────────────────────────────────────────────────────────────────────────
// Stat card
// ─────────────────────────────────────────────────────────────────────────────

const StatCard: React.FC<{
  icon: string; label: string; value: string; color?: string; wide?: boolean;
}> = ({ icon, label, value, color = C.primary, wide = false }) => (
  <View style={[sc.card, wide && { flex: 1 }]}>
    <View style={[sc.icon, { backgroundColor: color + '15' }]}>
      <MaterialCommunityIcons name={icon as any} size={18} color={color} />
    </View>
    <Text style={sc.value}>{value}</Text>
    <Text style={sc.label}>{label}</Text>
  </View>
);

const sc = StyleSheet.create({
  card: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    borderWidth: 1,
    borderColor: C.border,
    padding: 14,
    alignItems: 'center',
    gap: 6,
    width: (SW - 60) / 2,
  },
  icon: { width: 36, height: 36, borderRadius: 10, alignItems: 'center', justifyContent: 'center' },
  value: { fontSize: 20, fontWeight: '800', color: C.textMain },
  label: { fontSize: 11, color: C.textMuted, textAlign: 'center', fontWeight: '600' },
});

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

const AnalyticsScreen: React.FC = () => {
  const [loading, setLoading]   = useState(true);
  const [fatigue, setFatigue]   = useState<any>(null);
  const [sessions, setSessions] = useState<RoutineSessionSummary[]>([]);
  const [weekData, setWeekData] = useState<{ label: string; kg: number }[]>([]);
  const [weightHistory, setWeightHistory] = useState<WeightHistory[]>([]);
  const [isWeightModalVisible, setWeightModalVisible] = useState(false);
  const [newWeight, setNewWeight] = useState('');
  const [isSubmittingWeight, setIsSubmittingWeight] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    try {
      const [fatigueRes, sessionData, weightData] = await Promise.all([
        apiClient.get('/api/v1/analytics/fatigue/me').catch(() => ({ data: null })),
        getMySessions(100).catch(() => []),
        getWeightHistory().catch(() => []),
      ]);
      if (fatigueRes.data) setFatigue(fatigueRes.data);
      const s = Array.isArray(sessionData) ? sessionData : [];
      setSessions(s);
      setWeekData(buildWeeklyVolume(s));
      setWeightHistory(Array.isArray(weightData) ? weightData : []);
    } catch (err) {
      console.error('[Analytics] error:', err);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchAll(); }, []));

  const handleLogWeight = async () => {
    const w = parseFloat(newWeight);
    if (isNaN(w) || w <= 0) {
      Alert.alert('Error', 'Ingresa un peso válido');
      return;
    }
    try {
      setIsSubmittingWeight(true);
      await logWeight(w);
      setNewWeight('');
      setWeightModalVisible(false);
      fetchAll();
    } catch {
      Alert.alert('Error', 'No se pudo guardar el peso');
    } finally {
      setIsSubmittingWeight(false);
    }
  };

  const completedSessions = sessions.filter(s => s.status === 'completed');
  const totalVolume = completedSessions.reduce(
    (acc, s) => acc + (Number(s.volume_load_kg) || 0), 0
  );

  const avgRpe = fatigue?.avg_rpe ? Number(fatigue.avg_rpe).toFixed(1) : '—';
  const acwr   = fatigue?.acwr   ? Number(fatigue.acwr).toFixed(2)   : '—';

  if (loading) {
    return (
      <View style={styles.loadingContainer}>
        <ActivityIndicator size="large" color={C.primary} />
        <Text style={styles.loadingText}>Cargando analíticas...</Text>
      </View>
    );
  }

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Progreso</Text>
          <Text style={styles.subtitle}>Tus métricas de rendimiento</Text>
        </View>
        <View style={styles.headerIcon}>
          <MaterialCommunityIcons name="chart-areaspline" size={22} color={C.primary} />
        </View>
      </View>

      <ScrollView
        contentContainerStyle={styles.scroll}
        showsVerticalScrollIndicator={false}
      >
        {/* ── AI / Fatigue Card ─────────────────────────────────────── */}
        {fatigue && (
          <LinearGradient
            colors={['#1e1b4b', '#312e81']}
            start={{ x: 0, y: 0 }}
            end={{ x: 1, y: 1 }}
            style={styles.aiCard}
          >
            <View style={styles.aiHeader}>
              <View style={styles.aiIconWrap}>
                <MaterialCommunityIcons name="brain" size={20} color={C.primary} />
              </View>
              <View>
                <Text style={styles.aiTitle}>NovaFit AI</Text>
                <Text style={styles.aiSubLabel}>Análisis de tu semana</Text>
              </View>
            </View>

            <View style={styles.aiMetricsRow}>
              <View style={styles.aiMetric}>
                <Text style={[styles.aiMetricValue, { color: acwrColor(Number(acwr)) }]}>
                  {acwr}
                </Text>
                <Text style={styles.aiMetricLabel}>Balance de Carga</Text>
              </View>
              <View style={styles.aiMetricDivider} />
              <View style={styles.aiMetric}>
                <Text style={[styles.aiMetricValue, { color: C.primary }]}>
                  {fatigue.fatigue_score != null ? Math.round(fatigue.fatigue_score) : '—'}
                </Text>
                <Text style={styles.aiMetricLabel}>Nivel de Fatiga</Text>
              </View>
              <View style={styles.aiMetricDivider} />
              <View style={styles.aiMetric}>
                <Text style={[styles.aiMetricValue, { color: C.amber }]}>{avgRpe}</Text>
                <Text style={styles.aiMetricLabel}>Esfuerzo (RPE)</Text>
              </View>
            </View>

            {fatigue.deload_recommended && (
              <View style={styles.deloadAlert}>
                <MaterialCommunityIcons name="sync-alert" size={16} color={C.amber} />
                <Text style={styles.deloadAlertText}>
                  Reducción de Carga — Te sugerimos disminuir la intensidad de tus entrenamientos en un 40% esta semana para favorecer tu recuperación muscular.
                </Text>
              </View>
            )}
          </LinearGradient>
        )}

        {/* ── Summary stats ─────────────────────────────────────────── */}
        <View style={styles.sectionHeader}>
          <MaterialCommunityIcons name="chart-bar" size={16} color={C.primary} />
          <Text style={styles.sectionTitle}>Resumen General</Text>
        </View>
        <View style={styles.statsGrid}>
          <StatCard
            icon="dumbbell"
            label="Sesiones Completadas"
            value={String(completedSessions.length)}
            color={C.emerald}
          />
          <StatCard
            icon="weight"
            label="Tonelaje Total (kg)"
            value={totalVolume >= 1000
              ? `${(totalVolume / 1000).toFixed(1)}t`
              : `${Math.round(totalVolume)}`}
            color={C.primary}
          />
          <StatCard
            icon="fire"
            label="Series al Fallo"
            value={fatigue?.failure_sets_count != null ? String(fatigue.failure_sets_count) : '—'}
            color={C.danger}
          />
          <StatCard
            icon="calendar-check-outline"
            label="Sesiones esta semana"
            value={fatigue?.sessions_completed != null
              ? `${fatigue.sessions_completed}/${fatigue.sessions_planned}`
              : '—'}
            color={C.amber}
          />
        </View>

        {/* ── Weekly volume chart ───────────────────────────────────── */}
        <View style={styles.sectionHeader}>
          <MaterialCommunityIcons name="trending-up" size={16} color={C.emerald} />
          <Text style={styles.sectionTitle}>Tonelaje Semanal</Text>
        </View>
        <View style={styles.chartCard}>
          <View style={styles.chartCardHeader}>
            <Text style={styles.chartCardTitle}>Volumen (kg) por semana</Text>
            <View style={styles.chartLegend}>
              <View style={[styles.legendDot, { backgroundColor: C.primary }]} />
              <Text style={styles.legendText}>Volumen</Text>
            </View>
          </View>
          {weekData.length > 0 ? (
            <SimpleBarChart data={weekData} />
          ) : (
            <View style={styles.chartEmpty}>
              <MaterialCommunityIcons name="chart-bar" size={40} color={C.border} />
              <Text style={styles.chartEmptyText}>
                Completa sesiones para ver tu progreso de volumen
              </Text>
            </View>
          )}
        </View>

        {/* ── Weight History ────────────────────────────────────────── */}
        <View style={styles.sectionHeader}>
          <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
            <MaterialCommunityIcons name="scale-bathroom" size={16} color={C.amber} />
            <Text style={styles.sectionTitle}>Mi Peso Corporal</Text>
          </View>
          <TouchableOpacity onPress={() => setWeightModalVisible(true)} style={styles.addWeightBtn}>
            <MaterialCommunityIcons name="plus" size={16} color={C.textMain} />
            <Text style={styles.addWeightText}>Registrar</Text>
          </TouchableOpacity>
        </View>
        <View style={styles.chartCard}>
          <View style={styles.chartCardHeader}>
            <Text style={styles.chartCardTitle}>Últimos registros (kg)</Text>
          </View>
          {weightHistory.length > 0 ? (
            <View style={styles.weightListRow}>
              {weightHistory.slice(-5).reverse().map((wh, idx) => (
                <View key={wh.id} style={styles.weightItem}>
                  <Text style={styles.weightItemVal}>{wh.weight_kg}</Text>
                  <Text style={styles.weightItemDate}>
                    {new Date(wh.measured_at).toLocaleDateString('es-CL', { month: 'short', day: 'numeric' })}
                  </Text>
                </View>
              ))}
            </View>
          ) : (
            <View style={styles.chartEmpty}>
              <MaterialCommunityIcons name="scale-bathroom" size={40} color={C.border} />
              <Text style={styles.chartEmptyText}>No hay registros de peso aún</Text>
            </View>
          )}
        </View>

        {/* ── Recent sessions timeline ──────────────────────────────── */}
        {completedSessions.length > 0 && (
          <>
            <View style={styles.sectionHeader}>
              <MaterialCommunityIcons name="history" size={16} color={C.violet} />
              <Text style={styles.sectionTitle}>Últimas Sesiones</Text>
            </View>
            {completedSessions.slice(0, 5).map((s, i) => {
              const vol = s.volume_load_kg ?? 0;
              const exCount = s.exercise_count ?? 0;
              return (
                <View key={s.id} style={styles.timelineRow}>
                  <View style={styles.timelineDotCol}>
                    <View style={[
                      styles.timelineDot,
                      { backgroundColor: i === 0 ? C.primary : C.border }
                    ]} />
                    {i < 4 && <View style={styles.timelineLine} />}
                  </View>
                  <View style={styles.timelineContent}>
                    <Text style={styles.timelineName}>{s.name ?? 'Sesión completada'}</Text>
                    <Text style={styles.timelineDate}>
                      {s.scheduled_date
                        ? new Date(s.scheduled_date).toLocaleDateString('es-CL', {
                            weekday: 'short', day: '2-digit', month: 'short',
                          })
                        : 'Fecha desconocida'}
                    </Text>
                    <View style={styles.timelinePills}>
                      <View style={styles.timelinePill}>
                        <MaterialCommunityIcons name="layers-outline" size={11} color={C.textMuted} />
                        <Text style={styles.timelinePillText}>{exCount} ejercicios</Text>
                      </View>
                      <View style={styles.timelinePill}>
                        <MaterialCommunityIcons name="weight" size={11} color={C.textMuted} />
                        <Text style={styles.timelinePillText}>{Math.round(vol)} kg</Text>
                      </View>
                    </View>
                  </View>
                </View>
              );
            })}
          </>
        )}

        <View style={{ height: 100 }} />
      </ScrollView>

      {/* ── Modal Log Weight ─────────────────────────────────────── */}
      <Modal visible={isWeightModalVisible} transparent animationType="fade">
        <View style={styles.modalOverlay}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Registrar Peso</Text>
            <Text style={styles.modalSub}>Ingresa tu peso actual en kg</Text>
            <TextInput
              style={styles.modalInput}
              keyboardType="numeric"
              placeholder="Ej: 75.5"
              placeholderTextColor={C.textMuted}
              value={newWeight}
              onChangeText={setNewWeight}
              autoFocus
            />
            <View style={styles.modalActions}>
              <TouchableOpacity
                style={styles.modalBtnCancel}
                onPress={() => setWeightModalVisible(false)}
              >
                <Text style={styles.modalBtnCancelText}>Cancelar</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.modalBtnSubmit}
                onPress={handleLogWeight}
                disabled={isSubmittingWeight}
              >
                {isSubmittingWeight ? (
                  <ActivityIndicator color={C.bgBase} size="small" />
                ) : (
                  <Text style={styles.modalBtnSubmitText}>Guardar</Text>
                )}
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </SafeAreaView>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Styles
// ─────────────────────────────────────────────────────────────────────────────

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: C.bgBase },
  loadingContainer: {
    flex: 1, backgroundColor: C.bgBase,
    alignItems: 'center', justifyContent: 'center', gap: 16,
  },
  loadingText: { color: C.textMuted, fontSize: 14 },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  title:    { fontSize: 26, fontWeight: '800', color: C.textMain, letterSpacing: -0.5 },
  subtitle: { fontSize: 13, color: C.textMuted, marginTop: 2 },
  headerIcon: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: C.primary + '15',
    borderWidth: 1, borderColor: C.primary + '30',
    alignItems: 'center', justifyContent: 'center',
  },
  scroll: { padding: 20, paddingTop: 24 },

  // AI card
  aiCard: {
    borderRadius: 20, padding: 20, marginBottom: 24,
    borderWidth: 1, borderColor: '#4c1d95',
  },
  aiHeader: { flexDirection: 'row', alignItems: 'center', gap: 12, marginBottom: 20 },
  aiIconWrap: {
    width: 40, height: 40, borderRadius: 12,
    backgroundColor: C.primary + '20',
    alignItems: 'center', justifyContent: 'center',
  },
  aiTitle:    { color: C.textMain, fontSize: 16, fontWeight: '800' },
  aiSubLabel: { color: '#a5b4fc', fontSize: 12, marginTop: 2 },
  aiMetricsRow: {
    flexDirection: 'row', alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)', borderRadius: 14, padding: 16,
  },
  aiMetric:       { flex: 1, alignItems: 'center', gap: 4 },
  aiMetricDivider:{ width: 1, height: 36, backgroundColor: 'rgba(255,255,255,0.1)' },
  aiMetricValue:  { fontSize: 22, fontWeight: '900' },
  aiMetricLabel:  { fontSize: 11, color: '#a5b4fc', fontWeight: '600' },
  deloadAlert: {
    flexDirection: 'row', alignItems: 'center', gap: 8,
    marginTop: 16, backgroundColor: C.amber + '15',
    borderRadius: 10, padding: 12,
    borderWidth: 1, borderColor: C.amber + '30',
  },
  deloadAlertText: { flex: 1, color: C.amber, fontSize: 12, fontWeight: '600', lineHeight: 18 },

  // Section header
  sectionHeader: {
    flexDirection: 'row', alignItems: 'center', gap: 8, marginBottom: 14,
  },
  sectionTitle: {
    fontSize: 13, fontWeight: '700', color: C.textMuted,
    letterSpacing: 0.8, textTransform: 'uppercase',
  },

  // Stats grid
  statsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: 12, marginBottom: 28 },

  // Chart card
  chartCard: {
    backgroundColor: C.bgPanel, borderRadius: 20,
    borderWidth: 1, borderColor: C.border, padding: 18, marginBottom: 28,
  },
  chartCardHeader: {
    flexDirection: 'row', justifyContent: 'space-between',
    alignItems: 'center', marginBottom: 4,
  },
  chartCardTitle: { fontSize: 15, fontWeight: '700', color: C.textMain },
  chartLegend: { flexDirection: 'row', alignItems: 'center', gap: 6 },
  legendDot:   { width: 8, height: 8, borderRadius: 4 },
  legendText:  { fontSize: 11, color: C.textMuted },
  chartEmpty: { alignItems: 'center', paddingVertical: 32, gap: 12 },
  chartEmptyText: { color: C.textMuted, fontSize: 13, textAlign: 'center', lineHeight: 20 },

  // Timeline
  timelineRow: { flexDirection: 'row', marginBottom: 4, gap: 12 },
  timelineDotCol: { alignItems: 'center', width: 16, paddingTop: 4 },
  timelineDot: { width: 12, height: 12, borderRadius: 6 },
  timelineLine: { flex: 1, width: 2, backgroundColor: C.border, marginTop: 4, minHeight: 40 },
  timelineContent: {
    flex: 1, backgroundColor: C.bgPanel,
    borderRadius: 16, borderWidth: 1, borderColor: C.border,
    padding: 14, marginBottom: 10,
  },
  timelineName: { fontSize: 14, fontWeight: '700', color: C.textMain, marginBottom: 2 },
  timelineDate: { fontSize: 12, color: C.textMuted, textTransform: 'capitalize', marginBottom: 8 },
  timelinePills: { flexDirection: 'row', gap: 8 },
  timelinePill: {
    flexDirection: 'row', alignItems: 'center', gap: 4,
    backgroundColor: C.bgBase, borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3,
  },
  timelinePillText: { fontSize: 11, color: C.textMuted },
  
  // Weight History
  addWeightBtn: {
    marginLeft: 'auto',
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: C.primary,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
  },
  addWeightText: { color: C.textMain, fontSize: 12, fontWeight: '700' },
  weightListRow: { flexDirection: 'row', justifyContent: 'space-between', gap: 8 },
  weightItem: {
    flex: 1,
    backgroundColor: C.bgBase,
    padding: 10,
    borderRadius: 10,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: C.border,
  },
  weightItemVal: { fontSize: 16, fontWeight: '800', color: C.textMain },
  weightItemDate: { fontSize: 10, color: C.textMuted, marginTop: 4 },

  // Modal
  modalOverlay: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.6)',
    justifyContent: 'center',
    alignItems: 'center',
    padding: 20,
  },
  modalContent: {
    backgroundColor: C.bgPanel,
    width: '100%',
    borderRadius: 20,
    padding: 24,
    borderWidth: 1,
    borderColor: C.border,
  },
  modalTitle: { fontSize: 20, fontWeight: '800', color: C.textMain, marginBottom: 8 },
  modalSub: { fontSize: 13, color: C.textMuted, marginBottom: 20 },
  modalInput: {
    backgroundColor: C.bgBase,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: 12,
    padding: 16,
    color: C.textMain,
    fontSize: 16,
    marginBottom: 24,
  },
  modalActions: { flexDirection: 'row', gap: 12 },
  modalBtnCancel: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    alignItems: 'center',
    borderWidth: 1,
    borderColor: C.border,
  },
  modalBtnCancelText: { color: C.textMuted, fontSize: 14, fontWeight: '600' },
  modalBtnSubmit: {
    flex: 1,
    padding: 14,
    borderRadius: 12,
    backgroundColor: C.primary,
    alignItems: 'center',
  },
  modalBtnSubmitText: { color: C.bgBase, fontSize: 14, fontWeight: '700' },
});

export default AnalyticsScreen;
