import React, { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, ActivityIndicator, TouchableOpacity, Image } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';
import { useAuth } from '../context/AuthContext';
import apiClient from '../api/client';

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  primary: '#00e5ff',
  primaryDark: '#0284c7',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  emerald: '#10b981',
  danger: '#ef4444',
  accent: '#8b5cf6',
};

const ProfileScreen: React.FC = () => {
  const { user, logout } = useAuth();
  const [membership, setMembership] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchProfile = async () => {
      try {
        const res = await apiClient.get('/api/v1/auth/me');
        setMembership(res.data.membership);
      } catch (err) {
        console.error('Error fetching profile', err);
      } finally {
        setLoading(false);
      }
    };
    fetchProfile();
  }, []);

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={['#0f172a', '#1e1b4b']}
        style={StyleSheet.absoluteFillObject}
      />
      <SafeAreaView style={{ flex: 1 }} edges={['top']}>
        <View style={styles.header}>
          <Text style={styles.title}>Mi Perfil</Text>
        </View>

        {loading ? (
          <ActivityIndicator size="large" color={C.primary} style={{ marginTop: 40 }} />
        ) : (
          <ScrollView contentContainerStyle={styles.scrollContent}>
            
            <View style={styles.avatarSection}>
              <LinearGradient
                colors={[C.primary, C.accent]}
                style={styles.avatarGradient}
                start={{ x: 0, y: 0 }}
                end={{ x: 1, y: 1 }}
              >
                <Text style={styles.avatarText}>{user?.first_name?.[0]}{user?.last_name?.[0]}</Text>
              </LinearGradient>
              <Text style={styles.name}>{user?.first_name} {user?.last_name}</Text>
              <Text style={styles.email}>{user?.email}</Text>
            </View>

            <View style={styles.card}>
              <View style={styles.cardHeader}>
                <View style={styles.iconContainer}>
                  <Ionicons name="card-outline" size={20} color={C.primary} />
                </View>
                <Text style={styles.cardTitle}>Plan Actual</Text>
              </View>
              <View style={styles.cardContent}>
                {membership ? (
                  <>
                    <View style={styles.planBanner}>
                      <Text style={styles.planName}>{membership.plan_name || 'Miembro NovaFit'}</Text>
                      <View style={[styles.badge, { backgroundColor: membership.status === 'active' ? C.emerald + '20' : C.danger + '20' }]}>
                        <Text style={[styles.badgeText, { color: membership.status === 'active' ? C.emerald : C.danger }]}>
                          {membership.status === 'active' ? 'ACTIVA' : 'INACTIVA'}
                        </Text>
                      </View>
                    </View>
                    
                    <View style={styles.statsRow}>
                      <View style={styles.statBox}>
                        <MaterialCommunityIcons name="calendar-clock-outline" size={24} color={C.textMuted} />
                        <Text style={styles.statValue}>
                          {membership.days_remaining > 0 ? `${membership.days_remaining} días` : 'Vencida'}
                        </Text>
                        <Text style={styles.statLabel}>Restantes</Text>
                      </View>
                      <View style={styles.statDivider} />
                      <View style={styles.statBox}>
                        <MaterialCommunityIcons name="calendar-end-outline" size={24} color={C.textMuted} />
                        <Text style={styles.statValue}>
                          {membership.end_date ? membership.end_date.slice(0,10) : 'N/A'}
                        </Text>
                        <Text style={styles.statLabel}>Vencimiento</Text>
                      </View>
                    </View>
                  </>
                ) : (
                  <Text style={styles.mutedText}>No hay información de membresía disponible.</Text>
                )}
              </View>
            </View>

            <TouchableOpacity style={styles.logoutBtn} onPress={logout}>
              <MaterialCommunityIcons name="logout" size={20} color={C.danger} />
              <Text style={styles.logoutText}>Cerrar Sesión</Text>
            </TouchableOpacity>

          </ScrollView>
        )}
      </SafeAreaView>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
  },
  header: {
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: 'rgba(255,255,255,0.05)',
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: C.textMain,
  },
  scrollContent: {
    padding: 24,
    paddingBottom: 120, // Space for the floating bottom tab bar
  },
  avatarSection: {
    alignItems: 'center',
    marginBottom: 36,
  },
  avatarGradient: {
    width: 90,
    height: 90,
    borderRadius: 45,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
    shadowColor: C.primary,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.4,
    shadowRadius: 8,
    elevation: 8,
  },
  avatarText: {
    fontSize: 32,
    fontWeight: '800',
    color: '#fff',
    textShadowColor: 'rgba(0,0,0,0.3)',
    textShadowOffset: { width: 0, height: 2 },
    textShadowRadius: 4,
  },
  name: {
    fontSize: 22,
    fontWeight: '800',
    color: C.textMain,
    letterSpacing: 0.5,
  },
  email: {
    fontSize: 14,
    color: C.textMuted,
    marginTop: 6,
  },
  card: {
    backgroundColor: 'rgba(30, 41, 59, 0.7)',
    borderRadius: 20,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.1)',
    padding: 20,
    marginBottom: 24,
  },
  cardHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 20,
    gap: 12,
  },
  iconContainer: {
    backgroundColor: C.primary + '15',
    padding: 8,
    borderRadius: 10,
  },
  cardTitle: {
    fontSize: 18,
    fontWeight: '700',
    color: C.textMain,
  },
  cardContent: {
    gap: 16,
  },
  planBanner: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    padding: 16,
    borderRadius: 14,
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.05)',
  },
  planName: {
    fontSize: 17,
    fontWeight: '700',
    color: C.textMain,
  },
  badge: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 12,
  },
  badgeText: {
    fontSize: 11,
    fontWeight: '800',
    letterSpacing: 1,
  },
  statsRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginTop: 8,
  },
  statBox: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: 'rgba(255,255,255,0.02)',
    padding: 16,
    borderRadius: 14,
  },
  statDivider: {
    width: 1,
    backgroundColor: 'rgba(255,255,255,0.05)',
    marginHorizontal: 10,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '700',
    color: C.textMain,
    marginTop: 10,
    marginBottom: 4,
  },
  statLabel: {
    fontSize: 12,
    color: C.textMuted,
  },
  mutedText: {
    fontSize: 14,
    color: C.textMuted,
    textAlign: 'center',
    padding: 20,
  },
  logoutBtn: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: 'rgba(239, 68, 68, 0.1)',
    borderWidth: 1,
    borderColor: 'rgba(239, 68, 68, 0.3)',
    padding: 16,
    borderRadius: 16,
    marginTop: 16,
  },
  logoutText: {
    color: C.danger,
    fontWeight: '700',
    fontSize: 16,
  },
});

export default ProfileScreen;
