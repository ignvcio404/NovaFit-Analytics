import React from 'react';
import { View, Text, StyleSheet, ScrollView, TouchableOpacity } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons, Ionicons } from '@expo/vector-icons';
import { LinearGradient } from 'expo-linear-gradient';

const C = {
  bgBase: '#0f172a',
  bgPanel: '#1e293b',
  primary: '#00e5ff',
  primaryDark: '#0284c7',
  textMain: '#f8fafc',
  textMuted: '#94a3b8',
  border: '#334155',
  accent: '#8b5cf6',
  emerald: '#10b981',
};

const ProgressScreen: React.FC = () => {
  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      <View style={styles.header}>
        <Text style={styles.title}>Mi Progreso</Text>
      </View>

      <ScrollView contentContainerStyle={styles.scrollContent}>
        
        {/* NovaFit AI Prediction Card */}
        <LinearGradient
          colors={['#1e1b4b', '#2e1065']}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.aiCard}
        >
          <View style={styles.aiHeader}>
            <MaterialCommunityIcons name="brain" size={24} color={C.primary} />
            <Text style={styles.aiTitle}>NovaFit AI · Siguiente Sesión</Text>
          </View>
          <Text style={styles.aiSubtitle}>
            Basado en tu historial de fatiga (Ratio ACWR) y volumen reciente, te recomendamos los siguientes pesos para evitar lesiones y optimizar resultados:
          </Text>

          <View style={styles.predictionRow}>
            <View style={styles.predictionItem}>
              <Text style={styles.exerciseName}>Press de Banca</Text>
              <View style={styles.weightBadge}>
                <Text style={styles.weightText}>85 kg</Text>
              </View>
            </View>
            <View style={styles.predictionItem}>
              <Text style={styles.exerciseName}>Sentadilla Libre</Text>
              <View style={styles.weightBadge}>
                <Text style={styles.weightText}>110 kg</Text>
              </View>
            </View>
          </View>
        </LinearGradient>

        <View style={styles.chartPlaceholder}>
          <View style={styles.chartHeader}>
            <Text style={styles.chartTitle}>Volumen Mensual</Text>
            <Ionicons name="bar-chart" size={20} color={C.textMuted} />
          </View>
          <View style={styles.emptyState}>
            <MaterialCommunityIcons name="chart-bell-curve" size={48} color={C.border} />
            <Text style={styles.emptyText}>
              Aún no hay suficientes datos para generar tus métricas de volumen. Continúa entrenando.
            </Text>
          </View>
        </View>

      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  header: {
    paddingHorizontal: 24,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  title: {
    fontSize: 24,
    fontWeight: '800',
    color: C.textMain,
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 40,
  },
  aiCard: {
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: '#4c1d95',
  },
  aiHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: 12,
  },
  aiTitle: {
    color: C.primary,
    fontSize: 16,
    fontWeight: '700',
    marginLeft: 10,
    letterSpacing: 0.5,
  },
  aiSubtitle: {
    color: '#d8b4fe',
    fontSize: 13,
    lineHeight: 20,
    marginBottom: 20,
  },
  predictionRow: {
    gap: 12,
  },
  predictionItem: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: 'rgba(0,0,0,0.2)',
    padding: 12,
    borderRadius: 12,
  },
  exerciseName: {
    color: C.textMain,
    fontSize: 15,
    fontWeight: '600',
  },
  weightBadge: {
    backgroundColor: C.primary + '20',
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 8,
    borderWidth: 1,
    borderColor: C.primary + '50',
  },
  weightText: {
    color: C.primary,
    fontWeight: '800',
    fontSize: 15,
  },
  chartPlaceholder: {
    backgroundColor: C.bgPanel,
    borderRadius: 16,
    padding: 20,
    borderWidth: 1,
    borderColor: C.border,
  },
  chartHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 20,
  },
  chartTitle: {
    color: C.textMain,
    fontSize: 16,
    fontWeight: '700',
  },
  emptyState: {
    alignItems: 'center',
    paddingVertical: 30,
  },
  emptyText: {
    color: C.textMuted,
    textAlign: 'center',
    marginTop: 12,
    lineHeight: 20,
    fontSize: 13,
    paddingHorizontal: 20,
  },
});

export default ProgressScreen;
