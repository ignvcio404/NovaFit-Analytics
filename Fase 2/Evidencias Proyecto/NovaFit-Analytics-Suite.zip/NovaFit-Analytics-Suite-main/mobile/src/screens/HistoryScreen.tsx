/**
 * NovaFit Analytics Suite — HistoryScreen
 * =========================================
 *
 * Historial de sesiones completadas.
 * Usa FlatList para performance con listas largas.
 * EmptyComponent elegante cuando no hay sesiones.
 * Detalle expandible con exercises y sets.
 * Sin emojis — solo iconos de vector.
 */

import React, { useState, useCallback } from 'react';
import {
  ActivityIndicator,
  FlatList,
  StyleSheet,
  Text,
  TouchableOpacity,
  View,
} from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useFocusEffect } from '@react-navigation/native';

import { getMySessions, RoutineSessionSummary, getSessionById, RoutineSessionResponse } from '../api/trainingService';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase:    '#0f172a',
  bgPanel:   '#1e293b',
  bgPanelHi: '#273244',
  primary:   '#00e5ff',
  textMain:  '#f8fafc',
  textMuted: '#94a3b8',
  border:    '#334155',
  emerald:   '#10b981',
  amber:     '#f59e0b',
  violet:    '#8b5cf6',
};

// ─────────────────────────────────────────────────────────────────────────────
// Empty state component
// ─────────────────────────────────────────────────────────────────────────────

const EmptyHistory: React.FC = () => (
  <View style={emptyStyles.container}>
    <View style={emptyStyles.iconWrap}>
      <MaterialCommunityIcons name="clipboard-text-clock-outline" size={48} color={C.border} />
    </View>
    <Text style={emptyStyles.title}>Sin sesiones completadas</Text>
    <Text style={emptyStyles.subtitle}>
      Completa tu primera rutina y aparecerá aquí con todos los detalles.
    </Text>
  </View>
);

const emptyStyles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    marginTop: 80,
  },
  iconWrap: {
    width: 88,
    height: 88,
    borderRadius: 28,
    backgroundColor: C.bgPanel,
    borderWidth: 1,
    borderColor: C.border,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 24,
  },
  title: {
    fontSize: 18,
    fontWeight: '700',
    color: C.textMain,
    marginBottom: 8,
    textAlign: 'center',
  },
  subtitle: {
    fontSize: 14,
    color: C.textMuted,
    textAlign: 'center',
    lineHeight: 22,
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// Session card (expandable)
// ─────────────────────────────────────────────────────────────────────────────

interface SessionCardProps {
  session: RoutineSessionSummary;
  isExpanded: boolean;
  onToggle: () => void;
}

const SessionCard: React.FC<SessionCardProps> = ({ session, isExpanded, onToggle }) => {
  const [details, setDetails] = useState<RoutineSessionResponse | null>(null);
  const [loadingDetails, setLoadingDetails] = useState(false);

  React.useEffect(() => {
    if (isExpanded && !details) {
      setLoadingDetails(true);
      getSessionById(session.id)
        .then(res => setDetails(res))
        .catch(err => console.log('Error fetching session details', err))
        .finally(() => setLoadingDetails(false));
    }
  }, [isExpanded, session.id]);

  const totalSets = session.total_sets ?? 0;
  const totalVolume = session.volume_load_kg ?? 0;
  const exerciseCount = session.exercise_count ?? 0;

  const formattedDate = session.scheduled_date
    ? new Date(session.scheduled_date).toLocaleDateString('es-CL', {
        weekday: 'long', day: 'numeric', month: 'long',
      })
    : 'Fecha desconocida';

  return (
    <TouchableOpacity
      style={cardStyles.card}
      onPress={onToggle}
      activeOpacity={0.85}
    >
      {/* Header */}
      <View style={cardStyles.header}>
        <View style={cardStyles.iconBox}>
          <MaterialCommunityIcons name="dumbbell" size={18} color={C.primary} />
        </View>
        <View style={{ flex: 1 }}>
          <Text style={cardStyles.name} numberOfLines={1}>
            {session.name ?? 'Sesión completada'}
          </Text>
          <Text style={cardStyles.date}>{formattedDate}</Text>
        </View>
        <View style={cardStyles.completedBadge}>
          <MaterialCommunityIcons name="check-circle" size={14} color={C.emerald} />
          <Text style={cardStyles.completedText}>Completada</Text>
        </View>
      </View>

      {/* Stats row */}
      <View style={cardStyles.statsRow}>
        <View style={cardStyles.statItem}>
          <MaterialCommunityIcons name="layers-outline" size={14} color={C.textMuted} />
          <Text style={cardStyles.statValue}>{exerciseCount}</Text>
          <Text style={cardStyles.statLabel}>Ejercicios</Text>
        </View>
        <View style={cardStyles.statDivider} />
        <View style={cardStyles.statItem}>
          <MaterialCommunityIcons name="repeat" size={14} color={C.textMuted} />
          <Text style={cardStyles.statValue}>{totalSets}</Text>
          <Text style={cardStyles.statLabel}>Series</Text>
        </View>
        <View style={cardStyles.statDivider} />
        <View style={cardStyles.statItem}>
          <MaterialCommunityIcons name="weight" size={14} color={C.textMuted} />
          <Text style={cardStyles.statValue}>
            {totalVolume >= 1000
              ? `${(totalVolume / 1000).toFixed(1)}t`
              : `${Math.round(totalVolume)}kg`}
          </Text>
          <Text style={cardStyles.statLabel}>Volumen</Text>
        </View>
        <View style={{ flex: 1 }} />
        <MaterialCommunityIcons
          name={isExpanded ? 'chevron-up' : 'chevron-down'}
          size={22}
          color={C.textMuted}
        />
      </View>

      {/* Expanded detail */}
      {isExpanded && (
        <View style={cardStyles.details}>
          <View style={cardStyles.divider} />
          {loadingDetails ? (
            <ActivityIndicator color={C.primary} style={{ padding: 20 }} />
          ) : details ? (
            <View style={{ paddingTop: 8 }}>
              {details.exercises?.map((ex: any, idx: number) => (
                <View key={ex.id || idx} style={{ marginBottom: 12 }}>
                  <Text style={{ color: C.textMain, fontWeight: '600', fontSize: 14, marginBottom: 4 }}>
                    {idx + 1}. {ex.exercise_name}
                  </Text>
                  {ex.sets?.map((set: any, sIdx: number) => (
                    <View key={set.id || sIdx} style={{ flexDirection: 'row', alignItems: 'center', marginLeft: 12, paddingVertical: 2 }}>
                      <Text style={{ color: C.textMuted, fontSize: 12, width: 60 }}>Serie {sIdx + 1}</Text>
                      <Text style={{ color: C.emerald, fontSize: 13, flex: 1 }}>{set.weight ?? 0} kg × {set.reps ?? 0} reps {set.rpe ? `(RPE ${set.rpe})` : ''}</Text>
                    </View>
                  ))}
                </View>
              ))}
            </View>
          ) : (
            <Text style={{ color: C.textMuted, fontSize: 12, textAlign: 'center', padding: 12 }}>
              Error al cargar el detalle.
            </Text>
          )}
        </View>
      )}
    </TouchableOpacity>
  );
};

const cardStyles = StyleSheet.create({
  card: {
    backgroundColor: C.bgPanel,
    borderRadius: 20,
    borderWidth: 1,
    borderColor: C.border,
    padding: 18,
    marginBottom: 14,
  },
  header: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
    marginBottom: 14,
  },
  iconBox: {
    width: 38,
    height: 38,
    borderRadius: 11,
    backgroundColor: C.primary + '18',
    alignItems: 'center',
    justifyContent: 'center',
  },
  name: {
    fontSize: 15,
    fontWeight: '700',
    color: C.textMain,
    marginBottom: 2,
  },
  date: {
    fontSize: 12,
    color: C.textMuted,
    textTransform: 'capitalize',
  },
  completedBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: C.emerald + '15',
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
  },
  completedText: {
    fontSize: 11,
    fontWeight: '700',
    color: C.emerald,
  },
  statsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    paddingTop: 12,
    borderTopWidth: 1,
    borderTopColor: C.border,
    gap: 8,
  },
  statItem: {
    alignItems: 'center',
    gap: 2,
  },
  statValue: {
    fontSize: 16,
    fontWeight: '800',
    color: C.textMain,
  },
  statLabel: {
    fontSize: 10,
    color: C.textMuted,
    fontWeight: '600',
    letterSpacing: 0.3,
  },
  statDivider: {
    width: 1,
    height: 28,
    backgroundColor: C.border,
    marginHorizontal: 4,
  },
  details: {
    marginTop: 4,
  },
  divider: {
    height: 1,
    backgroundColor: C.border,
    marginVertical: 12,
  },
  exerciseBlock: {
    marginBottom: 14,
  },
  exerciseHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  exerciseName: {
    fontSize: 13,
    fontWeight: '700',
    color: C.textMain,
  },
  exerciseSetCount: {
    fontSize: 12,
    color: C.textMuted,
  },
  setsTable: {
    backgroundColor: C.bgBase,
    borderRadius: 10,
    overflow: 'hidden',
  },
  setRow: {
    flexDirection: 'row',
    paddingVertical: 7,
    paddingHorizontal: 12,
  },
  setRowAlt: {
    backgroundColor: 'rgba(255,255,255,0.02)',
  },
  setCol: {
    width: 32,
    fontSize: 12,
    color: C.textMuted,
    fontWeight: '600',
    textAlign: 'center',
  },
  setColWide: {
    flex: 1,
    fontSize: 12,
    color: C.textMain,
    fontWeight: '500',
    textAlign: 'center',
  },
  setColHeader: {
    color: C.textMuted,
    fontSize: 10,
    fontWeight: '700',
    letterSpacing: 0.8,
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// Main Screen
// ─────────────────────────────────────────────────────────────────────────────

const HistoryScreen: React.FC = () => {
  const [loading, setLoading]     = useState(true);
  const [sessions, setSessions]   = useState<RoutineSessionSummary[]>([]);
  const [expandedId, setExpandedId] = useState<string | null>(null);

  const fetchHistory = async () => {
    setLoading(true);
    try {
      const all = await getMySessions(50);
      const completed = Array.isArray(all)
        ? all.filter(s => s.status === 'completed')
        : [];
      setSessions(completed);
    } catch (err) {
      console.error('[HistoryScreen] fetch error:', err);
      setSessions([]);
    } finally {
      setLoading(false);
    }
  };

  useFocusEffect(useCallback(() => { fetchHistory(); }, []));

  const toggleExpand = useCallback((id: string) => {
    setExpandedId(prev => prev === id ? null : id);
  }, []);

  return (
    <SafeAreaView style={styles.container} edges={['top']}>
      {/* Header */}
      <View style={styles.header}>
        <View>
          <Text style={styles.title}>Historial</Text>
          <Text style={styles.subtitle}>
            {sessions.length > 0
              ? `${sessions.length} sesión${sessions.length !== 1 ? 'es' : ''} completada${sessions.length !== 1 ? 's' : ''}`
              : 'Tu progreso registrado'}
          </Text>
        </View>
        <View style={styles.headerBadge}>
          <MaterialCommunityIcons name="history" size={20} color={C.primary} />
        </View>
      </View>

      {loading ? (
        <View style={styles.loadingContainer}>
          <ActivityIndicator size="large" color={C.primary} />
          <Text style={styles.loadingText}>Cargando historial...</Text>
        </View>
      ) : (
        <FlatList
          data={sessions}
          keyExtractor={item => item.id}
          contentContainerStyle={styles.listContent}
          showsVerticalScrollIndicator={false}
          ListEmptyComponent={<EmptyHistory />}
          renderItem={({ item }) => (
            <SessionCard
              session={item}
              isExpanded={expandedId === item.id}
              onToggle={() => toggleExpand(item.id)}
            />
          )}
          ListFooterComponent={
            sessions.length > 0
              ? <View style={{ height: 100 }} />
              : null
          }
        />
      )}
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bgBase,
  },
  header: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 20,
    paddingVertical: 16,
    borderBottomWidth: 1,
    borderBottomColor: C.border,
  },
  title: {
    fontSize: 26,
    fontWeight: '800',
    color: C.textMain,
    letterSpacing: -0.5,
  },
  subtitle: {
    fontSize: 13,
    color: C.textMuted,
    marginTop: 2,
  },
  headerBadge: {
    width: 40,
    height: 40,
    borderRadius: 12,
    backgroundColor: C.primary + '15',
    borderWidth: 1,
    borderColor: C.primary + '30',
    alignItems: 'center',
    justifyContent: 'center',
  },
  loadingContainer: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    gap: 16,
  },
  loadingText: {
    color: C.textMuted,
    fontSize: 14,
  },
  listContent: {
    padding: 16,
    paddingTop: 20,
  },
});

export default HistoryScreen;
