/**
 * NovaFit Analytics Suite — Mobile
 * ==================================
 * API Client
 *
 * Axios instance pre-configured for the NovaFit backend.
 * - Base URL apunta a Render (production)
 * - Interceptor de request inyecta el JWT Bearer desde AsyncStorage
 * - Interceptor de response maneja 401 (logout) y 403 MEMBERSHIP_REQUIRED
 *
 * NOTA: AsyncStorage es asíncrono en React Native, por lo que el interceptor
 * de request es async para poder awaitar el token correctamente.
 */

import axios, { AxiosError, InternalAxiosRequestConfig } from 'axios';
import AsyncStorage from '@react-native-async-storage/async-storage';

// ─────────────────────────────────────────────────────────────────────────────
// Constants
// ─────────────────────────────────────────────────────────────────────────────

export const API_BASE_URL = 'https://novafit-analytics-suite.onrender.com';

export const TOKEN_KEY = '@novafit:token';
export const USER_KEY = '@novafit:user';

// ─────────────────────────────────────────────────────────────────────────────
// Axios instance
// ─────────────────────────────────────────────────────────────────────────────

const apiClient = axios.create({
  baseURL: API_BASE_URL,
  timeout: 60_000, // 60s — Render free tier may be cold-starting
  headers: {
    'Content-Type': 'application/json',
    Accept: 'application/json',
  },
});

// ── Request interceptor — attach JWT ─────────────────────────────────────────

apiClient.interceptors.request.use(
  async (config: InternalAxiosRequestConfig) => {
    const token = await AsyncStorage.getItem(TOKEN_KEY);
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error: AxiosError) => Promise.reject(error),
);

// ── Response interceptor — global error handling ─────────────────────────────

apiClient.interceptors.response.use(
  (response) => response,
  async (error: AxiosError<{ detail?: any }>) => {
    const status = error.response?.status;

    if (status === 401) {
      // Token expired or invalid → clear storage and signal the app
      await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
      // AuthContext listens for this event to navigate to Login
      authEventEmitter.emit('UNAUTHORIZED');
    }

    if (status === 403) {
      const detail = error.response?.data?.detail;
      if (detail?.code === 'MEMBERSHIP_REQUIRED') {
        authEventEmitter.emit('MEMBERSHIP_EXPIRED');
      }
    }

    return Promise.reject(error);
  },
);

// ─────────────────────────────────────────────────────────────────────────────
// Minimal event emitter (no external dep)
// ─────────────────────────────────────────────────────────────────────────────

type AuthEvent = 'UNAUTHORIZED' | 'MEMBERSHIP_EXPIRED';
type Listener = () => void;

const _listeners = new Map<AuthEvent, Set<Listener>>();

export const authEventEmitter = {
  on(event: AuthEvent, cb: Listener) {
    if (!_listeners.has(event)) _listeners.set(event, new Set());
    _listeners.get(event)!.add(cb);
    return () => _listeners.get(event)?.delete(cb);
  },
  emit(event: AuthEvent) {
    _listeners.get(event)?.forEach((cb) => cb());
  },
};

export default apiClient;
