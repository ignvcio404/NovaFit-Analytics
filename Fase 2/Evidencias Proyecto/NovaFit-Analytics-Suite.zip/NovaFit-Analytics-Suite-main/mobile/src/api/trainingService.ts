/**
 * NovaFit Analytics Suite — Mobile
 * ==================================
 * Training Service
 *
 * Typed service layer that maps 1-to-1 with the backend training
 * endpoints. All types reflect the Pydantic schemas in:
 *   backend/app/training/schemas.py
 *   backend/app/api/v1/analytics_router.py (FatigueAnalysisResponse)
 */

import apiClient from './client';

// ─────────────────────────────────────────────────────────────────────────────
// Domain Types (mirrors backend Pydantic schemas)
// ─────────────────────────────────────────────────────────────────────────────

export type WeightUnit = 'kg' | 'lb' | 'bodyweight' | 'band';
export type FatigueLevel = 'low' | 'moderate' | 'high' | 'critical';
export type TrainingGoal = 'hypertrophy' | 'strength' | 'endurance' | 'power' | 'general_fitness';
export type DifficultyLevel = 'beginner' | 'intermediate' | 'advanced' | 'elite';

// ── ExerciseSet ───────────────────────────────────────────────────────────────

export interface ExerciseSetCreate {
  set_number: number;       // 1-based
  reps?: number;            // 0-200
  weight?: number;          // kg default
  weight_unit?: WeightUnit;
  rpe?: number;             // 1.0 – 10.0 Borg modified scale
  rest_seconds?: number;
  duration_seconds?: number;
  is_warmup?: boolean;
  is_failure?: boolean;
  notes?: string;
}

export interface ExerciseSetResponse extends ExerciseSetCreate {
  id: number;
  prescribed_reps?: number;
  prescribed_weight_kg?: number;
  logged_at: string; // ISO datetime
}

// ── Exercise Catalog ──────────────────────────────────────────────────────────

export interface ExerciseCatalog {
  id: number;
  name: string;
  name_en?: string;
  category: string;
  difficulty: string;
  equipment?: string;
  video_url?: string;
  thumbnail_url?: string;
  is_custom: boolean;
}

// ── Session Exercise ──────────────────────────────────────────────────────────

export interface SessionExerciseCreate {
  exercise_id: number;
  order_index: number;       // 1-based, unique per session
  superset_group?: number;
  notes?: string;
  sets: ExerciseSetCreate[];
}

export interface SessionExerciseResponse {
  id: number;
  exercise_id: number;
  order_index: number;
  superset_group?: number;
  notes?: string;
  sets: ExerciseSetResponse[];
  exercise?: ExerciseCatalog;
  exercise_name: string; // computed_field from backend
}

// ── Routine Session ───────────────────────────────────────────────────────────

export interface RoutineSessionCreate {
  name: string;
  scheduled_date: string;    // 'YYYY-MM-DD'
  status?: 'pending' | 'planned' | 'completed' | 'cancelled';
  exercises: SessionExerciseCreate[];
  perceived_effort?: number; // 1-10 overall RPE
  microcycle_id?: number;
  template_id?: number;
  member_notes?: string;
  trainer_notes?: string;
}

export interface RoutineSessionResponse {
  id: string;
  user_id: string;
  name: string;
  scheduled_date: string;
  status: string;
  perceived_effort?: number;
  actual_duration_min?: number;
  trainer_notes?: string;
  member_notes?: string;
  exercises: SessionExerciseResponse[];
  created_at: string;
  updated_at: string;
}

export interface RoutineSessionSummary {
  id: string;
  name: string;
  scheduled_date: string;
  status: string;
  perceived_effort?: number;
  exercise_count: number;
  total_sets: number;
  volume_load_kg: number;
}

// ── Routine Template ──────────────────────────────────────────────────────────

export interface TemplateExercise {
  exercise_id: number;
  order_index: number;
  sets: number;
  reps_target: string;    // e.g. "8-10"
  rest_seconds?: number;
  superset_group?: number;
  notes?: string;
}

export interface RoutineTemplateResponse {
  id: number;
  branch_id: string;
  created_by?: string;
  name: string;
  description?: string;
  goal: TrainingGoal;
  difficulty: DifficultyLevel;
  estimated_duration_min?: number;
  is_public: boolean;
  template_data: {
    exercises?: TemplateExercise[];
    [key: string]: any;
  };
  created_at: string;
  updated_at: string;
}

// ── Fatigue Analysis (Critical Flow #2) ──────────────────────────────────────

export interface FatigueAnalysisResponse {
  user_id: string;
  analysis_period_start: string;
  analysis_period_end: string;

  // Workload summary
  sessions_planned: number;
  sessions_completed: number;
  adherence_rate_pct: number;
  total_sets: number;
  total_reps: number;
  volume_load_kg: number;

  // Intensity signals
  avg_rpe?: number;
  max_rpe?: number;
  failure_sets_count: number;

  // ACWR — Acute:Chronic Workload Ratio
  acute_workload?: number;
  chronic_workload?: number;
  acwr?: number;         // Safe: 0.8-1.3 | Risk: >1.5

  // ML composite score
  fatigue_score: number;      // 0-100
  fatigue_level: FatigueLevel; // 'low' | 'moderate' | 'high' | 'critical'

  // Recommendation
  deload_recommended: boolean;
  deload_reason?: string;
  recommendation_confidence: number; // 0.0-1.0

  // Metadata
  algorithm_version: string;
  computed_at: string;
}

// ── Phase 3: Connected Tables ────────────────────────────────────────────────

export interface WeightHistory {
  id: string;
  weight_kg: number;
  measured_at: string;
  notes?: string;
}

export interface PredictiveAlert {
  id: string;
  alert_type: string;
  severity: string;
  message: string;
  is_read: boolean;
  created_at: string;
}

export interface AttendanceRecord {
  id: string;
  branch_id: string;
  check_in: string;
  check_out?: string;
  method: string;
}

// ─────────────────────────────────────────────────────────────────────────────
// API Service Functions
// ─────────────────────────────────────────────────────────────────────────────

const BASE = '/api/v1';

/** Fetch all public + assigned templates */
export const getTemplates = async (): Promise<RoutineTemplateResponse[]> => {
  const res = await apiClient.get<RoutineTemplateResponse[]>(`${BASE}/training/templates`);
  return res.data;
};

/** Instantiate a template into a live session struct (no DB write yet) */
export const instantiateTemplate = async (
  templateId: number,
  scheduledDate?: string,
): Promise<RoutineSessionResponse> => {
  const res = await apiClient.post<RoutineSessionResponse>(
    `${BASE}/training/templates/${templateId}/instantiate`,
    { scheduled_date: scheduledDate },
  );
  return res.data;
};

/** List recent sessions for the authenticated athlete */
export const getMySessions = async (limit = 5): Promise<RoutineSessionSummary[]> => {
  const res = await apiClient.get<RoutineSessionSummary[]>(`${BASE}/training/sessions`, {
    params: { limit },
  });
  return res.data;
};

/** Get a specific session by ID */
export const getSessionById = async (id: string): Promise<RoutineSessionResponse> => {
  const res = await apiClient.get<RoutineSessionResponse>(`${BASE}/training/sessions/${id}`);
  return res.data;
};

/** Delete a training session */
export const deleteSession = async (id: string): Promise<void> => {
  await apiClient.delete(`${BASE}/training/sessions/${id}`);
};

/**
 * POST a completed training session — Critical Flow #1.
 * Payload shape mirrors RoutineSessionCreate from backend schemas.
 */
export const createTrainingSession = async (
  payload: RoutineSessionCreate,
): Promise<RoutineSessionResponse> => {
  const res = await apiClient.post<RoutineSessionResponse>(
    `${BASE}/training/sessions`,
    payload,
  );
  return res.data;
};

/**
 * GET fatigue analysis for the authenticated user — Critical Flow #2.
 * Returns ACWR + composite ML score + deload recommendation.
 */
export const getMyFatigueAnalysis = async (): Promise<FatigueAnalysisResponse> => {
  const res = await apiClient.get<FatigueAnalysisResponse>(`${BASE}/analytics/fatigue/me`);
  return res.data;
};

export const getVolumeProgress = async (): Promise<any[]> => {
  const res = await apiClient.get<any[]>(`${BASE}/analytics/volume-progress`);
  return res.data;
};

export const getAiPredictions = async (): Promise<{ predictions: any[] }> => {
  const res = await apiClient.get<{ predictions: any[] }>(`${BASE}/analytics/ai-predictions`);
  return res.data;
};

/** Fetch the exercise catalog (for exercise name lookup) */
export const getExerciseCatalog = async (): Promise<ExerciseCatalog[]> => {
  const res = await apiClient.get<ExerciseCatalog[]>(`${BASE}/training/exercises`);
  return res.data;
};

/** Mark a pending session as completed */
export const completeSession = async (
  sessionId: string,
  rpe?: number,
  updated_sets?: any[]
): Promise<RoutineSessionResponse> => {
  const res = await apiClient.patch<RoutineSessionResponse>(
    `${BASE}/training/sessions/${sessionId}/complete`,
    { rpe, updated_sets }
  );
  return res.data;
};

// ── Phase 3 APIs ─────────────────────────────────────────────────────────────

export const getWeightHistory = async (): Promise<WeightHistory[]> => {
  const res = await apiClient.get<WeightHistory[]>(`${BASE}/athlete/weight-history/me`);
  return res.data;
};

export const logWeight = async (weight_kg: number, notes?: string): Promise<WeightHistory> => {
  const res = await apiClient.post<WeightHistory>(`${BASE}/athlete/weight-history`, { weight_kg, notes });
  return res.data;
};

export const checkInGym = async (): Promise<AttendanceRecord> => {
  const res = await apiClient.post<AttendanceRecord>(`${BASE}/athlete/attendance/check-in`);
  return res.data;
};

export const getMyAlerts = async (): Promise<PredictiveAlert[]> => {
  const res = await apiClient.get<PredictiveAlert[]>(`${BASE}/analytics/alerts/me`);
  return res.data;
};
