/**
 * NovaFit Analytics Suite — Mobile
 * ==================================
 * AuthContext
 *
 * Gestiona autenticación y persiste sesión en AsyncStorage.
 * Escucha los eventos globales del apiClient (UNAUTHORIZED, MEMBERSHIP_EXPIRED)
 * para forzar logout o mostrar pantalla de bloqueo sin necesidad de Redux.
 */

import React, {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useRef,
  useState,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import apiClient, { authEventEmitter, TOKEN_KEY, USER_KEY } from '../api/client';
import { registerForPushNotificationsAsync } from '../services/pushNotifications';

// ─────────────────────────────────────────────────────────────────────────────
// Types
// ─────────────────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  email: string;
  first_name: string;
  last_name: string;
  role: string;
  roles?: string[];
  branch_id?: string;
}

interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  membershipExpired: boolean;
}

interface AuthContextValue extends AuthState {
  login: (email: string, password: string) => Promise<void>;
  logout: () => Promise<void>;
  clearMembershipBlock: () => void;
}

// ─────────────────────────────────────────────────────────────────────────────
// Context
// ─────────────────────────────────────────────────────────────────────────────

export const AuthContext = createContext<AuthContextValue | null>(null);

export const useAuth = (): AuthContextValue => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
};

// ─────────────────────────────────────────────────────────────────────────────
// Provider
// ─────────────────────────────────────────────────────────────────────────────

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [state, setState] = useState<AuthState>({
    user: null,
    token: null,
    isLoading: true,
    membershipExpired: false,
  });

  const isMounted = useRef(true);

  // ── Bootstrap — rehydrate from AsyncStorage ────────────────────────────────

  useEffect(() => {
    const rehydrate = async () => {
      try {
        const [storedToken, storedUser] = await AsyncStorage.multiGet([TOKEN_KEY, USER_KEY]);
        const token = storedToken[1];
        const userRaw = storedUser[1];

        if (token && userRaw) {
          const user: AuthUser = JSON.parse(userRaw);
          if (isMounted.current) {
            setState({ user, token, isLoading: false, membershipExpired: false });
          }
        } else if (token) {
          // Token exists but user not cached — re-fetch /me
          try {
            const res = await apiClient.get<AuthUser>('/api/v1/auth/me');
            await AsyncStorage.setItem(USER_KEY, JSON.stringify(res.data));
            if (isMounted.current) {
              setState({ user: res.data, token, isLoading: false, membershipExpired: false });
            }
          } catch {
            await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
            if (isMounted.current) setState((s) => ({ ...s, isLoading: false }));
          }
        } else {
          if (isMounted.current) setState((s) => ({ ...s, isLoading: false }));
        }
      } catch {
        if (isMounted.current) setState((s) => ({ ...s, isLoading: false }));
      }
    };

    rehydrate();
    return () => { isMounted.current = false; };
  }, []);

  // ── Listen for global auth events from apiClient ───────────────────────────

  useEffect(() => {
    const unsubUnauth = authEventEmitter.on('UNAUTHORIZED', async () => {
      await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
      if (isMounted.current) {
        setState({ user: null, token: null, isLoading: false, membershipExpired: false });
      }
    });

    const unsubExpired = authEventEmitter.on('MEMBERSHIP_EXPIRED', () => {
      if (isMounted.current) {
        setState((s) => ({ ...s, membershipExpired: true }));
      }
    });

    return () => {
      unsubUnauth();
      unsubExpired();
    };
  }, []);

  // ── Register Push Notifications on Auth ──────────────────────────────────────
  
  useEffect(() => {
    if (state.token) {
      const registerToken = async () => {
        try {
          const pushToken = await registerForPushNotificationsAsync();
          if (pushToken) {
            await apiClient.post('/api/v1/users/device-token', { token: pushToken });
            console.log("Device token registered successfully");
          }
        } catch (err) {
          console.warn("Failed to register push token", err);
        }
      };
      registerToken();
    }
  }, [state.token]);

  // ── login ──────────────────────────────────────────────────────────────────

  const login = useCallback(async (email: string, password: string) => {
    const params = new URLSearchParams();
    params.append('username', email);
    params.append('password', password);

    const res = await apiClient.post<{ access_token: string }>('/api/v1/auth/login', params.toString(), {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded',
      },
    });

    const token = res.data.access_token;
    await AsyncStorage.setItem(TOKEN_KEY, token);

    // Re-fetch user profile immediately after token is stored
    const meRes = await apiClient.get<AuthUser>('/api/v1/auth/me');
    await AsyncStorage.setItem(USER_KEY, JSON.stringify(meRes.data));

    setState({
      user: meRes.data,
      token,
      isLoading: false,
      membershipExpired: false,
    });
  }, []);

  // ── logout ─────────────────────────────────────────────────────────────────

  const logout = useCallback(async () => {
    await AsyncStorage.multiRemove([TOKEN_KEY, USER_KEY]);
    setState({ user: null, token: null, isLoading: false, membershipExpired: false });
  }, []);

  const clearMembershipBlock = useCallback(() => {
    setState((s) => ({ ...s, membershipExpired: false }));
  }, []);

  return (
    <AuthContext.Provider value={{ ...state, login, logout, clearMembershipBlock }}>
      {children}
    </AuthContext.Provider>
  );
};
