const fs = require('fs');
const path = require('path');

const targetPath = path.join(__dirname, 'node_modules', 'react-native-css-interop', 'babel.js');

if (fs.existsSync(targetPath)) {
  let content = fs.readFileSync(targetPath, 'utf8');
  // Remove the problematic plugin line
  content = content.replace(/"react-native-worklets\/plugin",?/g, '');
  fs.writeFileSync(targetPath, content, 'utf8');
  console.log('Patched react-native-css-interop/babel.js to remove react-native-worklets/plugin');
} else {
  console.log('react-native-css-interop/babel.js not found, skipping patch');
}
