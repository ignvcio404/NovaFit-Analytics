/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    './App.{js,jsx,ts,tsx}',
    './src/**/*.{js,jsx,ts,tsx}',
  ],
  presets: [require('nativewind/preset')],
  theme: {
    extend: {
      colors: {
        // Mirrors web index.css --color-* custom properties
        primary: '#00e5ff',
        'primary-dark': '#00b3cc',
        'bg-base': '#0f172a',
        'bg-panel': '#1e293b',
        'bg-panel-hover': '#334155',
        'text-main': '#f8fafc',
        'text-muted': '#94a3b8',
        accent: '#f43f5e',
        success: '#10b981',
        warning: '#f59e0b',
        danger: '#ef4444',
      },
      fontFamily: {
        sans: ['Inter_400Regular', 'system-ui'],
        bold: ['Inter_700Bold', 'system-ui'],
      },
    },
  },
  plugins: [],
};
