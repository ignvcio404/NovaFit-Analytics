/**
 * NovaFit Analytics Suite — Mobile App Entry Point
 * ==================================================
 *
 * Stack de navegación:
 *   - Unauthenticated: LoginScreen
 *   - Authenticated (Athlete): Bottom Tab Navigator
 *       · AthleteDashboardScreen  (Dashboard)
 *       · TrainingSessionScreen   (Entrenar)
 *       · AnalyticsScreen         (Progreso)
 *       · HistoryScreen           (Historial)
 *       · ProfileBillingScreen    (Perfil)
 *
 * Diseño: Dark mode premium, paleta idéntica a la web.
 * Sin emojis — solo iconos de vector (MaterialCommunityIcons / Ionicons)
 */

import React from 'react';
import {
  View, Text, ActivityIndicator, StyleSheet, TouchableOpacity,
} from 'react-native';
import { NavigationContainer } from '@react-navigation/native';
import { createNativeStackNavigator } from '@react-navigation/native-stack';
import { createBottomTabNavigator } from '@react-navigation/bottom-tabs';
import { SafeAreaProvider } from 'react-native-safe-area-context';
import { StatusBar } from 'expo-status-bar';
import { Ionicons, MaterialCommunityIcons } from '@expo/vector-icons';

import { AuthProvider, useAuth } from './src/context/AuthContext';
import TrainingSessionScreen from './src/screens/TrainingSessionScreen';
import LoginScreen from './src/screens/LoginScreen';
import RegisterScreen from './src/screens/RegisterScreen';
import AthleteDashboardScreen from './src/screens/AthleteDashboardScreen';
import AnalyticsScreen from './src/screens/AnalyticsScreen';
import ProfileBillingScreen from './src/screens/ProfileBillingScreen';
import HistoryScreen from './src/screens/HistoryScreen';

// ─────────────────────────────────────────────────────────────────────────────
// Design tokens — mirrors index.css CSS vars
// ─────────────────────────────────────────────────────────────────────────────

const C = {
  bgBase:   '#0f172a',
  bgPanel:  '#1e293b',
  primary:  '#00e5ff',
  textMain: '#f8fafc',
  textMuted:'#94a3b8',
  border:   '#334155',
  danger:   '#ef4444',
  warning:  '#f59e0b',
  emerald:  '#10b981',
};

// ─────────────────────────────────────────────────────────────────────────────
// Navigators
// ─────────────────────────────────────────────────────────────────────────────

const AuthStack = createNativeStackNavigator();
const AthleteTab = createBottomTabNavigator();

// ── Membership Expired overlay ───────────────────────────────────────────────

const MembershipExpiredScreen: React.FC = () => {
  const { clearMembershipBlock } = useAuth();
  return (
    <View style={expiredStyles.overlay}>
      <View style={expiredStyles.card}>
        <View style={expiredStyles.iconCircle}>
          <Ionicons name="lock-closed" size={36} color={C.danger} />
        </View>
        <Text style={expiredStyles.title}>Membresía Vencida</Text>
        <Text style={expiredStyles.body}>
          Tu membresía ha expirado. Contacta a tu entrenador o realiza tu pago para continuar.
        </Text>
        <TouchableOpacity style={expiredStyles.btn} onPress={clearMembershipBlock}>
          <Text style={expiredStyles.btnText}>Ver opciones de pago</Text>
        </TouchableOpacity>
      </View>
    </View>
  );
};

const expiredStyles = StyleSheet.create({
  overlay: {
    flex: 1,
    backgroundColor: C.bgBase,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
  },
  card: {
    backgroundColor: C.bgPanel,
    borderRadius: 24,
    borderWidth: 1,
    borderColor: C.danger + '40',
    padding: 32,
    alignItems: 'center',
    maxWidth: 360,
    width: '100%',
  },
  iconCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: C.danger + '20',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  title: {
    fontSize: 22,
    fontWeight: '800',
    color: C.textMain,
    marginBottom: 12,
    textAlign: 'center',
  },
  body: {
    fontSize: 14,
    color: C.textMuted,
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 28,
  },
  btn: {
    backgroundColor: C.primary,
    borderRadius: 14,
    paddingVertical: 14,
    paddingHorizontal: 32,
    width: '100%',
    alignItems: 'center',
  },
  btnText: {
    fontSize: 15,
    fontWeight: '700',
    color: C.bgBase,
    letterSpacing: 0.5,
  },
});

// ── Athlete Tab Navigator ────────────────────────────────────────────────────

const AthleteTabNavigator: React.FC = () => (
  <AthleteTab.Navigator
    screenOptions={{
      headerShown: false,
      tabBarShowLabel: true,
      tabBarLabelStyle: {
        fontSize: 10,
        fontWeight: '600',
        marginTop: -4,
        marginBottom: 6,
      },
      tabBarStyle: {
        position: 'absolute',
        bottom: 20,
        left: 16,
        right: 16,
        elevation: 0,
        backgroundColor: 'rgba(15, 23, 42, 0.96)',
        borderRadius: 28,
        height: 72,
        borderWidth: 1,
        borderColor: 'rgba(51, 65, 85, 0.8)',
        shadowColor: '#000',
        shadowOffset: { width: 0, height: 10 },
        shadowOpacity: 0.35,
        shadowRadius: 24,
        paddingBottom: 0,
        paddingTop: 0,
      },
      tabBarActiveTintColor: C.primary,
      tabBarInactiveTintColor: C.textMuted,
    }}
  >
    <AthleteTab.Screen
      name="Dashboard"
      component={AthleteDashboardScreen}
      options={{
        tabBarLabel: 'Inicio',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="view-dashboard-outline" size={size} color={color} />
        ),
      }}
    />
    <AthleteTab.Screen
      name="Training"
      component={TrainingSessionScreen}
      options={{
        tabBarLabel: 'Entrenar',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="dumbbell" size={size} color={color} />
        ),
      }}
    />
    <AthleteTab.Screen
      name="History"
      component={HistoryScreen}
      options={{
        tabBarLabel: 'Historial',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="history" size={size} color={color} />
        ),
      }}
    />
    <AthleteTab.Screen
      name="Progress"
      component={AnalyticsScreen}
      options={{
        tabBarLabel: 'Progreso',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="chart-areaspline" size={size} color={color} />
        ),
      }}
    />
    <AthleteTab.Screen
      name="Profile"
      component={ProfileBillingScreen}
      options={{
        tabBarLabel: 'Perfil',
        tabBarIcon: ({ color, size }) => (
          <MaterialCommunityIcons name="account-circle-outline" size={size} color={color} />
        ),
      }}
    />
  </AthleteTab.Navigator>
);

// ─────────────────────────────────────────────────────────────────────────────
// Root Navigator — reads auth state from context
// ─────────────────────────────────────────────────────────────────────────────

const RootNavigator: React.FC = () => {
  const { user, isLoading, membershipExpired } = useAuth();

  if (isLoading) {
    return (
      <View style={rootStyles.loadingContainer}>
        <View style={rootStyles.logoMark}>
          <MaterialCommunityIcons name="lightning-bolt" size={40} color={C.primary} />
        </View>
        <Text style={rootStyles.loadingBrand}>NovaFit</Text>
        <ActivityIndicator color={C.primary} size="large" style={{ marginTop: 32 }} />
        <Text style={rootStyles.loadingSubtext}>Verificando sesión...</Text>
      </View>
    );
  }

  if (membershipExpired) {
    return <MembershipExpiredScreen />;
  }

  return (
    <NavigationContainer>
      {user ? (
        <AthleteTabNavigator />
      ) : (
        <AuthStack.Navigator screenOptions={{ headerShown: false }}>
          <AuthStack.Screen name="Login" component={LoginScreen} />
          <AuthStack.Screen name="Register" component={RegisterScreen} />
        </AuthStack.Navigator>
      )}
    </NavigationContainer>
  );
};

const rootStyles = StyleSheet.create({
  loadingContainer: {
    flex: 1,
    backgroundColor: C.bgBase,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
  },
  logoMark: {
    width: 80,
    height: 80,
    borderRadius: 24,
    backgroundColor: C.primary + '15',
    borderWidth: 1,
    borderColor: C.primary + '40',
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 16,
  },
  loadingBrand: {
    fontSize: 32,
    fontWeight: '900',
    color: C.textMain,
    letterSpacing: 1,
  },
  loadingSubtext: {
    color: C.textMuted,
    marginTop: 12,
    fontSize: 14,
  },
});

// ─────────────────────────────────────────────────────────────────────────────
// App Root
// ─────────────────────────────────────────────────────────────────────────────

export default function App() {
  return (
    <SafeAreaProvider>
      <StatusBar style="light" />
      <AuthProvider>
        <RootNavigator />
      </AuthProvider>
    </SafeAreaProvider>
  );
}
