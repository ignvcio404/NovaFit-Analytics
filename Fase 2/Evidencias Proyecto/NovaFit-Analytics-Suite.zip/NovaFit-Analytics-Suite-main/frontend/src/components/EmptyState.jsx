import React from 'react';
import { useNavigate } from 'react-router-dom';
import { Inbox } from 'lucide-react';

const EmptyState = ({ 
  icon: Icon = Inbox, 
  title = "No hay datos disponibles", 
  description = "No pudimos encontrar nada para mostrar aquí en este momento.", 
  actionText, 
  actionPath 
}) => {
  const navigate = useNavigate();

  return (
    <div className="glass-panel p-10 flex flex-col items-center justify-center text-center space-y-4 animate-fade-in my-8">
      <div className="bg-slate-800/50 p-4 rounded-full border border-slate-700/50">
        <Icon className="h-10 w-10 text-slate-400" />
      </div>
      
      <div className="space-y-1">
        <h3 className="text-xl font-semibold text-white">{title}</h3>
        <p className="text-slate-400 max-w-sm mx-auto">
          {description}
        </p>
      </div>

      {actionText && actionPath && (
        <button 
          onClick={() => navigate(actionPath)}
          className="mt-4 px-6 py-2 bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white rounded-lg font-medium transition-all shadow-lg hover:shadow-cyan-500/25 active:scale-95"
        >
          {actionText}
        </button>
      )}
    </div>
  );
};

export default EmptyState;
