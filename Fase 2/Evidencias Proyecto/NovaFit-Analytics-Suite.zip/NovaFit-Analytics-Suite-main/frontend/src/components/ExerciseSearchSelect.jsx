import React, { useState, useEffect, useRef } from 'react';
import { Search, Loader2, X } from 'lucide-react';
import { trainingService } from '../services/trainingService';

const ExerciseSearchSelect = ({ value, onChange, error }) => {
  const [query, setQuery] = useState(value ? value.name : '');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [isOpen, setIsOpen] = useState(false);
  const wrapperRef = useRef(null);

  useEffect(() => {
    if (value && value.name !== query) {
      setQuery(value.name);
    }
  }, [value]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (wrapperRef.current && !wrapperRef.current.contains(event.target)) {
        setIsOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  useEffect(() => {
    const search = async () => {
      if (query.length < 2) {
        setResults([]);
        return;
      }
      
      // Don't search if the query perfectly matches the selected value
      if (value && query === value.name) {
        return;
      }

      setLoading(true);
      try {
        const data = await trainingService.searchExercises(query);
        setResults(data);
        setIsOpen(true);
      } catch (err) {
        console.error("Failed to search exercises:", err);
      } finally {
        setLoading(false);
      }
    };

    const debounce = setTimeout(() => {
      search();
    }, 300);

    return () => clearTimeout(debounce);
  }, [query, value]);

  const handleSelect = (exercise) => {
    setQuery(exercise.name);
    onChange({ id: exercise.wger_id, name: exercise.name });
    setIsOpen(false);
  };

  const handleClear = () => {
    setQuery('');
    onChange(null);
    setResults([]);
    setIsOpen(false);
  };

  return (
    <div ref={wrapperRef} className="relative w-full">
      <div className="relative">
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => { if (results.length > 0) setIsOpen(true); }}
          placeholder="Buscar ejercicio (ej: Press de banca)..."
          className={`w-full bg-slate-900 border ${error ? 'border-red-500 focus:border-red-500' : 'border-slate-700 focus:border-cyan-500'} rounded-md py-2 pl-10 pr-10 text-white placeholder-slate-500 focus:outline-none focus:ring-1 ${error ? 'focus:ring-red-500' : 'focus:ring-cyan-500'} transition-colors`}
        />
        <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
          {loading ? (
            <Loader2 className="h-4 w-4 text-slate-400 animate-spin" />
          ) : (
            <Search className="h-4 w-4 text-slate-400" />
          )}
        </div>
        {query && (
          <button
            type="button"
            onClick={handleClear}
            className="absolute inset-y-0 right-0 pr-3 flex items-center text-slate-400 hover:text-white"
          >
            <X className="h-4 w-4" />
          </button>
        )}
      </div>

      {isOpen && results.length > 0 && (
        <ul className="absolute z-50 mt-1 w-full bg-slate-800 border border-slate-700 rounded-md shadow-xl max-h-60 overflow-y-auto">
          {results.map((exercise) => (
            <li
              key={exercise.wger_id}
              onClick={() => handleSelect(exercise)}
              className="px-4 py-2 hover:bg-slate-700 cursor-pointer text-sm text-slate-200 border-b border-slate-700/50 last:border-0"
            >
              <div className="font-medium text-white">{exercise.name}</div>
              <div className="text-xs text-slate-400 mt-1 capitalize">
                {exercise.category} {exercise.equipment ? `• ${exercise.equipment}` : ''}
              </div>
            </li>
          ))}
        </ul>
      )}
      
      {isOpen && query.length >= 2 && results.length === 0 && !loading && (
        <div className="absolute z-50 mt-1 w-full bg-slate-800 border border-slate-700 rounded-md shadow-xl p-4 text-sm text-slate-400 text-center">
          No se encontraron ejercicios.
        </div>
      )}
    </div>
  );
};

export default ExerciseSearchSelect;
