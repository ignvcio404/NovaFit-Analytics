import React, { useState } from 'react';
import apiClient from '../../services/api';
import toast from 'react-hot-toast';

const ExerciseDBModal = ({ isOpen, onClose, onImportSuccess }) => {
  const [query, setQuery] = useState('');
  const [results, setResults] = useState([]);
  const [loading, setLoading] = useState(false);
  const [importing, setImporting] = useState(null); // id del ejercicio importando

  if (!isOpen) return null;

  const handleSearch = async () => {
    if (!query.trim()) return;
    setLoading(true);
    try {
      const response = await apiClient.get(`/api/v1/exercises/external/search?query=${encodeURIComponent(query)}&limit=10`);
      setResults(response.data);
    } catch (error) {
      console.error(error);
      toast.error('Error al buscar en ExerciseDB');
    } finally {
      setLoading(false);
    }
  };

  const handleImport = async (exercise) => {
    setImporting(exercise.id);
    try {
      const response = await apiClient.post('/api/v1/exercises/import', {
        name: exercise.name.charAt(0).toUpperCase() + exercise.name.slice(1),
        category_name: exercise.bodyPart || 'General',
        gif_url: exercise.gifUrl
      });
      toast.success('Ejercicio importado al catálogo local');
      if (onImportSuccess) {
        onImportSuccess(response.data); // Pasa el ejercicio local creado
      }
    } catch (error) {
      console.error(error);
      toast.error('Error al importar el ejercicio');
    } finally {
      setImporting(null);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-[#1e293b] border border-[#334155] rounded-2xl shadow-2xl w-full max-w-3xl overflow-hidden flex flex-col max-h-[85vh]">
        {/* Header */}
        <div className="flex justify-between items-center p-6 border-b border-white/10">
          <div>
            <h2 className="text-2xl font-bold text-white">Importar desde ExerciseDB</h2>
            <p className="text-[#94a3b8] text-sm mt-1">Busca ejercicios animados para añadir a tu catálogo local.</p>
          </div>
          <button onClick={onClose} className="text-[#94a3b8] hover:text-white transition-colors">
            <svg className="w-6 h-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Search Bar */}
        <div className="p-6 pb-2">
          <div className="flex gap-4">
            <input
              type="text"
              placeholder="Ej: Bicep curl, Squat, Bench press..."
              className="flex-1 bg-black/30 border border-white/10 rounded-lg p-3 text-white focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] outline-none transition-all"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
            />
            <button
              onClick={handleSearch}
              disabled={loading}
              className="bg-[#00e5ff] text-black font-bold px-6 py-3 rounded-lg hover:bg-[#00cce6] transition-colors shadow-[0_0_15px_rgba(0,229,255,0.3)] disabled:opacity-50"
            >
              {loading ? 'Buscando...' : 'Buscar'}
            </button>
          </div>
        </div>

        {/* Results */}
        <div className="flex-1 overflow-y-auto p-6 pt-4">
          {results.length === 0 && !loading && (
            <div className="text-center text-[#94a3b8] py-10">
              No hay resultados. Escribe un nombre y presiona Buscar.
            </div>
          )}
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {results.map((ex) => (
              <div key={ex.id} className="bg-black/20 border border-white/5 rounded-xl p-4 flex flex-col gap-3 group hover:border-[#00e5ff]/30 transition-colors">
                <div className="flex gap-4 items-start">
                  <div className="w-24 h-24 bg-black rounded-lg overflow-hidden border border-white/10 shrink-0">
                    {ex.gifUrl ? (
                      <img src={ex.gifUrl} alt={ex.name} className="w-full h-full object-cover" loading="lazy" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-[#475569]">No Media</div>
                    )}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-white font-bold truncate capitalize" title={ex.name}>{ex.name}</h3>
                    <p className="text-[#00e5ff] text-xs font-semibold capitalize mt-1">{ex.bodyPart}</p>
                    <p className="text-[#94a3b8] text-xs mt-1 capitalize">Target: {ex.target}</p>
                    <p className="text-[#94a3b8] text-xs capitalize">Equipo: {ex.equipment}</p>
                  </div>
                </div>
                <button
                  onClick={() => handleImport(ex)}
                  disabled={importing === ex.id}
                  className="w-full mt-auto bg-white/5 border border-white/10 hover:bg-[#00e5ff]/20 hover:border-[#00e5ff]/50 hover:text-[#00e5ff] text-white py-2 rounded-lg transition-all text-sm font-semibold disabled:opacity-50"
                >
                  {importing === ex.id ? 'Importando...' : 'Importar a Catálogo'}
                </button>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ExerciseDBModal;
