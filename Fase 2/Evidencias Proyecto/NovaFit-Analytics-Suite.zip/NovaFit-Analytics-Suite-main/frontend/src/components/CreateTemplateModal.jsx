import React, { useState } from 'react';
import { X, Plus, Trash2, Loader2, Save } from 'lucide-react';
import { trainingService } from '../services/trainingService';
import ExerciseSearchSelect from './ExerciseSearchSelect';
import ExerciseDBModal from './admin/ExerciseDBModal';

const GOAL_OPTIONS = [
  { value: 'hypertrophy', label: 'Hipertrofia' },
  { value: 'strength', label: 'Fuerza' },
  { value: 'endurance', label: 'Resistencia' },
  { value: 'power', label: 'Potencia' },
  { value: 'maintenance', label: 'Mantenimiento' },
];

const DIFFICULTY_OPTIONS = [
  { value: 'beginner', label: 'Principiante' },
  { value: 'intermediate', label: 'Intermedio' },
  { value: 'advanced', label: 'Avanzado' },
  { value: 'elite', label: 'Élite' },
];

const CreateTemplateModal = ({ isOpen, onClose, onSuccess, templateToEdit }) => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);
  const [isExerciseDBModalOpen, setIsExerciseDBModalOpen] = useState(false);
  const [targetExerciseIndex, setTargetExerciseIndex] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    goal: 'hypertrophy',
    difficulty: 'intermediate',
    estimated_duration_min: 60,
    is_public: false,
  });

  const [exercises, setExercises] = useState([
    { exercise: null, sets: 3, reps_target: '8-12', rest_seconds: 90, notes: '' }
  ]);

  const [validationErrors, setValidationErrors] = useState({});

  React.useEffect(() => {
    if (isOpen) {
      if (templateToEdit) {
        setFormData({
          name: templateToEdit.name || '',
          description: templateToEdit.description || '',
          goal: templateToEdit.goal || 'hypertrophy',
          difficulty: templateToEdit.difficulty || 'intermediate',
          estimated_duration_min: templateToEdit.estimated_duration_min || 60,
          is_public: templateToEdit.is_public || false,
        });
        
        if (templateToEdit.template_data && templateToEdit.template_data.exercises) {
          const loadedExercises = templateToEdit.template_data.exercises.map(ex => ({
            exercise: { id: ex.exercise_id, name: ex.exercise?.name || 'Ejercicio Cargado' }, 
            sets: ex.sets || 3,
            reps_target: ex.reps_target || '8-12',
            rest_seconds: ex.rest_seconds || 90,
            notes: ex.notes || ''
          }));
          setExercises(loadedExercises.length > 0 ? loadedExercises : [{ exercise: null, sets: 3, reps_target: '8-12', rest_seconds: 90, notes: '' }]);
        } else {
          setExercises([{ exercise: null, sets: 3, reps_target: '8-12', rest_seconds: 90, notes: '' }]);
        }
      } else {
        setFormData({
          name: '',
          description: '',
          goal: 'hypertrophy',
          difficulty: 'intermediate',
          estimated_duration_min: 60,
          is_public: false,
        });
        setExercises([{ exercise: null, sets: 3, reps_target: '8-12', rest_seconds: 90, notes: '' }]);
      }
      setValidationErrors({});
      setError(null);
    }
  }, [isOpen, templateToEdit]);

  if (!isOpen) return null;

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleExerciseChange = (index, field, value) => {
    const newExercises = [...exercises];
    newExercises[index][field] = value;
    setExercises(newExercises);
    
    // Clear validation error for this exercise if any
    if (validationErrors[`exercise_${index}`]) {
      setValidationErrors(prev => {
        const next = { ...prev };
        delete next[`exercise_${index}`];
        return next;
      });
    }
  };

  const addExercise = () => {
    setExercises([
      ...exercises,
      { exercise: null, sets: 3, reps_target: '10', rest_seconds: 60, notes: '' }
    ]);
  };

  const removeExercise = (index) => {
    if (exercises.length === 1) return;
    const newExercises = [...exercises];
    newExercises.splice(index, 1);
    setExercises(newExercises);
  };

  const validate = () => {
    const errors = {};
    if (!formData.name.trim()) errors.name = "El nombre es requerido.";
    if (formData.estimated_duration_min < 1) errors.duration = "Debe ser mayor a 0.";
    
    exercises.forEach((ex, idx) => {
      if (!ex.exercise) {
        errors[`exercise_${idx}`] = "Seleccione un ejercicio.";
      }
      if (!ex.reps_target.trim()) {
        errors[`reps_${idx}`] = "Obligatorio.";
      }
    });

    setValidationErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError(null);

    if (!validate()) return;

    setLoading(true);
    try {
      // Map frontend state to backend schema
      const payload = {
        name: formData.name,
        description: formData.description || null,
        goal: formData.goal,
        difficulty: formData.difficulty,
        estimated_duration_min: parseInt(formData.estimated_duration_min, 10),
        is_public: formData.is_public,
        exercises: exercises.map((ex, index) => ({
          exercise_id: ex.exercise.id,
          order_index: index + 1,
          sets: parseInt(ex.sets, 10),
          reps_target: ex.reps_target,
          rest_seconds: parseInt(ex.rest_seconds, 10) || null,
          notes: ex.notes || null,
          superset_group: null
        }))
      };

      if (templateToEdit) {
        await trainingService.updateTemplate(templateToEdit.id, payload);
      } else {
        await trainingService.createTemplate(payload);
      }
      onSuccess();
      onClose();
    } catch (err) {
      console.error("Error saving template:", err);
      setError(err.response?.data?.detail || "Ocurrió un error al guardar la plantilla.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm">
      <div className="bg-slate-900 border border-slate-700 rounded-xl shadow-2xl w-full max-w-4xl max-h-[90vh] flex flex-col">
        
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-slate-800">
          <h2 className="text-2xl font-bold text-white">{templateToEdit ? 'Editar Plantilla' : 'Crear Nueva Plantilla'}</h2>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 overflow-y-auto flex-1 custom-scrollbar">
          {error && (
            <div className="bg-red-500/10 border border-red-500/50 text-red-400 p-4 rounded-lg mb-6 text-sm">
              {error}
            </div>
          )}

          <form id="template-form" onSubmit={handleSubmit} className="space-y-8">
            
            {/* General Info */}
            <div className="space-y-4">
              <h3 className="text-lg font-semibold text-cyan-400 border-b border-slate-800 pb-2">Datos Generales</h3>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Nombre *</label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleInputChange}
                    className={`w-full bg-slate-800 border ${validationErrors.name ? 'border-red-500' : 'border-slate-700'} rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-500`}
                    placeholder="Ej. Empuje Hipertrofia"
                  />
                  {validationErrors.name && <p className="text-red-400 text-xs mt-1">{validationErrors.name}</p>}
                </div>
                
                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Duración Est. (min)</label>
                  <input
                    type="number"
                    name="estimated_duration_min"
                    value={formData.estimated_duration_min}
                    onChange={handleInputChange}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-500"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Objetivo</label>
                  <select
                    name="goal"
                    value={formData.goal}
                    onChange={handleInputChange}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-500"
                  >
                    {GOAL_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-slate-300 mb-1">Dificultad</label>
                  <select
                    name="difficulty"
                    value={formData.difficulty}
                    onChange={handleInputChange}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-500"
                  >
                    {DIFFICULTY_OPTIONS.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>

                <div className="md:col-span-2">
                  <label className="block text-sm font-medium text-slate-300 mb-1">Descripción</label>
                  <textarea
                    name="description"
                    value={formData.description}
                    onChange={handleInputChange}
                    rows={2}
                    className="w-full bg-slate-800 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none focus:border-cyan-500"
                    placeholder="Notas generales de la rutina..."
                  />
                </div>
              </div>
            </div>

            {/* Exercises */}
            <div className="space-y-4">
              <div className="flex items-center justify-between border-b border-slate-800 pb-2">
                <h3 className="text-lg font-semibold text-cyan-400">Ejercicios</h3>
                <button
                  type="button"
                  onClick={addExercise}
                  className="text-xs btn-secondary flex items-center gap-1 py-1 px-3"
                >
                  <Plus className="h-3 w-3" /> Añadir Fila
                </button>
              </div>

              <div className="space-y-4">
                {exercises.map((ex, idx) => (
                  <div key={idx} className="bg-slate-800/50 p-4 rounded-lg border border-slate-700/50 flex flex-col md:flex-row gap-4 items-start">
                    <div className="flex-none flex items-center justify-center w-8 h-8 rounded-full bg-slate-700 text-slate-300 font-bold">
                      {idx + 1}
                    </div>
                    
                    <div className="flex-1 grid grid-cols-1 md:grid-cols-12 gap-4 w-full">
                      <div className="md:col-span-5">
                        <div className="flex justify-between items-center mb-1">
                          <label className="block text-xs text-slate-400">Ejercicio *</label>
                          <button 
                            type="button"
                            onClick={() => {
                              setTargetExerciseIndex(idx);
                              setIsExerciseDBModalOpen(true);
                            }}
                            className="text-[10px] text-cyan-400 hover:underline"
                          >
                            + Buscar Externo
                          </button>
                        </div>
                        <ExerciseSearchSelect
                          value={ex.exercise}
                          onChange={(val) => handleExerciseChange(idx, 'exercise', val)}
                          error={validationErrors[`exercise_${idx}`]}
                        />
                      </div>
                      
                      <div className="md:col-span-2">
                        <label className="block text-xs text-slate-400 mb-1">Series *</label>
                        <input
                          type="number"
                          min="1" max="20"
                          value={ex.sets}
                          onChange={(e) => handleExerciseChange(idx, 'sets', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none"
                        />
                      </div>

                      <div className="md:col-span-2">
                        <label className="block text-xs text-slate-400 mb-1">Reps *</label>
                        <input
                          type="text"
                          value={ex.reps_target}
                          onChange={(e) => handleExerciseChange(idx, 'reps_target', e.target.value)}
                          placeholder="Ej: 8-12"
                          className={`w-full bg-slate-900 border ${validationErrors[`reps_${idx}`] ? 'border-red-500' : 'border-slate-700'} rounded-md py-2 px-3 text-white focus:outline-none`}
                        />
                      </div>

                      <div className="md:col-span-3">
                        <label className="block text-xs text-slate-400 mb-1">Descanso (s)</label>
                        <input
                          type="number"
                          value={ex.rest_seconds}
                          onChange={(e) => handleExerciseChange(idx, 'rest_seconds', e.target.value)}
                          className="w-full bg-slate-900 border border-slate-700 rounded-md py-2 px-3 text-white focus:outline-none"
                        />
                      </div>
                    </div>

                    <button
                      type="button"
                      onClick={() => removeExercise(idx)}
                      disabled={exercises.length === 1}
                      className="text-slate-500 hover:text-red-400 disabled:opacity-30 disabled:hover:text-slate-500 mt-6"
                      title="Eliminar ejercicio"
                    >
                      <Trash2 className="h-5 w-5" />
                    </button>
                  </div>
                ))}
              </div>
            </div>

          </form>
        </div>

        {/* Footer */}
        <div className="p-6 border-t border-slate-800 flex justify-end gap-3 bg-slate-900/80 rounded-b-xl">
          <button
            type="button"
            onClick={onClose}
            className="btn-secondary"
            disabled={loading}
          >
            Cancelar
          </button>
          <button
            type="submit"
            form="template-form"
            className="btn-primary flex items-center gap-2"
            disabled={loading}
          >
            <Save className="h-4 w-4" />
            {templateToEdit ? 'Guardar Cambios' : 'Crear Plantilla'}
          </button>
        </div>
      </div>

      {/* Modal de búsqueda externa */}
      <ExerciseDBModal 
        isOpen={isExerciseDBModalOpen} 
        onClose={() => {
          setIsExerciseDBModalOpen(false);
          setTargetExerciseIndex(null);
        }} 
        onImportSuccess={(localExercise) => {
          if (targetExerciseIndex !== null) {
            handleExerciseChange(targetExerciseIndex, 'exercise', localExercise);
          }
          setIsExerciseDBModalOpen(false);
          setTargetExerciseIndex(null);
        }}
      />
    </div>
  );
};

export default CreateTemplateModal;
