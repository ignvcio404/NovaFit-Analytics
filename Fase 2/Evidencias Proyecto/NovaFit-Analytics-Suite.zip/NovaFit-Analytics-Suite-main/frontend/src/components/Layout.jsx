import React, { useContext } from 'react';
import Navbar from './Navbar';
import { NavLink } from 'react-router-dom';
import { LayoutDashboard, Dumbbell, ClipboardList, TrendingUp, Activity, CreditCard, Users } from 'lucide-react';
import { AuthContext } from '../context/AuthContext';

const Layout = ({ children }) => {
  const { user } = useContext(AuthContext);

  const isTrainer = user && (user.role === 'trainer' || user.role === 'super_admin' || 
                    (Array.isArray(user.roles) && (user.roles.includes('trainer') || user.roles.includes('super_admin'))));

  const athleteNavItems = [
    { to: '/', label: 'Panel General', icon: LayoutDashboard, end: true },
    { to: '/sessions', label: 'Sesiones', icon: Dumbbell },
    { to: '/templates', label: 'Plantillas', icon: ClipboardList },
    { to: '/analytics/volume', label: 'Progreso de Volumen', icon: TrendingUp },
    { to: '/analytics/fatigue', label: 'Fatiga y Descarga', icon: Activity },
    { to: '/billing', label: 'Mis Pagos', icon: CreditCard },
  ];

  const trainerNavItems = [
    { to: '/admin', label: 'Panel General', icon: LayoutDashboard, end: true },
    { to: '/admin/athletes', label: 'Mis Atletas', icon: Users },
    { to: '/admin/routines', label: 'Asignación de Rutinas', icon: ClipboardList },
  ];

  const navItems = isTrainer ? trainerNavItems : athleteNavItems;

  return (
    <div className="min-h-screen bg-[var(--color-bg-base)] flex flex-col">
      <Navbar />
      
      <div className="flex flex-1 overflow-hidden px-4 pb-4 gap-6 flex-col md:flex-row">
        {/* Sidebar */}
        <aside className="w-full md:w-64 flex-shrink-0">
          <div className="glass-panel p-4 h-full flex flex-col">
            <h3 className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-4 px-3">
              {isTrainer ? 'Portal Entrenador' : 'Navegación'}
            </h3>
            <nav className="flex flex-col gap-2 flex-1">
              {navItems.map((item) => {
                const Icon = item.icon;
                return (
                  <NavLink
                    key={item.to}
                    to={item.to}
                    end={item.end}
                    className={({ isActive }) =>
                      `flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 ${
                        isActive
                          ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_10px_rgba(0,229,255,0.05)]'
                          : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800'
                      }`
                    }
                  >
                    <Icon className="h-5 w-5" />
                    <span className="font-medium">{item.label}</span>
                  </NavLink>
                );
              })}
            </nav>
            {isTrainer && (
              <div className="mt-4 pt-4 border-t border-slate-700/50">
                <div className="px-3 py-2 text-xs text-slate-500 text-center">
                  Modo Gestión Activo
                </div>
              </div>
            )}
          </div>
        </aside>

        {/* Main Content */}
        <main className="flex-1 overflow-y-auto">
          <div className="h-full">
            {children}
          </div>
        </main>
      </div>
    </div>
  );
};

export default Layout;
