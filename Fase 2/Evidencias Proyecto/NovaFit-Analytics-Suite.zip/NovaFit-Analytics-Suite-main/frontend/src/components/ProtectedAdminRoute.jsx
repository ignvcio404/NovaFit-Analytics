/**
 * NovaFit Analytics Suite
 * ========================
 * ProtectedAdminRoute
 * ========================
 *
 * Role-gated wrapper for /admin/* routes.
 * Allows only users with role: 'trainer' | 'super_admin'.
 * Athletes who try to navigate here are redirected to their dashboard.
 *
 * Does NOT re-check membership status — admins are always allowed through
 * regardless of their own membership (they manage others').
 */

import React, { useContext } from 'react';
import { Navigate } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { Loader } from 'lucide-react';

const ADMIN_ROLES = ['trainer', 'super_admin'];

const isAdminRole = (user) => {
  if (!user) return false;
  if (ADMIN_ROLES.includes(user.role)) return true;
  if (Array.isArray(user.roles) && user.roles.some((r) => ADMIN_ROLES.includes(r))) return true;
  return false;
};

const ProtectedAdminRoute = ({ children }) => {
  const { user, loading } = useContext(AuthContext);

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[var(--color-bg-base)]">
        <Loader className="h-10 w-10 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  if (!isAdminRole(user)) {
    // Athlete tried to access admin area → send back to athlete dashboard
    return <Navigate to="/" replace />;
  }

  return children;
};

export default ProtectedAdminRoute;
