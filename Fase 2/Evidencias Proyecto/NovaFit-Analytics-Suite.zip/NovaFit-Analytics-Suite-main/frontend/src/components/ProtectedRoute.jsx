import React, { useContext } from 'react';
import { Navigate, useLocation } from 'react-router-dom';
import { AuthContext } from '../context/AuthContext';
import { useMembership } from '../context/MembershipContext';
import { Loader } from 'lucide-react';
import ExpiredMembership from '../pages/ExpiredMembership';

// Routes that remain accessible even with an expired membership
const ALWAYS_ALLOWED = ['/billing', '/payment/success', '/payment/failure'];

const ProtectedRoute = ({ children }) => {
  const { user, loading } = useContext(AuthContext);
  const { isBlocked, membershipStatus } = useMembership();
  const location = useLocation();

  if (loading || membershipStatus === 'loading') {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-[var(--color-bg-base)]">
        <Loader className="h-10 w-10 animate-spin text-cyan-400" />
      </div>
    );
  }

  if (!user) {
    return <Navigate to="/login" replace />;
  }

  // If membership is blocked but user is on an allowed route, let them through
  const isAllowedRoute = ALWAYS_ALLOWED.some((path) =>
    location.pathname.startsWith(path)
  );

  if (isBlocked && !isAllowedRoute) {
    return <ExpiredMembership />;
  }

  return children;
};

export default ProtectedRoute;
