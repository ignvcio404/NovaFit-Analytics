import React, { useContext, useState, useEffect, useRef } from 'react';
import { AuthContext } from '../context/AuthContext';
import { LogOut, User as UserIcon, Activity, Bell, Check, X, Loader2 } from 'lucide-react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../services/api';
import toast from 'react-hot-toast';

const Navbar = () => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [invitations, setInvitations] = useState([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [loading, setLoading] = useState(false);
  const dropdownRef = useRef(null);

  const isAthlete = user && user.role !== 'trainer' && user.role !== 'super_admin' && 
                    !(Array.isArray(user.roles) && (user.roles.includes('trainer') || user.roles.includes('super_admin')));

  const fetchInvitations = async () => {
    if (!isAthlete) return;
    try {
      const response = await api.get('/api/v1/trainer/invitations/pending');
      setInvitations(response.data || []);
    } catch (error) {
      console.error("Error fetching invitations:", error);
    }
  };

  useEffect(() => {
    fetchInvitations();
    // Refresh every 30 seconds
    const interval = setInterval(fetchInvitations, 30000);
    return () => clearInterval(interval);
  }, [isAthlete]);

  useEffect(() => {
    const handleClickOutside = (event) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setShowDropdown(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleAccept = async (linkId) => {
    try {
      setLoading(true);
      await api.post(`/api/v1/trainer/invitations/${linkId}/accept`);
      toast.success('Invitación aceptada');
      fetchInvitations();
    } catch (error) {
      toast.error('Error al aceptar la invitación');
    } finally {
      setLoading(false);
    }
  };

  const handleReject = async (linkId) => {
    try {
      setLoading(true);
      await api.post(`/api/v1/trainer/invitations/${linkId}/reject`);
      toast.success('Invitación rechazada');
      fetchInvitations();
    } catch (error) {
      toast.error('Error al rechazar la invitación');
    } finally {
      setLoading(false);
    }
  };

  return (
    <nav className="glass-panel sticky top-0 z-50 flex items-center justify-between px-6 py-4 mx-4 mt-4 mb-6">
      <Link to="/" className="flex items-center gap-3">
        <img 
          src="https://uxvyjopnmxiwfbtvnbxi.supabase.co/storage/v1/object/sign/assets/logo.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MzM4Y2RiMC05NTY0LTRhMjktOWFmYS0xZjdkODU2OTRjMDUiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvbG9nby5wbmciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzg2MTcxMDA0LCJleHAiOjE4MTc3MDcwMDR9.V2vualki_oTjY-8tIcYxXA71haxKaFa_BhpBgX9OPTI" 
          alt="NovaFit Logo" 
          className="h-10 w-auto drop-shadow-md"
        />
        <span className="text-xl font-bold tracking-tight text-white hidden sm:block">
          NovaFit <span className="text-cyan-400">Análisis</span>
        </span>
      </Link>

      {user && (
        <div className="flex items-center gap-4 sm:gap-6">
          {/* Notifications Dropdown */}
          {isAthlete && (
            <div className="relative" ref={dropdownRef}>
              <button 
                onClick={() => setShowDropdown(!showDropdown)}
                className="relative p-2 text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 rounded-lg transition-colors border border-slate-700"
              >
                <Bell className="h-5 w-5" />
                {invitations.length > 0 && (
                  <span className="absolute -top-1 -right-1 h-4 w-4 bg-red-500 rounded-full flex items-center justify-center text-[10px] font-bold text-white border border-slate-900">
                    {invitations.length}
                  </span>
                )}
              </button>

              {showDropdown && (
                <div className="absolute right-0 mt-2 w-80 bg-slate-800 border border-slate-700 rounded-xl shadow-2xl overflow-hidden z-50">
                  <div className="px-4 py-3 bg-slate-800/80 border-b border-slate-700">
                    <h3 className="text-sm font-semibold text-white">Invitaciones Pendientes</h3>
                  </div>
                  <div className="max-h-[300px] overflow-y-auto">
                    {invitations.length === 0 ? (
                      <div className="px-4 py-6 text-center text-sm text-slate-400">
                        No tienes invitaciones nuevas.
                      </div>
                    ) : (
                      <ul className="divide-y divide-slate-700/50">
                        {invitations.map((inv) => (
                          <li key={inv.link_id} className="px-4 py-3 hover:bg-slate-700/30 transition-colors">
                            <p className="text-sm text-slate-200 mb-2">
                              <span className="font-semibold text-cyan-400">{inv.trainer_first_name} {inv.trainer_last_name}</span> te ha invitado a unirte como su atleta.
                            </p>
                            <div className="flex items-center gap-2 mt-2">
                              <button 
                                onClick={() => handleAccept(inv.link_id)}
                                disabled={loading}
                                className="flex-1 flex items-center justify-center gap-1 bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-400 py-1.5 rounded-lg text-xs font-medium transition-colors disabled:opacity-50"
                              >
                                {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <Check className="h-3 w-3" />} Aceptar
                              </button>
                              <button 
                                onClick={() => handleReject(inv.link_id)}
                                disabled={loading}
                                className="flex-1 flex items-center justify-center gap-1 bg-red-500/10 hover:bg-red-500/20 text-red-400 py-1.5 rounded-lg text-xs font-medium transition-colors disabled:opacity-50"
                              >
                                {loading ? <Loader2 className="h-3 w-3 animate-spin" /> : <X className="h-3 w-3" />} Rechazar
                              </button>
                            </div>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              )}
            </div>
          )}

          <div className="flex items-center gap-3 hidden sm:flex border-l border-slate-700 pl-6">
            <div className="h-10 w-10 bg-slate-700 rounded-full flex items-center justify-center border border-slate-600">
              <UserIcon className="h-5 w-5 text-slate-300" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-slate-100">{user.first_name} {user.last_name}</span>
              <span className="text-xs text-slate-400">{user.email}</span>
            </div>
          </div>
          
          <button 
            onClick={handleLogout}
            className="flex items-center gap-2 text-sm font-medium text-slate-300 hover:text-white bg-slate-800 hover:bg-slate-700 py-2 px-4 rounded-lg transition-colors border border-slate-700"
          >
            <LogOut className="h-4 w-4" />
            <span className="hidden sm:inline">Cerrar Sesión</span>
          </button>
        </div>
      )}
    </nav>
  );
};

export default Navbar;
