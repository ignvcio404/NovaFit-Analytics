/**
 * NovaFit Analytics Suite
 * ========================
 * AdminLayout — Web Admin Dashboard
 * ========================
 *
 * Specialized layout for Admins and Trainers.
 * Renders a rich glassmorphism sidebar with role-aware navigation
 * grouped by domain: Core, Financiero, Entrenamiento.
 *
 * This layout is ONLY used for /admin/* routes.
 * Athletes land on the regular Layout (src/components/Layout.jsx).
 */

import React, { useContext, useState } from 'react';
import { NavLink, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Users,
  Building2,
  CreditCard,
  AlertTriangle,
  ClipboardList,
  Dumbbell,
  ChevronLeft,
  ChevronRight,
  LogOut,
  Shield,
  Activity,
  BarChart3,
  Settings,
  Zap,
  MapPin,
  HeartPulse
} from 'lucide-react';
import { AuthContext } from '../context/AuthContext';
import Navbar from './Navbar';

// ─────────────────────────────────────────────────────────────────────────────
// Navigation map — grouped by domain
// ─────────────────────────────────────────────────────────────────────────────

const NAV_SECTIONS = [
  {
    id: 'core',
    label: 'Core',
    items: [
      { to: '/admin', label: 'Panel General', icon: LayoutDashboard, end: true },
      { to: '/admin/billing', label: 'Facturación & Morosidad', icon: CreditCard, roles: ['super_admin'] },
      { to: '/admin/risk-fatigue', label: 'Riesgo y Fatiga', icon: HeartPulse },
      { to: '/admin/athletes', label: 'Mis Atletas', icon: Users, roles: ['trainer'] },
      { to: '/admin/users', label: 'Usuarios', icon: Users, roles: ['super_admin'] },
      { to: '/admin/plans', label: 'Gestión de Planes', icon: ClipboardList, roles: ['super_admin'] },
      { to: '/admin/trainers', label: 'Entrenadores', icon: Users, roles: ['super_admin'] },
      { to: '/admin/branches', label: 'Sucursales', icon: MapPin, roles: ['super_admin'] },
    ],
  },
  {
    id: 'training',
    label: 'Entrenamiento',
    items: [
      { to: '/admin/templates', label: 'Plantillas Maestras', icon: ClipboardList },
      { to: '/admin/routines', label: 'Asignación de Rutinas', icon: Dumbbell, roles: ['trainer'] },
    ],
  },

];

// ─────────────────────────────────────────────────────────────────────────────
// Role badge helper
// ─────────────────────────────────────────────────────────────────────────────

const getRoleBadge = (user) => {
  const role = user?.role || (Array.isArray(user?.roles) ? user.roles[0] : '');
  if (role === 'super_admin') return { label: 'Super Admin', color: 'text-violet-400 bg-violet-500/10 border-violet-500/20' };
  if (role === 'trainer') return { label: 'Entrenador', color: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20' };
  return { label: 'Admin', color: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20' };
};

// ─────────────────────────────────────────────────────────────────────────────
// Sidebar NavItem
// ─────────────────────────────────────────────────────────────────────────────

const SidebarItem = ({ item, collapsed }) => {
  const Icon = item.icon;
  return (
    <NavLink
      to={item.to}
      end={item.end}
      title={collapsed ? item.label : undefined}
      className={({ isActive }) =>
        `group relative flex items-center gap-3 px-3 py-2.5 rounded-xl transition-all duration-200 ${
          isActive
            ? 'bg-cyan-500/10 text-cyan-400 border border-cyan-500/20 shadow-[0_0_12px_rgba(0,229,255,0.07)]'
            : 'text-slate-400 hover:text-slate-100 hover:bg-slate-800/60 border border-transparent'
        } ${collapsed ? 'justify-center' : ''}`
      }
    >
      <Icon className="h-[18px] w-[18px] flex-shrink-0" />
      {!collapsed && (
        <span className="text-sm font-medium truncate">{item.label}</span>
      )}
      {/* Tooltip when collapsed */}
      {collapsed && (
        <span className="absolute left-full ml-3 px-2 py-1 bg-slate-800 text-white text-xs rounded-lg border border-slate-700 whitespace-nowrap opacity-0 group-hover:opacity-100 pointer-events-none transition-opacity z-50 shadow-xl">
          {item.label}
        </span>
      )}
    </NavLink>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Main AdminLayout component
// ─────────────────────────────────────────────────────────────────────────────

const AdminLayout = ({ children }) => {
  const { user, logout } = useContext(AuthContext);
  const navigate = useNavigate();
  const [collapsed, setCollapsed] = useState(false);
  const badge = getRoleBadge(user);
  const role = user?.role || (Array.isArray(user?.roles) ? user.roles[0] : '');

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  return (
    <div className="h-screen bg-[var(--color-bg-base)] flex flex-col">
      <Navbar />

      <div className="flex flex-1 overflow-hidden px-4 pb-4 gap-4">
        {/* ── Sidebar ───────────────────────────────────────────────────────── */}
        <aside
          className={`flex-shrink-0 transition-all duration-300 ease-in-out ${
            collapsed ? 'w-16' : 'w-64'
          }`}
        >
          <div className="glass-panel h-full flex flex-col py-4 overflow-y-auto">

            {/* Header — Role badge + collapse toggle */}
            <div className={`flex items-center mb-6 px-3 ${collapsed ? 'justify-center' : 'justify-between'}`}>
              {!collapsed && (
                <div className="flex items-center gap-2 min-w-0">
                  <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0 shadow-[0_0_12px_rgba(0,229,255,0.3)]">
                    <Shield className="h-4 w-4 text-white" />
                  </div>
                  <div className="min-w-0">
                    <p className="text-xs font-bold text-white truncate">
                      {role === 'trainer' ? 'Portal Entrenador' : 'Portal Admin'}
                    </p>
                    <span className={`text-[10px] font-semibold px-1.5 py-0.5 rounded-md border ${badge.color}`}>
                      {badge.label}
                    </span>
                  </div>
                </div>
              )}
              <button
                id="admin-sidebar-toggle"
                onClick={() => setCollapsed(!collapsed)}
                className="p-1.5 rounded-lg text-slate-400 hover:text-white hover:bg-slate-700 transition-colors flex-shrink-0"
                aria-label={collapsed ? 'Expandir sidebar' : 'Colapsar sidebar'}
              >
                {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
              </button>
            </div>

            {/* Live indicator */}
            {!collapsed && (
              <div className="mx-3 mb-5 px-3 py-2 rounded-xl bg-emerald-500/5 border border-emerald-500/20 flex items-center gap-2">
                <span className="relative flex h-2 w-2">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75" />
                  <span className="relative inline-flex rounded-full h-2 w-2 bg-emerald-500" />
                </span>
                <span className="text-[11px] font-medium text-emerald-400">Sistema Operativo</span>
              </div>
            )}

            {/* Navigation sections */}
            <nav className="flex flex-col gap-1 flex-1 px-3">
              {NAV_SECTIONS.map((section, sIdx) => {
                const role = user?.role || (Array.isArray(user?.roles) ? user.roles[0] : '');
                
                // Filter items by role explicitly
                const visibleItems = section.items.filter(item => {
                  if (!item.roles) return true; // Available to all
                  return item.roles.includes(role);
                });

                if (visibleItems.length === 0) return null;

                return (
                <div key={section.id} className={sIdx > 0 ? 'mt-5' : ''}>
                  {!collapsed && (
                    <p className="text-[10px] font-bold text-slate-500 uppercase tracking-widest mb-2 px-3">
                      {section.label}
                    </p>
                  )}
                  {collapsed && sIdx > 0 && (
                    <div className="my-2 border-t border-slate-700/50 mx-2" />
                  )}
                  <div className="flex flex-col gap-0.5">
                    {visibleItems.map((item) => (
                      <SidebarItem key={item.to} item={item} collapsed={collapsed} />
                    ))}
                  </div>
                </div>
                );
              })}
            </nav>

            {/* Footer — User info + logout */}
            <div className={`mt-4 pt-4 border-t border-slate-700/50 px-3 ${collapsed ? 'flex justify-center' : ''}`}>
              {!collapsed ? (
                <div className="flex flex-col gap-3">
                  <div className="flex items-center gap-3 px-2">
                    <div className="h-8 w-8 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center border border-slate-600 flex-shrink-0">
                      <span className="text-xs font-bold text-white">
                        {user?.first_name?.[0]}{user?.last_name?.[0]}
                      </span>
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-slate-200 truncate">
                        {user?.first_name} {user?.last_name}
                      </p>
                      <p className="text-[10px] text-slate-500 truncate">{user?.email}</p>
                    </div>
                  </div>
                  <button
                    id="admin-logout-btn"
                    onClick={handleLogout}
                    className="flex items-center gap-2 px-3 py-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/5 border border-transparent hover:border-red-500/10 transition-all duration-200 text-sm"
                  >
                    <LogOut className="h-4 w-4" />
                    <span>Cerrar Sesión</span>
                  </button>
                </div>
              ) : (
                <button
                  onClick={handleLogout}
                  title="Cerrar Sesión"
                  className="p-2 rounded-xl text-slate-400 hover:text-red-400 hover:bg-red-500/5 transition-all duration-200"
                >
                  <LogOut className="h-4 w-4" />
                </button>
              )}
            </div>
          </div>
        </aside>

        {/* ── Main Content ──────────────────────────────────────────────────── */}
        <main className="flex-1 overflow-y-auto min-w-0">
          {/* Breadcrumb-style mode indicator */}
          <div className="flex items-center gap-2 mb-4">
            <Zap className="h-3.5 w-3.5 text-cyan-400" />
            <span className="text-xs text-slate-500 font-medium">Modo Gestión Activo</span>
            <Activity className="h-3 w-3 text-emerald-400 ml-auto" />
          </div>
          {children}
        </main>
      </div>
    </div>
  );
};

export default AdminLayout;
