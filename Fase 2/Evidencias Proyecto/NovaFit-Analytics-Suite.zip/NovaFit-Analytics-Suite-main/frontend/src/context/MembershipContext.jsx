/**
 * MembershipContext
 * =================
 * Provides membership status information to the entire app.
 *
 * Queries GET /api/v1/billing/my-invoices on mount (after the user is
 * authenticated) and infers the current membership state from the response.
 *
 * Exposed values:
 *   membershipStatus  "active" | "expired" | "pending" | "none" | "loading"
 *   isBlocked         boolean — true when a member has no active membership
 *   daysRemaining     number | null — days until expiry (null if not applicable)
 *   refresh()         function — re-fetch membership data (call after payment)
 */

import React, {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
} from "react";
import api from "../services/api";
import { useAuth } from "./AuthContext";

const MembershipContext = createContext(null);

export function MembershipProvider({ children }) {
  const { user } = useAuth();

  const [membershipStatus, setMembershipStatus] = useState("loading");
  const [daysRemaining, setDaysRemaining] = useState(null);
  const [isBlocked, setIsBlocked] = useState(false);

  // Staff roles never get blocked — they don't need a paid membership
  const isStaff = () => {
    if (!user?.roles) return false;
    const roleNames = user.roles.map((r) => r.name ?? r);
    return roleNames.some((n) => ["trainer", "super_admin"].includes(n));
  };

  const inferStatus = useCallback((invoices) => {
    if (!invoices || invoices.length === 0) {
      setMembershipStatus("none");
      setIsBlocked(true);
      setDaysRemaining(null);
      return;
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);

    // Find the most recent PAID invoice whose membership is still active.
    // The backend marks the membership as ACTIVE and sets the end_date on payment.
    // We infer this from the invoice paid_at date + approximate duration.
    // The cleanest signal: look for any invoice with status "paid" and a
    // membership end_date that is still in the future.
    // Since we don't get end_date directly from my-invoices, we use a dedicated
    // membership endpoint if available, otherwise fall back to invoice dates.

    // Sort invoices by paid_at descending, pick the first PAID one
    const sorted = [...invoices].sort(
      (a, b) => new Date(b.paid_at ?? 0) - new Date(a.paid_at ?? 0)
    );
    const lastPaid = sorted.find((inv) => inv.status === "paid");

    if (!lastPaid) {
      setMembershipStatus("pending");
      setIsBlocked(true);
      setDaysRemaining(null);
      return;
    }

    // Use due_date as a proxy for membership end_date when end_date isn't exposed
    const endDate = lastPaid.membership_end_date
      ? new Date(lastPaid.membership_end_date)
      : null;

    if (endDate) {
      endDate.setHours(0, 0, 0, 0);
      const diffMs = endDate - today;
      const diffDays = Math.ceil(diffMs / (1000 * 60 * 60 * 24));

      if (diffDays >= 0) {
        setMembershipStatus("active");
        setIsBlocked(false);
        setDaysRemaining(diffDays);
      } else {
        setMembershipStatus("expired");
        setIsBlocked(true);
        setDaysRemaining(diffDays); // negative = days overdue
      }
    } else {
      // No end_date exposed — trust the backend 403 interceptor to block
      setMembershipStatus("active");
      setIsBlocked(false);
      setDaysRemaining(null);
    }
  }, []);

  const refresh = useCallback(async () => {
    if (!user) {
      setMembershipStatus("none");
      setIsBlocked(false);
      return;
    }

    // Staff bypass — never block trainers or admins
    if (isStaff()) {
      setMembershipStatus("active");
      setIsBlocked(false);
      setDaysRemaining(null);
      return;
    }

    try {
      const { data } = await api.get("/api/v1/billing/my-invoices");
      inferStatus(data);
    } catch (err) {
      // If the request fails (network error etc.), don't block the user
      // — the backend 403 is the authoritative gate
      setMembershipStatus("active");
      setIsBlocked(false);
    }
  }, [user, inferStatus]);

  // Listen for the membership-expired event dispatched by api.js interceptor
  useEffect(() => {
    const handleExpired = () => {
      setMembershipStatus("expired");
      setIsBlocked(true);
    };
    window.addEventListener("membership-expired", handleExpired);
    return () => window.removeEventListener("membership-expired", handleExpired);
  }, []);

  // Fetch on mount and whenever the user changes
  useEffect(() => {
    if (user) {
      refresh();
    } else {
      setMembershipStatus("none");
      setIsBlocked(false);
    }
  }, [user, refresh]);

  return (
    <MembershipContext.Provider
      value={{ membershipStatus, isBlocked, daysRemaining, refresh }}
    >
      {children}
    </MembershipContext.Provider>
  );
}

export function useMembership() {
  const ctx = useContext(MembershipContext);
  if (!ctx) throw new Error("useMembership must be used within MembershipProvider");
  return ctx;
}
