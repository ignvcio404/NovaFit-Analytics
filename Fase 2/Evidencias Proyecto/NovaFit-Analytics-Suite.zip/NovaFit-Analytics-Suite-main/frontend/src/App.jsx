/**
 * NovaFit Analytics Suite — Frontend Router
 * ==========================================
 *
 * Arquitectura de rutas FINAL:
 *
 *  /login, /register, /forgot-password, /reset-password  → Auth (público)
 *  /payment/*                                             → Resultado de pago (público)
 *
 *  /admin/*   → ProtectedAdminRoute + AdminLayout → TRAINERS & SUPER_ADMIN
 *  /*         → Fallback / Redirección. Atletas ven pantalla de "Usa la App".
 */

import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './context/AuthContext';
import { MembershipProvider } from './context/MembershipContext';
import { Toaster } from 'react-hot-toast';

// ── Guards & Layouts ──────────────────────────────────────────────────────────
import ProtectedAdminRoute from './components/ProtectedAdminRoute';
import AdminLayout from './components/AdminLayout';

// ── Auth Pages ────────────────────────────────────────────────────────────────
import Login from './pages/Login';

import ForgotPassword from './pages/ForgotPassword';
import ResetPassword from './pages/ResetPassword';

// ── Trainer & Admin Pages ─────────────────────────────────────────────────────
import TrainerDashboard from './pages/TrainerDashboard';
import TrainerAthletes from './pages/TrainerAthletes';
import TemplatesList from './pages/TemplatesList';
import TrainerRoutines from './pages/TrainerRoutines';
import AdminDashboard from './pages/admin/AdminDashboard';
import UserManagement from './pages/admin/UserManagement';
import TrainerManagement from './pages/admin/TrainerManagement';
import BillingDashboard from './pages/admin/BillingDashboard';
import BranchesDashboard from './pages/admin/BranchesDashboard';

import PlansManagement from './pages/admin/PlansManagement';
import RiskAndFatigueDashboard from './pages/admin/RiskAndFatigueDashboard';

// ── Global ────────────────────────────────────────────────────────────────────
import PaymentResult from './pages/PaymentResult';
import NotFound from './pages/NotFound';

// ── Role Route Protector ────────────────────────────────────────────────────
const RoleRoute = ({ children, allowedRoles }) => {
  const { user } = useAuth();
  if (!user) return <Navigate to="/login" replace />;
  const userRoles = Array.isArray(user.roles) ? user.roles : (user.role ? [user.role] : []);
  const hasAccess = userRoles.some(r => allowedRoles.includes(r));
  if (!hasAccess) return <Navigate to="/admin" replace />;
  return children;
};

// ── Admin Index Delegator ───────────────────────────────────────────────────
const AdminIndex = () => {
  const { user } = useAuth();
  if (user?.roles?.includes('super_admin') || user?.roles?.includes('branch_admin')) {
    return <AdminDashboard />;
  }
  return <TrainerDashboard />;
};

// ── Root Redirector ─────────────────────────────────────────────────────────
const RootRedirector = () => {
  const { user, isLoading } = useAuth();
  
  if (isLoading) return null;
  
  if (!user) {
    return <Navigate to="/login" replace />;
  }
  
  if (user.roles?.includes('athlete') && !user.roles?.includes('trainer') && !user.roles?.includes('super_admin')) {
    return (
      <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', justifyContent: 'center', height: '100vh', backgroundColor: '#0f172a', color: '#f8fafc', padding: '20px', textAlign: 'center' }}>
        <h1 style={{ fontSize: '2rem', marginBottom: '16px', color: '#00e5ff' }}>NovaFit App Móvil</h1>
        <p style={{ fontSize: '1.2rem', color: '#94a3b8', maxWidth: '400px' }}>
          La plataforma web es ahora de uso exclusivo para el staff. Por favor, descarga e inicia sesión en nuestra aplicación móvil para ver tu progreso, agendar sesiones y revisar tu membresía.
        </p>
      </div>
    );
  }
  
  return <Navigate to="/admin" replace />;
};

function App() {
  return (
    <AuthProvider>
      <MembershipProvider>
        <Router>
          <Routes>
            {/* ── Public Auth Routes ───────────────────────────────────── */}
            <Route path="/login" element={<Login />} />

            <Route path="/forgot-password" element={<ForgotPassword />} />
            <Route path="/reset-password" element={<ResetPassword />} />
            <Route path="/payment/success" element={<PaymentResult />} />
            <Route path="/payment/failure" element={<PaymentResult />} />

            {/* ── Admin Routes (/admin/*) ──────────────────────────────── */}
            <Route
              path="/admin/*"
              element={
                <ProtectedAdminRoute>
                  <AdminLayout>
                    <Routes>
                      {/* Panel general delegado (Admin o Entrenador) */}
                      <Route index element={<AdminIndex />} />
                      {/* Gestión de atletas (Entrenador) */}
                      <Route path="athletes" element={<RoleRoute allowedRoles={['trainer']}><TrainerAthletes /></RoleRoute>} />
                      {/* Gestión de usuarios (Admin) */}
                      <Route path="users" element={<RoleRoute allowedRoles={['super_admin', 'branch_admin']}><UserManagement /></RoleRoute>} />
                      {/* Gestión de entrenadores (Admin) */}
                      <Route path="trainers" element={<RoleRoute allowedRoles={['super_admin', 'branch_admin']}><TrainerManagement /></RoleRoute>} />
                      {/* Creador de rutinas maestras */}
                      <Route path="templates" element={<TemplatesList />} />
                      {/* Asignación de rutinas */}
                      <Route path="routines" element={<RoleRoute allowedRoles={['trainer']}><TrainerRoutines /></RoleRoute>} />
                      {/* Riesgo y Fatiga */}
                      <Route path="risk-fatigue" element={<RiskAndFatigueDashboard />} />
                      {/* Facturación & morosidad */}
                      <Route path="billing" element={<RoleRoute allowedRoles={['super_admin', 'branch_admin']}><BillingDashboard /></RoleRoute>} />
                      {/* Sucursales */}
                      <Route path="branches" element={<RoleRoute allowedRoles={['super_admin']}><BranchesDashboard /></RoleRoute>} />
                      {/* Gestión de planes */}
                      <Route path="plans" element={<RoleRoute allowedRoles={['super_admin']}><PlansManagement /></RoleRoute>} />
                      {/* Analytics y reportes generales */}

                      {/* Catch-all dentro de /admin */}
                      <Route path="*" element={<NotFound />} />
                    </Routes>
                  </AdminLayout>
                </ProtectedAdminRoute>
              }
            />

            {/* ── Root Catch-All ───────────────────────────────────────── */}
            <Route path="/*" element={<RootRedirector />} />
          </Routes>
        </Router>
        <Toaster
          position="top-right"
          toastOptions={{
            style: {
              background: '#1e293b',
              color: '#f8fafc',
              border: '1px solid #334155',
              borderRadius: '12px',
            },
          }}
        />
      </MembershipProvider>
    </AuthProvider>
  );
}

export default App;
