import api from './api';

export const authService = {
  login: async (email, password) => {
    // The backend uses OAuth2PasswordRequestForm which requires x-www-form-urlencoded
    // Let's check the endpoint type. For /api/v1/auth/login we typically send form data.
    // If it expects JSON, we can use JSON. Let's send a standard OAuth2 form payload first.
    const params = new URLSearchParams();
    params.append('username', email); // OAuth2 expects 'username'
    params.append('password', password);
    
    const response = await api.post('/api/v1/auth/login', params, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });
    return response.data;
  },

  register: async (userData) => {
    // Expected to receive email, password, first_name, last_name, etc.
    const response = await api.post('/api/v1/auth/register', userData);
    return response.data;
  },
  
  getMe: async () => {
    const response = await api.get('/api/v1/auth/me');
    return response.data;
  },

  forgotPassword: async (email) => {
    const response = await api.post('/api/v1/auth/forgot-password', { email });
    return response.data;
  },

  resetPassword: async (token, new_password) => {
    const response = await api.post('/api/v1/auth/reset-password', { token, new_password });
    return response.data;
  }
};
