/**
 * NovaFit Analytics Suite
 * ========================
 * Billing Admin Service
 * ========================
 *
 * Encapsulates all API calls for the Admin Billing Dashboard.
 * Consumes endpoints under /api/v1/billing/admin/* which require
 * trainer or super_admin role (enforced server-side via RBAC).
 *
 * All calls flow through the shared `api` axios instance which
 * automatically injects the JWT Bearer token and handles 401/403 globally.
 */

import api from './api';

const BILLING_ADMIN_BASE = '/api/v1/billing/admin';
const BILLING_BASE = '/api/v1/billing';

// ─────────────────────────────────────────────────────────────────────────────
// READ — Invoices & Delinquency
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Fetch all invoices across all members.
 * @param {Object} params - Optional query params: { status, branch_id, page, limit }
 * @returns {Promise<Array>} Array of invoice objects
 */
export const fetchAllInvoices = async (params = {}) => {
  const response = await api.get(`${BILLING_ADMIN_BASE}/invoices`, { params });
  return response.data;
};

/**
 * Fetch all delinquent members (expired/overdue memberships).
 * @param {Object} params - Optional: { branch_id }
 * @returns {Promise<Array>} Array of delinquent member objects
 */
export const fetchDelinquentMembers = async (params = {}) => {
  const response = await api.get(`${BILLING_ADMIN_BASE}/delinquent`, { params });
  return response.data;
};

/**
 * Fetch billing summary KPIs for the admin dashboard header cards.
 * @returns {Promise<Object>} { total_collected, total_pending, delinquent_count, payment_rate }
 */
export const fetchBillingSummary = async () => {
  const response = await api.get(`${BILLING_ADMIN_BASE}/summary`);
  return response.data;
};

/**
 * Fetch monthly revenue data for the Recharts trend line.
 * @param {number} months - Number of months to look back (default: 6)
 * @returns {Promise<Array>} [{ month: "2025-01", revenue: 450000, invoices: 12 }, ...]
 */
export const fetchMonthlyRevenue = async (months = 6) => {
  const response = await api.get(`${BILLING_ADMIN_BASE}/revenue-trend`, {
    params: { months },
  });
  return response.data;
};

// ─────────────────────────────────────────────────────────────────────────────
// WRITE — Generate Invoices & Register Payments
// ─────────────────────────────────────────────────────────────────────────────

/**
 * Generate a MercadoPago checkout preference for a member.
 * @param {Object} payload - { member_id, plan_id, plan_name, amount }
 * @returns {Promise<Object>} { preference_id, checkout_url, init_point, ... }
 */
export const generatePaymentPreference = async (payload) => {
  const response = await api.post('/api/v1/billing/mercadopago/preference', payload);
  return response.data;
};

/**
 * Register a manual (cash/transfer) payment for a member.
 * @param {Object} payload - { member_id, plan_id, plan_name, amount }
 * @returns {Promise<Object>} Created invoice object
 */
export const registerManualPayment = async (payload) => {
  const response = await api.post('/api/v1/billing/admin/register-manual-payment', payload);
  return response.data;
};

/**
 * Fetch all membership plans (for the invoice generation form dropdown).
 * @returns {Promise<Array>} Array of plan objects { id, name, price, duration_days }
 */
export const fetchMembershipPlans = async () => {
  const response = await api.get('/api/v1/billing/plans');
  return response.data;
};

/**
 * Fetch all branches for filtering (super_admin only).
 * @returns {Promise<Array>} Array of branch objects
 */
export const fetchBranches = async () => {
  const response = await api.get('/api/v1/users/branches');
  return response.data;
};
