import axios from 'axios';
import toast from 'react-hot-toast';

const API_URL = 'https://novafit-analytics-suite.onrender.com';

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
  },
});

// Request interceptor to add the auth token header to every request
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => {
    return Promise.reject(error);
  }
);

// Response interceptor to handle global errors like 401 Unauthorized
api.interceptors.response.use(
  (response) => response,
  (error) => {
    if (error.response && error.response.status === 401) {
      // Clear token and redirect to login if unauthorized
      localStorage.removeItem('token');
      localStorage.removeItem('user');
      window.dispatchEvent(new Event('auth-error'));
    } else if (error.response && error.response.status === 403) {
      // Check for the structured membership error from require_active_membership
      const detail = error.response.data?.detail;
      if (detail?.code === 'MEMBERSHIP_REQUIRED') {
        window.dispatchEvent(new Event('membership-expired'));
        // Do NOT show a generic toast — the ExpiredMembership screen handles UX
        return Promise.reject(error);
      }
      // All other 403s (role permissions, etc.) bubble up normally
    } else if (error.response && error.response.status >= 500) {
      toast.error('Error del servidor. Por favor, intenta de nuevo más tarde.');
    } else if (!error.response && error.message !== 'canceled') {
      toast.error('Error de conexión. Verifica tu internet.');
    }
    return Promise.reject(error);
  }
);


export default api;
