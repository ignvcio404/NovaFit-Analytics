import api from './api';

export const analyticsService = {
  getMyFatigue: async () => {
    const response = await api.get('/api/v1/analytics/fatigue/me');
    return response.data;
  },

  getUserFatigue: async (userId) => {
    const response = await api.get(`/api/v1/analytics/fatigue/${userId}`);
    return response.data;
  },

  getVolumeProgress: async () => {
    const response = await api.get('/api/v1/analytics/volume-progress');
    return response.data;
  },
  
  getPersonalRecords: async () => {
    const response = await api.get('/api/v1/analytics/personal-records');
    return response.data;
  }
};
