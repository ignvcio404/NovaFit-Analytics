import api from './api';

export const trainingService = {
  // Sessions
  getSessions: async () => {
    try {
      const response = await api.get('/api/v1/training/sessions');
      return Array.isArray(response.data) ? response.data : [];
    } catch (error) {
      console.warn("Failed to fetch sessions, returning empty array:", error);
      return [];
    }
  },
  
  getSessionById: async (sessionId) => {
    const response = await api.get(`/api/v1/training/sessions/${sessionId}`);
    return response.data;
  },

  createSession: async (sessionData) => {
    const response = await api.post('/api/v1/training/sessions', sessionData);
    return response.data;
  },

  completeSession: async (sessionId, rpe = null, updatedSets = null) => {
    const payload = {};
    if (rpe !== null) payload.rpe = Number(rpe);
    if (updatedSets) payload.updated_sets = updatedSets;
    const response = await api.patch(`/api/v1/training/sessions/${sessionId}/complete`, payload);
    return response.data;
  },

  // Templates
  getTemplates: async () => {
    const response = await api.get('/api/v1/training/templates');
    return response.data;
  },

  createTemplate: async (templateData) => {
    const response = await api.post('/api/v1/training/templates', templateData);
    return response.data;
  },

  updateTemplate: async (templateId, templateData) => {
    const response = await api.put(`/api/v1/training/templates/${templateId}`, templateData);
    return response.data;
  },

  deleteTemplate: async (templateId) => {
    const response = await api.delete(`/api/v1/training/templates/${templateId}`);
    return response.data;
  },

  instantiateTemplate: async (templateId, data = {}) => {
    const response = await api.post(`/api/v1/training/templates/${templateId}/instantiate`, data);
    return response.data;
  },

  // Exercises
  getExercises: async () => {
    const response = await api.get('/api/v1/training/exercises');
    return response.data;
  },

  searchExercises: async (query) => {
    const response = await api.get(`/api/v1/exercises/search?query=${query}&language_id=8&limit=15`);
    return response.data;
  }
};
