﻿/**
 * ExpiredMembership
 * =================
 * Full-page blocking screen shown when a member's membership has expired,
 * been cancelled, or is pending payment.
 *
 * Rendered by ProtectedRoute when MembershipContext.isBlocked === true.
 * The only actions available are:
 *   - Navigate to /billing to renew
 *   - Log out
 */

import React from "react";
import { useNavigate } from "react-router-dom";
import { Lock, CreditCard, LogOut, AlertTriangle, RefreshCw } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useMembership } from "../context/MembershipContext";

const STATUS_CONFIG = {
  expired: {
    icon: <Lock className="h-16 w-16 text-red-400" />,
    title: "Tu membresía ha vencido",
    subtitle:
      "Tu plan ya no está activo. Renueva ahora para seguir registrando tus entrenos y ver tu progreso.",
    accentColor: "red",
  },
  pending: {
    icon: <AlertTriangle className="h-16 w-16 text-amber-400" />,
    title: "Pago pendiente",
    subtitle:
      "Tienes una factura pendiente de pago. Completa el pago para activar tu membresía y acceder a la plataforma.",
    accentColor: "amber",
  },
  none: {
    icon: <Lock className="h-16 w-16 text-slate-400" />,
    title: "Sin membresía activa",
    subtitle:
      "Todavía no tienes un plan contratado. Contacta a tu entrenador para empezar.",
    accentColor: "slate",
  },
};

export default function ExpiredMembership() {
  const navigate = useNavigate();
  const { logout } = useAuth();
  const { membershipStatus, daysRemaining, refresh } = useMembership();

  const config =
    STATUS_CONFIG[membershipStatus] ?? STATUS_CONFIG.expired;

  const daysOverdue =
    typeof daysRemaining === "number" && daysRemaining < 0
      ? Math.abs(daysRemaining)
      : null;

  const handleLogout = () => {
    logout();
    navigate("/login", { replace: true });
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--color-bg-base)] px-4">
      {/* Background glow */}
      <div
        className="absolute inset-0 pointer-events-none"
        style={{
          background:
            "radial-gradient(ellipse 60% 40% at 50% 30%, rgba(239,68,68,0.08) 0%, transparent 70%)",
        }}
      />

      <div className="relative z-10 w-full max-w-md text-center">
        {/* Card */}
        <div
          className="glass-panel p-10 rounded-2xl"
          style={{ border: "1px solid rgba(239,68,68,0.15)" }}
        >
          {/* Icon */}
          <div className="flex justify-center mb-6">
            <div className="p-5 rounded-full bg-red-500/10 ring-1 ring-red-500/20">
              {config.icon}
            </div>
          </div>

          {/* Title */}
          <h1 className="text-2xl font-bold text-white mb-3">{config.title}</h1>

          {/* Days overdue badge */}
          {daysOverdue !== null && (
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-red-900/30 border border-red-700/40 text-red-300 text-sm mb-4">
              <AlertTriangle className="h-3.5 w-3.5" />
              Vencida hace {daysOverdue} {daysOverdue === 1 ? "día" : "días"}
            </div>
          )}

          {/* Subtitle */}
          <p className="text-slate-400 text-sm leading-relaxed mb-8">
            {config.subtitle}
          </p>

          {/* Actions */}
          <div className="flex flex-col gap-3">
            <button
              onClick={() => navigate("/billing")}
              className="flex items-center justify-center gap-2 w-full py-3 px-6 rounded-xl
                         bg-gradient-to-r from-cyan-500 to-indigo-500
                         hover:from-cyan-400 hover:to-indigo-400
                         text-white font-semibold text-sm
                         transition-all duration-200 shadow-lg shadow-cyan-500/20"
            >
              <CreditCard className="h-4 w-4" />
              Renovar Plan
            </button>

            <button
              onClick={refresh}
              className="flex items-center justify-center gap-2 w-full py-3 px-6 rounded-xl
                         bg-slate-700/50 hover:bg-slate-700/80 border border-slate-600/50
                         text-slate-300 hover:text-white font-medium text-sm
                         transition-all duration-200"
            >
              <RefreshCw className="h-4 w-4" />
              Ya pagué — Verificar estado
            </button>

            <button
              onClick={handleLogout}
              className="flex items-center justify-center gap-2 w-full py-2.5 px-6
                         text-slate-500 hover:text-slate-300 text-sm
                         transition-colors duration-200"
            >
              <LogOut className="h-4 w-4" />
              Cerrar sesión
            </button>
          </div>
        </div>

        {/* Footer note */}
        <p className="mt-6 text-xs text-slate-600">
          ¿Problemas con tu pago? Contacta a tu entrenador o administrador.
        </p>
      </div>
    </div>
  );
}
