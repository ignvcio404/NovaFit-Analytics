import React, { useEffect, useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { trainingService } from '../services/trainingService';
import { Link, useNavigate } from 'react-router-dom';
import { ClipboardList, Play, Loader2, Plus, LayoutTemplate, Trash2, Edit } from 'lucide-react';
import CreateTemplateModal from '../components/CreateTemplateModal';
import EmptyState from '../components/EmptyState';
import toast from 'react-hot-toast';

const TemplatesList = () => {
  const [templates, setTemplates] = useState([]);
  const [loading, setLoading] = useState(true);
  const [instantiatingId, setInstantiatingId] = useState(null);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [templateToEdit, setTemplateToEdit] = useState(null);
  const navigate = useNavigate();
  const { user } = useContext(AuthContext);
  const hasPermission = user?.roles?.some(r => ['super_admin', 'trainer'].includes(r));

  const fetchTemplates = async () => {
    setLoading(true);
    try {
      const data = await trainingService.getTemplates();
      setTemplates(data);
    } catch (error) {
      console.error("Error fetching templates:", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar esta plantilla? Esto no se puede deshacer.')) return;
    try {
      await trainingService.deleteTemplate(id);
      toast.success('Plantilla eliminada exitosamente');
      fetchTemplates();
    } catch (error) {
      console.error("Error al eliminar:", error);
      toast.error('No se pudo eliminar la plantilla');
    }
  };

  const handleInstantiate = async (templateId) => {
    setInstantiatingId(templateId);
    try {
      const today = new Date().toISOString().split('T')[0];
      const session = await trainingService.instantiateTemplate(templateId, {
        scheduled_date: today,
        microcycle_id: null
      });
      navigate(`/sessions/${session.id}`);
    } catch (error) {
      console.error("Error instantiating template:", error);
      toast.error("Error al iniciar la sesión. Por favor, intenta de nuevo.");
    } finally {
      setInstantiatingId(null);
    }
  };

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <header className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-8">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Plantillas de Entrenamiento</h1>
          <p className="text-slate-400">Administra tus rutinas predefinidas e inicia entrenamientos rápidamente.</p>
        </div>
        {hasPermission && (
          <button 
            onClick={() => {
              setTemplateToEdit(null);
              setIsModalOpen(true);
            }}
            className="btn-primary flex items-center justify-center gap-2"
          >
            <Plus className="h-4 w-4" /> Crear Plantilla
          </button>
        )}
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {templates.length === 0 ? (
          <div className="col-span-full">
            <EmptyState 
              icon={LayoutTemplate}
              title="No se encontraron plantillas"
              description="Aún no has creado ninguna plantilla de entrenamiento."
              actionText={hasPermission ? "Crear Plantilla" : undefined}
              actionPath={hasPermission ? "#" : undefined}
            />
          </div>
        ) : (
          templates.map((template) => (
            <div key={template.id} className="glass-card flex flex-col h-full group hover:border-cyan-500/50 transition-colors">
              <div className="flex-1">
                <div className="flex items-center justify-between mb-3">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xl font-bold text-white group-hover:text-cyan-400 transition-colors">{template.name}</h3>
                    {template.difficulty && (
                      <span className="text-xs px-2 py-1 rounded bg-slate-700 text-slate-300 capitalize">
                        {template.difficulty}
                      </span>
                    )}
                  </div>
                  {hasPermission && (
                    <div className="flex gap-2">
                      <button 
                        onClick={() => {
                          setTemplateToEdit(template);
                          setIsModalOpen(true);
                        }}
                        className="text-slate-500 hover:text-cyan-400 transition-colors p-1"
                        title="Editar plantilla"
                      >
                        <Edit className="h-5 w-5" />
                      </button>
                      <button 
                        onClick={() => handleDelete(template.id)}
                        className="text-slate-500 hover:text-red-400 transition-colors p-1"
                        title="Eliminar plantilla"
                      >
                        <Trash2 className="h-5 w-5" />
                      </button>
                    </div>
                  )}
                </div>
                <p className="text-sm text-slate-400 mb-4 line-clamp-2">
                  {template.description || 'Sin descripción proporcionada.'}
                </p>
                {template.goal && (
                  <div className="mb-4">
                    <span className="text-xs font-medium text-slate-500 uppercase tracking-wider">Objetivo:</span>
                    <span className="ml-2 text-sm text-slate-300 capitalize">{template.goal}</span>
                  </div>
                )}
              </div>
              
              <div className="mt-4 pt-4 border-t border-slate-700/50">
                <button 
                  onClick={() => handleInstantiate(template.id)}
                  disabled={instantiatingId === template.id}
                  className="w-full btn-primary flex items-center justify-center gap-2 h-10"
                >
                  {instantiatingId === template.id ? (
                    <Loader2 className="h-4 w-4 animate-spin" />
                  ) : (
                    <>
                      <Play className="h-4 w-4" /> Iniciar Entrenamiento
                    </>
                  )}
                </button>
              </div>
            </div>
          ))
        )}
      </div>

      <CreateTemplateModal 
        isOpen={isModalOpen} 
        onClose={() => {
          setIsModalOpen(false);
          setTemplateToEdit(null);
        }} 
        onSuccess={() => {
          fetchTemplates();
          setIsModalOpen(false);
          setTemplateToEdit(null);
        }}
        templateToEdit={templateToEdit}
      />
    </div>
  );
};

export default TemplatesList;
