import React, { useState, useContext } from 'react';
import { AuthContext } from '../context/AuthContext';
import { useNavigate, Link } from 'react-router-dom';
import { Loader2 } from 'lucide-react';

// ─────────────────────────────────────────────────────────────────────────────
// Role resolver — centralises the "where does this role land after login?" logic
// Matches the same ADMIN_ROLES check used in ProtectedAdminRoute.jsx
// ─────────────────────────────────────────────────────────────────────────────
const ADMIN_ROLES = ['trainer', 'super_admin'];

const getPostLoginRoute = (user) => {
  if (!user) return '/';
  const role = user.role ?? '';
  const roles = Array.isArray(user.roles) ? user.roles : [];
  const isAdmin = ADMIN_ROLES.includes(role) || roles.some((r) => ADMIN_ROLES.includes(r));
  return isAdmin ? '/admin' : '/';
};

const Login = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');
  const [isLoading, setIsLoading] = useState(false);

  // AuthContext.login() now returns the userData from /me, so we can
  // read the role immediately without any setState race condition.
  const { login } = useContext(AuthContext);
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setError('');
    setIsLoading(true);

    try {
      const userData = await login(email, password);
      // Navigate based on the role returned directly from the login response —
      // no dependency on React's async state update cycle.
      navigate(getPostLoginRoute(userData));
    } catch (err) {
      setError(err.response?.data?.detail || 'Error al iniciar sesión. Por favor verifica tus credenciales.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--color-bg-base)] px-4">
      <div className="glass-panel w-full max-w-md p-8 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl -ml-32 -mb-32"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <img 
            src="https://uxvyjopnmxiwfbtvnbxi.supabase.co/storage/v1/object/sign/assets/logo.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MzM4Y2RiMC05NTY0LTRhMjktOWFmYS0xZjdkODU2OTRjMDUiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvbG9nby5wbmciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzg2MTcxMDA0LCJleHAiOjE4MTc3MDcwMDR9.V2vualki_oTjY-8tIcYxXA71haxKaFa_BhpBgX9OPTI" 
            alt="NovaFit Logo" 
            className="h-12 w-auto mx-auto drop-shadow-md mb-6"
          />
          
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Bienvenido</h2>
          <p className="text-slate-400 text-sm mb-8 text-center">Inicia sesión en NovaFit Analytics Suite</p>
          
          {error && (
            <div className="w-full bg-red-500/10 border border-red-500/50 text-red-400 px-4 py-3 rounded-xl mb-6 text-sm">
              {error}
            </div>
          )}
          
          <form onSubmit={handleSubmit} className="w-full space-y-5">
            <div>
              <label className="label-text">Correo Electrónico</label>
              <input
                type="email"
                required
                className={`input-field ${email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? 'border-red-500 focus:border-red-500 focus:ring-red-500/20' : ''}`}
                placeholder="you@example.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              {email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && (
                <p className="text-red-400 text-xs mt-1">Por favor, ingresa un correo electrónico válido</p>
              )}
            </div>
            
            <div>
              <div className="flex items-center justify-between">
                <label className="label-text">Contraseña</label>
                <Link to="/forgot-password" className="text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors">
                  ¿Olvidaste tu contraseña?
                </Link>
              </div>
              <input
                type="password"
                required
                className="input-field mt-1"
                placeholder="••••••••"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
            </div>
            
            <button 
              type="submit" 
              className="btn-primary w-full mt-4 flex items-center justify-center h-11"
              disabled={isLoading || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || !password}
            >
              {isLoading ? <Loader2 className="animate-spin h-5 w-5" /> : 'Iniciar Sesión'}
            </button>
          </form>
          
          <p className="mt-8 text-slate-400 text-sm">
            ¿No tienes una cuenta?{' '}
            <Link to="/register" className="text-cyan-400 hover:text-cyan-300 transition-colors">
              Regístrate aquí
            </Link>
          </p>
        </div>
      </div>
    </div>
  );
};

export default Login;
