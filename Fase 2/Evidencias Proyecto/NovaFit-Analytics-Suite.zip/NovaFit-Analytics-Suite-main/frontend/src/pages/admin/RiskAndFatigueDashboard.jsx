import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';
import { useAuth } from '../../context/AuthContext';
import { Loader2, HeartPulse, ShieldAlert, Activity, CheckCircle, TrendingUp, Search } from 'lucide-react';

export default function RiskAndFatigueDashboard() {
  const { user } = useAuth();
  const isAdmin = user?.roles?.includes('super_admin') || user?.roles?.includes('branch_admin');
  
  const [athletes, setAthletes] = useState([]);
  const [loadingAthletes, setLoadingAthletes] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [fatigueData, setFatigueData] = useState(null);
  const [loadingFatigue, setLoadingFatigue] = useState(false);
  const [alerts, setAlerts] = useState([]);
  const [weightHistory, setWeightHistory] = useState([]);

  useEffect(() => {
    fetchAthletes();
  }, []);

  const fetchAthletes = async () => {
    setLoadingAthletes(true);
    try {
      if (isAdmin) {
        const res = await api.get('/api/v1/users?page_size=100&role=member');
        setAthletes(res.data.items || []);
      } else {
        const res = await api.get('/api/v1/trainer/dashboard');
        // El dashboard retorna active_athletes
        setAthletes(res.data.active_athletes || []);
      }
    } catch (error) {
      toast.error('Error al cargar atletas');
    } finally {
      setLoadingAthletes(false);
    }
  };

  const loadFatigueData = async (athlete) => {
    // Si la data viene del endpoint del admin es `athlete.id`, 
    // si viene del trainer dashboard es `athlete.athlete_id`
    const athleteId = athlete.athlete_id || athlete.id;
    
    // Crear un objeto unificado con la información del atleta
    const unifiedAthlete = {
      id: athleteId,
      first_name: athlete.first_name || athlete.athlete_first_name,
      last_name: athlete.last_name || athlete.athlete_last_name,
      email: athlete.email || athlete.athlete_email
    };
    
    setSelectedAthlete(unifiedAthlete);
    setLoadingFatigue(true);
    try {
      const [fatigueRes, alertsRes, weightRes] = await Promise.all([
        api.get(`/api/v1/analytics/fatigue/${athleteId}`),
        api.get(`/api/v1/analytics/alerts/${athleteId}`).catch(() => ({ data: [] })),
        api.get(`/api/v1/athlete/weight-history/${athleteId}`).catch(() => ({ data: [] })),
      ]);
      setFatigueData(fatigueRes.data);
      setAlerts(alertsRes.data || []);
      setWeightHistory(weightRes.data || []);
    } catch (error) {
      setFatigueData(null);
      setAlerts([]);
      setWeightHistory([]);
      if (error.response?.status === 404) {
        toast.error('No hay historial suficiente para analizar.');
      } else {
        toast.error('No se pudo cargar el análisis de este atleta.');
      }
    } finally {
      setLoadingFatigue(false);
    }
  };

  const filteredAthletes = athletes.filter(a => {
    const fn = a.first_name || a.athlete_first_name || '';
    const ln = a.last_name || a.athlete_last_name || '';
    const em = a.email || a.athlete_email || '';
    return `${fn} ${ln} ${em}`.toLowerCase().includes(searchTerm.toLowerCase());
  });

  return (
    <div className="flex h-[calc(100vh-100px)] gap-6 overflow-hidden">
      
      {/* Columna Izquierda: Lista de Atletas */}
      <div className="w-1/3 flex flex-col bg-slate-800/50 border border-slate-700/50 rounded-xl overflow-hidden shadow-xl backdrop-blur-sm">
        <div className="p-4 border-b border-slate-700/50">
          <h2 className="text-xl font-bold text-white mb-4 flex items-center gap-2">
            <HeartPulse className="h-5 w-5 text-emerald-400" />
            Directorio de Atletas
          </h2>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
            <input
              type="text"
              placeholder="Buscar atleta..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full bg-slate-900 border border-slate-700 rounded-lg pl-10 pr-4 py-2 text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500"
            />
          </div>
        </div>
        
        <div className="flex-1 overflow-y-auto p-2">
          {loadingAthletes ? (
            <div className="flex justify-center p-8"><Loader2 className="h-6 w-6 animate-spin text-cyan-400" /></div>
          ) : filteredAthletes.length === 0 ? (
            <p className="text-center text-slate-500 p-4">No se encontraron atletas.</p>
          ) : (
            filteredAthletes.map(a => {
              const id = a.id || a.athlete_id;
              const fn = a.first_name || a.athlete_first_name;
              const ln = a.last_name || a.athlete_last_name;
              const em = a.email || a.athlete_email;
              const isSelected = selectedAthlete?.id === id;
              
              return (
                <button
                  key={id}
                  onClick={() => loadFatigueData(a)}
                  className={`w-full text-left p-4 rounded-lg mb-2 transition-all ${isSelected ? 'bg-cyan-500/20 border border-cyan-500/30' : 'hover:bg-slate-700/50 border border-transparent'}`}
                >
                  <div className={`font-medium ${isSelected ? 'text-cyan-400' : 'text-white'}`}>{fn} {ln}</div>
                  <div className="text-xs text-slate-400">{em}</div>
                </button>
              )
            })
          )}
        </div>
      </div>

      {/* Columna Derecha: Detalles y Análisis */}
      <div className="flex-1 overflow-y-auto bg-slate-800/30 border border-slate-700/50 rounded-xl p-6 shadow-xl backdrop-blur-sm">
        {!selectedAthlete ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-500">
            <Activity className="h-16 w-16 mb-4 opacity-50" />
            <p>Selecciona un atleta del directorio para ver su análisis de riesgo.</p>
          </div>
        ) : loadingFatigue ? (
          <div className="h-full flex items-center justify-center">
            <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
          </div>
        ) : !fatigueData ? (
          <div className="h-full flex flex-col items-center justify-center text-slate-500">
            <Activity className="h-12 w-12 mb-4 opacity-30 text-rose-400" />
            <p>No hay datos suficientes para este atleta.</p>
            <p className="text-sm mt-2 opacity-70">El atleta necesita completar entrenamientos para calcular la fatiga.</p>
          </div>
        ) : (
          <div className="space-y-6">
            
            {/* Header del Atleta */}
            <div className="border-b border-slate-700/50 pb-4">
              <h1 className="text-2xl font-bold text-white">Perfil de Riesgo y Fatiga</h1>
              <p className="text-slate-400">Atleta: <span className="text-white font-medium">{selectedAthlete.first_name} {selectedAthlete.last_name}</span></p>
            </div>

            {/* Banner de Recomendación */}
            {alerts.length > 0 && alerts.map(alert => (
              <div key={alert.id} className={`p-5 rounded-xl flex items-start gap-4 border ${
                alert.severity === 'critical' || alert.severity === 'high'
                  ? 'bg-rose-500/10 border-rose-500/30'
                  : 'bg-amber-500/10 border-amber-500/30'
              }`}>
                <div className={`p-3 rounded-full shrink-0 ${
                  alert.severity === 'critical' || alert.severity === 'high'
                    ? 'bg-rose-500/20' : 'bg-amber-500/20'
                }`}>
                  <ShieldAlert className={`h-6 w-6 ${
                    alert.severity === 'critical' || alert.severity === 'high'
                      ? 'text-rose-400' : 'text-amber-400'
                  }`} />
                </div>
                <div>
                  <h3 className={`text-lg font-bold mb-1 ${
                    alert.severity === 'critical' || alert.severity === 'high'
                      ? 'text-rose-400' : 'text-amber-400'
                  }`}>Alerta: {alert.alert_type}</h3>
                  <p className="text-slate-300 mb-2">{alert.message}</p>
                </div>
              </div>
            ))}

            {fatigueData.deload_recommended ? (
              <div className="bg-rose-500/10 border border-rose-500/30 p-5 rounded-xl flex items-start gap-4">
                <div className="p-3 bg-rose-500/20 rounded-full shrink-0">
                  <ShieldAlert className="h-6 w-6 text-rose-400" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-rose-400 mb-1">¡Alerta de Sobrecarga! Se recomienda Descarga</h3>
                  <p className="text-slate-300 mb-2">
                    El sistema detectó niveles elevados de fatiga acumulada o un salto brusco en la carga de trabajo (ACWR alto). Continuar con la misma intensidad eleva drásticamente el riesgo de lesión.
                  </p>
                  <div className="inline-block bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 mt-2">
                    <span className="text-cyan-400 font-semibold block text-sm mb-1">Pesos y Cargas Sugeridos:</span>
                    <span className="text-white text-sm">Disminuir los pesos levantados entre un 20% a 30% respecto a la semana pasada, y reducir ligeramente el volumen de series.</span>
                  </div>
                </div>
              </div>
            ) : (
              <div className="bg-emerald-500/10 border border-emerald-500/30 p-5 rounded-xl flex items-start gap-4">
                <div className="p-3 bg-emerald-500/20 rounded-full shrink-0">
                  <CheckCircle className="h-6 w-6 text-emerald-400" />
                </div>
                <div>
                  <h3 className="text-lg font-bold text-emerald-400 mb-1">Estado Óptimo: Progresión Segura</h3>
                  <p className="text-slate-300 mb-2">
                    El atleta mantiene parámetros saludables de carga, asimilando correctamente el volumen de entrenamiento sin estrés sistémico excesivo.
                  </p>
                  <div className="inline-block bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 mt-2">
                    <span className="text-cyan-400 font-semibold block text-sm mb-1">Pesos y Cargas Sugeridos:</span>
                    <span className="text-white text-sm">Mantener los pesos actuales o aplicar sobrecarga progresiva regular (incrementos del 2-5%).</span>
                  </div>
                </div>
              </div>
            )}

            {/* Métricas Clave */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-700/50">
                <div className="flex items-center gap-2 mb-2">
                  <Activity className="h-5 w-5 text-cyan-400" />
                  <p className="font-semibold text-slate-300">Fatiga Sistémica</p>
                </div>
                <div className="flex items-end gap-2">
                  <p className="text-4xl font-bold text-white">
                    {Number(fatigueData.fatigue_score || 0).toFixed(1)}
                  </p>
                  <p className="text-slate-500 mb-1">/ 100</p>
                </div>
                <p className="text-xs text-slate-500 mt-2">Puntaje global de estrés acumulado.</p>
              </div>

              <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-700/50">
                <div className="flex items-center gap-2 mb-2">
                  <TrendingUp className="h-5 w-5 text-amber-400" />
                  <p className="font-semibold text-slate-300">Ratio ACWR</p>
                </div>
                <p className="text-4xl font-bold text-white">
                  {Number(fatigueData.acwr || 0).toFixed(2)}
                </p>
                <p className="text-xs text-slate-500 mt-2">Agudo vs Crónico. Valores &gt; 1.5 indican alto riesgo de lesión.</p>
              </div>
            </div>

            {/* Fatiga Localizada */}
            <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-700/50">
              <h3 className="font-semibold text-slate-300 mb-4 border-b border-slate-700/50 pb-2">Fatiga Localizada por Grupo Muscular</h3>
              <div className="space-y-4">
                {Object.entries(fatigueData.localized_fatigue || {}).length > 0 ? (
                  Object.entries(fatigueData.localized_fatigue).map(([muscle, score]) => (
                    <div key={muscle}>
                      <div className="flex justify-between text-sm mb-1">
                        <span className="text-slate-300 font-medium capitalize">{muscle}</span>
                        <span className={`font-bold ${score > 70 ? 'text-rose-400' : 'text-emerald-400'}`}>{Number(score).toFixed(0)} / 100</span>
                      </div>
                      <div className="h-2 w-full bg-slate-800 rounded-full overflow-hidden">
                        <div 
                          className={`h-full rounded-full transition-all duration-1000 ${score > 70 ? 'bg-rose-500' : score > 40 ? 'bg-amber-400' : 'bg-emerald-500'}`}
                          style={{ width: `${Math.min(score, 100)}%` }}
                        ></div>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-slate-500">No hay datos de fatiga localizada recientes.</p>
                )}
              </div>
            </div>

            {/* Historial de Peso Corporal */}
            <div className="bg-slate-900/50 p-6 rounded-xl border border-slate-700/50 mt-6">
              <h3 className="font-semibold text-slate-300 mb-4 border-b border-slate-700/50 pb-2">Historial de Peso Corporal</h3>
              {weightHistory.length > 0 ? (
                <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 gap-4">
                  {weightHistory.slice(-8).reverse().map((wh) => (
                    <div key={wh.id} className="bg-slate-800 p-4 rounded-lg border border-slate-700 flex flex-col items-center">
                      <span className="text-2xl font-bold text-white">{wh.weight_kg} <span className="text-sm font-normal text-slate-400">kg</span></span>
                      <span className="text-xs text-slate-400 mt-1">
                        {new Date(wh.measured_at).toLocaleDateString('es-CL')}
                      </span>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-slate-500">No hay registros de peso para este atleta.</p>
              )}
            </div>

          </div>
        )}
      </div>

    </div>
  );
}
