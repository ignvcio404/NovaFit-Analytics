import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';
import { Users, Plus, Edit2, Trash2, Search, Loader2, Activity, HeartPulse } from 'lucide-react';

function UserManagement() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' | 'edit'
  const [selectedUser, setSelectedUser] = useState(null);
  
  // Metadata for forms
  const [branches, setBranches] = useState([]);
  const [plans, setPlans] = useState([]);

  const [formData, setFormData] = useState({
    email: '',
    first_name: '',
    last_name: '',
    password: '',
    phone_number: '',
    branch_id: '',
    plan_id: '',
    amount: '',
    status: 'active'
  });

  const fetchUsers = async (silent = false) => {
    try {
      if (!silent) setLoading(true);
      const res = await api.get(`/api/v1/users?page_size=100&search=${searchTerm}`);
      const allUsers = res.data.items || [];
      const athletes = allUsers.filter(u => {
        const hasAdminRole = u.roles?.some(r => ['trainer', 'super_admin', 'branch_admin'].includes(r.name || r));
        return !hasAdminRole;
      });
      setUsers(athletes);
    } catch (error) {
      if (!silent) toast.error('Error al cargar usuarios');
    } finally {
      setLoading(false);
    }
  };

  const fetchMetadata = async () => {
    try {
      const res = await api.get('/api/v1/users/metadata/options');
      setBranches(res.data.branches || []);
      setPlans(res.data.plans || []);
    } catch (error) {
      console.error('Error fetching metadata', error);
    }
  };

  useEffect(() => {
    fetchMetadata();
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      fetchUsers();
    }, 500);

    return () => {
      clearTimeout(delayDebounceFn);
    };
  }, [searchTerm]);

  const handleOpenModal = (mode, user = null) => {
    setModalMode(mode);
    setSelectedUser(user);
    if (mode === 'edit' && user) {
      setFormData({
        email: user.email,
        first_name: user.first_name,
        last_name: user.last_name,
        password: '', // Leave blank for edit
        phone_number: user.phone_number !== 'Sin teléfono' ? user.phone_number : '',
        status: user.membership?.status || 'active',
        plan_id: '', // Would need more precise mapping if we had the plan ID
        amount: '',
        branch_id: ''
      });
    } else {
      setFormData({
        email: '',
        first_name: '',
        last_name: '',
        password: '',
        phone_number: '',
        branch_id: branches[0]?.id || '',
        plan_id: plans[0]?.id || '',
        amount: plans[0]?.price || '',
        status: 'active'
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (modalMode === 'create') {
        await api.post('/api/v1/users/advanced', formData);
        toast.success('Usuario creado correctamente');
      } else {
        await api.put(`/api/v1/users/${selectedUser.id}`, {
          email: formData.email,
          first_name: formData.first_name,
          last_name: formData.last_name,
          phone_number: formData.phone_number,
          status: formData.status,
          plan_id: formData.plan_id ? parseInt(formData.plan_id) : undefined
        });
        toast.success('Usuario actualizado correctamente');
      }
      setIsModalOpen(false);
      fetchUsers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al guardar el usuario');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este usuario? Esto borrará todo su historial.')) return;
    try {
      await api.delete(`/api/v1/users/${id}`);
      toast.success('Usuario eliminado');
      fetchUsers();
    } catch (error) {
      toast.error('Error al eliminar usuario');
    }
  };

  const handlePlanChange = (e) => {
    const planId = e.target.value;
    const selected = plans.find(p => p.id.toString() === planId);
    setFormData({
      ...formData,
      plan_id: planId,
      amount: selected ? selected.price : formData.amount
    });
  };

  const handleOpenFatigue = async (user) => {
    setSelectedUser(user);
    setIsFatigueModalOpen(true);
    setLoadingFatigue(true);
    setFatigueData(null);
    try {
      const res = await api.get(`/api/v1/analytics/fatigue/${user.id}`);
      setFatigueData(res.data);
    } catch (error) {
      toast.error('Error al cargar datos de fatiga');
    } finally {
      setLoadingFatigue(false);
    }
  };

  return (
    <div className="space-y-6 text-slate-200">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Gestión de Usuarios</h1>
          <p className="text-slate-400">Administra los atletas de la plataforma.</p>
        </div>
        <button 
          onClick={() => handleOpenModal('create')}
          className="flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 font-semibold text-slate-900 transition-colors hover:bg-cyan-400"
        >
          <Plus className="h-5 w-5" />
          Nuevo Usuario
        </button>
      </header>

      <div className="flex items-center gap-4 bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nombre o correo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-slate-600 bg-slate-700/50 py-2 pl-10 pr-4 text-white focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-700/50 bg-slate-800/50 backdrop-blur-sm">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="bg-slate-700/50 text-xs uppercase text-slate-400">
            <tr>
              <th className="px-6 py-4">Usuario</th>
              <th className="px-6 py-4">Sucursal</th>
              <th className="px-6 py-4">Plan Actual</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/50">
            {loading ? (
              <tr>
                <td colSpan="5" className="py-8 text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto text-cyan-400" />
                </td>
              </tr>
            ) : users.length === 0 ? (
              <tr>
                <td colSpan="5" className="py-8 text-center text-slate-400">
                  No se encontraron usuarios.
                </td>
              </tr>
            ) : (
              users.map((u) => (
                <tr key={u.id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-semibold text-white">{u.first_name} {u.last_name}</div>
                    <div className="text-xs text-slate-400">{u.email}</div>
                  </td>
                  <td className="px-6 py-4">{u.branch_name}</td>
                  <td className="px-6 py-4">
                    <div className="text-white">{u.membership?.plan_name}</div>
                    {u.membership?.days_remaining > 0 ? (
                      <div className="text-xs text-emerald-400">{u.membership.days_remaining} días restantes</div>
                    ) : (
                      <div className="text-xs text-rose-400">Vencido</div>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                      u.membership?.status === 'active' ? 'bg-emerald-500/20 text-emerald-400' : 'bg-rose-500/20 text-rose-400'
                    }`}>
                      {u.membership?.status === 'active' ? 'Activo' : 'Inactivo'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleOpenModal('edit', u)}
                      className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-colors"
                      title="Editar Usuario"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(u.id)}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl bg-slate-800 p-6 shadow-xl border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-6">
              {modalMode === 'create' ? 'Crear Nuevo Usuario' : 'Editar Usuario'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Nombre</label>
                  <input
                    type="text"
                    required
                    value={formData.first_name}
                    onChange={(e) => setFormData({...formData, first_name: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Apellido</label>
                  <input
                    type="text"
                    required
                    value={formData.last_name}
                    onChange={(e) => setFormData({...formData, last_name: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Correo Electrónico</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {modalMode === 'create' && (
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Contraseña Temporal</label>
                  <input
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Teléfono</label>
                <input
                  type="tel"
                  value={formData.phone_number}
                  onChange={(e) => setFormData({...formData, phone_number: e.target.value})}
                  placeholder="+56912345678"
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {modalMode === 'create' && (
                <>
                  <div>
                    <label className="block text-sm font-medium text-slate-400 mb-1">Sucursal</label>
                    <select
                      value={formData.branch_id}
                      onChange={(e) => setFormData({...formData, branch_id: e.target.value})}
                      className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                    >
                      <option value="">Seleccione...</option>
                      {branches.map(b => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                      ))}
                    </select>
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1">Plan</label>
                      <select
                        value={formData.plan_id}
                        onChange={handlePlanChange}
                        className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                      >
                        <option value="">Seleccione...</option>
                        {plans.map(p => (
                          <option key={p.id} value={p.id}>{p.name}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-slate-400 mb-1">Monto a Cobrar</label>
                      <input
                        type="number"
                        value={formData.amount}
                        onChange={(e) => setFormData({...formData, amount: e.target.value})}
                        className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                      />
                    </div>
                  </div>
                </>
              )}

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-lg px-4 py-2 font-medium text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-cyan-500 px-4 py-2 font-medium text-slate-900 hover:bg-cyan-400 transition-colors"
                >
                  {modalMode === 'create' ? 'Crear y Cobrar' : 'Guardar Cambios'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

    </div>
  );
}

export default UserManagement;
