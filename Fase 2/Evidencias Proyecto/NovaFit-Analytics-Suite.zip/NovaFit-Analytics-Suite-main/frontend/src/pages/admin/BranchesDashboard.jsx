import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';
import { Building2, Plus, Edit2, Trash2, Loader2 } from 'lucide-react';

function BranchesDashboard() {
  const [branches, setBranches] = useState([]);
  const [loading, setLoading] = useState(true);
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create');
  const [selectedBranch, setSelectedBranch] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    code: '',
    address: '',
    phone: '',
    city: '',
    country_code: 'ARG',
    timezone: 'America/Santiago'
  });

  const fetchBranches = async () => {
    try {
      setLoading(true);
      const res = await api.get('/api/v1/branches');
      setBranches(res.data || []);
    } catch (error) {
      toast.error('Error al cargar sucursales');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBranches();
  }, []);

  const handleOpenModal = (mode, branch = null) => {
    setModalMode(mode);
    setSelectedBranch(branch);
    if (mode === 'edit' && branch) {
      setFormData({
        name: branch.name,
        code: branch.code,
        address: branch.address || '',
        phone: branch.phone || '',
        city: branch.city || '',
        country_code: branch.country_code || 'ARG',
        timezone: branch.timezone || 'America/Santiago'
      });
    } else {
      setFormData({
        name: '',
        code: '',
        address: '',
        phone: '',
        city: '',
        country_code: 'ARG',
        timezone: 'America/Santiago'
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (modalMode === 'create') {
        await api.post('/api/v1/branches', formData);
        toast.success('Sucursal creada correctamente');
      } else {
        await api.put(`/api/v1/branches/${selectedBranch.id}`, formData);
        toast.success('Sucursal actualizada correctamente');
      }
      setIsModalOpen(false);
      fetchBranches();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al guardar la sucursal');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar esta sucursal?')) return;
    try {
      await api.delete(`/api/v1/branches/${id}`);
      toast.success('Sucursal eliminada');
      fetchBranches();
    } catch (error) {
      toast.error('Error al eliminar sucursal');
    }
  };

  return (
    <div className="space-y-6 text-slate-200">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Gestión de Sucursales</h1>
          <p className="text-slate-400">Administra las ubicaciones físicas de NovaFit.</p>
        </div>
        <button 
          onClick={() => handleOpenModal('create')}
          className="flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 font-semibold text-slate-900 transition-colors hover:bg-cyan-400"
        >
          <Plus className="h-5 w-5" />
          Nueva Sucursal
        </button>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {loading ? (
            <div className="col-span-full flex justify-center py-12">
                <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
            </div>
        ) : branches.length === 0 ? (
            <div className="col-span-full text-center py-12 text-slate-400">
                No hay sucursales registradas.
            </div>
        ) : (
            branches.map((b) => (
                <div key={b.id} className="rounded-xl border border-slate-700/50 bg-slate-800/50 p-6 shadow-sm backdrop-blur-sm relative overflow-hidden group hover:border-cyan-500/50 transition-colors">
                    <div className="flex items-start justify-between">
                        <div className="flex items-center gap-3">
                            <div className="p-3 bg-cyan-500/10 rounded-xl text-cyan-400">
                                <Building2 className="h-6 w-6" />
                            </div>
                            <div>
                                <h3 className="text-lg font-bold text-white">{b.name}</h3>
                                <span className="text-xs font-mono text-slate-400 bg-slate-700/50 px-2 py-1 rounded">{b.code}</span>
                            </div>
                        </div>
                    </div>

                    <div className="mt-6 space-y-2 text-sm text-slate-400">
                        <p><strong className="text-slate-300">Dirección:</strong> {b.address || 'No definida'}</p>
                        <p><strong className="text-slate-300">Ciudad:</strong> {b.city || 'No definida'} ({b.country_code})</p>
                        <p><strong className="text-slate-300">Teléfono:</strong> {b.phone || 'No definido'}</p>
                    </div>

                    <div className="mt-6 flex items-center gap-2 border-t border-slate-700/50 pt-4">
                        <button 
                            onClick={() => handleOpenModal('edit', b)}
                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-slate-300 hover:bg-slate-700 rounded-lg transition-colors"
                        >
                            <Edit2 className="h-4 w-4" /> Editar
                        </button>
                        <button 
                            onClick={() => handleDelete(b.id)}
                            className="flex-1 flex items-center justify-center gap-2 px-3 py-2 text-sm font-medium text-rose-400 hover:bg-rose-500/10 rounded-lg transition-colors"
                        >
                            <Trash2 className="h-4 w-4" /> Eliminar
                        </button>
                    </div>
                </div>
            ))
        )}
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-xl bg-slate-800 p-6 shadow-xl border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-6">
              {modalMode === 'create' ? 'Crear Nueva Sucursal' : 'Editar Sucursal'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Nombre</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Código Único</label>
                <input
                  type="text"
                  required
                  disabled={modalMode === 'edit'}
                  value={formData.code}
                  onChange={(e) => setFormData({...formData, code: e.target.value.toUpperCase()})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none disabled:opacity-50"
                  placeholder="Ej: SUC-01"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Dirección</label>
                <input
                  type="text"
                  value={formData.address}
                  onChange={(e) => setFormData({...formData, address: e.target.value})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Teléfono</label>
                <input
                  type="text"
                  value={formData.phone}
                  onChange={(e) => setFormData({...formData, phone: e.target.value})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">Ciudad</label>
                    <input
                        type="text"
                        value={formData.city}
                        onChange={(e) => setFormData({...formData, city: e.target.value})}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                        placeholder="Ciudad"
                    />
                </div>
                <div>
                    <label className="block text-sm font-medium text-slate-300 mb-1">País</label>
                    <input
                        type="text"
                        value={formData.country_code}
                        onChange={(e) => setFormData({...formData, country_code: e.target.value})}
                        className="w-full bg-slate-900 border border-slate-700 rounded-lg px-4 py-2 text-white focus:outline-none focus:border-cyan-500"
                        placeholder="Ej: ARG"
                    />
                </div>
              </div>

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-lg px-4 py-2 font-medium text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-cyan-500 px-4 py-2 font-medium text-slate-900 hover:bg-cyan-400 transition-colors"
                >
                  {modalMode === 'create' ? 'Crear Sucursal' : 'Guardar Cambios'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default BranchesDashboard;
