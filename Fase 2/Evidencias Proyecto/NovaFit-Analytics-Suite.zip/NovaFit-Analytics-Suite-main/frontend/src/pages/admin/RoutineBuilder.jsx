import React, { useState, useEffect } from 'react';
import apiClient from '../../services/api';
import toast from 'react-hot-toast';
import ExerciseDBModal from '../../components/admin/ExerciseDBModal';

const RoutineBuilder = () => {
  const [routineName, setRoutineName] = useState('');
  const [description, setDescription] = useState('');
  const [difficulty, setDifficulty] = useState('Intermediate');
  const [exercises, setExercises] = useState([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [templates, setTemplates] = useState([]);
  
  const [currentExercise, setCurrentExercise] = useState({
    name: '',
    sets: 3,
    reps: 10,
    rest: 60,
    notes: ''
  });

  const handleAddExercise = () => {
    if (!currentExercise.name.trim()) {
      toast.error('El nombre del ejercicio es obligatorio');
      return;
    }
    setExercises([...exercises, { ...currentExercise, id: Date.now() }]);
    setCurrentExercise({
      name: '',
      sets: 3,
      reps: 10,
      rest: 60,
      notes: ''
    });
  };

  const handleRemoveExercise = (id) => {
    setExercises(exercises.filter(ex => ex.id !== id));
  };

  const fetchTemplates = async () => {
    try {
      const response = await apiClient.get('/api/v1/training/templates');
      setTemplates(response.data);
    } catch (error) {
      console.error(error);
    }
  };

  useEffect(() => {
    fetchTemplates();
  }, []);

  const handleDeleteTemplate = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar esta plantilla? Esto no se puede deshacer.')) return;
    try {
      await apiClient.delete(`/api/v1/training/templates/${id}`);
      toast.success('Plantilla eliminada');
      fetchTemplates();
    } catch (error) {
      console.error(error);
      toast.error('Error al eliminar la plantilla');
    }
  };

  const handleSaveRoutine = async () => {
    if (!routineName.trim() || exercises.length === 0) {
      toast.error('Debes proporcionar un nombre y al menos un ejercicio');
      return;
    }

    try {
      // Endpoint to save the routine
      await apiClient.post('/api/v1/training/templates', {
        name: routineName,
        description,
        difficulty,
        exercises_data: exercises
      });
      toast.success('Plantilla guardada exitosamente');
      // Reset form
      setRoutineName('');
      setDescription('');
      setExercises([]);
      fetchTemplates();
    } catch (error) {
      console.error(error);
      toast.error('Error al guardar la plantilla');
    }
  };

  return (
    <div className="p-6 max-w-5xl mx-auto space-y-6">
      <div className="mb-8">
        <h1 className="text-3xl font-extrabold text-[#f8fafc] tracking-tight">Creador de Rutinas</h1>
        <p className="text-[#94a3b8] mt-2">Diseña plantillas maestras de entrenamiento para tus atletas.</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Left Column - Form */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-[#1e293b]/80 border border-[#334155]/50 backdrop-blur-md rounded-xl shadow-lg">
            <div className="border-b border-white/5 px-6 py-4">
              <h3 className="text-xl font-bold text-[#f8fafc]">Detalles de Plantilla</h3>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-1">Nombre de la Rutina</label>
                <input 
                  type="text" 
                  className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] outline-none transition-all"
                  placeholder="Ej: Hipertrofia Tren Superior"
                  value={routineName}
                  onChange={(e) => setRoutineName(e.target.value)}
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-1">Dificultad</label>
                <select 
                  className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] outline-none transition-all"
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                >
                  <option value="Beginner" className="bg-[#1e293b]">Principiante</option>
                  <option value="Intermediate" className="bg-[#1e293b]">Intermedio</option>
                  <option value="Advanced" className="bg-[#1e293b]">Avanzado</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-1">Descripción</label>
                <textarea 
                  className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] focus:border-[#00e5ff] focus:ring-1 focus:ring-[#00e5ff] outline-none transition-all resize-none h-24"
                  placeholder="Objetivos de la rutina..."
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                />
              </div>
            </div>
          </div>

          <div className="bg-[#1e293b]/80 border border-[#334155]/50 backdrop-blur-md rounded-xl shadow-lg">
            <div className="border-b border-white/5 px-6 py-4">
              <h3 className="text-xl font-bold text-[#f8fafc]">Agregar Ejercicio</h3>
            </div>
            <div className="p-6 space-y-4">
              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-sm font-medium text-[#94a3b8]">Ejercicio</label>
                  <button 
                    onClick={() => setIsModalOpen(true)}
                    className="text-xs text-[#00e5ff] hover:underline"
                  >
                    Buscar en Catálogo Externo
                  </button>
                </div>
                <input 
                  type="text" 
                  className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] outline-none"
                  placeholder="Ej: Press de Banca"
                  value={currentExercise.name}
                  onChange={(e) => setCurrentExercise({...currentExercise, name: e.target.value})}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-[#94a3b8] mb-1">Series</label>
                  <input 
                    type="number" 
                    className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] outline-none"
                    value={currentExercise.sets}
                    onChange={(e) => setCurrentExercise({...currentExercise, sets: Number(e.target.value)})}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-[#94a3b8] mb-1">Repeticiones</label>
                  <input 
                    type="number" 
                    className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] outline-none"
                    value={currentExercise.reps}
                    onChange={(e) => setCurrentExercise({...currentExercise, reps: Number(e.target.value)})}
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-[#94a3b8] mb-1">Descanso (segundos)</label>
                <input 
                  type="number" 
                  className="w-full bg-black/20 border border-white/10 rounded-lg p-2.5 text-[#f8fafc] outline-none"
                  value={currentExercise.rest}
                  onChange={(e) => setCurrentExercise({...currentExercise, rest: Number(e.target.value)})}
                />
              </div>

              <button 
                onClick={handleAddExercise}
                className="w-full mt-2 bg-[#00e5ff] text-[#0f172a] font-bold py-3 rounded-lg hover:bg-[#00cce6] transition-colors shadow-[0_0_15px_rgba(0,229,255,0.3)]"
              >
                Añadir a la Rutina
              </button>
            </div>
          </div>
        </div>

        {/* Right Column - Preview */}
        <div className="lg:col-span-2">
          <div className="bg-[#1e293b]/80 border border-[#334155]/50 backdrop-blur-md h-full min-h-[600px] rounded-xl shadow-lg">
            <div className="flex flex-row justify-between items-center border-b border-white/5 px-6 py-4">
              <h3 className="text-xl font-bold text-[#f8fafc]">Vista Previa: {routineName || 'Nueva Rutina'}</h3>
              <span className="px-3 py-1 rounded-full bg-[#00e5ff]/10 text-[#00e5ff] text-xs font-bold border border-[#00e5ff]/20">
                {exercises.length} Ejercicios
              </span>
            </div>
            <div className="p-6">
              {exercises.length === 0 ? (
                <div className="h-full flex flex-col items-center justify-center text-[#94a3b8] pt-20">
                  <svg className="w-16 h-16 mb-4 opacity-20" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1} d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                  </svg>
                  <p className="text-lg">Tu rutina está vacía.</p>
                  <p className="text-sm">Agrega ejercicios desde el panel izquierdo.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {exercises.map((ex, index) => (
                    <div key={ex.id} className="flex items-center justify-between p-4 bg-black/20 border border-white/5 rounded-xl group hover:border-[#00e5ff]/30 transition-colors">
                      <div className="flex items-center gap-4">
                        <div className="h-10 w-10 rounded-lg bg-[#1e293b] flex items-center justify-center border border-[#334155] text-[#94a3b8] font-bold">
                          {index + 1}
                        </div>
                        <div>
                          <h4 className="text-[#f8fafc] font-bold text-lg">{ex.name}</h4>
                          <p className="text-[#94a3b8] text-sm">
                            {ex.sets} Series × {ex.reps} Reps | Descanso: {ex.rest}s
                          </p>
                        </div>
                      </div>
                      <button 
                        onClick={() => handleRemoveExercise(ex.id)}
                        className="text-[#ef4444] opacity-50 hover:opacity-100 p-2 transition-opacity"
                        title="Eliminar ejercicio"
                      >
                        <svg className="w-5 h-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                        </svg>
                      </button>
                    </div>
                  ))}
                  
                  <div className="pt-6 mt-6 border-t border-white/5">
                    <button 
                      onClick={handleSaveRoutine}
                      className="w-full bg-gradient-to-r from-[#8b5cf6] to-[#6366f1] text-white font-bold py-4 rounded-xl hover:opacity-90 transition-opacity shadow-[0_4px_20px_rgba(99,102,241,0.4)]"
                    >
                      Guardar Plantilla Maestra
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>

      <ExerciseDBModal 
        isOpen={isModalOpen} 
        onClose={() => setIsModalOpen(false)} 
        onImportSuccess={(ex) => {
          setCurrentExercise({...currentExercise, name: ex.name, exercise_id: ex.id});
          setIsModalOpen(false);
        }}
      />

      {/* Lista de Plantillas Existentes */}
      <div className="mt-12 bg-[#1e293b]/80 border border-[#334155]/50 backdrop-blur-md rounded-xl shadow-lg">
        <div className="border-b border-white/5 px-6 py-4">
          <h3 className="text-xl font-bold text-[#f8fafc]">Plantillas Maestras Guardadas</h3>
        </div>
        <div className="p-6">
          {templates.length === 0 ? (
            <p className="text-[#94a3b8]">No hay plantillas guardadas.</p>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {templates.map(tpl => (
                <div key={tpl.id} className="bg-black/20 border border-white/10 rounded-xl p-5 hover:border-[#00e5ff]/30 transition-colors flex flex-col">
                  <div className="flex justify-between items-start mb-2">
                    <h4 className="text-[#f8fafc] font-bold text-lg">{tpl.name}</h4>
                    <span className="px-2 py-1 bg-[#1e293b] rounded text-xs text-[#00e5ff] uppercase font-bold tracking-wider">
                      {tpl.difficulty}
                    </span>
                  </div>
                  <p className="text-[#94a3b8] text-sm mb-4 line-clamp-2">{tpl.description || 'Sin descripción'}</p>
                  
                  <div className="mt-auto flex justify-between items-center pt-4 border-t border-white/5">
                    <span className="text-[#94a3b8] text-xs">
                      {tpl.template_data?.exercises?.length || 0} ejercicios
                    </span>
                    <button 
                      onClick={() => handleDeleteTemplate(tpl.id)}
                      className="text-rose-400 hover:text-rose-300 hover:bg-rose-400/10 px-3 py-1.5 rounded-lg text-sm font-semibold transition-colors"
                    >
                      Eliminar
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default RoutineBuilder;
