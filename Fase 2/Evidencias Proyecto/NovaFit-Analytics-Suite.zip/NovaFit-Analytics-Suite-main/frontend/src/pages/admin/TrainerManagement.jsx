import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import toast from 'react-hot-toast';
import { Users, Plus, Edit2, Trash2, Search, Loader2 } from 'lucide-react';

function TrainerManagement() {
  const [trainers, setTrainers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  
  // Modal State
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create');
  const [selectedTrainer, setSelectedTrainer] = useState(null);
  const [branches, setBranches] = useState([]);

  const [formData, setFormData] = useState({
    email: '',
    username: '',
    first_name: '',
    last_name: '',
    password: '',
    phone_number: '',
    branch_id: '',
    status: 'active'
  });

  const fetchTrainers = async () => {
    try {
      setLoading(true);
      const res = await api.get(`/api/v1/users?page_size=100&role=trainer&search=${searchTerm}`);
      setTrainers(res.data.items || []);
    } catch (error) {
      toast.error('Error al cargar entrenadores');
    } finally {
      setLoading(false);
    }
  };

  const fetchMetadata = async () => {
    try {
      const res = await api.get('/api/v1/users/metadata/options');
      setBranches(res.data.branches || []);
    } catch (error) {
      console.error('Error fetching metadata', error);
    }
  };

  useEffect(() => {
    fetchMetadata();
  }, []);

  useEffect(() => {
    const delayDebounceFn = setTimeout(() => {
      fetchTrainers();
    }, 500);
    return () => clearTimeout(delayDebounceFn);
  }, [searchTerm]);

  const handleOpenModal = (mode, trainer = null) => {
    setModalMode(mode);
    setSelectedTrainer(trainer);
    if (mode === 'edit' && trainer) {
      setFormData({
        email: trainer.email,
        username: trainer.email.split('@')[0],
        first_name: trainer.first_name,
        last_name: trainer.last_name,
        password: '', 
        phone_number: trainer.phone_number !== 'Sin teléfono' ? trainer.phone_number : '',
        status: trainer.status || 'active',
        branch_id: ''
      });
    } else {
      setFormData({
        email: '',
        username: '',
        first_name: '',
        last_name: '',
        password: '',
        phone_number: '',
        branch_id: branches[0]?.id || '',
        status: 'active'
      });
    }
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (modalMode === 'create') {
        const payload = {
            ...formData,
            role: "trainer"
        };
        await api.post('/api/v1/auth/register', payload);
        toast.success('Entrenador creado correctamente');
      } else {
        await api.put(`/api/v1/users/${selectedTrainer.id}`, {
          email: formData.email,
          first_name: formData.first_name,
          last_name: formData.last_name,
          phone_number: formData.phone_number,
          status: formData.status
        });
        toast.success('Entrenador actualizado correctamente');
      }
      setIsModalOpen(false);
      fetchTrainers();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al guardar el entrenador');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar a este entrenador?')) return;
    try {
      await api.delete(`/api/v1/users/${id}`);
      toast.success('Entrenador eliminado');
      fetchTrainers();
    } catch (error) {
      toast.error('Error al eliminar entrenador');
    }
  };

  return (
    <div className="space-y-6 text-slate-200">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Gestión de Entrenadores</h1>
          <p className="text-slate-400">Administra los entrenadores de la plataforma.</p>
        </div>
        <button 
          onClick={() => handleOpenModal('create')}
          className="flex items-center gap-2 rounded-lg bg-cyan-500 px-4 py-2 font-semibold text-slate-900 transition-colors hover:bg-cyan-400"
        >
          <Plus className="h-5 w-5" />
          Nuevo Entrenador
        </button>
      </header>

      <div className="flex items-center gap-4 bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 h-5 w-5 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Buscar por nombre o correo..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="w-full rounded-lg border border-slate-600 bg-slate-700/50 py-2 pl-10 pr-4 text-white focus:border-cyan-500 focus:outline-none focus:ring-1 focus:ring-cyan-500"
          />
        </div>
      </div>

      <div className="overflow-x-auto rounded-xl border border-slate-700/50 bg-slate-800/50 backdrop-blur-sm">
        <table className="w-full text-left text-sm text-slate-300">
          <thead className="bg-slate-700/50 text-xs uppercase text-slate-400">
            <tr>
              <th className="px-6 py-4">Entrenador</th>
              <th className="px-6 py-4">Sucursal</th>
              <th className="px-6 py-4">Teléfono</th>
              <th className="px-6 py-4">Estado</th>
              <th className="px-6 py-4 text-right">Acciones</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-700/50">
            {loading ? (
              <tr>
                <td colSpan="5" className="py-8 text-center">
                  <Loader2 className="h-8 w-8 animate-spin mx-auto text-cyan-400" />
                </td>
              </tr>
            ) : trainers.length === 0 ? (
              <tr>
                <td colSpan="5" className="py-8 text-center text-slate-400">
                  No se encontraron entrenadores.
                </td>
              </tr>
            ) : (
              trainers.map((t) => (
                <tr key={t.id} className="hover:bg-slate-700/30 transition-colors">
                  <td className="px-6 py-4">
                    <div className="font-semibold text-white">{t.first_name} {t.last_name}</div>
                    <div className="text-xs text-slate-400">{t.email}</div>
                  </td>
                  <td className="px-6 py-4">{t.branch_name}</td>
                  <td className="px-6 py-4">{t.phone_number}</td>
                  <td className="px-6 py-4">
                    <span className="px-2 py-1 rounded-full text-xs font-medium bg-emerald-500/20 text-emerald-400">
                      Activo
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right space-x-2">
                    <button 
                      onClick={() => handleOpenModal('edit', t)}
                      className="p-2 text-slate-400 hover:text-cyan-400 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      <Edit2 className="h-4 w-4" />
                    </button>
                    <button 
                      onClick={() => handleDelete(t.id)}
                      className="p-2 text-slate-400 hover:text-rose-400 hover:bg-slate-700 rounded-lg transition-colors"
                    >
                      <Trash2 className="h-4 w-4" />
                    </button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-lg rounded-xl bg-slate-800 p-6 shadow-xl border border-slate-700">
            <h2 className="text-xl font-bold text-white mb-6">
              {modalMode === 'create' ? 'Crear Nuevo Entrenador' : 'Editar Entrenador'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Nombre</label>
                  <input
                    type="text"
                    required
                    value={formData.first_name}
                    onChange={(e) => setFormData({...formData, first_name: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Apellido</label>
                  <input
                    type="text"
                    required
                    value={formData.last_name}
                    onChange={(e) => setFormData({...formData, last_name: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Correo Electrónico</label>
                <input
                  type="email"
                  required
                  value={formData.email}
                  onChange={(e) => setFormData({...formData, email: e.target.value, username: e.target.value.split('@')[0]})}
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {modalMode === 'create' && (
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Contraseña Temporal</label>
                  <input
                    type="password"
                    required
                    value={formData.password}
                    onChange={(e) => setFormData({...formData, password: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  />
                </div>
              )}

              <div>
                <label className="block text-sm font-medium text-slate-400 mb-1">Teléfono</label>
                <input
                  type="tel"
                  value={formData.phone_number}
                  onChange={(e) => setFormData({...formData, phone_number: e.target.value})}
                  placeholder="+56912345678"
                  className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                />
              </div>

              {modalMode === 'create' && (
                <div>
                  <label className="block text-sm font-medium text-slate-400 mb-1">Sucursal Asignada</label>
                  <select
                    value={formData.branch_id}
                    onChange={(e) => setFormData({...formData, branch_id: e.target.value})}
                    className="w-full rounded-lg border border-slate-600 bg-slate-700/50 p-2 text-white focus:border-cyan-500 focus:outline-none"
                  >
                    <option value="">Seleccione...</option>
                    {branches.map(b => (
                        <option key={b.id} value={b.id}>{b.name}</option>
                    ))}
                  </select>
                </div>
              )}

              <div className="mt-6 flex justify-end gap-3">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-lg px-4 py-2 font-medium text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="rounded-lg bg-cyan-500 px-4 py-2 font-medium text-slate-900 hover:bg-cyan-400 transition-colors"
                >
                  {modalMode === 'create' ? 'Crear Entrenador' : 'Guardar Cambios'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}

export default TrainerManagement;
