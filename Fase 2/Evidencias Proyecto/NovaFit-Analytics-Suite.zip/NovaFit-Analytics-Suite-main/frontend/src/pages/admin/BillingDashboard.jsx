/**
 * NovaFit Analytics Suite
 * ========================
 * BillingDashboard — Admin Web Dashboard
 * ========================
 *
 * Master billing control center for Admins and Trainers.
 * Displays financial KPIs, invoice table with status filters,
 * delinquent member list, and a quick-action panel to generate
 * invoices or register manual payments.
 *
 * API Endpoints consumed:
 *   GET  /api/v1/billing/admin/invoices
 *   GET  /api/v1/billing/admin/delinquent
 *   GET  /api/v1/billing/admin/summary     (KPI cards)
 *   GET  /api/v1/billing/admin/revenue-trend
 *   POST /api/v1/billing/generate-preference
 *   POST /api/v1/billing/register-manual-payment
 */

import React, { useState, useEffect, useCallback } from 'react';
import api from '../../services/api';
import {
  AreaChart,
  Area,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';
import {
  CreditCard,
  AlertTriangle,
  TrendingUp,
  CheckCircle2,
  Clock,
  XCircle,
  Loader2,
  RefreshCw,
  FileText,
  DollarSign,
  Users,
  Percent,
  ChevronDown,
  ExternalLink,
  Send,
  Banknote,
  Filter,
  Search,
  X,
} from 'lucide-react';
import toast from 'react-hot-toast';
import {
  fetchAllInvoices,
  fetchDelinquentMembers,
  fetchBillingSummary,
  fetchMonthlyRevenue,
  generatePaymentPreference,
  registerManualPayment,
} from '../../services/billingAdminService';

// ─────────────────────────────────────────────────────────────────────────────
// Constants & helpers
// ─────────────────────────────────────────────────────────────────────────────

const STATUS_CONFIG = {
  PAID: {
    label: 'Pagada',
    icon: CheckCircle2,
    classes: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/20',
  },
  ISSUED: {
    label: 'Emitida',
    icon: Clock,
    classes: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
  },
  DRAFT: {
    label: 'Borrador',
    icon: FileText,
    classes: 'text-slate-400 bg-slate-500/10 border-slate-500/20',
  },
  CANCELLED: {
    label: 'Cancelada',
    icon: XCircle,
    classes: 'text-red-400 bg-red-500/10 border-red-500/20',
  },
  VOID: {
    label: 'Anulada',
    icon: XCircle,
    classes: 'text-slate-500 bg-slate-600/10 border-slate-600/20',
  },
};

const STATUS_FILTERS = ['TODOS', 'PAID', 'ISSUED', 'CANCELLED', 'VOID'];

const formatCLP = (amount) =>
  new Intl.NumberFormat('es-CL', { style: 'currency', currency: 'CLP', maximumFractionDigits: 0 }).format(amount ?? 0);

const formatDate = (dateStr) => {
  if (!dateStr) return '—';
  return new Date(dateStr).toLocaleDateString('es-CL', { day: '2-digit', month: 'short', year: 'numeric' });
};

// ─────────────────────────────────────────────────────────────────────────────
// Sub-components
// ─────────────────────────────────────────────────────────────────────────────

/** KPI card with gradient icon and animated border glow */
const KpiCard = ({ icon: Icon, label, value, subtext, colorClass, glowClass, loading }) => (
  <div className="glass-panel p-5 flex items-start gap-4 group">
    <div className={`h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0 shadow-lg ${colorClass}`}>
      <Icon className="h-6 w-6 text-white" />
    </div>
    <div className="min-w-0 flex-1">
      <p className="text-xs font-semibold text-slate-400 uppercase tracking-wider mb-1">{label}</p>
      {loading ? (
        <div className="h-7 w-28 bg-slate-700/60 rounded-lg animate-pulse" />
      ) : (
        <p className={`text-2xl font-bold ${glowClass}`}>{value}</p>
      )}
      {subtext && <p className="text-xs text-slate-500 mt-1">{subtext}</p>}
    </div>
  </div>
);

/** Status badge pill */
const StatusBadge = ({ status }) => {
  const normalizedStatus = (status || '').toUpperCase();
  const cfg = STATUS_CONFIG[normalizedStatus] ?? STATUS_CONFIG.DRAFT;
  const Icon = cfg.icon;
  return (
    <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-semibold border ${cfg.classes}`}>
      <Icon className="h-3.5 w-3.5" />
      {cfg.label}
    </span>
  );
};

/** Custom Recharts tooltip */
const CustomTooltip = ({ active, payload, label }) => {
  if (!active || !payload?.length) return null;
  return (
    <div className="bg-slate-900/95 border border-slate-700 rounded-xl px-4 py-3 shadow-2xl backdrop-blur-md">
      <p className="text-xs text-slate-400 mb-2 font-medium">{label}</p>
      <p className="text-sm font-bold text-cyan-400">{formatCLP(payload[0]?.value)}</p>
      <p className="text-xs text-slate-500">{payload[0]?.payload?.invoices ?? 0} facturas</p>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Quick Action Panel — Generate Invoice / Manual Payment
// ─────────────────────────────────────────────────────────────────────────────

const QuickActionPanel = ({ onSuccess }) => {
  const [mode, setMode] = useState('mp'); // 'mp' | 'manual'
  const [form, setForm] = useState({ member_id: '', plan_id: '', plan_name: '', amount: '' });
  const [submitting, setSubmitting] = useState(false);
  const [athletes, setAthletes] = useState([]);
  const [plans, setPlans] = useState([]);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [usersRes, plansRes] = await Promise.allSettled([
          api.get('/api/v1/users?page_size=100'),
          api.get('/api/v1/users/metadata/options')
        ]);
        
        if (usersRes.status === 'fulfilled') {
          // Parse paginated items list instead of full object
          const allUsers = usersRes.value.data.items || usersRes.value.data || [];
          const onlyAthletes = allUsers.filter(u => 
            !u.roles || (!u.roles.includes('super_admin') && !u.roles.includes('trainer') && !u.roles.includes('branch_admin'))
          );
          setAthletes(onlyAthletes);
        }
        
        if (plansRes.status === 'fulfilled') {
          // Endpoint returns {"branches": [...], "plans": [...]}
          setPlans(plansRes.value.data.plans || []);
        }
      } catch (error) {
        console.error('Failed to load QuickAction data', error);
      }
    };
    loadData();
  }, []);

  const selectedPlan = plans.find((p) => String(p.id) === String(form.plan_id));

  const handlePlanChange = (e) => {
    const plan = plans.find((p) => String(p.id) === e.target.value);
    setForm((prev) => ({
      ...prev,
      plan_id: e.target.value,
      plan_name: plan?.name ?? '',
      amount: plan?.price ?? '',
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!form.member_id || !form.plan_id || !form.amount) {
      toast.error('Completa todos los campos');
      return;
    }

    setSubmitting(true);
    try {
      const payload = {
        member_id: form.member_id,
        plan_id: parseInt(form.plan_id),
        plan_name: form.plan_name,
        amount: parseFloat(form.amount),
      };

      if (mode === 'mp') {
        await generatePaymentPreference(payload);
        toast.success('Factura generada y enviada por correo al cliente');
      } else {
        await registerManualPayment(payload);
        toast.success('Pago manual registrado correctamente');
        onSuccess?.();
      }
      setForm({ member_id: '', plan_id: '', plan_name: '', amount: '' });
    } catch (err) {
      const msg = err?.response?.data?.detail?.message ?? err?.response?.data?.detail ?? 'Error al procesar';
      toast.error(msg);
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <div className="glass-panel p-5 flex flex-col gap-5">
      <div className="flex items-center gap-2">
        <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-[0_0_10px_rgba(0,229,255,0.25)]">
          <Banknote className="h-4 w-4 text-white" />
        </div>
        <h3 className="text-sm font-bold text-white">Acción Rápida</h3>
      </div>

      {/* Mode toggle */}
      <div className="flex rounded-xl bg-slate-900/50 p-1 border border-slate-700/50">
        <button
          type="button"
          id="billing-mode-mp"
          onClick={() => setMode('mp')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold transition-all duration-200 ${
            mode === 'mp'
              ? 'bg-gradient-to-r from-cyan-500 to-blue-500 text-white shadow-lg'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <ExternalLink className="h-3.5 w-3.5" />
          Enviar cobro por correo
        </button>
        <button
          type="button"
          id="billing-mode-manual"
          onClick={() => setMode('manual')}
          className={`flex-1 flex items-center justify-center gap-1.5 py-2 px-3 rounded-lg text-xs font-semibold transition-all duration-200 ${
            mode === 'manual'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 text-white shadow-lg'
              : 'text-slate-400 hover:text-white'
          }`}
        >
          <Banknote className="h-3.5 w-3.5" />
          Manual
        </button>
      </div>

      <form id="billing-quick-action-form" onSubmit={handleSubmit} className="flex flex-col gap-3">
        <div>
          <label className="label-text">Atleta</label>
          <div className="relative">
            <select
              id="billing-member-id"
              value={form.member_id}
              onChange={(e) => setForm((prev) => ({ ...prev, member_id: e.target.value }))}
              className="input-field text-sm appearance-none pr-8"
            >
              <option value="">Seleccionar atleta...</option>
              {athletes.map((athlete) => (
                <option key={athlete.id} value={athlete.id}>
                  {athlete.first_name} {athlete.last_name} ({athlete.membership?.plan_name || 'Sin plan'})
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
          </div>
        </div>

        <div>
          <label className="label-text">Plan</label>
          <div className="relative">
            <select
              id="billing-plan-select"
              value={form.plan_id}
              onChange={handlePlanChange}
              className="input-field text-sm appearance-none pr-8"
            >
              <option value="">Seleccionar plan...</option>
              {plans.map((plan) => (
                <option key={plan.id} value={plan.id}>
                  {plan.name} — {formatCLP(plan.price)}
                </option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400 pointer-events-none" />
          </div>
        </div>

        <div>
          <label className="label-text">Monto (CLP)</label>
          <input
            id="billing-amount"
            type="number"
            placeholder="0"
            value={form.amount}
            onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value }))}
            className="input-field text-sm"
          />
        </div>

        <button
          type="submit"
          id="billing-submit-btn"
          disabled={submitting}
          className={`btn-primary flex items-center justify-center gap-2 mt-1 ${
            mode === 'manual'
              ? 'bg-gradient-to-r from-emerald-500 to-teal-500 hover:from-emerald-400 hover:to-teal-400 shadow-[0_0_15px_rgba(16,185,129,0.3)]'
              : ''
          }`}
        >
          {submitting ? (
            <Loader2 className="h-4 w-4 animate-spin" />
          ) : mode === 'mp' ? (
            <Send className="h-4 w-4" />
          ) : (
            <Banknote className="h-4 w-4" />
          )}
          {submitting ? 'Procesando...' : mode === 'mp' ? 'Generar Link' : 'Registrar Pago'}
        </button>
      </form>
    </div>
  );
};

// ─────────────────────────────────────────────────────────────────────────────
// Main BillingDashboard component
// ─────────────────────────────────────────────────────────────────────────────

const BillingDashboard = () => {
  const [invoices, setInvoices] = useState([]);
  const [delinquent, setDelinquent] = useState([]);
  const [summary, setSummary] = useState(null);
  const [revenueData, setRevenueData] = useState([]);
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);

  // Filters
  const [statusFilter, setStatusFilter] = useState('TODOS');
  const [searchQuery, setSearchQuery] = useState('');
  const [activeTab, setActiveTab] = useState('invoices'); // 'invoices' | 'delinquent'

  // ── Data fetching ────────────────────────────────────────────────────────

  const loadData = useCallback(async (showRefreshSpinner = false) => {
    if (showRefreshSpinner) setRefreshing(true);
    else setLoading(true);

    try {
      const [invoicesRes, delinquentRes, summaryRes, revenueRes, plansRes] = await Promise.allSettled([
        fetchAllInvoices(),
        fetchDelinquentMembers(),
        fetchBillingSummary(),
        fetchMonthlyRevenue(6),
      ]);

      if (invoicesRes.status === 'fulfilled') setInvoices(invoicesRes.value ?? []);
      if (delinquentRes.status === 'fulfilled') setDelinquent(delinquentRes.value ?? []);
      if (summaryRes.status === 'fulfilled') setSummary(summaryRes.value);
      if (revenueRes.status === 'fulfilled') setRevenueData(revenueRes.value ?? []);
    } catch (err) {
      toast.error('Error al cargar los datos de facturación');
      console.error('[BillingDashboard] loadData error:', err);
    } finally {
      setLoading(false);
      setRefreshing(false);
    }
  }, []);

  useEffect(() => {
    loadData();

    // Auto-refresh every 30 seconds
    const interval = setInterval(() => {
      // Pass a flag to prevent full loading state if loadData accepts one, or just call it
      loadData();
    }, 30000);

    return () => clearInterval(interval);
  }, [loadData]);

  // ── Derived state ────────────────────────────────────────────────────────

  const filteredInvoices = invoices.filter((inv) => {
    const normalizedStatus = (inv.status || '').toUpperCase();
    const matchesStatus = statusFilter === 'TODOS' || normalizedStatus === statusFilter;
    const q = searchQuery.toLowerCase();
    const matchesSearch =
      !q ||
      inv.invoice_number?.toLowerCase().includes(q) ||
      inv.member_name?.toLowerCase().includes(q);
    return matchesStatus && matchesSearch;
  });

  // ── Render ───────────────────────────────────────────────────────────────

  return (
    <div className="space-y-6 pb-6">
      {/* ── Page header ─────────────────────────────────────────────────── */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-white tracking-tight flex items-center gap-3">
            <CreditCard className="h-7 w-7 text-cyan-400" />
            Facturación & Morosidad
          </h1>
          <p className="text-sm text-slate-400 mt-1">
            Control financiero centralizado — {new Date().toLocaleDateString('es-CL', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric' })}
          </p>
        </div>
        <button
          id="billing-refresh-btn"
          onClick={() => loadData(true)}
          disabled={refreshing}
          className="btn-secondary flex items-center gap-2 text-sm"
        >
          <RefreshCw className={`h-4 w-4 ${refreshing ? 'animate-spin' : ''}`} />
          {refreshing ? 'Actualizando...' : 'Actualizar'}
        </button>
      </div>

      {/* ── KPI Cards ───────────────────────────────────────────────────── */}
      <div className="grid grid-cols-2 xl:grid-cols-4 gap-4">
        <KpiCard
          icon={DollarSign}
          label="Total Cobrado"
          value={formatCLP(summary?.total_collected)}
          subtext="Este mes"
          colorClass="bg-gradient-to-br from-emerald-500 to-teal-600"
          glowClass="text-emerald-400"
          loading={loading}
        />
        <KpiCard
          icon={Clock}
          label="Pendiente"
          value={formatCLP(summary?.total_pending)}
          subtext="Sin cobrar"
          colorClass="bg-gradient-to-br from-amber-500 to-orange-600"
          glowClass="text-amber-400"
          loading={loading}
        />
        <KpiCard
          icon={AlertTriangle}
          label="Morosos"
          value={loading ? '—' : `${summary?.delinquent_count ?? delinquent.length}`}
          subtext="Membresías vencidas"
          colorClass="bg-gradient-to-br from-red-500 to-rose-600"
          glowClass="text-red-400"
          loading={loading}
        />
        <KpiCard
          icon={Percent}
          label="Tasa de Pago"
          value={loading ? '—' : `${summary?.payment_rate ?? 0}%`}
          subtext="Facturas cobradas"
          colorClass="bg-gradient-to-br from-cyan-500 to-blue-600"
          glowClass="text-cyan-400"
          loading={loading}
        />
      </div>

      {/* ── Revenue Trend Chart + Quick Action ──────────────────────────── */}
      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        {/* Chart — 2/3 width */}
        <div className="xl:col-span-2 glass-panel p-5">
          <div className="flex items-center justify-between mb-5">
            <div>
              <h2 className="text-sm font-bold text-white flex items-center gap-2">
                <TrendingUp className="h-4 w-4 text-cyan-400" />
                Tendencia de Ingresos
              </h2>
              <p className="text-xs text-slate-400 mt-0.5">Últimos 6 meses</p>
            </div>
          </div>
          {loading ? (
            <div className="h-52 flex items-center justify-center">
              <Loader2 className="h-8 w-8 animate-spin text-cyan-400/40" />
            </div>
          ) : revenueData.length === 0 ? (
            <div className="h-52 flex items-center justify-center text-slate-500 text-sm">
              Sin datos de ingresos aún.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={200}>
              <AreaChart data={revenueData} margin={{ top: 4, right: 4, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="revenueGradient" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00e5ff" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#00e5ff" stopOpacity={0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#334155" vertical={false} />
                <XAxis
                  dataKey="month"
                  tick={{ fill: '#64748b', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  tickFormatter={(v) => `$${(v / 1000).toFixed(0)}k`}
                  tick={{ fill: '#64748b', fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                  width={48}
                />
                <Tooltip content={<CustomTooltip />} />
                <Area
                  type="monotone"
                  dataKey="revenue"
                  stroke="#00e5ff"
                  strokeWidth={2.5}
                  fill="url(#revenueGradient)"
                  dot={{ fill: '#00e5ff', strokeWidth: 0, r: 4 }}
                  activeDot={{ r: 6, fill: '#00e5ff', stroke: '#0f172a', strokeWidth: 2 }}
                />
              </AreaChart>
            </ResponsiveContainer>
          )}
        </div>

        {/* Quick Action Panel — 1/3 width */}
        <QuickActionPanel onSuccess={() => loadData(true)} />
      </div>

      {/* ── Tabs: Invoices / Delinquent ─────────────────────────────────── */}
      <div className="glass-panel overflow-hidden">
        {/* Tab header */}
        <div className="flex border-b border-slate-700/50">
          <button
            id="billing-tab-invoices"
            onClick={() => setActiveTab('invoices')}
            className={`flex items-center gap-2 px-5 py-3.5 text-sm font-semibold transition-all duration-200 border-b-2 ${
              activeTab === 'invoices'
                ? 'border-cyan-400 text-cyan-400 bg-cyan-500/5'
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <FileText className="h-4 w-4" />
            Facturas
            <span className="ml-1 text-xs bg-slate-700 text-slate-300 px-2 py-0.5 rounded-full font-medium">
              {invoices.length}
            </span>
          </button>
          <button
            id="billing-tab-delinquent"
            onClick={() => setActiveTab('delinquent')}
            className={`flex items-center gap-2 px-5 py-3.5 text-sm font-semibold transition-all duration-200 border-b-2 ${
              activeTab === 'delinquent'
                ? 'border-red-400 text-red-400 bg-red-500/5'
                : 'border-transparent text-slate-400 hover:text-white hover:bg-slate-800/50'
            }`}
          >
            <AlertTriangle className="h-4 w-4" />
            Morosos
            {delinquent.length > 0 && (
              <span className="ml-1 text-xs bg-red-500/20 text-red-400 border border-red-500/20 px-2 py-0.5 rounded-full font-bold animate-pulse">
                {delinquent.length}
              </span>
            )}
          </button>
        </div>

        {/* ── INVOICES TAB ────────────────────────────────────────────── */}
        {activeTab === 'invoices' && (
          <div>
            {/* Filters bar */}
            <div className="flex flex-col sm:flex-row items-start sm:items-center gap-3 p-4 border-b border-slate-700/30">
              {/* Status pills */}
              <div className="flex items-center gap-1.5 flex-wrap">
                <Filter className="h-3.5 w-3.5 text-slate-500" />
                {STATUS_FILTERS.map((f) => (
                  <button
                    key={f}
                    id={`billing-filter-${f.toLowerCase()}`}
                    onClick={() => setStatusFilter(f)}
                    className={`px-3 py-1 rounded-full text-xs font-semibold border transition-all duration-200 ${
                      statusFilter === f
                        ? 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
                        : 'text-slate-400 border-slate-700 hover:text-white hover:border-slate-500'
                    }`}
                  >
                    {f === 'TODOS' ? 'Todas' : STATUS_CONFIG[f]?.label ?? f}
                  </button>
                ))}
              </div>

              {/* Search */}
              <div className="relative sm:ml-auto">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-slate-500" />
                <input
                  id="billing-search"
                  type="text"
                  placeholder="Buscar factura o miembro..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="input-field text-xs pl-8 pr-8 py-2 w-56"
                />
                {searchQuery && (
                  <button
                    onClick={() => setSearchQuery('')}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-500 hover:text-white"
                  >
                    <X className="h-3.5 w-3.5" />
                  </button>
                )}
              </div>
            </div>

            {/* Table */}
            <div className="overflow-x-auto">
              <table className="w-full text-sm">
                <thead>
                  <tr className="border-b border-slate-700/50 text-xs font-semibold text-slate-400 uppercase tracking-wider">
                    <th className="px-5 py-3 text-left">N° Factura</th>
                    <th className="px-5 py-3 text-left">Miembro</th>
                    <th className="px-5 py-3 text-left">Vencimiento</th>
                    <th className="px-5 py-3 text-right">Total</th>
                    <th className="px-5 py-3 text-left">Estado</th>
                    <th className="px-5 py-3 text-left">Acciones</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-700/30">
                  {loading ? (
                    Array.from({ length: 6 }).map((_, i) => (
                      <tr key={i} className="animate-pulse">
                        {Array.from({ length: 6 }).map((_, j) => (
                          <td key={j} className="px-5 py-3.5">
                            <div className="h-4 bg-slate-700/60 rounded-lg w-full" />
                          </td>
                        ))}
                      </tr>
                    ))
                  ) : filteredInvoices.length === 0 ? (
                    <tr>
                      <td colSpan={6} className="px-5 py-12 text-center text-slate-500 text-sm">
                        No se encontraron facturas con los filtros aplicados.
                      </td>
                    </tr>
                  ) : (
                    filteredInvoices.map((inv) => (
                      <tr
                        key={inv.id}
                        className="hover:bg-slate-800/30 transition-colors duration-150 group"
                      >
                        <td className="px-5 py-3.5 font-mono text-xs text-slate-300 font-medium">
                          {inv.invoice_number}
                        </td>
                        <td className="px-5 py-3.5">
                          <div className="flex items-center gap-2.5">
                            <div className="h-7 w-7 rounded-full bg-gradient-to-br from-slate-600 to-slate-700 flex items-center justify-center text-[11px] font-bold text-slate-200 flex-shrink-0 border border-slate-600">
                              {inv.member_name?.[0] ?? '?'}
                            </div>
                            <span className="text-slate-200 font-medium text-xs truncate max-w-[120px]">
                              {inv.member_name ?? '—'}
                            </span>
                          </div>
                        </td>
                        <td className="px-5 py-3.5 text-xs text-slate-400">{formatDate(inv.due_date)}</td>
                        <td className="px-5 py-3.5 text-right">
                          <span className="font-bold text-white tabular-nums">{formatCLP(inv.total)}</span>
                        </td>
                        <td className="px-5 py-3.5">
                          <StatusBadge status={inv.status} />
                        </td>
                        <td className="px-5 py-3.5">
                          {inv.payment_link && inv.status !== 'PAID' && (
                            <a
                              href={inv.payment_link}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center gap-1 text-xs text-cyan-400 hover:text-cyan-300 font-medium transition-colors"
                            >
                              <ExternalLink className="h-3.5 w-3.5" />
                              Enviar cobro por correo
                            </a>
                          )}
                        </td>
                      </tr>
                    ))
                  )}
                </tbody>
              </table>
            </div>

            {/* Footer count */}
            {!loading && (
              <div className="px-5 py-3 border-t border-slate-700/30 text-xs text-slate-500">
                Mostrando {filteredInvoices.length} de {invoices.length} facturas
              </div>
            )}
          </div>
        )}

        {/* ── DELINQUENT TAB ──────────────────────────────────────────── */}
        {activeTab === 'delinquent' && (
          <div>
            {loading ? (
              <div className="p-8 flex justify-center">
                <Loader2 className="h-8 w-8 animate-spin text-cyan-400/40" />
              </div>
            ) : delinquent.length === 0 ? (
              <div className="p-12 text-center">
                <CheckCircle2 className="h-12 w-12 text-emerald-400 mx-auto mb-3 opacity-60" />
                <p className="text-slate-400 font-medium">Sin morosos registrados</p>
                <p className="text-slate-500 text-xs mt-1">Todos los miembros tienen membresía activa</p>
              </div>
            ) : (
              <div className="divide-y divide-slate-700/30">
                {delinquent.map((member) => (
                  <div
                    key={member.id}
                    className="flex items-center justify-between px-5 py-4 hover:bg-slate-800/30 transition-colors group"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-9 w-9 rounded-full bg-gradient-to-br from-red-500/20 to-rose-600/20 flex items-center justify-center text-sm font-bold text-red-400 flex-shrink-0 border border-red-500/20">
                        {member.first_name?.[0]}{member.last_name?.[0]}
                      </div>
                      <div className="min-w-0">
                        <p className="text-sm font-semibold text-white truncate">
                          {member.first_name} {member.last_name}
                        </p>
                        <p className="text-xs text-slate-400 truncate">{member.email}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      <div className="text-right hidden sm:block">
                        <p className="text-xs text-slate-500">Venció</p>
                        <p className="text-xs font-semibold text-red-400">{formatDate(member.end_date)}</p>
                      </div>
                      <span className="text-[10px] font-bold px-2 py-1 rounded-full bg-red-500/10 text-red-400 border border-red-500/20 uppercase tracking-wider">
                        Moroso
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}

            {/* Footer count */}
            {!loading && delinquent.length > 0 && (
              <div className="px-5 py-3 border-t border-slate-700/30 flex items-center justify-between text-xs text-slate-500">
                <span>{delinquent.length} miembro{delinquent.length !== 1 ? 's' : ''} moroso{delinquent.length !== 1 ? 's' : ''}</span>
                <span className="text-red-400 font-medium flex items-center gap-1">
                  <AlertTriangle className="h-3.5 w-3.5" />
                  Requiere atención
                </span>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default BillingDashboard;
