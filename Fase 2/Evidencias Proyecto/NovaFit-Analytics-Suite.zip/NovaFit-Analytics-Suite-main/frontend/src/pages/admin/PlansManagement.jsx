import React, { useState, useEffect } from 'react';
import { Plus, Edit2, Trash2, Loader2, Save, X } from 'lucide-react';
import api from '../../services/api';
import toast from 'react-hot-toast';

const PlansManagement = () => {
  const [plans, setPlans] = useState([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [modalMode, setModalMode] = useState('create'); // 'create' | 'edit'
  const [selectedPlan, setSelectedPlan] = useState(null);
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    billing_cycle: 'monthly',
    price: 0,
    duration_days: 30,
    max_freeze_days: 15,
    is_active: true
  });

  const fetchPlans = async () => {
    try {
      const res = await api.get('/api/v1/plans');
      setPlans(res.data);
    } catch (error) {
      toast.error('Error al cargar los planes');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchPlans();
    // Auto-refresh every 30 seconds
    const interval = setInterval(fetchPlans, 30000);
    return () => clearInterval(interval);
  }, []);

  const openCreateModal = () => {
    setModalMode('create');
    setFormData({
      name: '',
      description: '',
      billing_cycle: 'monthly',
      price: 0,
      duration_days: 30,
      max_freeze_days: 15,
      is_active: true
    });
    setIsModalOpen(true);
  };

  const openEditModal = (plan) => {
    setModalMode('edit');
    setSelectedPlan(plan);
    setFormData({
      name: plan.name,
      description: plan.description || '',
      billing_cycle: plan.billing_cycle,
      price: plan.price,
      duration_days: plan.duration_days,
      max_freeze_days: plan.max_freeze_days,
      is_active: plan.is_active
    });
    setIsModalOpen(true);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    try {
      if (modalMode === 'create') {
        await api.post('/api/v1/plans', formData);
        toast.success('Plan creado exitosamente');
      } else {
        await api.put(`/api/v1/plans/${selectedPlan.id}`, formData);
        toast.success('Plan actualizado exitosamente');
      }
      setIsModalOpen(false);
      fetchPlans();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al guardar el plan');
    }
  };

  const handleDelete = async (id) => {
    if (!window.confirm('¿Estás seguro de eliminar este plan? Puede afectar a usuarios activos.')) return;
    try {
      await api.delete(`/api/v1/plans/${id}`);
      toast.success('Plan eliminado');
      fetchPlans();
    } catch (error) {
      toast.error('Error al eliminar el plan');
    }
  };

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-emerald-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-white">Gestión de Planes</h1>
        <button
          onClick={openCreateModal}
          className="flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 font-medium text-slate-900 hover:bg-emerald-400 transition-colors"
        >
          <Plus className="h-4 w-4" /> Nuevo Plan
        </button>
      </div>

      <div className="glass-panel overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm text-slate-300">
            <thead className="bg-slate-800/50 text-xs uppercase text-slate-400">
              <tr>
                <th className="px-6 py-4 font-medium">Nombre</th>
                <th className="px-6 py-4 font-medium">Ciclo</th>
                <th className="px-6 py-4 font-medium">Precio (CLP)</th>
                <th className="px-6 py-4 font-medium">Días Duración</th>
                <th className="px-6 py-4 font-medium">Estado</th>
                <th className="px-6 py-4 text-right font-medium">Acciones</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800">
              {plans.map((plan) => (
                <tr key={plan.id} className="hover:bg-slate-800/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-white">{plan.name}</td>
                  <td className="px-6 py-4 capitalize">{plan.billing_cycle}</td>
                  <td className="px-6 py-4">${plan.price.toLocaleString('es-CL')}</td>
                  <td className="px-6 py-4">{plan.duration_days} días</td>
                  <td className="px-6 py-4">
                    <span className={`inline-flex items-center rounded-full px-2 py-1 text-xs font-medium ${
                      plan.is_active ? 'bg-emerald-500/10 text-emerald-400' : 'bg-slate-500/10 text-slate-400'
                    }`}>
                      {plan.is_active ? 'Activo' : 'Inactivo'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                      <button
                        onClick={() => openEditModal(plan)}
                        className="rounded-lg bg-slate-800 p-2 text-slate-400 hover:bg-slate-700 hover:text-white transition-colors"
                        title="Editar plan"
                      >
                        <Edit2 className="h-4 w-4" />
                      </button>
                      <button
                        onClick={() => handleDelete(plan.id)}
                        className="rounded-lg bg-slate-800 p-2 text-slate-400 hover:bg-rose-500/20 hover:text-rose-400 transition-colors"
                        title="Eliminar plan"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
              {plans.length === 0 && (
                <tr>
                  <td colSpan="6" className="px-6 py-8 text-center text-slate-400">
                    No hay planes registrados.
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm">
          <div className="w-full max-w-md rounded-xl bg-slate-800 p-6 shadow-xl border border-slate-700 relative">
            <button 
              onClick={() => setIsModalOpen(false)}
              className="absolute top-4 right-4 text-slate-400 hover:text-white"
            >
              <X className="h-5 w-5" />
            </button>
            <h2 className="text-xl font-bold text-white mb-6">
              {modalMode === 'create' ? 'Nuevo Plan' : 'Editar Plan'}
            </h2>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-300">Nombre del Plan</label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({...formData, name: e.target.value})}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  placeholder="Ej. Plan Gold"
                />
              </div>

              <div>
                <label className="mb-1 block text-sm font-medium text-slate-300">Descripción</label>
                <input
                  type="text"
                  value={formData.description}
                  onChange={(e) => setFormData({...formData, description: e.target.value})}
                  className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  placeholder="Ej. Acceso completo 24/7"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-300">Precio (CLP)</label>
                  <input
                    type="number"
                    required
                    value={formData.price}
                    onChange={(e) => setFormData({...formData, price: parseFloat(e.target.value)})}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-300">Duración (Días)</label>
                  <input
                    type="number"
                    required
                    value={formData.duration_days}
                    onChange={(e) => setFormData({...formData, duration_days: parseInt(e.target.value)})}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-300">Ciclo de Cobro</label>
                  <select
                    value={formData.billing_cycle}
                    onChange={(e) => setFormData({...formData, billing_cycle: e.target.value})}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  >
                    <option value="monthly">Mensual</option>
                    <option value="quarterly">Trimestral</option>
                    <option value="semi_annual">Semestral</option>
                    <option value="annual">Anual</option>
                    <option value="one_time">Único</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1 block text-sm font-medium text-slate-300">Días Congelables</label>
                  <input
                    type="number"
                    required
                    value={formData.max_freeze_days}
                    onChange={(e) => setFormData({...formData, max_freeze_days: parseInt(e.target.value)})}
                    className="w-full rounded-lg bg-slate-900 border border-slate-700 p-2.5 text-white focus:border-emerald-500 focus:outline-none"
                  />
                </div>
              </div>

              <div className="flex items-center gap-2 mt-2">
                <input
                  type="checkbox"
                  id="isActive"
                  checked={formData.is_active}
                  onChange={(e) => setFormData({...formData, is_active: e.target.checked})}
                  className="rounded border-slate-700 bg-slate-900 text-emerald-500 focus:ring-emerald-500"
                />
                <label htmlFor="isActive" className="text-sm font-medium text-slate-300">
                  Plan Activo (Visible)
                </label>
              </div>

              <div className="mt-6 flex justify-end gap-3 pt-4 border-t border-slate-700">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="rounded-lg px-4 py-2 text-sm font-medium text-slate-300 hover:bg-slate-700 transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  className="flex items-center gap-2 rounded-lg bg-emerald-500 px-4 py-2 font-medium text-slate-900 hover:bg-emerald-400 transition-colors"
                >
                  <Save className="h-4 w-4" />
                  {modalMode === 'create' ? 'Crear Plan' : 'Guardar'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default PlansManagement;
