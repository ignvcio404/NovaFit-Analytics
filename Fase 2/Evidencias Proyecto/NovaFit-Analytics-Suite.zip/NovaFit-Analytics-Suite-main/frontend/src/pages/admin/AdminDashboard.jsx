import React, { useState, useEffect } from 'react';
import api from '../../services/api';
import { useAuth } from '../../context/AuthContext';
import { 
  AreaChart, Area, XAxis, YAxis, CartesianGrid, Tooltip as RechartsTooltip, ResponsiveContainer,
  Radar, RadarChart, PolarGrid, PolarAngleAxis, PolarRadiusAxis,
  PieChart, Pie, Cell
} from 'recharts';
import { TrendingUp, Users, HeartPulse, Activity, Loader2, Zap, AlertTriangle, CreditCard } from 'lucide-react';
import toast from 'react-hot-toast';

function AdminDashboard() {
  const { user } = useAuth();
  const [kpis, setKpis] = useState(null);
  const [timeSeries, setTimeSeries] = useState({ revenue_trend: [], attendance_trend: [] });
  const [athletesFatigue, setAthletesFatigue] = useState([]);
  const [recentUsers, setRecentUsers] = useState([]);
  const [systemStatus, setSystemStatus] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchData = async () => {
      try {
        const [kpiRes, tsRes, fatigueRes, recentUsersRes, systemRes] = await Promise.all([
          api.get('/api/v1/users/dashboard/kpis'),
          api.get('/api/v1/analytics/system/time-series'),
          api.get('/api/v1/analytics/fatigue/athletes'),
          api.get('/api/v1/users?page_size=5'),
          api.get('/api/v1/billing/admin/summary')
        ]);
        setKpis(kpiRes.data);
        setTimeSeries(tsRes.data);
        setAthletesFatigue(fatigueRes.data || []);
        setRecentUsers(recentUsersRes.data.items || []);
        setSystemStatus(systemRes.data);
      } catch (error) {
        toast.error('Error al cargar datos del panel general');
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);

  if (loading) {
    return (
      <div className="flex h-full items-center justify-center">
        <Loader2 className="h-10 w-10 animate-spin text-cyan-500" />
      </div>
    );
  }

  // Aggregate ACWR Data for Risk Distribution
  const riskCategories = {
    optimo: 0,
    precaucion: 0,
    peligro: 0,
    sin_datos: 0
  };

  let totalRPE = 0;
  let rpeCount = 0;

  athletesFatigue.forEach(a => {
    const acwr = a.acwr;
    if (acwr === null || acwr === undefined) riskCategories.sin_datos++;
    else if (acwr > 1.5) riskCategories.peligro++;
    else if (acwr > 1.3) riskCategories.precaucion++;
    else riskCategories.optimo++;

    if (a.avg_rpe) {
      totalRPE += a.avg_rpe;
      rpeCount++;
    }
  });

  const pieData = [
    { name: 'Óptimo (0.8 - 1.3)', value: riskCategories.optimo, color: '#10b981' },
    { name: 'Precaución (1.3 - 1.5)', value: riskCategories.precaucion, color: '#f59e0b' },
    { name: 'Riesgo (> 1.5)', value: riskCategories.peligro, color: '#ef4444' },
  ].filter(d => d.value > 0);

  const avgGymRpe = rpeCount > 0 ? (totalRPE / rpeCount).toFixed(1) : 'N/A';

  // Radar Data (Mocked dimensions based on available stats for "Community Health")
  const radarData = [
    { subject: 'Asistencia', A: kpis?.sessions_logged_this_week || 50, fullMark: 100 },
    { subject: 'Retención', A: 90, fullMark: 100 },
    { subject: 'Intensidad', A: rpeCount > 0 ? (totalRPE/rpeCount)*10 : 50, fullMark: 100 },
    { subject: 'Crecimiento', A: (kpis?.new_members_this_month || 0) * 10, fullMark: 100 },
    { subject: 'Salud ACWR', A: (riskCategories.optimo / (athletesFatigue.length || 1)) * 100, fullMark: 100 },
  ];

  return (
    <div className="space-y-6 text-slate-200">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div>
          <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-emerald-400 mb-2">
            Panel General
          </h1>
          <p className="text-slate-400">Bienvenido, {user?.first_name || 'Admin'}. Analítica predictiva y estado de tu centro.</p>
        </div>
      </header>

      {/* Futuristic KPI Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="relative overflow-hidden rounded-2xl bg-slate-800/40 p-6 border border-cyan-500/30 backdrop-blur-md group hover:bg-slate-800/60 transition-all">
          <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-cyan-500/20 blur-2xl group-hover:bg-cyan-500/30 transition-all"></div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-cyan-200">Usuarios Activos</h3>
            <Users className="h-5 w-5 text-cyan-400" />
          </div>
          <div className="text-4xl font-black text-white">{kpis?.active_members || 0}</div>
          <div className="mt-2 text-xs text-cyan-400 flex items-center gap-1">
            <TrendingUp className="h-3 w-3" /> +{kpis?.new_members_this_month || 0} este mes
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-slate-800/40 p-6 border border-emerald-500/30 backdrop-blur-md group hover:bg-slate-800/60 transition-all">
          <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-emerald-500/20 blur-2xl group-hover:bg-emerald-500/30 transition-all"></div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-emerald-200">Salud ACWR</h3>
            <HeartPulse className="h-5 w-5 text-emerald-400" />
          </div>
          <div className="text-4xl font-black text-white">
            {athletesFatigue.length ? Math.round((riskCategories.optimo / athletesFatigue.length) * 100) : 0}%
          </div>
          <div className="mt-2 text-xs text-emerald-400 flex items-center gap-1">
            Atletas en zona segura
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-slate-800/40 p-6 border border-fuchsia-500/30 backdrop-blur-md group hover:bg-slate-800/60 transition-all">
          <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-fuchsia-500/20 blur-2xl group-hover:bg-fuchsia-500/30 transition-all"></div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-fuchsia-200">Esfuerzo (RPE)</h3>
            <Zap className="h-5 w-5 text-fuchsia-400" />
          </div>
          <div className="text-4xl font-black text-white">{avgGymRpe}</div>
          <div className="mt-2 text-xs text-fuchsia-400 flex items-center gap-1">
            Promedio global del gimnasio
          </div>
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-slate-800/40 p-6 border border-blue-500/30 backdrop-blur-md group hover:bg-slate-800/60 transition-all">
          <div className="absolute -right-6 -top-6 h-24 w-24 rounded-full bg-blue-500/20 blur-2xl group-hover:bg-blue-500/30 transition-all"></div>
          <div className="flex items-center justify-between mb-2">
            <h3 className="text-sm font-medium text-blue-200">Sesiones Semanales</h3>
            <Activity className="h-5 w-5 text-blue-400" />
          </div>
          <div className="text-4xl font-black text-white">{kpis?.sessions_logged_this_week || 0}</div>
          <div className="mt-2 text-xs text-blue-400 flex items-center gap-1">
            Entrenamientos registrados esta semana
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-8">
        {/* Risk Distribution Pie Chart */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/50 p-6 border border-slate-700/50 backdrop-blur-xl shadow-xl flex flex-col">
          <h3 className="text-lg font-bold text-white mb-2">Distribución de Riesgo</h3>
          <p className="text-xs text-slate-400 mb-4">Proporción de atletas según su carga (ACWR)</p>
          <div className="flex-1 min-h-[250px] relative">
            {pieData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    innerRadius={60}
                    outerRadius={90}
                    paddingAngle={5}
                    dataKey="value"
                    stroke="none"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <RechartsTooltip 
                    contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                    itemStyle={{ color: '#fff' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-full text-slate-500 text-sm">Sin datos suficientes</div>
            )}
          </div>
          {/* Custom Legend */}
          <div className="flex flex-col gap-2 mt-4">
            {pieData.map((d, i) => (
              <div key={i} className="flex justify-between items-center text-sm">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: d.color }}></div>
                  <span className="text-slate-300">{d.name}</span>
                </div>
                <span className="font-bold text-white">{d.value}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Community Radar Chart */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/50 p-6 border border-slate-700/50 backdrop-blur-xl shadow-xl flex flex-col">
          <h3 className="text-lg font-bold text-white mb-2">Huella de la Comunidad</h3>
          <p className="text-xs text-slate-400 mb-4">Balance de métricas vitales del centro</p>
          <div className="flex-1 min-h-[250px]">
            <ResponsiveContainer width="100%" height="100%">
              <RadarChart cx="50%" cy="50%" outerRadius="70%" data={radarData}>
                <PolarGrid stroke="#334155" />
                <PolarAngleAxis dataKey="subject" tick={{ fill: '#94a3b8', fontSize: 11 }} />
                <Radar name="Comunidad" dataKey="A" stroke="#c026d3" fill="#d946ef" fillOpacity={0.3} />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                />
              </RadarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Revenue Trend Area Chart */}
        <div className="lg:col-span-1 rounded-2xl bg-slate-900/50 p-6 border border-slate-700/50 backdrop-blur-xl shadow-xl flex flex-col">
          <h3 className="text-lg font-bold text-white mb-2">Ingresos Financieros</h3>
          <div className="flex items-baseline gap-2 mb-4">
            <span className="text-3xl font-bold text-emerald-400">${Number(kpis?.revenue_this_month || 0).toLocaleString()}</span>
            <span className="text-xs text-slate-400">Este mes</span>
          </div>
          <div className="flex-1 min-h-[200px]">
            <ResponsiveContainer width="100%" height="100%">
              <AreaChart data={timeSeries.revenue_trend} margin={{ top: 0, right: 0, left: 0, bottom: 0 }}>
                <defs>
                  <linearGradient id="colorRev" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#10b981" stopOpacity={0.5}/>
                    <stop offset="95%" stopColor="#10b981" stopOpacity={0}/>
                  </linearGradient>
                </defs>
                <XAxis dataKey="name" hide />
                <YAxis hide />
                <RechartsTooltip 
                  contentStyle={{ backgroundColor: '#0f172a', borderColor: '#334155', borderRadius: '8px' }}
                  itemStyle={{ color: '#10b981' }}
                  formatter={(val) => [`$${val.toLocaleString()}`, 'Ingreso']}
                  labelStyle={{ display: 'none' }}
                />
                <Area type="monotone" dataKey="value" stroke="#10b981" strokeWidth={3} fill="url(#colorRev)" />
              </AreaChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mt-8">
        {/* Actividad Reciente */}
        <div className="rounded-2xl border border-slate-700/50 bg-slate-900/50 p-6 shadow-xl backdrop-blur-xl">
          <h3 className="text-lg font-semibold text-white mb-4">Actividad Reciente</h3>
          {recentUsers.length > 0 ? (
            <div className="space-y-4">
              {recentUsers.map((u) => (
                <div key={u.id} className="flex items-center justify-between border-b border-slate-700/50 pb-3 last:border-0 last:pb-0">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-full bg-slate-700 flex items-center justify-center text-slate-300 font-bold">
                      {u.first_name ? u.first_name.charAt(0).toUpperCase() : '?'}
                    </div>
                    <div>
                      <p className="text-sm font-medium text-white">{u.first_name} {u.last_name}</p>
                      <p className="text-xs text-slate-400">{u.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <span className="inline-block px-2 py-1 rounded text-xs font-medium bg-slate-700 text-slate-300">
                      {u.roles[0] || 'Member'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400">
              <Activity className="h-8 w-8 mb-3 opacity-50" />
              <p>No hay actividad reciente.</p>
            </div>
          )}
        </div>

        {/* Estado del Sistema */}
        <div className="rounded-2xl border border-slate-700/50 bg-slate-900/50 p-6 shadow-xl backdrop-blur-xl">
          <h3 className="text-lg font-semibold text-white mb-4">Estado del Sistema</h3>
          {systemStatus ? (
            <div className="space-y-5">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <TrendingUp className="h-5 w-5 text-emerald-400" />
                  <span className="text-sm font-medium">Tasa de Recaudación</span>
                </div>
                <span className="text-white font-bold">{systemStatus.payment_rate}%</span>
              </div>
              
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <CreditCard className="h-5 w-5 text-indigo-400" />
                  <span className="text-sm font-medium">Facturas Pagadas</span>
                </div>
                <span className="text-white font-bold">${systemStatus.total_collected.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <Activity className="h-5 w-5 text-amber-400" />
                  <span className="text-sm font-medium">Facturas Pendientes</span>
                </div>
                <span className="text-white font-bold">${systemStatus.total_pending.toLocaleString()}</span>
              </div>

              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2 text-slate-300">
                  <Users className="h-5 w-5 text-rose-400" />
                  <span className="text-sm font-medium">Atletas Morosos</span>
                </div>
                <span className="text-white font-bold">{systemStatus.delinquent_count}</span>
              </div>
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center h-48 text-slate-400">
              <CreditCard className="h-8 w-8 mb-3 opacity-50" />
              <p>Todos los servicios operan con normalidad.</p>
            </div>
          )}
        </div>
      </div>

    </div>
  );
}

export default AdminDashboard;
