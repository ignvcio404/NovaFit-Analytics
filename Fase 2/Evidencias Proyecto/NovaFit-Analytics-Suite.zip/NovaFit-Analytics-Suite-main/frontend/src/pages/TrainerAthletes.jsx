import React, { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { Users, Activity, TrendingUp, Search, Loader2, X } from 'lucide-react';

function TrainerAthletes() {
  const [athletes, setAthletes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');

  // Modal State
  const [selectedAthlete, setSelectedAthlete] = useState(null);
  const [athleteStats, setAthleteStats] = useState(null);
  const [athleteSessions, setAthleteSessions] = useState([]);
  const [athleteWeights, setAthleteWeights] = useState([]);
  const [loadingStats, setLoadingStats] = useState(false);

  const fetchAthletes = async () => {
    try {
      setLoading(true);
      const response = await api.get('/api/v1/trainer/dashboard');
      setAthletes(response.data.active_athletes || []);
    } catch (error) {
      toast.error('Error al cargar la lista de atletas');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchAthletes();
  }, []);

  const openAthleteModal = async (athlete) => {
    setSelectedAthlete(athlete);
    setLoadingStats(true);
    setAthleteStats(null);
    setAthleteSessions([]);
    setAthleteWeights([]);
    try {
      const [statsRes, sessionsRes, weightsRes] = await Promise.all([
        api.get(`/api/v1/analytics/fatigue/${athlete.id}`),
        api.get(`/api/v1/trainer/athletes/${athlete.id}/sessions`),
        api.get(`/api/v1/athlete/weight-history/${athlete.id}`)
      ]);
      setAthleteStats(statsRes.data);
      setAthleteSessions(sessionsRes.data || []);
      setAthleteWeights(weightsRes.data || []);
    } catch (error) {
      toast.error('Error al cargar datos del atleta');
    } finally {
      setLoadingStats(false);
    }
  };

  const closeAthleteModal = () => {
    setSelectedAthlete(null);
    setAthleteStats(null);
  };

  // Safe mapping for analytics data (handles both /me and /fatigue/{id} schemas)
  const getSafeMetric = (data) => {
    if (!data) return {};
    return {
      acwr: data.acwr ?? data.acwr_value ?? data.current_acwr ?? null,
      fatigue: data.fatigue_score ?? data.fatigue ?? data.composite_fatigue_score ?? null,
      needsDeload: data.deload_recommended ?? data.needs_deload ?? false,
      reason: data.deload_reason ?? data.recommendation_reason ?? 'Sin recomendaciones.',
      sessions: data.sessions_completed ?? data.acute_sessions ?? 0,
      acuteLoad: data.acute_workload ?? data.acute_load ?? null,
      chronicLoad: data.chronic_workload ?? data.chronic_load ?? null,
    };
  };

  const stats = getSafeMetric(athleteStats);

  const filteredAthletes = athletes.filter(a => 
    `${a.first_name} ${a.last_name}`.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="space-y-6 text-slate-200 h-full flex flex-col relative">
      <header className="mb-4 flex flex-col sm:flex-row justify-between sm:items-end gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Mis Atletas</h1>
          <p className="text-slate-400">Listado detallado de tus clientes vinculados y su estado físico.</p>
        </div>
        <div className="relative w-full sm:w-64">
          <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
            <Search className="h-4 w-4 text-slate-500" />
          </div>
          <input
            type="text"
            placeholder="Buscar atleta..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full pl-9 pr-4 py-2 bg-slate-800/50 border border-slate-700/50 rounded-xl focus:outline-none focus:border-cyan-500 text-sm transition-colors text-white"
          />
        </div>
      </header>

      <div className="glass-panel overflow-hidden flex-1 flex flex-col">
        {loading ? (
          <div className="flex-1 flex items-center justify-center min-h-[300px]">
            <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
          </div>
        ) : filteredAthletes.length === 0 ? (
          <div className="flex-1 flex flex-col items-center justify-center min-h-[300px] text-center p-6">
            <Users className="h-12 w-12 text-slate-600 mb-4" />
            <h3 className="text-lg font-semibold text-white mb-1">No se encontraron atletas</h3>
            <p className="text-slate-400 max-w-sm">No tienes atletas vinculados que coincidan con la búsqueda.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left border-collapse">
              <thead>
                <tr className="bg-slate-800/50 border-b border-slate-700/50 text-slate-300 text-sm">
                  <th className="py-4 px-6 font-semibold">Atleta</th>
                  <th className="py-4 px-6 font-semibold">Estado de Fatiga</th>
                  <th className="py-4 px-6 font-semibold">ACWR</th>
                  <th className="py-4 px-6 font-semibold">Fatiga</th>
                  <th className="py-4 px-6 font-semibold text-right">Acciones</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-700/50">
                {filteredAthletes.map((athlete) => (
                  <tr key={athlete.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-3">
                        <div className="h-10 w-10 bg-cyan-500/10 rounded-full flex items-center justify-center border border-cyan-500/20 text-cyan-400 font-bold">
                          {athlete.first_name[0]}{athlete.last_name[0]}
                        </div>
                        <div>
                          <p className="font-semibold text-white">{athlete.first_name} {athlete.last_name}</p>
                          <p className="text-xs text-slate-400">ID: {athlete.id.substring(0, 8)}...</p>
                        </div>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      {athlete.acwr > 1.5 ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-red-500/10 text-red-400 border border-red-500/20">
                          <span className="h-2 w-2 rounded-full bg-red-500 animate-pulse"></span> Riesgo Crítico
                        </span>
                      ) : (athlete.acwr >= 0.8 && athlete.acwr <= 1.3) ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                          <span className="h-2 w-2 rounded-full bg-emerald-500"></span> Óptimo
                        </span>
                      ) : (athlete.acwr > 1.3 && athlete.acwr <= 1.5) ? (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                          <span className="h-2 w-2 rounded-full bg-amber-500"></span> Precaución
                        </span>
                      ) : (
                        <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full text-xs font-medium bg-slate-500/10 text-slate-400 border border-slate-500/20">
                          <span className="h-2 w-2 rounded-full bg-slate-500"></span> Desentrenado / N/A
                        </span>
                      )}
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2">
                        <TrendingUp className="h-4 w-4 text-slate-500" />
                        <span className="font-medium text-slate-200">{athlete.acwr != null ? Number(athlete.acwr).toFixed(2) : 'N/A'}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6">
                      <div className="flex items-center gap-2">
                        <Activity className="h-4 w-4 text-slate-500" />
                        <span className="font-medium text-slate-200">{athlete.fatigue_score != null ? Number(athlete.fatigue_score).toFixed(1) : 'N/A'}</span>
                      </div>
                    </td>
                    <td className="py-4 px-6 text-right">
                      <button 
                        onClick={() => openAthleteModal(athlete)}
                        className="px-3 py-1.5 bg-slate-700/50 hover:bg-slate-700 text-slate-300 hover:text-white rounded-lg text-xs font-medium transition-colors"
                      >
                        Gestionar
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Athlete Modal */}
      {selectedAthlete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-slate-900 border border-slate-700/50 rounded-2xl w-full max-w-lg shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-slate-700/50 flex justify-between items-start bg-slate-800/30">
              <div className="flex items-center gap-4">
                <div className="h-12 w-12 bg-cyan-500/10 rounded-full flex items-center justify-center border border-cyan-500/20 text-cyan-400 text-xl font-bold">
                  {selectedAthlete.first_name[0]}{selectedAthlete.last_name[0]}
                </div>
                <div>
                  <h2 className="text-xl font-bold text-white">{selectedAthlete.first_name} {selectedAthlete.last_name}</h2>
                  <p className="text-sm text-slate-400">ID: {selectedAthlete.id.substring(0,8)}</p>
                </div>
              </div>
              <button onClick={closeAthleteModal} className="text-slate-400 hover:text-white p-1 rounded-lg hover:bg-slate-800 transition-colors">
                <X className="h-5 w-5" />
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto flex-1">
              {loadingStats ? (
                <div className="flex flex-col items-center justify-center py-12">
                  <Loader2 className="h-8 w-8 animate-spin text-cyan-400 mb-4" />
                  <p className="text-slate-400 text-sm">Cargando métricas avanzadas...</p>
                </div>
              ) : athleteStats ? (
                <div className="space-y-6">
                  {/* Status Card */}
                  <div className={`p-4 rounded-xl border ${stats.needsDeload ? 'bg-red-500/10 border-red-500/20' : 'bg-emerald-500/10 border-emerald-500/20'}`}>
                    <h3 className={`font-semibold mb-1 ${stats.needsDeload ? 'text-red-400' : 'text-emerald-400'}`}>
                      {stats.needsDeload ? '¡Descarga Recomendada!' : 'Estado Óptimo'}
                    </h3>
                    <p className="text-sm text-slate-300">{stats.reason}</p>
                  </div>

                  {/* Metrics Grid */}
                  <div className="grid grid-cols-2 gap-4">
                    <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                      <div className="text-sm text-slate-400 mb-1 flex items-center gap-2"><TrendingUp className="h-4 w-4"/> ACWR</div>
                      <div className="text-2xl font-bold text-white">{stats.acwr != null ? Number(stats.acwr).toFixed(2) : 'N/A'}</div>
                      <div className="text-xs text-slate-500 mt-1">Ratio de carga Crónica/Aguda</div>
                    </div>
                    <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                      <div className="text-sm text-slate-400 mb-1 flex items-center gap-2"><Activity className="h-4 w-4"/> Puntuación de Fatiga</div>
                      <div className="text-2xl font-bold text-white">{stats.fatigue != null ? Number(stats.fatigue).toFixed(1) : 'N/A'}/100</div>
                      <div className="text-xs text-slate-500 mt-1">Basado en volumen y RPE</div>
                    </div>
                  </div>

                  {/* Session Metrics */}
                  <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                    <h4 className="text-sm font-semibold text-white mb-3">Historial Reciente</h4>
                    <div className="space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-slate-400">Sesiones (7 días):</span>
                        <span className="font-medium text-slate-200">{stats.sessions}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Carga Aguda (7 días):</span>
                        <span className="font-medium text-slate-200">{stats.acuteLoad != null ? Number(stats.acuteLoad).toFixed(1) : '0.0'}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-slate-400">Carga Crónica (28 días):</span>
                        <span className="font-medium text-slate-200">{stats.chronicLoad != null ? Number(stats.chronicLoad).toFixed(1) : '0.0'}</span>
                      </div>
                    </div>
                  </div>

                  {/* Sessions List */}
                  <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                    <h4 className="text-sm font-semibold text-white mb-3">Rutinas Asignadas</h4>
                    {athleteSessions.length === 0 ? (
                      <p className="text-sm text-slate-500">No hay rutinas asignadas.</p>
                    ) : (
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                        {athleteSessions.map(session => (
                          <div key={session.id} className="flex justify-between items-center bg-slate-900/50 p-3 rounded-lg border border-slate-700/30">
                            <div>
                              <p className="text-sm font-medium text-slate-200">{session.name}</p>
                              <p className="text-xs text-slate-500">{new Date(session.scheduled_date).toLocaleDateString()}</p>
                            </div>
                            <div>
                              {session.status === 'pending' || session.status === 'planned' ? (
                                <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-medium bg-amber-500/10 text-amber-400 border border-amber-500/20">
                                  Pendiente
                                </span>
                              ) : (
                                <span className="inline-flex items-center gap-1.5 px-2 py-1 rounded-md text-[10px] font-medium bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
                                  Completada
                                </span>
                              )}
                            </div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>

                  {/* Weight History List */}
                  <div className="bg-slate-800/50 p-4 rounded-xl border border-slate-700/50">
                    <h4 className="text-sm font-semibold text-white mb-3">Evolución de Peso Corporal</h4>
                    {athleteWeights.length === 0 ? (
                      <p className="text-sm text-slate-500">No hay registros de peso aún.</p>
                    ) : (
                      <div className="space-y-3 max-h-48 overflow-y-auto pr-2">
                        {athleteWeights.map(w => (
                          <div key={w.id} className="flex justify-between items-center bg-slate-900/50 p-3 rounded-lg border border-slate-700/30">
                            <div>
                              <p className="text-sm font-bold text-cyan-400">{w.weight_kg} kg</p>
                              <p className="text-xs text-slate-500">{new Date(w.measured_at).toLocaleDateString()}</p>
                            </div>
                            {w.notes && (
                              <div className="text-xs text-slate-400 max-w-[50%] text-right truncate">
                                {w.notes}
                              </div>
                            )}
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="text-center py-12 text-slate-500">
                  No se pudieron cargar las métricas.
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default TrainerAthletes;
