import React, { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { useAuth } from '../context/AuthContext';
import { Users, UserPlus, Clock, Mail, X, Activity, TrendingUp, Loader2 } from 'lucide-react';

function TrainerDashboard() {
  const { user } = useAuth();
  const [activeAthletes, setActiveAthletes] = useState([]);
  const [pendingAthletes, setPendingAthletes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [emailInput, setEmailInput] = useState('');
  const [isInviting, setIsInviting] = useState(false);

  const fetchDashboardData = async () => {
    try {
      setLoading(true);
      const response = await api.get('/api/v1/trainer/dashboard');
      setActiveAthletes(response.data.active_athletes || []);
      setPendingAthletes(response.data.pending_athletes || []);
    } catch (error) {
      toast.error('Error al cargar el panel de entrenador');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDashboardData();
  }, []);

  const handleInviteAthlete = async (e) => {
    e.preventDefault();
    if (!emailInput) return;

    try {
      setIsInviting(true);
      await api.post('/api/v1/trainer/invite-athlete', { athlete_email: emailInput });
      toast.success('Invitación enviada correctamente');
      setEmailInput('');
      fetchDashboardData();
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al invitar al atleta');
    } finally {
      setIsInviting(false);
    }
  };

  const handleRemoveAthlete = async (athleteId) => {
    if (!window.confirm('¿Estás seguro de que deseas desvincular a este atleta?')) return;

    try {
      await api.delete(`/api/v1/trainer/remove-athlete/${athleteId}`);
      toast.success('Atleta desvinculado');
      fetchDashboardData();
    } catch (error) {
      toast.error('Error al desvincular al atleta');
    }
  };

  if (loading) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-200">
      <header className="mb-8 flex flex-col sm:flex-row sm:items-start sm:justify-between gap-4">
        <div>
          <h1 className="text-3xl font-bold text-white mb-2">Portal de Entrenador</h1>
          <p className="text-slate-400">Bienvenido, {user?.first_name || 'Entrenador'}.</p>
        </div>
      </header>

      {/* Invite Section */}
      <div className="glass-panel p-6">
        <div className="flex items-center gap-3 mb-4">
          <div className="p-2 bg-indigo-500/20 rounded-lg">
            <UserPlus className="h-5 w-5 text-indigo-400" />
          </div>
          <h2 className="text-xl font-bold text-white">Invitar Nuevo Atleta</h2>
        </div>
        <p className="text-slate-400 text-sm mb-6">
          Ingresa el correo del atleta para enviarle una invitación de vinculación.
        </p>
        <form onSubmit={handleInviteAthlete} className="flex flex-col sm:flex-row gap-4">
          <div className="relative flex-1">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Mail className="h-5 w-5 text-slate-500" />
            </div>
            <input
              type="email"
              value={emailInput}
              onChange={(e) => setEmailInput(e.target.value)}
              placeholder="correo@ejemplo.com"
              className="w-full pl-10 pr-4 py-3 bg-slate-800/50 border border-slate-700/50 rounded-xl focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-colors text-white placeholder-slate-500"
              required
            />
          </div>
          <button
            type="submit"
            disabled={isInviting || !emailInput}
            className="px-6 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-700 disabled:text-slate-400 text-white font-medium rounded-xl transition-all flex items-center justify-center gap-2"
          >
            {isInviting ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Enviar Invitación'}
          </button>
        </form>
      </div>

      <div className="grid lg:grid-cols-2 gap-6">
        {/* Active Athletes */}
        <div className="glass-panel p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-emerald-500/20 rounded-lg">
                <Users className="h-5 w-5 text-emerald-400" />
              </div>
              <h2 className="text-xl font-bold text-white">Atletas Activos</h2>
            </div>
            <span className="bg-slate-800 text-slate-300 text-xs px-2 py-1 rounded-full font-medium">
              {activeAthletes.length} total
            </span>
          </div>

          {activeAthletes.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-10 text-center border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
              <Users className="h-10 w-10 text-slate-600 mb-3" />
              <p className="text-slate-400">No tienes atletas vinculados actualmente.</p>
            </div>
          ) : (
            <ul className="space-y-4 flex-1">
              {activeAthletes.map((athlete) => (
                <li key={athlete.id} className="p-4 bg-slate-800/50 border border-slate-700/50 rounded-xl hover:border-slate-600 transition-colors flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div>
                    <h3 className="font-bold text-white text-lg">
                      {athlete.first_name} {athlete.last_name}
                    </h3>
                    <div className="flex flex-wrap items-center gap-4 mt-2">
                      <div className="flex items-center gap-1 text-sm text-slate-400">
                        <TrendingUp className="h-4 w-4 text-cyan-400" />
                        <span>ACWR: <strong className="text-slate-200">{athlete.acwr || 'N/A'}</strong></span>
                      </div>
                      <div className="flex items-center gap-1 text-sm text-slate-400">
                        <Activity className="h-4 w-4 text-emerald-400" />
                        <span>Fatiga: <strong className="text-slate-200">{athlete.fatigue_score || 'N/A'}</strong></span>
                      </div>
                    </div>
                  </div>
                  <button
                    onClick={() => handleRemoveAthlete(athlete.id)}
                    className="flex items-center justify-center gap-2 px-4 py-2 bg-red-500/10 hover:bg-red-500/20 text-red-400 rounded-lg transition-colors text-sm font-medium"
                  >
                    <X className="h-4 w-4" /> Desvincular
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Pending Invitations */}
        <div className="glass-panel p-6 flex flex-col">
          <div className="flex items-center justify-between mb-6">
            <div className="flex items-center gap-3">
              <div className="p-2 bg-amber-500/20 rounded-lg">
                <Clock className="h-5 w-5 text-amber-400" />
              </div>
              <h2 className="text-xl font-bold text-white">Invitaciones Pendientes</h2>
            </div>
            <span className="bg-slate-800 text-slate-300 text-xs px-2 py-1 rounded-full font-medium">
              {pendingAthletes.length} pendientes
            </span>
          </div>

          {pendingAthletes.length === 0 ? (
            <div className="flex-1 flex flex-col items-center justify-center py-10 text-center border border-dashed border-slate-700 rounded-xl bg-slate-800/20">
              <Clock className="h-10 w-10 text-slate-600 mb-3" />
              <p className="text-slate-400">No hay invitaciones esperando respuesta.</p>
            </div>
          ) : (
            <ul className="space-y-4 flex-1">
              {pendingAthletes.map((athlete) => (
                <li key={athlete.id} className="p-4 bg-slate-800/30 border border-slate-700/50 rounded-xl flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                  <div>
                    <h3 className="font-semibold text-slate-200">
                      {athlete.first_name} {athlete.last_name}
                    </h3>
                    <p className="text-sm text-amber-500/80 mt-1 flex items-center gap-1">
                      <Clock className="h-3 w-3" /> Esperando aceptación
                    </p>
                  </div>
                  <button
                    onClick={() => handleRemoveAthlete(athlete.id)}
                    className="text-slate-400 hover:text-red-400 text-sm font-medium transition-colors"
                  >
                    Cancelar
                  </button>
                </li>
              ))}
            </ul>
          )}
        </div>
      </div>
    </div>
  );
}

export default TrainerDashboard;
