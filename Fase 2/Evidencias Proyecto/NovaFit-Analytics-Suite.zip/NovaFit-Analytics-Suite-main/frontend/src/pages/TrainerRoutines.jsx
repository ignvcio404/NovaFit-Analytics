import React, { useState, useEffect } from 'react';
import api from '../services/api';
import toast from 'react-hot-toast';
import { ClipboardList, User, Calendar, Loader2 } from 'lucide-react';

function TrainerRoutines() {
  const [athletes, setAthletes] = useState([]);
  const [templates, setTemplates] = useState([]);
  const [loadingData, setLoadingData] = useState(true);
  
  const [selectedAthlete, setSelectedAthlete] = useState('');
  const [selectedTemplate, setSelectedTemplate] = useState('');
  const [scheduledDate, setScheduledDate] = useState('');
  const [isAssigning, setIsAssigning] = useState(false);

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoadingData(true);
        // Fetch athletes
        const dashRes = await api.get('/api/v1/trainer/dashboard');
        setAthletes(dashRes.data.active_athletes || []);
        
        // Fetch templates
        const tplRes = await api.get('/api/v1/training/templates');
        setTemplates(tplRes.data || []);
      } catch (error) {
        toast.error('Error al cargar datos necesarios');
      } finally {
        setLoadingData(false);
      }
    };
    fetchData();
  }, []);

  const handleAssign = async (e) => {
    e.preventDefault();
    if (!selectedAthlete || !selectedTemplate) {
      toast.error('Selecciona un atleta y una plantilla');
      return;
    }

    try {
      setIsAssigning(true);
      await api.post('/api/v1/trainer/assign-template', {
        athlete_id: selectedAthlete,
        template_id: parseInt(selectedTemplate),
        scheduled_date: scheduledDate || null
      });
      toast.success('Rutina asignada correctamente');
      
      // Reset form optionally
      setSelectedAthlete('');
      setSelectedTemplate('');
      setScheduledDate('');
    } catch (error) {
      toast.error(error.response?.data?.detail || 'Error al asignar rutina');
    } finally {
      setIsAssigning(false);
    }
  };

  if (loadingData) {
    return (
      <div className="flex h-full w-full items-center justify-center">
        <Loader2 className="h-8 w-8 animate-spin text-cyan-400" />
      </div>
    );
  }

  return (
    <div className="space-y-6 text-slate-200 h-full flex flex-col max-w-4xl mx-auto w-full">
      <header className="mb-4">
        <h1 className="text-3xl font-bold text-white mb-2">Asignación de Rutinas</h1>
        <p className="text-slate-400">Selecciona un atleta vinculado y envíale una plantilla de entrenamiento.</p>
      </header>

      <div className="glass-panel p-8">
        <div className="flex items-center gap-3 mb-8 border-b border-slate-700/50 pb-4">
          <div className="p-2 bg-purple-500/20 rounded-lg">
            <ClipboardList className="h-6 w-6 text-purple-400" />
          </div>
          <h2 className="text-xl font-bold text-white">Nueva Asignación</h2>
        </div>

        <form onSubmit={handleAssign} className="space-y-6">
          <div className="space-y-4">
            
            {/* Athlete Select */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1 flex items-center gap-2">
                <User className="h-4 w-4" /> Atleta Destino
              </label>
              <select
                value={selectedAthlete}
                onChange={(e) => setSelectedAthlete(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700/50 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors text-white"
              >
                <option value="">Selecciona un atleta...</option>
                {athletes.map(a => (
                  <option key={a.id} value={a.id}>{a.first_name} {a.last_name}</option>
                ))}
              </select>
            </div>

            {/* Template Select */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1 flex items-center gap-2">
                <ClipboardList className="h-4 w-4" /> Plantilla de Entrenamiento
              </label>
              <select
                value={selectedTemplate}
                onChange={(e) => setSelectedTemplate(e.target.value)}
                required
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700/50 rounded-xl focus:outline-none focus:border-purple-500 transition-colors text-white"
              >
                <option value="">Selecciona una plantilla...</option>
                {templates.map(t => (
                  <option key={t.id} value={t.id}>{t.name}</option>
                ))}
              </select>
            </div>

            {/* Date Select */}
            <div>
              <label className="block text-sm font-medium text-slate-300 mb-1 flex items-center gap-2">
                <Calendar className="h-4 w-4" /> Fecha Programada (Opcional)
              </label>
              <input
                type="date"
                value={scheduledDate}
                onChange={(e) => setScheduledDate(e.target.value)}
                className="w-full px-4 py-3 bg-slate-800/50 border border-slate-700/50 rounded-xl focus:outline-none focus:border-cyan-500 transition-colors text-white [color-scheme:dark]"
              />
            </div>

          </div>

          <div className="pt-6 border-t border-slate-700/50">
            <button
              type="submit"
              disabled={isAssigning || !selectedAthlete || !selectedTemplate}
              className="w-full sm:w-auto px-8 py-3 bg-gradient-to-r from-purple-600 to-indigo-600 hover:from-purple-500 hover:to-indigo-500 disabled:from-slate-700 disabled:to-slate-700 disabled:text-slate-400 text-white font-semibold rounded-xl transition-all shadow-lg hover:shadow-purple-500/25 flex justify-center items-center gap-2"
            >
              {isAssigning ? <Loader2 className="h-5 w-5 animate-spin" /> : 'Asignar Rutina'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

export default TrainerRoutines;
