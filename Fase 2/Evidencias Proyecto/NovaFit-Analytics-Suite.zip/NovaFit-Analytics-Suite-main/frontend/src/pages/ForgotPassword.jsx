import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { Activity, Loader2, ArrowLeft } from 'lucide-react';
import { authService } from '../services/authService';
import toast from 'react-hot-toast';

const ForgotPassword = () => {
  const [email, setEmail] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSent, setIsSent] = useState(false);
  
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    try {
      await authService.forgotPassword(email);
      setIsSent(true);
      toast.success('Si el correo está registrado, se enviaron instrucciones.');
    } catch (err) {
      toast.error('Ocurrió un error al procesar la solicitud.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--color-bg-base)] px-4">
      <div className="glass-panel w-full max-w-md p-8 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl -ml-32 -mb-32"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <img 
            src="https://uxvyjopnmxiwfbtvnbxi.supabase.co/storage/v1/object/sign/assets/logo.png?token=eyJraWQiOiJzdG9yYWdlLXVybC1zaWduaW5nLWtleV82MzM4Y2RiMC05NTY0LTRhMjktOWFmYS0xZjdkODU2OTRjMDUiLCJhbGciOiJIUzI1NiJ9.eyJ1cmwiOiJhc3NldHMvbG9nby5wbmciLCJzY29wZSI6ImRvd25sb2FkIiwiaWF0IjoxNzg2MTcxMDA0LCJleHAiOjE4MTc3MDcwMDR9.V2vualki_oTjY-8tIcYxXA71haxKaFa_BhpBgX9OPTI" 
            alt="NovaFit Logo" 
            className="h-12 w-auto mx-auto drop-shadow-md mb-6"
          />
          
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Recuperar Contraseña</h2>
          
          {isSent ? (
            <div className="w-full text-center mt-4">
              <p className="text-[var(--color-text-muted)] mb-6">
                Revisa tu bandeja de entrada o spam. Si el correo existe, te hemos enviado un enlace para crear una nueva contraseña.
              </p>
              <button
                onClick={() => navigate('/login')}
                className="btn-primary w-full flex justify-center py-3 font-semibold text-lg"
              >
                Volver al inicio de sesión
              </button>
            </div>
          ) : (
            <div className="w-full text-center">
              <p className="text-[var(--color-text-muted)] mb-8">
                Ingresa tu correo electrónico y te enviaremos un enlace para restablecerla.
              </p>
              
              <form onSubmit={handleSubmit} className="w-full space-y-6">
                <div className="space-y-2 text-left">
                  <label htmlFor="email" className="block text-sm font-medium text-[var(--color-text-muted)]">
                    Correo Electrónico
                  </label>
                  <input
                    id="email"
                    name="email"
                    type="email"
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className={`input-field w-full ${email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) ? 'border-red-500 focus:border-red-500 focus:ring-red-500/20' : ''}`}
                    placeholder="tu@correo.com"
                  />
                  {email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) && (
                    <p className="text-red-400 text-xs mt-1">Por favor, ingresa un correo electrónico válido</p>
                  )}
                </div>
                
                <button
                  type="submit"
                  disabled={isLoading || !email || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)}
                  className="btn-primary w-full flex justify-center py-3 font-semibold text-lg"
                >
                  {isLoading ? <Loader2 className="animate-spin h-6 w-6" /> : 'Enviar enlace'}
                </button>
              </form>
              
              <div className="mt-6 flex items-center justify-center">
                <Link to="/login" className="text-sm font-medium text-cyan-400 hover:text-cyan-300 transition-colors flex items-center gap-2">
                  <ArrowLeft className="h-4 w-4" />
                  Volver al inicio de sesión
                </Link>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ForgotPassword;
