import React, { useEffect } from 'react';
import { useSearchParams, useNavigate, useLocation } from 'react-router-dom';
import { CheckCircle, XCircle } from 'lucide-react';
import toast from 'react-hot-toast';

const PaymentResult = () => {
  const [searchParams] = useSearchParams();
  const navigate = useNavigate();
  const location = useLocation();

  const isSuccess = location.pathname.includes('/success');
  const paymentId = searchParams.get('payment_id');
  const status = searchParams.get('status');

  useEffect(() => {
    if (isSuccess) {
      toast.success('¡Pago completado con éxito!');
    } else {
      toast.error('Hubo un problema con el pago.');
    }
  }, [isSuccess]);

  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center px-4">
      {isSuccess ? (
        <>
          <CheckCircle className="w-20 h-20 text-emerald-500 mb-6" />
          <h1 className="text-3xl font-bold text-gray-100 mb-4">¡Pago Exitoso!</h1>
          <p className="text-gray-400 max-w-md mb-8">
            Tu pago ha sido procesado correctamente por MercadoPago. En breve recibirás un correo con el comprobante y los detalles de tu plan.
          </p>
          {paymentId && (
            <p className="text-gray-500 text-sm mb-8">Ref: {paymentId} ({status})</p>
          )}
        </>
      ) : (
        <>
          <XCircle className="w-20 h-20 text-red-500 mb-6" />
          <h1 className="text-3xl font-bold text-gray-100 mb-4">Pago Fallido o Cancelado</h1>
          <p className="text-gray-400 max-w-md mb-8">
            El pago no pudo procesarse. Puedes intentar nuevamente desde tu portal de facturación.
          </p>
        </>
      )}

      <button
        onClick={() => navigate('/')}
        className="px-6 py-3 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg font-medium transition-colors"
      >
        Volver al inicio
      </button>
    </div>
  );
};

export default PaymentResult;
