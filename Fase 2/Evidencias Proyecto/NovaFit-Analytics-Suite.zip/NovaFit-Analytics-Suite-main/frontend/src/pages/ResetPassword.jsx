import React, { useState, useEffect } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { Activity, Loader2, CheckCircle2 } from 'lucide-react';
import { authService } from '../services/authService';
import toast from 'react-hot-toast';

const ResetPassword = () => {
  const [searchParams] = useSearchParams();
  const token = searchParams.get('token');
  
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [isSuccess, setIsSuccess] = useState(false);
  
  const navigate = useNavigate();

  useEffect(() => {
    if (!token) {
      toast.error('Enlace inválido o expirado.');
      navigate('/login');
    }
  }, [token, navigate]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (password !== confirmPassword) {
      toast.error('Las contraseñas no coinciden.');
      return;
    }
    
    if (password.length < 8) {
      toast.error('La contraseña debe tener al menos 8 caracteres.');
      return;
    }
    
    setIsLoading(true);
    
    try {
      await authService.resetPassword(token, password);
      setIsSuccess(true);
      toast.success('Contraseña actualizada exitosamente.');
    } catch (err) {
      toast.error(err.response?.data?.detail || 'Error al restablecer la contraseña.');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-[var(--color-bg-base)] px-4">
      <div className="glass-panel w-full max-w-md p-8 relative overflow-hidden">
        {/* Decorative elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-cyan-500/10 rounded-full blur-3xl -mr-32 -mt-32"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-blue-600/10 rounded-full blur-3xl -ml-32 -mb-32"></div>
        
        <div className="relative z-10 flex flex-col items-center">
          <div className="bg-gradient-to-br from-cyan-400 to-blue-600 p-3 rounded-2xl mb-6 shadow-[0_0_20px_rgba(0,229,255,0.3)]">
            <Activity className="h-8 w-8 text-white" />
          </div>
          
          <h2 className="text-3xl font-bold text-white mb-2 tracking-tight">Nueva Contraseña</h2>
          
          {isSuccess ? (
            <div className="w-full text-center mt-4">
              <div className="flex justify-center mb-4">
                <CheckCircle2 className="h-16 w-16 text-emerald-400" />
              </div>
              <p className="text-[var(--color-text-muted)] mb-6">
                Tu contraseña ha sido actualizada con éxito. Ya puedes iniciar sesión con tu nueva contraseña.
              </p>
              <button
                onClick={() => navigate('/login')}
                className="btn-primary w-full flex justify-center py-3 font-semibold text-lg"
              >
                Ir a Iniciar Sesión
              </button>
            </div>
          ) : (
            <div className="w-full text-center">
              <p className="text-[var(--color-text-muted)] mb-8">
                Crea una nueva contraseña segura para tu cuenta.
              </p>
              
              <form onSubmit={handleSubmit} className="w-full space-y-6">
                <div className="space-y-2 text-left">
                  <label htmlFor="new_password" className="block text-sm font-medium text-[var(--color-text-muted)]">
                    Nueva Contraseña
                  </label>
                  <input
                    id="new_password"
                    name="new_password"
                    type="password"
                    required
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className="input-field w-full"
                    placeholder="Mínimo 8 caracteres"
                  />
                </div>
                
                <div className="space-y-2 text-left">
                  <label htmlFor="confirm_password" className="block text-sm font-medium text-[var(--color-text-muted)]">
                    Confirmar Contraseña
                  </label>
                  <input
                    id="confirm_password"
                    name="confirm_password"
                    type="password"
                    required
                    value={confirmPassword}
                    onChange={(e) => setConfirmPassword(e.target.value)}
                    className="input-field w-full"
                    placeholder="Repite la nueva contraseña"
                  />
                </div>
                
                <button
                  type="submit"
                  disabled={isLoading}
                  className="btn-primary w-full flex justify-center py-3 font-semibold text-lg"
                >
                  {isLoading ? <Loader2 className="animate-spin h-6 w-6" /> : 'Actualizar Contraseña'}
                </button>
              </form>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default ResetPassword;
