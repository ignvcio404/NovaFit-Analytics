"""
NovaFit Analytics Suite
========================
FastAPI global exception handlers.
Maps domain exceptions → HTTP responses with consistent JSON envelope.
"""

import decimal
import json

from fastapi import FastAPI, Request, status
from fastapi.exceptions import RequestValidationError
from fastapi.responses import JSONResponse

from app.core.errors import (
    AuthenticationException,
    AuthorizationException,
    ConflictException,
    ExternalServiceException,
    FatigueComputationException,
    MembershipException,
    NovaFitException,
    NotFoundException,
    RoutineException,
    ValidationException,
)


def _sanitize(obj):
    """Recursively convert non-serializable types (Decimal, etc.) to safe Python types."""
    if isinstance(obj, decimal.Decimal):
        return float(obj)
    if isinstance(obj, dict):
        return {k: _sanitize(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [_sanitize(i) for i in obj]
    return obj


def _error_response(status_code: int, code: str, message: str, details: dict = None) -> JSONResponse:
    return JSONResponse(
        status_code=status_code,
        content=_sanitize({
            "success": False,
            "error": {
                "code": code,
                "message": message,
                "details": details or {},
            },
        }),
    )


def register_exception_handlers(app: FastAPI) -> None:
    """Register all global exception handlers on the FastAPI app."""

    @app.exception_handler(RequestValidationError)
    async def validation_error_handler(request: Request, exc: RequestValidationError):
        return _error_response(
            status.HTTP_422_UNPROCESSABLE_ENTITY,
            "SCHEMA_VALIDATION_ERROR",
            "Request validation failed.",
            {"errors": exc.errors()},
        )

    @app.exception_handler(ValidationException)
    async def business_validation_handler(request: Request, exc: ValidationException):
        return _error_response(
            status.HTTP_400_BAD_REQUEST, exc.code, exc.message, exc.details
        )

    @app.exception_handler(ConflictException)
    async def conflict_handler(request: Request, exc: ConflictException):
        return _error_response(
            status.HTTP_409_CONFLICT, exc.code, exc.message, exc.details
        )

    @app.exception_handler(AuthenticationException)
    async def auth_handler(request: Request, exc: AuthenticationException):
        return _error_response(
            status.HTTP_401_UNAUTHORIZED, exc.code, exc.message, exc.details
        )

    @app.exception_handler(AuthorizationException)
    async def authz_handler(request: Request, exc: AuthorizationException):
        return _error_response(
            status.HTTP_403_FORBIDDEN, exc.code, exc.message, exc.details
        )

    @app.exception_handler(NotFoundException)
    async def not_found_handler(request: Request, exc: NotFoundException):
        return _error_response(
            status.HTTP_404_NOT_FOUND, exc.code, exc.message, exc.details
        )

    @app.exception_handler(MembershipException)
    async def membership_handler(request: Request, exc: MembershipException):
        return _error_response(
            status.HTTP_409_CONFLICT, exc.code, exc.message, exc.details
        )

    @app.exception_handler(RoutineException)
    async def routine_handler(request: Request, exc: RoutineException):
        return _error_response(
            status.HTTP_409_CONFLICT, exc.code, exc.message, exc.details
        )

    @app.exception_handler(FatigueComputationException)
    async def fatigue_handler(request: Request, exc: FatigueComputationException):
        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR, exc.code, exc.message, exc.details
        )

    @app.exception_handler(ExternalServiceException)
    async def external_service_handler(request: Request, exc: ExternalServiceException):
        return _error_response(
            status.HTTP_502_BAD_GATEWAY, exc.code, exc.message, exc.details
        )

    @app.exception_handler(NovaFitException)
    async def generic_novafit_handler(request: Request, exc: NovaFitException):
        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR, exc.code, exc.message, exc.details
        )

    @app.exception_handler(Exception)
    async def unhandled_exception_handler(request: Request, exc: Exception):
        return _error_response(
            status.HTTP_500_INTERNAL_SERVER_ERROR,
            "INTERNAL_SERVER_ERROR",
            "Error interno del servidor. Por favor, intenta de nuevo.",
        )
