"""
NovaFit Analytics Suite
========================
Global application settings loaded from environment variables.
Uses pydantic-settings for automatic .env parsing and validation.
"""

from functools import lru_cache
from typing import List

from pydantic import Field, PostgresDsn, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file=".env",
        env_file_encoding="utf-8",
        case_sensitive=False,
        extra="ignore",
    )

    # ── Project metadata ───────────────────────────────────────────────────────
    PROJECT_NAME: str = "NovaFit Analytics Suite"
    API_VERSION: str = "1.0.0"
    API_V1_PREFIX: str = "/api/v1"
    ENVIRONMENT: str = Field(default="development")  # development | staging | production
    DEBUG: bool = Field(default=True)
    SECRET_KEY: str = Field(default="CHANGE_ME_IN_PRODUCTION_USE_256_BIT_RANDOM_KEY")

    # ── Database ───────────────────────────────────────────────────────────────
    DATABASE_URL: PostgresDsn = Field(
        default="postgresql+asyncpg://novafit_user:novafit_pass@localhost:5432/novafit_db"
    )
    DATABASE_POOL_SIZE: int = 10
    DATABASE_MAX_OVERFLOW: int = 20
    DATABASE_ECHO: bool = False  # Set True to log all SQL

    # ── Security / JWT ─────────────────────────────────────────────────────────
    JWT_ALGORITHM: str = "HS256"
    ACCESS_TOKEN_EXPIRE_MINUTES: int = 60
    REFRESH_TOKEN_EXPIRE_DAYS: int = 30
    FERNET_SECRET_KEY: str = Field(default="CHANGE_ME_FERNET_KEY_MUST_BE_32_URL_SAFE_BASE64=")

    # ── CORS / Hosts ───────────────────────────────────────────────────────────
    ALLOWED_ORIGINS: List[str] = ["http://localhost:3000", "http://localhost:5173"]
    ALLOWED_HOSTS: List[str] = ["localhost", "127.0.0.1"]
    FRONTEND_URL: str = Field(default="https://novafit-analytics-suite.onrender.com")

    # ── MercadoPago API ────────────────────────────────────────────────────────
    MERCADOPAGO_ACCESS_TOKEN: str = Field(default="TEST-XXXX-placeholder")
    MERCADOPAGO_PUBLIC_KEY: str = Field(default="TEST-XXXX-placeholder")
    MERCADOPAGO_WEBHOOK_SECRET: str = Field(default="CHANGE_ME")
    MERCADOPAGO_SANDBOX: bool = Field(default=True)

    # ── Zoho Mail (SMTP & REST) ────────────────────────────────────────────────
    SMTP_HOST: str = Field(default="smtp.zoho.com")
    SMTP_PORT: int = Field(default=465)
    SMTP_USER: str = Field(default="noreply@novafit.com")
    SMTP_PASSWORD: str = Field(default="zoho-smtp-password-placeholder")
    EMAILS_FROM_EMAIL: str = Field(default="noreply@novafit.com")
    
    ZOHO_CLIENT_ID: str | None = None
    ZOHO_CLIENT_SECRET: str | None = None
    ZOHO_REFRESH_TOKEN: str | None = None
    ZOHO_FROM_EMAIL: str = Field(default="noreply@novafit.com")
    ZOHO_FROM_NAME: str = Field(default="NovaFit Analytics Suite")
    ZOHO_ACCOUNT_ID: str | None = None

    # ── WhatsApp Cloud API ─────────────────────────────────────────────────────
    WHATSAPP_ACCESS_TOKEN: str = Field(default="whatsapp-access-token-placeholder")
    WHATSAPP_PHONE_NUMBER_ID: str = Field(default="whatsapp-phone-number-id")
    WHATSAPP_VERIFY_TOKEN: str = Field(default="whatsapp-verify-token-placeholder")
    WHATSAPP_API_VERSION: str = "v19.0"
    WHATSAPP_API_BASE_URL: str = "https://graph.facebook.com"

    # ── Upstash QStash ─────────────────────────────────────────────────────────
    QSTASH_CURRENT_SIGNING_KEY: str = Field(default="")
    QSTASH_NEXT_SIGNING_KEY: str = Field(default="")
    QSTASH_TOKEN: str = Field(default="")
    QSTASH_URL: str = Field(default="")

    # ── Wger API ───────────────────────────────────────────────────────────────
    WGER_API_BASE_URL: str = "https://wger.de/api/v2"
    WGER_API_KEY: str = Field(default="wger-api-key-placeholder")

    # ── Analytics / Fatigue Algorithm ─────────────────────────────────────────
    FATIGUE_ALGORITHM_VERSION: str = "1.0.0"
    ACWR_ACUTE_DAYS: int = 7
    ACWR_CHRONIC_DAYS: int = 28
    DELOAD_FATIGUE_THRESHOLD: float = 70.0   # Score 0-100 — above this = deload recommended
    DELOAD_ACWR_UPPER_LIMIT: float = 1.5     # ACWR above this = injury risk zone
    DELOAD_MIN_AVG_RPE: float = 8.0          # Sustained avg RPE above this = deload signal

    @field_validator("ALLOWED_ORIGINS", "ALLOWED_HOSTS", mode="before")
    @classmethod
    def parse_list(cls, v):
        if isinstance(v, str):
            return [item.strip() for item in v.split(",")]
        return v


@lru_cache
def get_settings() -> Settings:
    """Return a cached singleton Settings instance."""
    return Settings()


settings: Settings = get_settings()
