"""
NovaFit Analytics Suite
========================
Domain Exceptions — Clean Architecture Layer

All business-rule violations raise these typed exceptions.
They are caught by the global exception handlers in app/core/exceptions.py
and converted to appropriate HTTP responses.
"""

from typing import Any, Dict, Optional


# ─────────────────────────────────────────────────────────────────────────────
# Base Exceptions
# ─────────────────────────────────────────────────────────────────────────────

class NovaFitException(Exception):
    """
    Root exception for the entire NovaFit domain.
    Never raise this directly — use a specific subclass.
    """

    def __init__(
        self,
        message: str,
        code: str = "NOVAFIT_ERROR",
        details: Optional[Dict[str, Any]] = None,
    ) -> None:
        self.message = message
        self.code = code
        self.details = details or {}
        super().__init__(message)

    def __repr__(self) -> str:
        return f"<{self.__class__.__name__} code={self.code!r} message={self.message!r}>"


# ─────────────────────────────────────────────────────────────────────────────
# HTTP 400 — Bad Request / Validation
# ─────────────────────────────────────────────────────────────────────────────

class ValidationException(NovaFitException):
    """Raised when business-rule validation fails (distinct from Pydantic schema errors)."""

    def __init__(self, message: str, field: Optional[str] = None, **kwargs):
        super().__init__(message, code="VALIDATION_ERROR", **kwargs)
        self.field = field


class ConflictException(NovaFitException):
    """Raised when an operation would create a conflicting state (e.g. duplicate email)."""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, code="CONFLICT", **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP 401 / 403 — Auth
# ─────────────────────────────────────────────────────────────────────────────

class AuthenticationException(NovaFitException):
    """Raised when credentials are invalid or token is expired."""

    def __init__(self, message: str = "Invalid credentials", **kwargs):
        super().__init__(message, code="AUTHENTICATION_FAILED", **kwargs)


class AuthorizationException(NovaFitException):
    """Raised when the authenticated user lacks the required permission."""

    def __init__(self, message: str = "Insufficient permissions", **kwargs):
        super().__init__(message, code="FORBIDDEN", **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP 404 — Not Found
# ─────────────────────────────────────────────────────────────────────────────

class NotFoundException(NovaFitException):
    """Raised when a requested resource does not exist."""

    def __init__(self, resource: str, identifier: Any, **kwargs):
        message = f"{resource} with identifier '{identifier}' was not found."
        super().__init__(message, code="NOT_FOUND", **kwargs)
        self.resource = resource
        self.identifier = identifier


# ─────────────────────────────────────────────────────────────────────────────
# HTTP 409 — Business Rules
# ─────────────────────────────────────────────────────────────────────────────

class MembershipException(NovaFitException):
    """Raised for membership lifecycle violations (expired, frozen, etc.)."""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, code="MEMBERSHIP_ERROR", **kwargs)


class RoutineException(NovaFitException):
    """Raised for training routine business-rule violations."""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, code="ROUTINE_ERROR", **kwargs)


class FatigueComputationException(NovaFitException):
    """Raised when the fatigue analytics engine encounters an error."""

    def __init__(self, message: str, **kwargs):
        super().__init__(message, code="FATIGUE_COMPUTATION_ERROR", **kwargs)


# ─────────────────────────────────────────────────────────────────────────────
# HTTP 502 / 503 — External Services
# ─────────────────────────────────────────────────────────────────────────────

class ExternalServiceException(NovaFitException):
    """Raised when a call to an external API (MercadoPago, Zoho, WhatsApp) fails."""

    def __init__(self, service: str, message: str, **kwargs):
        super().__init__(
            f"[{service}] {message}",
            code="EXTERNAL_SERVICE_ERROR",
            details={"service": service},
            **kwargs,
        )
        self.service = service


class MercadoPagoException(ExternalServiceException):
    def __init__(self, message: str, **kwargs):
        super().__init__(service="MercadoPago", message=message, **kwargs)


class ZohoMailException(ExternalServiceException):
    def __init__(self, message: str, **kwargs):
        super().__init__(service="ZohoMail", message=message, **kwargs)


class WhatsAppException(ExternalServiceException):
    def __init__(self, message: str, **kwargs):
        super().__init__(service="WhatsAppCloud", message=message, **kwargs)


class WgerException(ExternalServiceException):
    def __init__(self, message: str, **kwargs):
        super().__init__(service="WgerAPI", message=message, **kwargs)
