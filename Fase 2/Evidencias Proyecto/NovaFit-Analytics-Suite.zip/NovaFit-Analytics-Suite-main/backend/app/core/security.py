"""
NovaFit Analytics Suite
========================
Security — JWT Authentication & RBAC Authorization
====================================================

Responsibilities:
  1. Password hashing / verification       (passlib[bcrypt])
  2. JWT access & refresh token creation   (python-jose[cryptography])
  3. Token decoding and validation         (python-jose)
  4. FastAPI dependency: get_current_user  (decodes Bearer token → User ORM row)
  5. FastAPI dependency: get_current_active_user  (asserts user is ACTIVE)
  6. Helper: require_permission()          (synchronous RBAC gate for route handlers)

Token payload (claims):
  - sub   : str(user.id)          — standard "subject" claim
  - type  : "access" | "refresh"  — prevents using a refresh token as access token
  - exp   : datetime               — expiry (handled by python-jose automatically)

Design notes:
  - Tokens are stateless (no DB lookup to validate, only to enrich).
  - get_current_user performs ONE async DB query per authenticated request to
    load the User row and its eager-loaded roles/permissions.
  - require_permission() is a *synchronous* guard intentionally — it only
    inspects the already-loaded `current_user` object; no I/O needed.
"""

import uuid
from datetime import datetime, timedelta, timezone
from typing import Any, Dict, Optional

from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError, jwt
from passlib.context import CryptContext
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.config import settings
from app.core.errors import AuthenticationException, AuthorizationException
from app.database.session import get_db
from app.database.models.core import User, UserStatus, UserRole, Role, RolePermission, Permission


# ─────────────────────────────────────────────────────────────────────────────
# Passlib context — bcrypt
# ─────────────────────────────────────────────────────────────────────────────

_pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")


def hash_password(plain_password: str) -> str:
    """Return the bcrypt hash of a plain-text password."""
    return _pwd_context.hash(plain_password)


def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Return True if `plain_password` matches `hashed_password`."""
    return _pwd_context.verify(plain_password, hashed_password)


# ─────────────────────────────────────────────────────────────────────────────
# JWT helpers
# ─────────────────────────────────────────────────────────────────────────────

# FastAPI security scheme — extracts "Bearer <token>" from the Authorization header.
oauth2_scheme = OAuth2PasswordBearer(tokenUrl="/api/v1/auth/login")


def create_access_token(
    subject: uuid.UUID,
    extra_claims: Optional[Dict[str, Any]] = None,
) -> str:
    """
    Create a signed JWT access token.

    Args:
        subject:     UUID of the authenticated user.
        extra_claims: Optional additional claims to embed (e.g. branch_id).

    Returns:
        Encoded JWT string.
    """
    expire = datetime.now(timezone.utc) + timedelta(
        minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
    )
    payload: Dict[str, Any] = {
        "sub": str(subject),
        "type": "access",
        "exp": expire,
    }
    if extra_claims:
        payload.update(extra_claims)
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def create_refresh_token(subject: uuid.UUID) -> str:
    """
    Create a signed JWT refresh token (longer-lived, no extra claims).

    Args:
        subject: UUID of the authenticated user.

    Returns:
        Encoded JWT string.
    """
    expire = datetime.now(timezone.utc) + timedelta(
        days=settings.REFRESH_TOKEN_EXPIRE_DAYS
    )
    payload: Dict[str, Any] = {
        "sub": str(subject),
        "type": "refresh",
        "exp": expire,
    }
    return jwt.encode(payload, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)


def decode_token(token: str) -> Dict[str, Any]:
    """
    Decode and validate a JWT token.

    Raises:
        AuthenticationException: if the token is expired, malformed, or
                                  uses an unexpected algorithm.

    Returns:
        Raw claims dictionary.
    """
    try:
        claims = jwt.decode(
            token,
            settings.SECRET_KEY,
            algorithms=[settings.JWT_ALGORITHM],
        )
        return claims
    except JWTError as exc:
        raise AuthenticationException(
            message=f"Could not validate credentials: {exc}"
        ) from exc


# ─────────────────────────────────────────────────────────────────────────────
# FastAPI Dependencies
# ─────────────────────────────────────────────────────────────────────────────

async def get_current_user(
    token: str = Depends(oauth2_scheme),
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    FastAPI dependency — decode the Bearer token and return the User ORM row.

    Loads the user together with their roles and the permissions attached to
    each role in a single query using eager loading, so that route handlers
    and `require_permission()` can inspect RBAC data without extra DB round-trips.

    Raises:
        HTTPException 401: token is invalid, expired, or user does not exist.
    """
    credentials_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials.",
        headers={"WWW-Authenticate": "Bearer"},
    )

    # ── Decode JWT ────────────────────────────────────────────────────────────
    try:
        claims = decode_token(token)
    except AuthenticationException:
        raise credentials_exception

    # ── Validate token type ───────────────────────────────────────────────────
    if claims.get("type") != "access":
        raise credentials_exception

    # ── Extract subject (user UUID) ───────────────────────────────────────────
    sub: Optional[str] = claims.get("sub")
    if sub is None:
        raise credentials_exception

    try:
        user_id = uuid.UUID(sub)
    except ValueError:
        raise credentials_exception

    # ── Load user with RBAC eager-loaded ──────────────────────────────────────
    result = await db.execute(
        select(User)
        .where(User.id == user_id)
        .options(
            selectinload(User.user_roles)
            .selectinload(UserRole.role)
            .selectinload(Role.role_permissions)
            .selectinload(RolePermission.permission)
        )
    )
    user: Optional[User] = result.scalar_one_or_none()

    if user is None:
        raise credentials_exception

    return user


async def get_current_active_user(
    current_user: User = Depends(get_current_user),
) -> User:
    """
    FastAPI dependency — assert that the authenticated user's account is ACTIVE.

    Extends `get_current_user` by adding a status check. Route handlers that
    need an authenticated + active user should declare this dependency.

    Raises:
        HTTPException 403: user exists but is suspended, inactive, or pending
                           e-mail verification.
    """
    if current_user.status != UserStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Account is not active (current status: {current_user.status.value}). "
                "Please contact your administrator."
            ),
        )
    return current_user


# ─────────────────────────────────────────────────────────────────────────────
# Synchronous RBAC gate
# ─────────────────────────────────────────────────────────────────────────────

def require_permission(user: User, resource: str, action: str) -> None:
    """
    Synchronous RBAC permission check.

    Inspects the already-loaded `user.user_roles` relationship to determine
    whether the user holds a role that grants `<resource>:<action>`.

    This is a *synchronous* function (no I/O) because `get_current_active_user`
    already eager-loaded the full role/permission graph. Call it directly inside
    route handlers — **not** as a `Depends`.

    Usage::

        require_permission(current_user, "analytics", "read")

    Raises:
        HTTPException 403: user does not hold the required permission.
    """
    for user_role in user.user_roles:
        role = user_role.role
        if role is None:
            continue
            
        # Superuser Bypass: super_admin has access to everything
        if role.name == "super_admin":
            return
            
        for role_perm in role.role_permissions:
            perm: Optional[Permission] = role_perm.permission
            if perm and perm.resource == resource and perm.action == action:
                return  # Permission granted

    raise HTTPException(
        status_code=status.HTTP_403_FORBIDDEN,
        detail=f"Permission denied: '{resource}:{action}' is required for this operation.",
    )

# ─────────────────────────────────────────────────────────────────────────────
# Data Encryption (Fernet)
# ─────────────────────────────────────────────────────────────────────────────

from cryptography.fernet import Fernet
import logging

_fernet: Optional[Fernet] = None

def get_fernet() -> Fernet:
    """Returns a singleton Fernet instance using the configured secret key."""
    global _fernet
    if _fernet is None:
        try:
            _fernet = Fernet(settings.FERNET_SECRET_KEY.encode('utf-8'))
        except Exception as e:
            logging.error(f"Failed to initialize Fernet: {e}")
            raise ValueError("Invalid FERNET_SECRET_KEY configuration.") from e
    return _fernet

def encrypt_data(data: str) -> str:
    """Encrypts a plain text string using Fernet symmetric encryption."""
    if not data:
        return data
    f = get_fernet()
    return f.encrypt(data.encode('utf-8')).decode('utf-8')

def decrypt_data(encrypted_data: str) -> str:
    """Decrypts a Fernet encrypted string back to plain text."""
    if not encrypted_data:
        return encrypted_data
    f = get_fernet()
    return f.decrypt(encrypted_data.encode('utf-8')).decode('utf-8')
