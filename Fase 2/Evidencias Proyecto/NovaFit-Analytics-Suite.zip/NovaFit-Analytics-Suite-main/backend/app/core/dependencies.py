"""
NovaFit Analytics Suite
========================
FastAPI Dependency Injection Container

This module wires together the concrete implementations of all
abstract interfaces (repositories, services) using FastAPI's
dependency injection system.

Clean Architecture boundary: no business logic lives here.
This file is purely a wiring/configuration concern.
"""

from datetime import date

from fastapi import Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.session import get_db
from app.training.repository import SQLAlchemyRoutineRepository, AbstractRoutineRepository
from app.analytics.repository import SQLAlchemyAnalyticsRepository, AbstractAnalyticsRepository
from app.notifications.service import (
    AbstractNotificationService,
    CompositeNotificationService,
    SilentNotificationService,
)
from app.training.service import RoutineService
from app.analytics.fatigue_service import FatigueService
from app.analytics.progress_service import ProgressService
from app.core.config import settings

# Import here to avoid circular imports — security.py does NOT import dependencies.py
from app.core.security import get_current_active_user
from app.database.models.core import User
from app.database.models.administrative import Membership, MembershipStatus


# ─────────────────────────────────────────────────────────────────────────────
# Membership guard
# ─────────────────────────────────────────────────────────────────────────────

async def require_active_membership(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
) -> User:
    """
    FastAPI dependency — enforces that the authenticated user has an ACTIVE membership.

    Add to any route that members (athletes) should not access with an expired plan:
        @router.post("/...", dependencies=[Depends(require_active_membership)])

    Rules:
      - Roles trainer / super_admin → always pass through (staff don't need a membership).
      - Role member → must have at least one Membership row with:
            status = ACTIVE  AND  end_date >= today
      - If no valid membership found → HTTP 403 with structured body:
            {"code": "MEMBERSHIP_REQUIRED", "message": "..."}
        The frontend detects this specific code to render the ExpiredMembership screen.

    Returns the current_user so it can be reused by the route handler if needed.
    """
    roles = {ur.role.name for ur in current_user.user_roles if ur.role}

    # Staff bypass — trainers and admins are not paying members
    if roles & {"trainer", "super_admin"}:
        return current_user

    today = date.today()
    stmt = (
        select(Membership)
        .where(
            Membership.user_id == current_user.id,
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date >= today,
        )
        .limit(1)
    )
    result = await db.execute(stmt)
    membership = result.scalars().first()

    if not membership:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail={
                "code": "MEMBERSHIP_REQUIRED",
                "message": (
                    "Tu membresía está vencida o inactiva. "
                    "Renueva tu plan para continuar usando NovaFit."
                ),
            },
        )

    return current_user


# ─────────────────────────────────────────────────────────────────────────────
# Repository providers
# ─────────────────────────────────────────────────────────────────────────────

async def get_routine_repository(
    db: AsyncSession = Depends(get_db),
) -> AbstractRoutineRepository:
    return SQLAlchemyRoutineRepository(db)


async def get_analytics_repository(
    db: AsyncSession = Depends(get_db),
) -> AbstractAnalyticsRepository:
    return SQLAlchemyAnalyticsRepository(db)


# ─────────────────────────────────────────────────────────────────────────────
# Notification service provider
# ─────────────────────────────────────────────────────────────────────────────

def get_notification_service(db: AsyncSession = Depends(get_db)) -> AbstractNotificationService:
    """
    Returns the appropriate notification service based on environment.

    In production: CompositeNotificationService (Zoho + WhatsApp live calls).
    In development/testing: SilentNotificationService (logs only).

    To use production integrations in development, set ENVIRONMENT=production
    and provide valid API credentials in .env
    """
    if settings.ENVIRONMENT == "production":
        from app.integrations.zoho_mail.service import ZohoMailService
        from app.integrations.whatsapp.service import WhatsAppService
        from app.database.models.core import User as UserModel

        class _InlineUserRepo:
            """
            Minimal inline user repository.
            Replaces the non-existent app.users.repository module.
            Uses the existing SQLAlchemy session to resolve user_id → User ORM row.
            """
            def __init__(self, session: AsyncSession) -> None:
                self._db = session

            async def get_by_id(self, user_id):
                result = await self._db.execute(
                    select(UserModel).where(UserModel.id == user_id)
                )
                return result.scalar_one_or_none()

        user_repo = _InlineUserRepo(db)
        return CompositeNotificationService(
            zoho_service=ZohoMailService(),
            whatsapp_service=WhatsAppService(),
            user_repo=user_repo,
        )
    return SilentNotificationService()


# ─────────────────────────────────────────────────────────────────────────────
# Integration providers
# ─────────────────────────────────────────────────────────────────────────────

def get_mercadopago_service() -> "MercadoPagoService":
    from app.integrations.mercadopago.service import MercadoPagoService
    return MercadoPagoService()

def get_whatsapp_service() -> "WhatsAppService":
    from app.integrations.whatsapp.service import WhatsAppService
    return WhatsAppService()


# ─────────────────────────────────────────────────────────────────────────────
# Service providers
# ─────────────────────────────────────────────────────────────────────────────

async def get_routine_service(
    routine_repo: AbstractRoutineRepository = Depends(get_routine_repository),
    notification_service: AbstractNotificationService = Depends(get_notification_service),
) -> RoutineService:
    """Provides a fully-wired RoutineService for request handlers."""
    return RoutineService(
        repository=routine_repo,
        notification_service=notification_service,
    )


async def get_fatigue_service(
    routine_repo: AbstractRoutineRepository = Depends(get_routine_repository),
    analytics_repo: AbstractAnalyticsRepository = Depends(get_analytics_repository),
    notification_service: AbstractNotificationService = Depends(get_notification_service),
) -> FatigueService:
    """Provides a fully-wired FatigueService for request handlers."""
    return FatigueService(
        routine_repo=routine_repo,
        analytics_repo=analytics_repo,
        notification_service=notification_service,
    )


async def get_progress_service(
    repo: AbstractAnalyticsRepository = Depends(get_analytics_repository),
) -> ProgressService:
    return ProgressService(repo=repo)


def get_email_service() -> "ZohoMailService":
    from app.integrations.zoho_mail.service import ZohoMailService
    return ZohoMailService()


async def get_billing_service(
    db: AsyncSession = Depends(get_db),
    email_service: "ZohoMailService" = Depends(get_email_service),
) -> "BillingService":
    from app.billing.service import BillingService
    return BillingService(db=db, email_service=email_service)

async def get_membership_service(
    db: AsyncSession = Depends(get_db),
) -> "MembershipService":
    from app.billing.service import MembershipService
    return MembershipService(db=db)
