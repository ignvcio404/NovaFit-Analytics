"""
NovaFit Analytics Suite
========================
MODULE 3 — Training
====================

Tables (9):
  16. muscle_groups          — Taxonomy of muscle groups (chest, back, legs…)
  17. exercise_catalog       — Master list of exercises (seeded from Wger API)
  18. exercise_muscle_groups — M:N junction: exercises <-> muscle_groups
  19. mesocycles             — Macro training block (4–12 weeks, goal-oriented)
  20. microcycles            — Weekly training plan within a mesocycle
  21. routine_templates      — Reusable session template created by a trainer
  22. routine_sessions       — Scheduled/logged session for a specific user
  23. session_exercises      — Ordered exercises within a session
  24. exercise_sets          — Individual set: weight, reps, RPE, rest time
"""

import uuid
import enum
from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import (
    Boolean, CheckConstraint, Date, DateTime, Enum as SAEnum,
    ForeignKey, Integer, Numeric, SmallInteger, String, Text, func,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, TimestampMixin, enum_values


# ─────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────

class TrainingGoal(str, enum.Enum):
    HYPERTROPHY = "hypertrophy"
    STRENGTH = "strength"
    ENDURANCE = "endurance"
    POWER = "power"
    WEIGHT_LOSS = "weight_loss"
    MAINTENANCE = "maintenance"
    REHABILITATION = "rehabilitation"


class DifficultyLevel(str, enum.Enum):
    BEGINNER = "beginner"
    INTERMEDIATE = "intermediate"
    ADVANCED = "advanced"
    ELITE = "elite"


class ExerciseCategory(str, enum.Enum):
    COMPOUND = "compound"
    ISOLATION = "isolation"
    CARDIO = "cardio"
    MOBILITY = "mobility"
    PLYOMETRIC = "plyometric"


class SessionStatus(str, enum.Enum):
    PLANNED = "planned"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"


class WeightUnit(str, enum.Enum):
    KG = "kg"
    LB = "lb"
    BODYWEIGHT = "bodyweight"
    BAND = "band"


# ─────────────────────────────────────────────
# TABLE 16 — muscle_groups
# ─────────────────────────────────────────────

class MuscleGroup(Base):
    """
    Hierarchical taxonomy of muscle groups.

    Supports nested structure (e.g. Chest > Upper Chest).
    Seeds initial data from Wger API `/api/v2/muscle/` endpoint.
    """

    __tablename__ = "muscle_groups"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    parent_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("muscle_groups.id", ondelete="SET NULL"), nullable=True
    )
    name: Mapped[str] = mapped_column(String(80), nullable=False)
    name_en: Mapped[Optional[str]] = mapped_column(String(80))
    wger_muscle_id: Mapped[Optional[int]] = mapped_column(
        Integer, unique=True, comment="Wger API muscle ID for sync"
    )
    body_part: Mapped[Optional[str]] = mapped_column(
        String(50), comment="Upper body | Lower body | Core | Full body"
    )

    # ── Self-referential relationship ────────────
    children: Mapped[List["MuscleGroup"]] = relationship(
        "MuscleGroup", back_populates="parent", foreign_keys=[parent_id]
    )
    parent: Mapped[Optional["MuscleGroup"]] = relationship(
        "MuscleGroup", back_populates="children", remote_side="MuscleGroup.id"
    )
    exercise_muscles: Mapped[List["ExerciseMuscleGroup"]] = relationship(
        "ExerciseMuscleGroup", back_populates="muscle_group"
    )

    def __repr__(self) -> str:
        return f"<MuscleGroup id={self.id} name={self.name!r}>"


# ─────────────────────────────────────────────
# TABLE 17 — exercise_catalog
# ─────────────────────────────────────────────

class ExerciseCatalog(Base, TimestampMixin):
    """
    Master catalogue of exercises.

    Exercises can be:
    - Seeded from Wger API (``wger_exercise_id`` is set)
    - Created manually by trainers (``wger_exercise_id`` is NULL)

    The `instructions` JSONB stores step-by-step execution cues
    in multiple languages: ``{"es": "...", "en": "..."}``
    """

    __tablename__ = "exercise_catalog"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    wger_exercise_id: Mapped[Optional[int]] = mapped_column(
        Integer, unique=True, comment="Wger API exercise base ID for sync"
    )

    name: Mapped[str] = mapped_column(String(120), nullable=False)
    name_en: Mapped[Optional[str]] = mapped_column(String(120))
    description: Mapped[Optional[str]] = mapped_column(Text)
    instructions: Mapped[Optional[dict]] = mapped_column(
        JSONB, comment="Multilingual step-by-step cues {lang_code: text}"
    )
    category: Mapped[ExerciseCategory] = mapped_column(
        SAEnum(ExerciseCategory, name="exercise_category_enum", values_callable=enum_values), nullable=False
    )
    difficulty: Mapped[DifficultyLevel] = mapped_column(
        SAEnum(DifficultyLevel, name="difficulty_level_enum", values_callable=enum_values),
        nullable=False,
        default=DifficultyLevel.INTERMEDIATE,
    )
    equipment: Mapped[Optional[str]] = mapped_column(
        String(120), comment="Required equipment (barbell, dumbbell, cable…)"
    )
    video_url: Mapped[Optional[str]] = mapped_column(String(512))
    thumbnail_url: Mapped[Optional[str]] = mapped_column(String(512))
    is_custom: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="True if created by a trainer rather than synced from Wger"
    )
    created_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    # ── Relationships ────────────────────────────
    muscle_groups: Mapped[List["ExerciseMuscleGroup"]] = relationship(
        "ExerciseMuscleGroup", back_populates="exercise", cascade="all, delete-orphan"
    )
    session_exercises: Mapped[List["SessionExercise"]] = relationship(
        "SessionExercise", back_populates="exercise"
    )

    def __repr__(self) -> str:
        return f"<ExerciseCatalog id={self.id} name={self.name!r} category={self.category}>"


# ─────────────────────────────────────────────
# TABLE 18 — exercise_muscle_groups  (M:N junction)
# ─────────────────────────────────────────────

class ExerciseMuscleGroup(Base):
    """
    M:N junction between ExerciseCatalog and MuscleGroup.

    The `is_primary` flag distinguishes the primary mover from
    secondary/synergist muscles. This drives the muscle-volume
    accumulation analytics in the deload prediction algorithm.
    """

    __tablename__ = "exercise_muscle_groups"

    exercise_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("exercise_catalog.id", ondelete="CASCADE"), primary_key=True
    )
    muscle_group_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("muscle_groups.id", ondelete="CASCADE"), primary_key=True
    )
    is_primary: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True,
        comment="True = primary mover; False = secondary / synergist"
    )

    exercise: Mapped["ExerciseCatalog"] = relationship(
        "ExerciseCatalog", back_populates="muscle_groups"
    )
    muscle_group: Mapped["MuscleGroup"] = relationship(
        "MuscleGroup", back_populates="exercise_muscles"
    )


# ─────────────────────────────────────────────
# TABLE 19 — mesocycles
# ─────────────────────────────────────────────

class Mesocycle(Base, TimestampMixin):
    """
    A macro training block of 4–12 weeks with a defined goal.

    A Mesocycle is designed by a trainer and assigned to a member.
    It contains multiple Microcycles (weekly blocks). This hierarchy
    supports progressive overload analytics and deload scheduling.

    Example: "12-Week Hypertrophy Block — Q1 2025"
    """

    __tablename__ = "mesocycles"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    trainer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    member_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="CASCADE"), nullable=False
    )

    name: Mapped[str] = mapped_column(String(150), nullable=False)
    goal: Mapped[TrainingGoal] = mapped_column(
        SAEnum(TrainingGoal, name="training_goal_enum", values_callable=enum_values), nullable=False
    )
    difficulty: Mapped[DifficultyLevel] = mapped_column(
        SAEnum(DifficultyLevel, name="difficulty_level_enum", values_callable=enum_values), nullable=False
    )
    start_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    end_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    total_weeks: Mapped[int] = mapped_column(
        Integer, nullable=False,
        comment="Calculated as (end_date - start_date).weeks + 1"
    )
    deload_week_interval: Mapped[int] = mapped_column(
        Integer, nullable=False, default=4,
        comment="Every N weeks a deload microcycle is inserted automatically"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # ── Relationships ────────────────────────────
    trainer: Mapped[Optional["User"]] = relationship("User", foreign_keys=[trainer_id])
    member: Mapped["User"] = relationship("User", foreign_keys=[member_id])
    microcycles: Mapped[List["Microcycle"]] = relationship(
        "Microcycle", back_populates="mesocycle", cascade="all, delete-orphan",
        order_by="Microcycle.week_number"
    )

    def __repr__(self) -> str:
        return f"<Mesocycle id={self.id} name={self.name!r} goal={self.goal}>"


# ─────────────────────────────────────────────
# TABLE 20 — microcycles
# ─────────────────────────────────────────────

class Microcycle(Base, TimestampMixin):
    """
    A single week within a Mesocycle.

    The `is_deload` flag marks recovery weeks where volume and
    intensity are programmatically reduced. The system's analytics
    engine (FatigueService) can automatically flag a week as deload
    based on accumulated fatigue indicators.

    Target metrics like `target_volume_sets` and `target_intensity_pct`
    express the planned overload progression (e.g. +2 sets/week).
    """

    __tablename__ = "microcycles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    mesocycle_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("mesocycles.id", ondelete="CASCADE"), nullable=False
    )

    week_number: Mapped[int] = mapped_column(
        Integer, nullable=False, comment="Sequential week within the mesocycle (1-based)"
    )
    week_start_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    week_end_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    is_deload: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="True if this week is a programmed or auto-detected recovery week"
    )
    target_volume_sets: Mapped[Optional[int]] = mapped_column(
        Integer, comment="Total planned sets across all sessions in this week"
    )
    target_intensity_pct: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(5, 2),
        comment="Target intensity as % of 1-Rep Max (e.g. 75.00 = 75%)"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        CheckConstraint("week_number >= 1", name="ck_microcycle_week_number_positive"),
    )

    # ── Relationships ────────────────────────────
    mesocycle: Mapped["Mesocycle"] = relationship("Mesocycle", back_populates="microcycles")
    sessions: Mapped[List["RoutineSession"]] = relationship(
        "RoutineSession", back_populates="microcycle", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return (
            f"<Microcycle id={self.id} meso={self.mesocycle_id} "
            f"week={self.week_number} deload={self.is_deload}>"
        )


# ─────────────────────────────────────────────
# TABLE 21 — routine_templates
# ─────────────────────────────────────────────

class RoutineTemplate(Base, TimestampMixin):
    """
    A reusable session template designed by a trainer.

    Templates are the trainer's "library" — they can be instantiated
    into concrete RoutineSessions for any member, avoiding redundant
    data entry. A template does NOT contain actual performed sets;
    those live in ExerciseSet rows under a RoutineSession.

    The `template_data` JSONB stores the ordered exercise list with
    prescribed sets, reps, and rest periods:
    ``[{"exercise_id": 12, "sets": 4, "reps": "8-10", "rest_s": 90}, ...]``
    """

    __tablename__ = "routine_templates"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    created_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="CASCADE"), nullable=False
    )

    name: Mapped[str] = mapped_column(String(150), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    goal: Mapped[TrainingGoal] = mapped_column(
        SAEnum(TrainingGoal, name="training_goal_enum", values_callable=enum_values), nullable=False
    )
    difficulty: Mapped[DifficultyLevel] = mapped_column(
        SAEnum(DifficultyLevel, name="difficulty_level_enum", values_callable=enum_values), nullable=False
    )
    estimated_duration_min: Mapped[Optional[int]] = mapped_column(Integer)
    template_data: Mapped[Optional[dict]] = mapped_column(JSONB)
    is_public: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="Public templates are visible to all trainers in the branch"
    )

    sessions: Mapped[List["RoutineSession"]] = relationship(
        "RoutineSession", back_populates="template"
    )

    def __repr__(self) -> str:
        return f"<RoutineTemplate id={self.id} name={self.name!r} goal={self.goal}>"


# ─────────────────────────────────────────────
# TABLE 22 — routine_sessions
# ─────────────────────────────────────────────

class RoutineSession(Base, TimestampMixin):
    """
    A concrete training session for a specific user on a specific date.

    Links to a Microcycle for periodization context, and optionally
    to a RoutineTemplate for traceability. After completion, the
    `actual_duration_min` and `perceived_effort` fields are filled
    by the member via the mobile/web app.
    """

    __tablename__ = "routine_sessions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    microcycle_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("microcycles.id", ondelete="SET NULL"), nullable=True
    )
    template_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("routine_templates.id", ondelete="SET NULL"), nullable=True
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )

    name: Mapped[str] = mapped_column(String(150), nullable=False)
    scheduled_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    started_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    completed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    actual_duration_min: Mapped[Optional[int]] = mapped_column(Integer)
    status: Mapped[SessionStatus] = mapped_column(
        SAEnum(SessionStatus, name="session_status_enum", values_callable=enum_values),
        nullable=False, default=SessionStatus.PLANNED,
    )
    perceived_effort: Mapped[Optional[int]] = mapped_column(
        SmallInteger,
        comment="Member's overall session RPE 1-10"
    )
    trainer_notes: Mapped[Optional[str]] = mapped_column(Text)
    member_notes: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        CheckConstraint(
            "perceived_effort BETWEEN 1 AND 10",
            name="ck_session_perceived_effort_range"
        ),
    )

    # ── Relationships ────────────────────────────
    microcycle: Mapped[Optional["Microcycle"]] = relationship(
        "Microcycle", back_populates="sessions"
    )
    template: Mapped[Optional["RoutineTemplate"]] = relationship(
        "RoutineTemplate", back_populates="sessions"
    )
    user: Mapped["User"] = relationship("User")
    exercises: Mapped[List["SessionExercise"]] = relationship(
        "SessionExercise", back_populates="session",
        cascade="all, delete-orphan", order_by="SessionExercise.order_index"
    )

    def __repr__(self) -> str:
        return (
            f"<RoutineSession id={self.id} user={self.user_id} "
            f"date={self.scheduled_date} status={self.status}>"
        )


# ─────────────────────────────────────────────
# TABLE 23 — session_exercises
# ─────────────────────────────────────────────

class SessionExercise(Base):
    """
    An ordered exercise entry within a RoutineSession.

    This is the "exercise header" that groups individual ExerciseSet
    rows. The `order_index` determines display order in the UI.
    """

    __tablename__ = "session_exercises"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("routine_sessions.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )
    exercise_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("exercise_catalog.id", ondelete="RESTRICT"), nullable=False
    )

    order_index: Mapped[int] = mapped_column(
        SmallInteger, nullable=False, comment="1-based display order within the session"
    )
    superset_group: Mapped[Optional[int]] = mapped_column(
        SmallInteger,
        comment="Exercises sharing the same superset_group are performed as a superset"
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))

    # ── Relationships ────────────────────────────
    session: Mapped["RoutineSession"] = relationship("RoutineSession", back_populates="exercises")
    exercise: Mapped["ExerciseCatalog"] = relationship(
        "ExerciseCatalog", back_populates="session_exercises"
    )
    sets: Mapped[List["ExerciseSet"]] = relationship(
        "ExerciseSet", back_populates="session_exercise",
        cascade="all, delete-orphan", order_by="ExerciseSet.set_number"
    )

    def __repr__(self) -> str:
        return (
            f"<SessionExercise id={self.id} session={self.session_id} "
            f"exercise={self.exercise_id} order={self.order_index}>"
        )


# ─────────────────────────────────────────────
# TABLE 24 — exercise_sets
# ─────────────────────────────────────────────

class ExerciseSet(Base):
    """
    A single performed set within a SessionExercise.

    This is the most granular unit of training data in the system.
    The RPE (Rate of Perceived Exertion) value on the Borg 1-10 scale
    is the primary input for the deload prediction algorithm.

    Key analytics fields:
    - `weight_kg`    : Used for volume load = weight × reps
    - `reps`         : Actual reps performed
    - `rpe`          : How hard the set felt (1 = trivial, 10 = max effort)
    - `rest_seconds` : Logged rest before next set (optional via app timer)
    - `is_failure`   : Did the member reach muscular failure?
    """

    __tablename__ = "exercise_sets"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    session_exercise_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("session_exercises.id", ondelete="CASCADE"),
        nullable=False,
        index=True,
    )

    set_number: Mapped[int] = mapped_column(
        SmallInteger, nullable=False, comment="1-based set counter within the exercise"
    )

    # ── Prescribed values (from template or trainer plan) ──
    prescribed_reps: Mapped[Optional[int]] = mapped_column(SmallInteger)
    prescribed_weight_kg: Mapped[Optional[Decimal]] = mapped_column(Numeric(6, 2))

    # ── Actual performed values ──────────────────
    reps: Mapped[Optional[int]] = mapped_column(SmallInteger)
    weight: Mapped[Optional[Decimal]] = mapped_column(Numeric(7, 2))
    weight_unit: Mapped[WeightUnit] = mapped_column(
        SAEnum(WeightUnit, name="weight_unit_enum", values_callable=enum_values),
        nullable=False, default=WeightUnit.KG,
    )
    rpe: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(3, 1),
        comment="Rate of Perceived Exertion — Borg modified scale 1.0 to 10.0"
    )
    rest_seconds: Mapped[Optional[int]] = mapped_column(Integer)
    duration_seconds: Mapped[Optional[int]] = mapped_column(
        Integer, comment="Elapsed time for time-based sets (planks, intervals)"
    )
    is_warmup: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_failure: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="Did the member reach muscular failure on this set?"
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))
    logged_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    __table_args__ = (
        CheckConstraint("rpe BETWEEN 1 AND 10", name="ck_set_rpe_range"),
        CheckConstraint("set_number >= 1", name="ck_set_number_positive"),
    )

    # ── Relationships ────────────────────────────
    session_exercise: Mapped["SessionExercise"] = relationship(
        "SessionExercise", back_populates="sets"
    )

    def __repr__(self) -> str:
        return (
            f"<ExerciseSet id={self.id} set#{self.set_number} "
            f"reps={self.reps} weight={self.weight}{self.weight_unit} rpe={self.rpe}>"
        )


# ─────────────────────────────────────────────
# TABLE 25 — supplement_logs
# ─────────────────────────────────────────────

class SupplementLog(Base, TimestampMixin):
    """
    Log for ergogenic aids (e.g. Creatine Monohydrate).
    Simple tracking for Module 3 (Hypertrophy & Supplementation).
    """

    __tablename__ = "supplement_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    supplement_name: Mapped[str] = mapped_column(String(150), nullable=False)
    dose_grams: Mapped[Decimal] = mapped_column(Numeric(7, 2), nullable=False)
    date: Mapped[datetime] = mapped_column(Date, nullable=False, default=func.now())

    user: Mapped["User"] = relationship("User")

    def __repr__(self) -> str:
        return f"<SupplementLog user={self.user_id} supplement={self.supplement_name!r} dose={self.dose_grams}g>"

