"""
NovaFit Analytics Suite
========================
MODULE 4 — Biometry & Analytics
=================================

Tables (6):
  25. weight_history                — Longitudinal body weight tracking
  26. anthropometric_measurements   — Body composition snapshots (skinfolds, circumferences)
  27. supplement_catalog            — Catalogue of supplements (creatine, whey, etc.)
  28. supplement_consumption        — Daily supplement intake log per user
  29. fatigue_indicators            — Derived analytics: weekly fatigue signals per user
  30. predictive_alerts             — System-generated alerts (deload needed, injury risk…)

This module feeds the core Data Science engine of NovaFit.
The FatigueService reads from these tables to compute deload recommendations.
"""

import uuid
import enum
from datetime import datetime
from decimal import Decimal
from typing import Optional, List

from sqlalchemy import (
    Boolean, CheckConstraint, Date, DateTime, Enum as SAEnum,
    ForeignKey, Integer, Numeric, SmallInteger, String, Text, func,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, TimestampMixin, enum_values


# ─────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────

class MeasurementSite(str, enum.Enum):
    """Standard skinfold / circumference measurement sites."""
    CHEST = "chest"
    ABDOMEN = "abdomen"
    THIGH = "thigh"
    TRICEPS = "triceps"
    SUBSCAPULAR = "subscapular"
    SUPRAILIAC = "suprailiac"
    MIDAXILLARY = "midaxillary"
    BICEP = "bicep"
    CALF = "calf"
    WAIST = "waist"
    HIP = "hip"
    NECK = "neck"
    FOREARM = "forearm"
    SHOULDER = "shoulder"


class SupplementForm(str, enum.Enum):
    POWDER = "powder"
    CAPSULE = "capsule"
    TABLET = "tablet"
    LIQUID = "liquid"
    GEL = "gel"
    BAR = "bar"


class DosageUnit(str, enum.Enum):
    GRAM = "g"
    MILLIGRAM = "mg"
    MILLILITER = "ml"
    CAPSULE = "capsule"
    SCOOP = "scoop"
    IU = "IU"


class FatigueLevel(str, enum.Enum):
    LOW = "low"
    MODERATE = "moderate"
    HIGH = "high"
    CRITICAL = "critical"


class AlertType(str, enum.Enum):
    DELOAD_RECOMMENDED = "deload_recommended"
    OVERTRAINING_RISK = "overtraining_risk"
    UNDERTRAINING = "undertraining"
    MEMBERSHIP_EXPIRING = "membership_expiring"
    MISSED_SESSIONS = "missed_sessions"
    PLATEAU_DETECTED = "plateau_detected"
    INJURY_RISK = "injury_risk"
    SUPPLEMENT_REMINDER = "supplement_reminder"


class AlertChannel(str, enum.Enum):
    IN_APP = "in_app"
    EMAIL = "email"           # Zoho Mail API
    WHATSAPP = "whatsapp"     # WhatsApp Cloud API


class AlertStatus(str, enum.Enum):
    PENDING = "pending"
    SENT = "sent"
    ACKNOWLEDGED = "acknowledged"
    DISMISSED = "dismissed"
    FAILED = "failed"


# ─────────────────────────────────────────────
# TABLE 25 — weight_history
# ─────────────────────────────────────────────

class WeightHistory(Base):
    """
    Longitudinal body weight log for a user.

    Simple but analytically powerful: used to detect plateau,
    compute rate-of-weight-change (for cut/bulk phases), and
    correlate with training volume to optimize periodization.

    Multiple measurements per day are allowed (e.g. morning + evening).
    The preferred reading is the first measurement of the day (morning, fasted).
    """

    __tablename__ = "weight_history"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True
    )

    measured_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=func.now()
    )
    weight_kg: Mapped[Decimal] = mapped_column(
        Numeric(5, 2), nullable=False,
        comment="Body weight in kilograms"
    )
    body_fat_pct: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(4, 1),
        comment="Optional body fat percentage (from BIA scale or trainer entry)"
    )
    muscle_mass_kg: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(5, 2),
        comment="Optional lean muscle mass in kg (from BIA scale)"
    )
    hydration_pct: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(4, 1),
        comment="Total body water % from BIA scale"
    )
    is_fasted: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=True,
        comment="True if measurement was taken in a fasted state (morning)"
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))

    __table_args__ = (
        CheckConstraint("weight_kg > 0", name="ck_weight_positive"),
        CheckConstraint(
            "body_fat_pct BETWEEN 3 AND 70",
            name="ck_body_fat_pct_range"
        ),
    )

    user: Mapped["User"] = relationship("User")

    def __repr__(self) -> str:
        return (
            f"<WeightHistory user={self.user_id} "
            f"weight={self.weight_kg}kg at={self.measured_at}>"
        )


# ─────────────────────────────────────────────
# TABLE 26 — anthropometric_measurements
# ─────────────────────────────────────────────

class AnthropometricMeasurement(Base, TimestampMixin):
    """
    Full body composition snapshot taken at a single point in time.

    Stores both skinfold caliper readings (mm) and circumference
    measurements (cm). Multiple `measurement_site` rows are grouped
    by `session_date` to form a complete assessment.

    The `measured_by` FK references the trainer who performed the
    assessment — important for inter-rater reliability tracking.
    """

    __tablename__ = "anthropometric_measurements"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    measured_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="SET NULL"), nullable=True
    )

    session_date: Mapped[datetime] = mapped_column(
        Date, nullable=False,
        comment="Date of the assessment session — groups related measurements"
    )
    measurement_site: Mapped[MeasurementSite] = mapped_column(
        SAEnum(MeasurementSite, name="measurement_site_enum", values_callable=enum_values), nullable=False
    )
    value_mm: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(5, 1), comment="Skinfold thickness in millimeters"
    )
    value_cm: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(6, 1), comment="Circumference in centimeters"
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))

    __table_args__ = (
        CheckConstraint(
            "value_mm IS NOT NULL OR value_cm IS NOT NULL",
            name="ck_anthropometric_has_value"
        ),
    )

    user: Mapped["User"] = relationship("User", foreign_keys=[user_id])
    trainer: Mapped[Optional["User"]] = relationship("User", foreign_keys=[measured_by])

    def __repr__(self) -> str:
        return (
            f"<AnthropometricMeasurement user={self.user_id} "
            f"site={self.measurement_site} date={self.session_date}>"
        )


# ─────────────────────────────────────────────
# TABLE 27 — supplement_catalog
# ─────────────────────────────────────────────

class SupplementCatalog(Base, TimestampMixin):
    """
    Master catalogue of supplements tracked by the platform.

    Pre-seeded with common supplements (creatine monohydrate, whey protein,
    beta-alanine, caffeine, etc.). Trainers can add custom entries.

    The `evidence_level` field encodes the scientific evidence tier:
    - 'A' = Strong evidence (e.g. creatine)
    - 'B' = Good evidence
    - 'C' = Limited / emerging evidence
    - 'D' = Insufficient evidence / anecdotal
    """

    __tablename__ = "supplement_catalog"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(120), nullable=False, unique=True)
    common_name: Mapped[Optional[str]] = mapped_column(String(120))
    description: Mapped[Optional[str]] = mapped_column(Text)
    form: Mapped[Optional[SupplementForm]] = mapped_column(
        SAEnum(SupplementForm, name="supplement_form_enum", values_callable=enum_values)
    )
    default_dosage_unit: Mapped[Optional[DosageUnit]] = mapped_column(
        SAEnum(DosageUnit, name="dosage_unit_enum", values_callable=enum_values)
    )
    recommended_daily_dose: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(7, 2),
        comment="Recommended daily dose in `default_dosage_unit` units"
    )
    evidence_level: Mapped[Optional[str]] = mapped_column(
        String(1),
        comment="Evidence tier: A | B | C | D"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text)

    consumptions: Mapped[List["SupplementConsumption"]] = relationship(
        "SupplementConsumption", back_populates="supplement"
    )

    def __repr__(self) -> str:
        return f"<SupplementCatalog id={self.id} name={self.name!r} evidence={self.evidence_level}>"


# ─────────────────────────────────────────────
# TABLE 28 — supplement_consumption
# ─────────────────────────────────────────────

class SupplementConsumption(Base):
    """
    Daily supplement intake log entry for a user.

    Correlated with training data to analyze performance patterns.
    For example: Does creatine intake correlate with increased
    strength output (higher weight lifted at same RPE)?

    The `timing` field captures when relative to a session the
    supplement was consumed: 'pre', 'intra', 'post', 'morning', 'evening'.
    """

    __tablename__ = "supplement_consumption"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    supplement_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("supplement_catalog.id", ondelete="RESTRICT"), nullable=False
    )
    session_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("routine_sessions.id", ondelete="SET NULL"),
        nullable=True,
        comment="Link to training session if supplement timing is session-relative"
    )

    consumed_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=func.now()
    )
    dosage: Mapped[Decimal] = mapped_column(Numeric(7, 2), nullable=False)
    dosage_unit: Mapped[DosageUnit] = mapped_column(
        SAEnum(DosageUnit, name="dosage_unit_enum_cons", values_callable=enum_values), nullable=False
    )
    timing: Mapped[Optional[str]] = mapped_column(
        String(20), comment="pre | intra | post | morning | evening | night"
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))

    user: Mapped["User"] = relationship("User")
    supplement: Mapped["SupplementCatalog"] = relationship(
        "SupplementCatalog", back_populates="consumptions"
    )

    def __repr__(self) -> str:
        return (
            f"<SupplementConsumption user={self.user_id} "
            f"supplement={self.supplement_id} dosage={self.dosage}{self.dosage_unit}>"
        )


# ─────────────────────────────────────────────
# TABLE 29 — fatigue_indicators
# ─────────────────────────────────────────────

class FatigueIndicator(Base, TimestampMixin):
    """
    Weekly derived analytics record per user — the core of the
    deload prediction algorithm.

    This row is computed by the `FatigueService` at the end of
    each microcycle and summarizes the accumulated fatigue signals.

    Key metrics:
    - `acwr`          : Acute:Chronic Workload Ratio
                        (target range: 0.8 – 1.3; >1.5 = injury risk zone)
    - `avg_rpe`       : Average RPE across all working sets in the week
    - `volume_load_kg`: Total tonnage (Σ sets × reps × weight)
    - `sessions_completed` vs `sessions_planned`: adherence ratio
    - `fatigue_score` : Composite score 0–100 derived from above metrics
    - `fatigue_level` : Categorized level: low | moderate | high | critical
    """

    __tablename__ = "fatigue_indicators"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    microcycle_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("microcycles.id", ondelete="SET NULL"), nullable=True
    )

    week_start_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    week_end_date: Mapped[datetime] = mapped_column(Date, nullable=False)

    # ── Workload Metrics ─────────────────────────
    sessions_planned: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    sessions_completed: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_sets: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    total_reps: Mapped[int] = mapped_column(Integer, nullable=False, default=0)
    volume_load_kg: Mapped[Decimal] = mapped_column(
        Numeric(12, 2), nullable=False, default=0,
        comment="Total tonnage = Σ (sets × reps × weight_kg)"
    )

    # ── Intensity Metrics ────────────────────────
    avg_rpe: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(3, 1), comment="Mean RPE across all working sets this week"
    )
    max_rpe: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(3, 1), comment="Peak RPE recorded in any single set this week"
    )
    failure_sets_count: Mapped[int] = mapped_column(
        Integer, nullable=False, default=0,
        comment="Number of sets taken to muscular failure"
    )

    # ── ACWR (Acute:Chronic Workload Ratio) ──────
    acute_workload: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 2), comment="Rolling 7-day volume load"
    )
    chronic_workload: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(10, 2), comment="Rolling 28-day average weekly volume load"
    )
    acwr: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(5, 3),
        comment="Acute:Chronic Workload Ratio — injury risk proxy"
    )

    # ── Composite Fatigue Score ───────────────────
    fatigue_score: Mapped[Optional[Decimal]] = mapped_column(
        Numeric(5, 2),
        comment="Composite fatigue score 0-100 (higher = more fatigued)"
    )
    fatigue_level: Mapped[Optional[FatigueLevel]] = mapped_column(
        SAEnum(FatigueLevel, name="fatigue_level_enum", values_callable=enum_values)
    )
    deload_recommended: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="True if the algorithm recommends a deload next week"
    )

    # ── Raw Computation Metadata ─────────────────
    algorithm_version: Mapped[str] = mapped_column(
        String(20), nullable=False, default="1.0.0",
        comment="Version of the FatigueService algorithm that generated this row"
    )
    computation_metadata: Mapped[Optional[dict]] = mapped_column(
        JSONB, comment="Debug/trace data from the fatigue calculation pipeline"
    )

    __table_args__ = (
        CheckConstraint(
            "fatigue_score BETWEEN 0 AND 100",
            name="ck_fatigue_score_range"
        ),
    )

    user: Mapped["User"] = relationship("User")

    def __repr__(self) -> str:
        return (
            f"<FatigueIndicator user={self.user_id} week={self.week_start_date} "
            f"score={self.fatigue_score} deload={self.deload_recommended}>"
        )


# ─────────────────────────────────────────────
# TABLE 30 — predictive_alerts
# ─────────────────────────────────────────────

class PredictiveAlert(Base, TimestampMixin):
    """
    System-generated alert delivered to a user or trainer.

    Alerts are produced by the analytics engine and dispatched
    through one or more channels (in-app, email via Zoho Mail,
    WhatsApp via WhatsApp Cloud API).

    The `payload` JSONB field stores alert-specific data:
    - DELOAD_RECOMMENDED: ``{"fatigue_score": 82, "acwr": 1.6, "weeks_since_last_deload": 5}``
    - MEMBERSHIP_EXPIRING: ``{"days_remaining": 7, "plan_name": "Premium Monthly"}``

    Delivery tracking: a row per channel × attempt is NOT used;
    instead, `sent_via_email`, `sent_via_whatsapp`, `sent_in_app`
    flags + timestamps track multi-channel delivery status.
    """

    __tablename__ = "predictive_alerts"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"),
        nullable=False, index=True
    )
    triggered_by_fatigue_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("fatigue_indicators.id", ondelete="SET NULL"), nullable=True,
        comment="FK to the FatigueIndicator row that triggered this alert (if applicable)"
    )

    alert_type: Mapped[AlertType] = mapped_column(
        SAEnum(AlertType, name="alert_type_enum", values_callable=enum_values), nullable=False
    )
    title: Mapped[str] = mapped_column(String(200), nullable=False)
    message: Mapped[str] = mapped_column(Text, nullable=False)
    payload: Mapped[Optional[dict]] = mapped_column(
        JSONB, comment="Structured context data for the alert renderer and delivery templates"
    )

    # ── Delivery status per channel ──────────────
    status: Mapped[AlertStatus] = mapped_column(
        SAEnum(AlertStatus, name="alert_status_enum", values_callable=enum_values),
        nullable=False, default=AlertStatus.PENDING,
    )
    sent_in_app: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    sent_via_email: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    sent_via_whatsapp: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    email_sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    whatsapp_sent_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    acknowledged_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))

    user: Mapped["User"] = relationship("User")

    def __repr__(self) -> str:
        return f"<PredictiveAlert id={self.id}>"
