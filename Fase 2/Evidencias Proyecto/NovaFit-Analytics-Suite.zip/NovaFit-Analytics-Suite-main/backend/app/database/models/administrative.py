"""
NovaFit Analytics Suite
========================
MODULE 2 — Administrative & Financial
======================================

Tables (8):
  8.  membership_plans          — Plan catalogue (monthly, quarterly, annual)
  9.  memberships               — Active subscription per user
  10. membership_freezes        — Temporal suspensions of a membership
  11. invoices                  — Commercial invoice header
  12. payment_methods           — Stored/tokenized payment instruments
  13. transactions              — Internal ledger of all money movements
  14. mercadopago_transactions  — Raw MercadoPago API response storage
  15. attendance_records        — Gym check-in / check-out events
"""

import uuid
import enum
from datetime import datetime
from decimal import Decimal
from typing import List, Optional

from sqlalchemy import (
    Boolean, Date, DateTime, Enum as SAEnum,
    ForeignKey, Integer, Numeric, String, Text, func,
)
from sqlalchemy.dialects.postgresql import UUID, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, TimestampMixin, enum_values


# ─────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────

class BillingCycle(str, enum.Enum):
    MONTHLY = "monthly"
    QUARTERLY = "quarterly"
    SEMI_ANNUAL = "semi_annual"
    ANNUAL = "annual"
    ONE_TIME = "one_time"


class MembershipStatus(str, enum.Enum):
    ACTIVE = "active"
    EXPIRED = "expired"
    FROZEN = "frozen"
    CANCELLED = "cancelled"
    PENDING_PAYMENT = "pending_payment"


class InvoiceStatus(str, enum.Enum):
    DRAFT = "draft"
    ISSUED = "issued"
    PAID = "paid"
    PARTIALLY_PAID = "partially_paid"
    OVERDUE = "overdue"
    VOID = "void"


class TransactionType(str, enum.Enum):
    PAYMENT = "payment"
    REFUND = "refund"
    CHARGEBACK = "chargeback"
    ADJUSTMENT = "adjustment"


class TransactionStatus(str, enum.Enum):
    PENDING = "pending"
    APPROVED = "approved"
    REJECTED = "rejected"
    CANCELLED = "cancelled"
    IN_PROCESS = "in_process"
    REFUNDED = "refunded"


class PaymentGateway(str, enum.Enum):
    MERCADOPAGO = "mercadopago"
    CASH = "cash"
    BANK_TRANSFER = "bank_transfer"
    OTHER = "other"


class CheckInMethod(str, enum.Enum):
    QR_CODE = "qr_code"
    RFID = "rfid"
    MANUAL = "manual"
    FACIAL = "facial"


# ─────────────────────────────────────────────
# TABLE 8 — membership_plans
# ─────────────────────────────────────────────

class MembershipPlan(Base, TimestampMixin):
    """
    Catalogue of membership plans offered by a branch.

    Each plan defines pricing, duration, and the set of features/
    access-hours a member gets. Plans are branch-specific, allowing
    franchises to have differentiated pricing.

    The `features` JSONB field stores flexible flags like:
    ``{"pool_access": true, "classes_per_week": 5, "personal_training": false}``
    """

    __tablename__ = "membership_plans"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="CASCADE"), nullable=False
    )

    name: Mapped[str] = mapped_column(String(120), nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    billing_cycle: Mapped[BillingCycle] = mapped_column(
        SAEnum(BillingCycle, name="billing_cycle_enum", values_callable=enum_values), nullable=False
    )
    price: Mapped[Decimal] = mapped_column(
        Numeric(10, 2), nullable=False,
        comment="Price in the branch's local currency"
    )
    currency_code: Mapped[str] = mapped_column(
        String(3), nullable=False, default="ARS",
        comment="ISO 4217 currency code"
    )
    duration_days: Mapped[int] = mapped_column(
        Integer, nullable=False,
        comment="Calendar days the membership is valid from activation date"
    )
    max_freeze_days: Mapped[int] = mapped_column(
        Integer, nullable=False, default=15,
        comment="Maximum days a member can freeze within one billing cycle"
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    features: Mapped[Optional[dict]] = mapped_column(JSONB)

    # ── Relationships ────────────────────────────
    memberships: Mapped[List["Membership"]] = relationship(
        "Membership", back_populates="plan"
    )

    def __repr__(self) -> str:
        return f"<MembershipPlan id={self.id} name={self.name!r} cycle={self.billing_cycle}>"


# ─────────────────────────────────────────────
# TABLE 9 — memberships
# ─────────────────────────────────────────────

class Membership(Base, TimestampMixin):
    """
    An active (or historical) subscription of a user to a plan.

    One user can have only one ACTIVE membership at a time per branch.
    Renewals create a new row — the previous row transitions to 'expired'.
    The `external_subscription_id` stores the MercadoPago preapproval ID
    for recurring billing integration.
    """

    __tablename__ = "memberships"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )
    plan_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("membership_plans.id", ondelete="RESTRICT"), nullable=False
    )
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="CASCADE"), nullable=False
    )

    status: Mapped[MembershipStatus] = mapped_column(
        SAEnum(MembershipStatus, name="membership_status_enum", values_callable=enum_values),
        nullable=False,
        default=MembershipStatus.PENDING_PAYMENT,
    )
    start_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    end_date: Mapped[datetime] = mapped_column(Date, nullable=False)
    auto_renew: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    external_subscription_id: Mapped[Optional[str]] = mapped_column(
        String(120), comment="MercadoPago preapproval / subscription ID"
    )
    notes: Mapped[Optional[str]] = mapped_column(Text)

    # ── Relationships ────────────────────────────
    user: Mapped["User"] = relationship("User")
    plan: Mapped["MembershipPlan"] = relationship("MembershipPlan", back_populates="memberships")
    freezes: Mapped[List["MembershipFreeze"]] = relationship(
        "MembershipFreeze", back_populates="membership", cascade="all, delete-orphan"
    )
    invoices: Mapped[List["Invoice"]] = relationship(
        "Invoice", back_populates="membership"
    )

    def __repr__(self) -> str:
        return (
            f"<Membership id={self.id} user={self.user_id} "
            f"status={self.status} end={self.end_date}>"
        )


# ─────────────────────────────────────────────
# TABLE 10 — membership_freezes
# ─────────────────────────────────────────────

class MembershipFreeze(Base, TimestampMixin):
    """
    Records a temporal suspension of an active membership.

    When a member freezes, `end_date` on the parent Membership
    is extended by `freeze_days`. The `status` column tracks
    whether the freeze is active or has been lifted.
    """

    __tablename__ = "membership_freezes"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    membership_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("memberships.id", ondelete="CASCADE"),
        nullable=False,
    )
    requested_by: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )
    freeze_start: Mapped[datetime] = mapped_column(Date, nullable=False)
    freeze_end: Mapped[datetime] = mapped_column(Date, nullable=False)
    reason: Mapped[Optional[str]] = mapped_column(String(255))
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    membership: Mapped["Membership"] = relationship("Membership", back_populates="freezes")

    def __repr__(self) -> str:
        return (
            f"<MembershipFreeze membership={self.membership_id} "
            f"from={self.freeze_start} to={self.freeze_end}>"
        )


# ─────────────────────────────────────────────
# TABLE 11 — invoices
# ─────────────────────────────────────────────

class Invoice(Base, TimestampMixin):
    """
    Commercial invoice header issued to a member.

    Each Invoice is linked to one Membership and may have multiple
    Transactions (partial payments). The PDF receipt is generated
    and emailed via the Zoho Mail integration after status → PAID.
    """

    __tablename__ = "invoices"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    membership_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("memberships.id", ondelete="RESTRICT"), nullable=False
    )
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="RESTRICT"), nullable=False
    )

    invoice_number: Mapped[str] = mapped_column(
        String(50), unique=True, nullable=False,
        comment="Human-readable sequential number (e.g. BUE01-2025-00042)"
    )
    status: Mapped[InvoiceStatus] = mapped_column(
        SAEnum(InvoiceStatus, name="invoice_status_enum", values_callable=enum_values),
        nullable=False, default=InvoiceStatus.DRAFT,
    )
    subtotal: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    tax_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False, default=0)
    discount_amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False, default=0)
    total: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency_code: Mapped[str] = mapped_column(String(3), nullable=False, default="ARS")
    due_date: Mapped[Optional[datetime]] = mapped_column(Date)
    paid_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    notes: Mapped[Optional[str]] = mapped_column(Text)
    pdf_url: Mapped[Optional[str]] = mapped_column(String(512))
    payment_link: Mapped[Optional[str]] = mapped_column(String(512))

    # ── Relationships ────────────────────────────
    membership: Mapped["Membership"] = relationship("Membership", back_populates="invoices")
    transactions: Mapped[List["Transaction"]] = relationship(
        "Transaction", back_populates="invoice"
    )

    def __repr__(self) -> str:
        return f"<Invoice {self.invoice_number} status={self.status} total={self.total}>"


# ─────────────────────────────────────────────
# TABLE 12 — payment_methods
# ─────────────────────────────────────────────

class PaymentMethod(Base, TimestampMixin):
    """
    A stored (tokenized) payment instrument associated with a user.

    Card numbers and CVVs are NEVER stored. Only MercadoPago card tokens
    (and last-4 digits for display) are persisted.
    """

    __tablename__ = "payment_methods"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False
    )

    gateway: Mapped[PaymentGateway] = mapped_column(
        SAEnum(PaymentGateway, name="payment_gateway_enum", values_callable=enum_values), nullable=False
    )
    token: Mapped[Optional[str]] = mapped_column(
        String(255), comment="Gateway-specific card token — NOT a raw card number"
    )
    last_four: Mapped[Optional[str]] = mapped_column(String(4))
    card_brand: Mapped[Optional[str]] = mapped_column(String(30))
    expiry_month: Mapped[Optional[int]] = mapped_column(Integer)
    expiry_year: Mapped[Optional[int]] = mapped_column(Integer)
    is_default: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)

    # ── Relationships ────────────────────────────
    user: Mapped["User"] = relationship("User")
    transactions: Mapped[List["Transaction"]] = relationship(
        "Transaction", back_populates="payment_method"
    )

    def __repr__(self) -> str:
        return f"<PaymentMethod user={self.user_id} gateway={self.gateway} ****{self.last_four}>"


# ─────────────────────────────────────────────
# TABLE 13 — transactions
# ─────────────────────────────────────────────

class Transaction(Base, TimestampMixin):
    """
    Internal ledger entry for every money movement in the system.

    Decoupled from the payment gateway layer: one Transaction row
    is created regardless of the gateway. The gateway-specific raw
    data lives in `mercadopago_transactions` (FK `transaction_id`).
    """

    __tablename__ = "transactions"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    invoice_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("invoices.id", ondelete="RESTRICT"), nullable=False
    )
    payment_method_id: Mapped[Optional[int]] = mapped_column(
        Integer, ForeignKey("payment_methods.id", ondelete="SET NULL"), nullable=True
    )

    type: Mapped[TransactionType] = mapped_column(
        SAEnum(TransactionType, name="transaction_type_enum", values_callable=enum_values), nullable=False
    )
    status: Mapped[TransactionStatus] = mapped_column(
        SAEnum(TransactionStatus, name="transaction_status_enum", values_callable=enum_values),
        nullable=False,
        default=TransactionStatus.PENDING,
    )
    amount: Mapped[Decimal] = mapped_column(Numeric(12, 2), nullable=False)
    currency_code: Mapped[str] = mapped_column(String(3), nullable=False, default="ARS")
    gateway: Mapped[PaymentGateway] = mapped_column(
        SAEnum(PaymentGateway, name="payment_gateway_enum", create_type=False, values_callable=enum_values), nullable=False
    )
    gateway_reference: Mapped[Optional[str]] = mapped_column(
        String(200), comment="Gateway's own payment ID for reconciliation"
    )
    processed_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    failure_reason: Mapped[Optional[str]] = mapped_column(String(255))

    # ── Relationships ────────────────────────────
    invoice: Mapped["Invoice"] = relationship("Invoice", back_populates="transactions")
    payment_method: Mapped[Optional["PaymentMethod"]] = relationship(
        "PaymentMethod", back_populates="transactions"
    )
    mercadopago_detail: Mapped[Optional["MercadoPagoTransaction"]] = relationship(
        "MercadoPagoTransaction", back_populates="transaction", uselist=False
    )

    def __repr__(self) -> str:
        return f"<Transaction id={self.id} type={self.type} status={self.status} amount={self.amount}>"


# ─────────────────────────────────────────────
# TABLE 14 — mercadopago_transactions
# ─────────────────────────────────────────────

class MercadoPagoTransaction(Base, TimestampMixin):
    """
    Stores the raw API response payload from MercadoPago.

    Extends `transactions` with MercadoPago-specific fields.
    The full JSON response is persisted in `raw_response` to
    support audits, reconciliation, and webhook replay.

    Integration entrypoint: `backend/integrations/mercadopago/`
    """

    __tablename__ = "mercadopago_transactions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    transaction_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("transactions.id", ondelete="CASCADE"),
        unique=True,
        nullable=False,
    )

    mp_payment_id: Mapped[Optional[str]] = mapped_column(
        String(100), index=True, comment="MercadoPago payment.id"
    )
    mp_preference_id: Mapped[Optional[str]] = mapped_column(
        String(200), comment="MercadoPago preference.id (checkout session)"
    )
    mp_external_reference: Mapped[Optional[str]] = mapped_column(
        String(200), comment="Our invoice UUID sent as external_reference"
    )
    mp_status: Mapped[Optional[str]] = mapped_column(
        String(50), comment="MercadoPago status: approved | pending | rejected"
    )
    mp_status_detail: Mapped[Optional[str]] = mapped_column(String(100))
    mp_payment_method_id: Mapped[Optional[str]] = mapped_column(String(50))
    mp_payment_type_id: Mapped[Optional[str]] = mapped_column(String(50))
    mp_installments: Mapped[Optional[int]] = mapped_column(Integer)
    raw_response: Mapped[Optional[dict]] = mapped_column(
        JSONB, comment="Full MercadoPago API JSON response for audit trail"
    )

    # ── Relationships ────────────────────────────
    transaction: Mapped["Transaction"] = relationship(
        "Transaction", back_populates="mercadopago_detail"
    )

    def __repr__(self) -> str:
        return (
            f"<MercadoPagoTransaction mp_id={self.mp_payment_id} "
            f"status={self.mp_status}>"
        )


# ─────────────────────────────────────────────
# TABLE 15 — attendance_records
# ─────────────────────────────────────────────

class AttendanceRecord(Base):
    """
    Records every gym check-in and check-out event per member.

    Used for:
    - Access control enforcement (member must have ACTIVE membership)
    - Analytics: visit frequency, peak hours, retention insights
    - Gamification: streak counters

    The `method` field tracks HOW entry was registered (QR, RFID, etc.)
    """

    __tablename__ = "attendance_records"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    branch_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("branches.id", ondelete="CASCADE"), nullable=False
    )

    check_in: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), nullable=False, default=func.now()
    )
    check_out: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    method: Mapped[CheckInMethod] = mapped_column(
        SAEnum(CheckInMethod, name="check_in_method_enum", values_callable=enum_values),
        nullable=False,
        default=CheckInMethod.QR_CODE,
    )
    notes: Mapped[Optional[str]] = mapped_column(String(255))

    # ── Relationships ────────────────────────────
    user: Mapped["User"] = relationship("User")

    def __repr__(self) -> str:
        return (
            f"<AttendanceRecord user={self.user_id} "
            f"in={self.check_in} method={self.method}>"
        )
