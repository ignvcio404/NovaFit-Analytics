"""
NovaFit Analytics Suite
========================
MODULE 1 — Core & Security
===========================

Tables (7):
  1.  branches          — Physical gym locations / franchises
  2.  roles             — RBAC role definitions
  3.  permissions       — Granular action permissions
  4.  role_permissions  — M:N junction: roles <-> permissions
  5.  users             — Platform users (admins, trainers, members)
  6.  user_roles        — M:N junction: users <-> roles
  7.  audit_logs        — Immutable event log for compliance
"""

import uuid
import enum
from datetime import datetime
from typing import List, Optional

from sqlalchemy import (
    Boolean, Date, DateTime, Enum as SAEnum,
    ForeignKey, Integer, Numeric, String, Text,
    UniqueConstraint, func, Index, text
)
from sqlalchemy.dialects.postgresql import UUID, INET, JSONB
from sqlalchemy.orm import Mapped, mapped_column, relationship

from .base import Base, TimestampMixin, enum_values


# ─────────────────────────────────────────────
# Enumerations
# ─────────────────────────────────────────────

class UserStatus(str, enum.Enum):
    ACTIVE = "active"
    INACTIVE = "inactive"
    SUSPENDED = "suspended"
    PENDING_VERIFICATION = "pending_verification"


class AuditAction(str, enum.Enum):
    CREATE = "create"
    READ = "read"
    UPDATE = "update"
    DELETE = "delete"
    LOGIN = "login"
    LOGOUT = "logout"
    PAYMENT = "payment"
    EXPORT = "export"


# ─────────────────────────────────────────────
# TABLE 1 — branches
# ─────────────────────────────────────────────

class Branch(Base, TimestampMixin):
    """
    Represents a physical gym location or franchise branch.

    A single NovaFit installation can manage multiple branches,
    each with its own address, timezone, and contact information.
    Users, memberships, and attendance records are all scoped
    to a specific branch.
    """

    __tablename__ = "branches"

    # ── Primary Key ─────────────────────────────
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    # ── Attributes ──────────────────────────────
    name: Mapped[str] = mapped_column(String(120), nullable=False)
    code: Mapped[str] = mapped_column(
        String(10), unique=True, nullable=False,
        comment="Short alphanumeric code used in billing prefixes (e.g. BUE01)"
    )
    address: Mapped[Optional[str]] = mapped_column(String(255))
    city: Mapped[Optional[str]] = mapped_column(String(100))
    country_code: Mapped[str] = mapped_column(
        String(3), nullable=False, default="ARG",
        comment="ISO 3166-1 alpha-3 country code"
    )
    phone: Mapped[Optional[str]] = mapped_column(String(30))
    email: Mapped[Optional[str]] = mapped_column(String(180))
    timezone: Mapped[str] = mapped_column(
        String(60), nullable=False, default="America/Argentina/Buenos_Aires"
    )
    is_active: Mapped[bool] = mapped_column(Boolean, nullable=False, default=True)
    logo_url: Mapped[Optional[str]] = mapped_column(String(512))

    # ── Relationships ────────────────────────────
    users: Mapped[List["User"]] = relationship("User", back_populates="branch")

    def __repr__(self) -> str:
        return f"<Branch id={self.id} name={self.name!r} code={self.code!r}>"


# ─────────────────────────────────────────────
# TABLE 2 — roles
# ─────────────────────────────────────────────

class Role(Base, TimestampMixin):
    """
    RBAC Role definition.

    Built-in roles: 'super_admin', 'branch_admin', 'trainer', 'member'.
    Custom roles can be created per branch to support granular access.
    """

    __tablename__ = "roles"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    name: Mapped[str] = mapped_column(String(80), unique=True, nullable=False)
    description: Mapped[Optional[str]] = mapped_column(Text)
    is_system: Mapped[bool] = mapped_column(
        Boolean, nullable=False, default=False,
        comment="System roles cannot be deleted"
    )

    # ── Relationships ────────────────────────────
    role_permissions: Mapped[List["RolePermission"]] = relationship(
        "RolePermission", back_populates="role", cascade="all, delete-orphan"
    )
    user_roles: Mapped[List["UserRole"]] = relationship(
        "UserRole", back_populates="role", cascade="all, delete-orphan"
    )

    def __repr__(self) -> str:
        return f"<Role id={self.id} name={self.name!r}>"


# ─────────────────────────────────────────────
# TABLE 3 — permissions
# ─────────────────────────────────────────────

class Permission(Base):
    """
    Atomic permission representing a single allowed action on a resource.

    Convention: '<resource>:<action>'  (e.g. 'routines:create', 'billing:read')
    """

    __tablename__ = "permissions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True, autoincrement=True)
    resource: Mapped[str] = mapped_column(
        String(80), nullable=False,
        comment="Logical resource the permission targets (e.g. 'routines')"
    )
    action: Mapped[str] = mapped_column(
        String(40), nullable=False,
        comment="Action verb: create | read | update | delete | export"
    )
    description: Mapped[Optional[str]] = mapped_column(Text)

    __table_args__ = (
        UniqueConstraint("resource", "action", name="uq_permission_resource_action"),
    )

    # ── Relationships ────────────────────────────
    role_permissions: Mapped[List["RolePermission"]] = relationship(
        "RolePermission", back_populates="permission"
    )

    def __repr__(self) -> str:
        return f"<Permission {self.resource}:{self.action}>"


# ─────────────────────────────────────────────
# TABLE 4 — role_permissions  (M:N junction)
# ─────────────────────────────────────────────

class RolePermission(Base):
    """
    M:N association between Role and Permission.
    Implements the Role-Based Access Control (RBAC) grant table.
    """

    __tablename__ = "role_permissions"

    role_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("roles.id", ondelete="CASCADE"), primary_key=True
    )
    permission_id: Mapped[int] = mapped_column(
        Integer, ForeignKey("permissions.id", ondelete="CASCADE"), primary_key=True
    )
    granted_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )

    # ── Relationships ────────────────────────────
    role: Mapped["Role"] = relationship("Role", back_populates="role_permissions")
    permission: Mapped["Permission"] = relationship(
        "Permission", back_populates="role_permissions"
    )

    def __repr__(self) -> str:
        return f"<RolePermission role={self.role_id} perm={self.permission_id}>"


# ─────────────────────────────────────────────
# TABLE 5 — users
# ─────────────────────────────────────────────

class User(Base, TimestampMixin):
    """
    Central user entity for the entire NovaFit platform.

    A user can be a gym member, trainer, branch administrator,
    or a super-admin. The actual access level is determined by
    the roles assigned via the `user_roles` table.

    Sensitive fields such as `password_hash` must NEVER be
    returned in API responses — use dedicated Pydantic schemas.
    """

    __tablename__ = "users"

    # ── Primary Key ─────────────────────────────
    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )

    # ── Foreign Keys ────────────────────────────
    branch_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("branches.id", ondelete="SET NULL"),
        nullable=True,
        comment="Primary branch this user belongs to (super_admin can be NULL)"
    )

    # ── Identity ────────────────────────────────
    email: Mapped[str] = mapped_column(String(254), unique=True, nullable=False)
    username: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    password_hash: Mapped[str] = mapped_column(String(255), nullable=False)
    first_name: Mapped[str] = mapped_column(String(80), nullable=False)
    last_name: Mapped[str] = mapped_column(String(80), nullable=False)
    phone_number: Mapped[Optional[str]] = mapped_column(
        String(30), comment="E.164 format — used for WhatsApp Cloud API notifications"
    )
    date_of_birth: Mapped[Optional[datetime]] = mapped_column(Date)
    avatar_url: Mapped[Optional[str]] = mapped_column(String(512))

    # ── Status & Flags ───────────────────────────
    status: Mapped[UserStatus] = mapped_column(
        SAEnum(UserStatus, name="user_status_enum", values_callable=enum_values),
        nullable=False,
        default=UserStatus.PENDING_VERIFICATION,
    )
    email_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    phone_verified: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    two_factor_enabled: Mapped[bool] = mapped_column(Boolean, nullable=False, default=False)
    two_factor_secret: Mapped[Optional[str]] = mapped_column(String(64))

    # ── Metadata ────────────────────────────────
    last_login_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True))
    last_login_ip: Mapped[Optional[str]] = mapped_column(
        INET, comment="Stored as PostgreSQL INET type for IP validation"
    )
    device_token: Mapped[Optional[str]] = mapped_column(
        String(255), comment="Expo push notification token"
    )

    # ── Relationships ────────────────────────────
    branch: Mapped[Optional["Branch"]] = relationship("Branch", back_populates="users")
    user_roles: Mapped[List["UserRole"]] = relationship(
        "UserRole",
        back_populates="user",
        cascade="all, delete-orphan",
        foreign_keys="[UserRole.user_id]",  # disambiguate from UserRole.assigned_by
    )
    audit_logs: Mapped[List["AuditLog"]] = relationship(
        "AuditLog", back_populates="user", foreign_keys="[AuditLog.user_id]"
    )

    def __repr__(self) -> str:
        return f"<User id={self.id} email={self.email!r} status={self.status}>"


# ─────────────────────────────────────────────
# TABLE 6 — user_roles  (M:N junction)
# ─────────────────────────────────────────────

class UserRole(Base):
    """
    M:N association between User and Role.
    A single user may hold multiple roles simultaneously
    (e.g. a trainer who also manages a branch).
    """

    __tablename__ = "user_roles"

    user_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="CASCADE"),
        primary_key=True,
    )
    role_id: Mapped[int] = mapped_column(
        Integer,
        ForeignKey("roles.id", ondelete="CASCADE"),
        primary_key=True,
    )
    assigned_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False
    )
    assigned_by: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
    )

    # ── Relationships ────────────────────────────
    user: Mapped["User"] = relationship("User", back_populates="user_roles", foreign_keys=[user_id])
    role: Mapped["Role"] = relationship("Role", back_populates="user_roles")

    def __repr__(self) -> str:
        return f"<UserRole user={self.user_id} role={self.role_id}>"


# ─────────────────────────────────────────────
# TABLE 7 — audit_logs
# ─────────────────────────────────────────────

class AuditLog(Base):
    """
    Immutable compliance log.

    Records every significant action performed in the system.
    Rows must NEVER be updated or deleted via application code.
    In PostgreSQL, enforce this with a BEFORE UPDATE/DELETE trigger.

    The `log_metadata` JSONB field stores context-specific payload
    (e.g. changed fields, request body snapshot) to support
    forensic investigation without joining multiple tables.
    """

    __tablename__ = "audit_logs"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    user_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("users.id", ondelete="SET NULL"),
        nullable=True,
        comment="NULL for system-generated events"
    )
    branch_id: Mapped[Optional[uuid.UUID]] = mapped_column(
        UUID(as_uuid=True),
        ForeignKey("branches.id", ondelete="SET NULL"),
        nullable=True,
    )
    action: Mapped[AuditAction] = mapped_column(
        SAEnum(AuditAction, name="audit_action_enum", values_callable=enum_values), nullable=False
    )
    resource_type: Mapped[str] = mapped_column(
        String(80), nullable=False,
        comment="Name of the entity type affected (e.g. 'routine', 'invoice')"
    )
    resource_id: Mapped[Optional[str]] = mapped_column(
        String(100),
        comment="PK of the affected row as a string (supports UUID & int PKs)"
    )
    ip_address: Mapped[Optional[str]] = mapped_column(INET)
    user_agent: Mapped[Optional[str]] = mapped_column(String(512))
    log_metadata: Mapped[Optional[dict]] = mapped_column(
        "metadata", JSONB, comment="Arbitrary JSON payload — changed fields, request context, etc."
    )
    occurred_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), nullable=False, index=True
    )

    # ── Relationships ────────────────────────────
    user: Mapped[Optional["User"]] = relationship(
        "User", back_populates="audit_logs", foreign_keys=[user_id]
    )

    def __repr__(self) -> str:
        return (
            f"<AuditLog id={self.id} action={self.action} "
            f"resource={self.resource_type}:{self.resource_id}>"
        )


# ─────────────────────────────────────────────
# TABLE 8 — trainer_athlete_link
# ─────────────────────────────────────────────

class LinkStatus(str, enum.Enum):
    PENDING = "pending"
    ACTIVE = "active"


class TrainerAthleteLink(Base, TimestampMixin):
    """
    M:1 association between an athlete and a trainer.
    
    A trainer can have multiple athletes, but an athlete can only have
    ONE active trainer at a time (enforced by a partial unique index).
    """

    __tablename__ = "trainer_athlete_link"

    id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), primary_key=True, default=uuid.uuid4
    )
    trainer_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    athlete_id: Mapped[uuid.UUID] = mapped_column(
        UUID(as_uuid=True), ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True
    )
    status: Mapped[LinkStatus] = mapped_column(
        SAEnum(LinkStatus, name="link_status_enum", values_callable=enum_values),
        nullable=False, default=LinkStatus.PENDING,
    )

    __table_args__ = (
        # Partial unique index: an athlete can have only one active trainer link at a time
        Index(
            "uq_athlete_active_trainer",
            "athlete_id",
            unique=True,
            postgresql_where=text("status = 'active'")
        ),
    )

    trainer: Mapped["User"] = relationship("User", foreign_keys=[trainer_id])
    athlete: Mapped["User"] = relationship("User", foreign_keys=[athlete_id])

    def __repr__(self) -> str:
        return f"<TrainerAthleteLink trainer={self.trainer_id} athlete={self.athlete_id} status={self.status}>"

