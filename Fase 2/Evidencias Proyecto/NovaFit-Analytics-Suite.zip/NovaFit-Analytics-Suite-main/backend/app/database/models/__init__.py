# NovaFit Analytics Suite - Database Models Package
# This package exposes all SQLAlchemy ORM models organized by logical module.

from .base import Base, TimestampMixin
from .core import (
    Branch, Role, Permission, RolePermission,
    User, UserRole, AuditLog, TrainerAthleteLink
)
from .administrative import (
    MembershipPlan, Membership, MembershipFreeze,
    Invoice, PaymentMethod, Transaction,
    MercadoPagoTransaction, AttendanceRecord
)
from .training import (
    MuscleGroup, ExerciseCatalog, ExerciseMuscleGroup,
    Mesocycle, Microcycle, RoutineTemplate,
    RoutineSession, SessionExercise, ExerciseSet,
    SupplementLog
)
from .biometry import (
    WeightHistory, AnthropometricMeasurement,
    SupplementCatalog, SupplementConsumption,
    FatigueIndicator, PredictiveAlert
)

__all__ = [
    "Base", "TimestampMixin",
    # Core & Security
    "Branch", "Role", "Permission", "RolePermission",
    "User", "UserRole", "AuditLog", "TrainerAthleteLink",
    # Administrative & Financial
    "MembershipPlan", "Membership", "MembershipFreeze",
    "Invoice", "PaymentMethod", "Transaction",
    "MercadoPagoTransaction", "AttendanceRecord",
    # Training
    "MuscleGroup", "ExerciseCatalog", "ExerciseMuscleGroup",
    "Mesocycle", "Microcycle", "RoutineTemplate",
    "RoutineSession", "SessionExercise", "ExerciseSet", "SupplementLog",
    # Biometry & Analytics
    "WeightHistory", "AnthropometricMeasurement",
    "SupplementCatalog", "SupplementConsumption",
    "FatigueIndicator", "PredictiveAlert",
]
