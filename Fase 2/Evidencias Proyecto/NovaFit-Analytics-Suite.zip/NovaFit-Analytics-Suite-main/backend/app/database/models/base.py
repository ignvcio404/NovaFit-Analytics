"""
NovaFit Analytics Suite
========================
SQLAlchemy Declarative Base and shared mixins.

All models inherit from `Base`. The `TimestampMixin` provides automatic
`created_at` / `updated_at` columns for every table that includes it.
"""

import uuid
from datetime import datetime, timezone

from sqlalchemy import DateTime, func
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


def enum_values(enum_class) -> list:
    """
    Return the string *values* of a Python Enum for use with SQLAlchemy SAEnum.

    Usage::

        SAEnum(MyEnum, name="my_enum", values_callable=enum_values)

    Without this, SQLAlchemy sends the member *names* (e.g. 'ACTIVE') to
    PostgreSQL instead of the lowercase *values* (e.g. 'active'), causing
    ``InvalidTextRepresentationError`` on every INSERT / UPDATE.
    """
    return [m.value for m in enum_class]


class Base(DeclarativeBase):
    """
    Project-wide SQLAlchemy declarative base.
    Every ORM model in NovaFit must inherit from this class.
    """
    pass


class TimestampMixin:
    """
    Reusable mixin that auto-populates audit timestamp columns.

    Attributes
    ----------
    created_at : datetime
        UTC timestamp set once on INSERT.
    updated_at : datetime
        UTC timestamp refreshed on every UPDATE.
    """

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True),
        server_default=func.now(),
        onupdate=func.now(),
        nullable=False,
    )
