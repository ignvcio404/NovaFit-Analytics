"""
NovaFit Analytics Suite
========================
CRITICAL FLOW #2 — Fatigue Service
=====================================

Data Science engine that computes weekly fatigue indicators and
issues a deload recommendation based on the ACWR model + RPE signals.

Algorithm Pipeline:
  1. Fetch all completed working sets for the user in the acute window (7 days)
  2. Fetch all completed working sets in the chronic window (28 days)
  3. Compute volume load (tonnage) for both windows
  4. Calculate ACWR = acute_workload / chronic_workload
  5. Compute avg_rpe and failure_set_count for the acute window
  6. Apply weighted composite formula → fatigue_score (0-100)
  7. Apply decision rules → deload_recommended (bool)
  8. Persist FatigueIndicator row
  9. If deload_recommended → create PredictiveAlert → dispatch via Zoho + WhatsApp
"""

import uuid
from dataclasses import dataclass, field
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, ROUND_HALF_UP
from typing import List, Optional

from app.core.config import settings
from app.core.errors import FatigueComputationException
from app.database.models.training import ExerciseSet
from app.database.models.biometry import FatigueIndicator
from app.training.repository import AbstractRoutineRepository
from app.training.schemas import FatigueAnalysisResponse
from app.analytics.repository import AbstractAnalyticsRepository
from app.notifications.service import AbstractNotificationService


# ─────────────────────────────────────────────────────────────────────────────
# Internal Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WorkloadWindow:
    """Computed metrics for a specific time window (acute or chronic)."""

    sets: List[ExerciseSet] = field(default_factory=list)
    volume_load_kg: float = 0.0
    total_reps: int = 0
    total_sets: int = 0
    rpe_values: List[float] = field(default_factory=list)
    failure_sets: int = 0

    @property
    def avg_rpe(self) -> Optional[float]:
        return round(sum(self.rpe_values) / len(self.rpe_values), 1) if self.rpe_values else None

    @property
    def max_rpe(self) -> Optional[float]:
        return max(self.rpe_values) if self.rpe_values else None


@dataclass
class FatigueDecision:
    """Output of the fatigue algorithm before persistence."""

    fatigue_score: float
    fatigue_level: str
    deload_recommended: bool
    deload_reason: Optional[str]
    recommendation_confidence: float
    triggered_signals: List[str] = field(default_factory=list)


# ─────────────────────────────────────────────────────────────────────────────
# Fatigue Service
# ─────────────────────────────────────────────────────────────────────────────

class FatigueService:
    """
    Core Data Science service for fatigue analytics and deload prediction.

    Critical Flow #2:
        GET /api/v1/analytics/fatigue/{user_id}
        → compute acute (7-day) and chronic (28-day) workloads
        → calculate ACWR
        → apply composite fatigue scoring formula
        → apply decision rules for deload recommendation
        → persist FatigueIndicator to database
        → if deload recommended → dispatch alerts via Zoho Mail + WhatsApp Cloud API
        → return FatigueAnalysisResponse

    Design note: The algorithm is fully deterministic given the same input sets.
    The `algorithm_version` field in FatigueIndicator allows reproducing any
    historical computation by replaying the same logic version.
    """

    # ── Algorithm Weights (sum must be ~1.0) ──────────────────────────────────
    WEIGHT_ACWR: float = 0.40         # ACWR deviation from safe zone
    WEIGHT_AVG_RPE: float = 0.30      # Sustained high perceived effort
    WEIGHT_FAILURE_DENSITY: float = 0.15  # Failure set proportion
    WEIGHT_ADHERENCE_PENALTY: float = 0.15  # Skipped sessions signal fatigue or burnout

    def __init__(
        self,
        routine_repo: AbstractRoutineRepository,
        analytics_repo: AbstractAnalyticsRepository,
        notification_service: AbstractNotificationService,
    ) -> None:
        self._routine_repo = routine_repo
        self._analytics_repo = analytics_repo
        self._notifier = notification_service

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    async def compute_deload_recommendation(
        self,
        user_id: uuid.UUID,
        reference_date: Optional[date] = None,
        background_tasks: Optional["BackgroundTasks"] = None,
    ) -> FatigueAnalysisResponse:
        """
        Main entry point for Critical Flow #2.

        Computes the full fatigue analysis for a user and returns
        a structured recommendation. Persists the result to fatigue_indicators.

        Args:
            user_id:        UUID of the member to analyze.
            reference_date: End of the acute window. Defaults to today.

        Returns:
            FatigueAnalysisResponse with ACWR, score, level, and recommendation.
            If the user has no training data in the evaluated period, returns a
            zeroed response immediately without hitting the algorithm or the DB.
        """
        ref_date = reference_date or date.today()

        # ── Step 0: Prioritise any already-persisted indicator ─────────────────
        # This check runs BEFORE fetching raw exercise sets so that users who
        # trained in a previous period (but not in the current acute window)
        # still see real data instead of the INITIALIZING placeholder.
        latest_indicator = await self._analytics_repo.get_latest_fatigue_indicator(user_id)

        # ── Step 1: Define time windows ────────────────────────────────────────
        acute_start = ref_date - timedelta(days=settings.ACWR_ACUTE_DAYS - 1)
        chronic_start = ref_date - timedelta(days=settings.ACWR_CHRONIC_DAYS - 1)

        # ── Step 2: Fetch raw sets from the database ───────────────────────────
        acute_sets = await self._routine_repo.get_user_sets_in_range(
            user_id, acute_start, ref_date
        )
        chronic_sets = await self._routine_repo.get_user_sets_in_range(
            user_id, chronic_start, ref_date
        )

        # ── Early exit: no raw training data in either window ──────────────────
        # If the user has a persisted indicator we return it so the UI shows
        # real historical data instead of an empty/INITIALIZING state.
        if not acute_sets and not chronic_sets:
            if latest_indicator:
                return self._indicator_to_response(user_id, latest_indicator)
            # Truly no data anywhere — return a neutral zeroed response.
            return FatigueAnalysisResponse(
                user_id=user_id,
                analysis_period_start=acute_start,
                analysis_period_end=ref_date,
                sessions_planned=0,
                sessions_completed=0,
                adherence_rate_pct=Decimal("0.00"),
                total_sets=0,
                total_reps=0,
                volume_load_kg=Decimal("0.00"),
                avg_rpe=None,
                max_rpe=None,
                failure_sets_count=0,
                acute_workload=Decimal("0.00"),
                chronic_workload=Decimal("0.00"),
                acwr=None,
                fatigue_score=Decimal("0.00"),
                fatigue_level="low",
                deload_recommended=False,
                deload_reason=None,
                recommendation_confidence=Decimal("0.00"),
                algorithm_version=settings.FATIGUE_ALGORITHM_VERSION,
                computed_at=datetime.now(timezone.utc),
            )

        # ── Step 3: Compute workload windows ───────────────────────────────────
        acute_window = self._compute_workload_window(acute_sets)
        chronic_window = self._compute_workload_window(chronic_sets)

        # ── Step 3.5: Determine History and Proportional Chronic Load ──────────
        if not chronic_sets:
            days_history = 0
        else:
            first_date = min(s.logged_at.date() for s in chronic_sets)
            days_history = max(1, (ref_date - first_date).days + 1)

        if days_history < 7:
            # Not enough continuous raw history in this window.
            # If we already have a persisted indicator, serve it so the UI is
            # not stuck on INITIALIZING for returning users.
            if latest_indicator:
                return self._indicator_to_response(user_id, latest_indicator)

            # Under a week of history and no persisted record — return the
            # INITIALIZING sentinel directly without any DB INSERT.
            return FatigueAnalysisResponse(
                user_id=user_id,
                analysis_period_start=acute_start,
                analysis_period_end=ref_date,
                sessions_planned=0,
                sessions_completed=0,
                adherence_rate_pct=Decimal("0.00"),
                total_sets=acute_window.total_sets,
                total_reps=acute_window.total_reps,
                volume_load_kg=Decimal(str(round(acute_window.volume_load_kg, 2))),
                avg_rpe=Decimal(str(acute_window.avg_rpe)) if acute_window.avg_rpe else None,
                max_rpe=Decimal(str(acute_window.max_rpe)) if acute_window.max_rpe else None,
                failure_sets_count=acute_window.failure_sets,
                acute_workload=Decimal(str(round(acute_window.volume_load_kg, 2))),
                chronic_workload=Decimal("0.00"),
                acwr=None,
                fatigue_score=Decimal("0.00"),
                fatigue_level="INITIALIZING",
                deload_recommended=False,
                deload_reason="No hay suficientes datos. Se requieren al menos 7 días de historial.",
                recommendation_confidence=Decimal("0.00"),
                algorithm_version=settings.FATIGUE_ALGORITHM_VERSION,
                computed_at=datetime.now(timezone.utc),
            )


        weeks_history = min(4.0, days_history / 7.0)
        chronic_weekly_avg = (chronic_window.volume_load_kg / weeks_history) if chronic_window.volume_load_kg else 0.0
        acwr = self._calculate_acwr(acute_window.volume_load_kg, chronic_weekly_avg)

        # ── Step 5: Get planned sessions for adherence calculation ─────────────
        sessions_planned, sessions_completed = await self._get_session_adherence(
            user_id, acute_start, ref_date
        )

        # ── Step 6: Run composite fatigue scoring algorithm ────────────────────
        decision = self._run_fatigue_algorithm(
            acwr=acwr,
            avg_rpe=acute_window.avg_rpe,
            failure_sets=acute_window.failure_sets,
            total_sets=acute_window.total_sets,
            sessions_planned=sessions_planned,
            sessions_completed=sessions_completed,
        )

        # ── Step 7: Persist FatigueIndicator row ──────────────────────────────
        indicator = await self._analytics_repo.save_fatigue_indicator(
            user_id=user_id,
            week_start_date=acute_start,
            week_end_date=ref_date,
            sessions_planned=sessions_planned,
            sessions_completed=sessions_completed,
            total_sets=acute_window.total_sets,
            total_reps=acute_window.total_reps,
            volume_load_kg=Decimal(str(acute_window.volume_load_kg)),
            avg_rpe=Decimal(str(acute_window.avg_rpe)) if acute_window.avg_rpe else None,
            max_rpe=Decimal(str(acute_window.max_rpe)) if acute_window.max_rpe else None,
            failure_sets_count=acute_window.failure_sets,
            acute_workload=Decimal(str(acute_window.volume_load_kg)),
            chronic_workload=Decimal(str(chronic_weekly_avg)),
            acwr=Decimal(str(round(acwr, 3))) if acwr else None,
            fatigue_score=Decimal(str(round(decision.fatigue_score, 2))),
            fatigue_level=decision.fatigue_level,
            deload_recommended=decision.deload_recommended,
            algorithm_version=settings.FATIGUE_ALGORITHM_VERSION,
            computation_metadata={
                "triggered_signals": decision.triggered_signals,
                "weights": {
                    "acwr": self.WEIGHT_ACWR,
                    "avg_rpe": self.WEIGHT_AVG_RPE,
                    "failure_density": self.WEIGHT_FAILURE_DENSITY,
                    "adherence_penalty": self.WEIGHT_ADHERENCE_PENALTY,
                },
                "reference_date": str(ref_date),
            },
        )

        # ── Step 8: Dispatch alerts if deload is recommended ──────────────────
        if decision.deload_recommended:
            already_alerted_today = False
            if latest_indicator and latest_indicator.deload_recommended:
                # Check if the last alert was triggered today
                if latest_indicator.created_at.date() == datetime.now(timezone.utc).date():
                    already_alerted_today = True

            if not already_alerted_today:
                await self._dispatch_deload_alert(
                    user_id=user_id,
                    fatigue_indicator_id=indicator.id,
                    decision=decision,
                    fatigue_score=decision.fatigue_score,
                    acwr=acwr,
                    background_tasks=background_tasks,
                )

        # ── Step 9: Build and return response ─────────────────────────────────
        adherence_rate = (
            Decimal(str(sessions_completed / sessions_planned * 100)).quantize(
                Decimal("0.01"), rounding=ROUND_HALF_UP
            )
            if sessions_planned > 0
            else Decimal("0.00")
        )

        return FatigueAnalysisResponse(
            user_id=user_id,
            analysis_period_start=acute_start,
            analysis_period_end=ref_date,
            sessions_planned=sessions_planned,
            sessions_completed=sessions_completed,
            adherence_rate_pct=adherence_rate,
            total_sets=acute_window.total_sets,
            total_reps=acute_window.total_reps,
            volume_load_kg=Decimal(str(round(acute_window.volume_load_kg, 2))),
            avg_rpe=Decimal(str(acute_window.avg_rpe)) if acute_window.avg_rpe else None,
            max_rpe=Decimal(str(acute_window.max_rpe)) if acute_window.max_rpe else None,
            failure_sets_count=acute_window.failure_sets,
            acute_workload=Decimal(str(round(acute_window.volume_load_kg, 2))),
            chronic_workload=Decimal(str(round(chronic_weekly_avg, 2))),
            acwr=Decimal(str(round(acwr, 3))) if acwr else None,
            fatigue_score=Decimal(str(round(decision.fatigue_score, 2))),
            fatigue_level=decision.fatigue_level,
            deload_recommended=decision.deload_recommended,
            deload_reason=decision.deload_reason,
            recommendation_confidence=Decimal(str(round(decision.recommendation_confidence, 2))),
            algorithm_version=settings.FATIGUE_ALGORITHM_VERSION,
            computed_at=datetime.now(timezone.utc),
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Private Helpers
    # ─────────────────────────────────────────────────────────────────────────

    def _indicator_to_response(
        self,
        user_id: uuid.UUID,
        indicator: "FatigueIndicator",
    ) -> FatigueAnalysisResponse:
        """
        Convert a persisted FatigueIndicator ORM row into a FatigueAnalysisResponse.

        Used whenever we short-circuit the live computation and serve a cached
        indicator — e.g. when the user has no raw sets in the current window
        but does have a valid historical record.
        """
        adherence_rate = (
            Decimal(
                str(
                    indicator.sessions_completed
                    / indicator.sessions_planned
                    * 100
                )
            ).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP)
            if indicator.sessions_planned and indicator.sessions_planned > 0
            else Decimal("0.00")
        )
        # fatigue_level may be a FatigueLevel enum; serialise to its string value.
        level_value = (
            indicator.fatigue_level.value
            if hasattr(indicator.fatigue_level, "value")
            else str(indicator.fatigue_level)
        )
        return FatigueAnalysisResponse(
            user_id=user_id,
            analysis_period_start=indicator.week_start_date,
            analysis_period_end=indicator.week_end_date,
            sessions_planned=indicator.sessions_planned,
            sessions_completed=indicator.sessions_completed,
            adherence_rate_pct=adherence_rate,
            total_sets=indicator.total_sets,
            total_reps=indicator.total_reps,
            volume_load_kg=indicator.volume_load_kg or Decimal("0.00"),
            avg_rpe=indicator.avg_rpe,
            max_rpe=indicator.max_rpe,
            failure_sets_count=indicator.failure_sets_count,
            acute_workload=indicator.acute_workload or Decimal("0.00"),
            chronic_workload=indicator.chronic_workload or Decimal("0.00"),
            acwr=indicator.acwr,
            fatigue_score=indicator.fatigue_score or Decimal("0.00"),
            fatigue_level=level_value,
            deload_recommended=indicator.deload_recommended,
            deload_reason=None,
            recommendation_confidence=Decimal("0.00"),
            algorithm_version=indicator.algorithm_version,
            computed_at=indicator.created_at,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Algorithm Internals
    # ─────────────────────────────────────────────────────────────────────────


    def _compute_workload_window(self, sets: List[ExerciseSet]) -> WorkloadWindow:
        """
        Aggregates raw exercise sets into a WorkloadWindow.

        Volume load (tonnage) = Σ (weight_kg × reps) for all working sets.
        Warmup sets are excluded (already filtered in the repository query).
        """
        window = WorkloadWindow(sets=sets)

        for s in sets:
            window.total_sets += 1
            if s.reps:
                window.total_reps += s.reps
            if s.weight and s.reps:
                # Normalize to kg if needed
                weight_kg = float(s.weight)
                if hasattr(s, "weight_unit") and s.weight_unit == "lb":
                    weight_kg *= 0.453592
                window.volume_load_kg += weight_kg * s.reps
            if s.rpe:
                window.rpe_values.append(float(s.rpe))
            if s.is_failure:
                window.failure_sets += 1

        return window

    def _calculate_acwr(
        self, acute_load: float, chronic_weekly_load: float
    ) -> Optional[float]:
        """
        ACWR = Acute Workload / Chronic Weekly Average Workload

        A ratio of 0.8–1.3 is the "sweet spot" (Hulin et al., 2016).
        - < 0.8 : Undertraining / detraining risk
        - 0.8 – 1.3 : Optimal training zone
        - 1.3 – 1.5 : Moderate risk
        - > 1.5 : HIGH injury risk zone → strong deload signal

        Returns None if there is insufficient chronic data.
        """
        if not chronic_weekly_load or chronic_weekly_load == 0:
            return None  # Not enough history — cannot compute ACWR
        return round(acute_load / chronic_weekly_load, 3)

    def _run_fatigue_algorithm(
        self,
        acwr: Optional[float],
        avg_rpe: Optional[float],
        failure_sets: int,
        total_sets: int,
        sessions_planned: int,
        sessions_completed: int,
    ) -> FatigueDecision:
        """
        Composite fatigue scoring formula.

        Each signal contributes a normalized score (0-100) that is
        weighted and summed into a final fatigue_score.

        Thresholds (from settings):
          - DELOAD_FATIGUE_THRESHOLD   = 70.0  → deload recommended
          - DELOAD_ACWR_UPPER_LIMIT    = 1.5   → injury risk zone
          - DELOAD_MIN_AVG_RPE         = 8.0   → sustained high effort

        Returns a FatigueDecision with score, level, recommendation, and reasons.
        """
        triggered_signals: List[str] = []
        component_scores: List[float] = []

        # ── Signal 1: ACWR (weight: 40%) ──────────────────────────────────────
        acwr_score = 0.0
        if acwr is not None:
            if acwr > settings.DELOAD_ACWR_UPPER_LIMIT:
                # Linear scaling: 1.5 ACWR → 100 score
                acwr_score = min(100.0, (acwr - 0.8) / (1.5 - 0.8) * 100)
                triggered_signals.append(
                    f"ACWR={acwr:.3f} exceeds safe zone upper limit of {settings.DELOAD_ACWR_UPPER_LIMIT}"
                )
            elif acwr < 0.8:
                # Undertraining: moderate signal
                acwr_score = 30.0
                triggered_signals.append(f"ACWR={acwr:.3f} below optimal zone — possible detraining")
            else:
                # In safe zone: proportional score
                acwr_score = max(0.0, (acwr - 0.8) / (1.3 - 0.8) * 50)
        component_scores.append(acwr_score * self.WEIGHT_ACWR)

        # ── Signal 2: Average RPE (weight: 30%) ───────────────────────────────
        rpe_score = 0.0
        if avg_rpe is not None:
            # RPE 8.0+ = 70+ score; RPE 9.5+ = 100 score
            rpe_score = max(0.0, (avg_rpe - 5.0) / (10.0 - 5.0) * 100)
            if avg_rpe >= settings.DELOAD_MIN_AVG_RPE:
                triggered_signals.append(
                    f"Sustained high RPE: avg={avg_rpe:.1f} (threshold={settings.DELOAD_MIN_AVG_RPE})"
                )
        component_scores.append(rpe_score * self.WEIGHT_AVG_RPE)

        # ── Signal 3: Failure Set Density (weight: 15%) ───────────────────────
        failure_score = 0.0
        if total_sets > 0:
            failure_density = failure_sets / total_sets
            failure_score = min(100.0, failure_density * 300)  # 33% failure rate → 99 score
            if failure_density > 0.20:
                triggered_signals.append(
                    f"High failure density: {failure_sets}/{total_sets} sets to failure ({failure_density:.0%})"
                )
        component_scores.append(failure_score * self.WEIGHT_FAILURE_DENSITY)

        # ── Signal 4: Adherence penalty (weight: 15%) ─────────────────────────
        adherence_score = 0.0
        if sessions_planned > 0:
            adherence_rate = sessions_completed / sessions_planned
            if adherence_rate < 0.60:
                # < 60% adherence → could indicate fatigue-driven avoidance
                adherence_score = (1.0 - adherence_rate) * 100
                triggered_signals.append(
                    f"Low session adherence: {sessions_completed}/{sessions_planned} completed ({adherence_rate:.0%})"
                )
        component_scores.append(adherence_score * self.WEIGHT_ADHERENCE_PENALTY)

        # ── Composite score ────────────────────────────────────────────────────
        fatigue_score = sum(component_scores)
        fatigue_score = max(0.0, min(100.0, fatigue_score))

        # ── Fatigue level classification ───────────────────────────────────────
        if fatigue_score >= 85:
            fatigue_level = "critical"
        elif fatigue_score >= 65:
            fatigue_level = "high"
        elif fatigue_score >= 40:
            fatigue_level = "moderate"
        else:
            fatigue_level = "low"

        # ── Deload decision ────────────────────────────────────────────────────
        hard_acwr_breach = (acwr or 0) > settings.DELOAD_ACWR_UPPER_LIMIT
        high_sustained_rpe = (avg_rpe or 0) >= settings.DELOAD_MIN_AVG_RPE
        score_breach = fatigue_score >= settings.DELOAD_FATIGUE_THRESHOLD

        # Deload if score breaches threshold OR ACWR is in the danger zone
        deload_recommended = score_breach or hard_acwr_breach

        # Build human-readable reason
        deload_reason: Optional[str] = None
        if deload_recommended:
            reasons = []
            if score_breach:
                reasons.append(f"puntaje de fatiga de {fatigue_score:.1f}/100 excede el límite saludable de {settings.DELOAD_FATIGUE_THRESHOLD}")
            if hard_acwr_breach:
                reasons.append(f"tu ACWR de {acwr:.2f} está en zona de riesgo de lesión (>{settings.DELOAD_ACWR_UPPER_LIMIT})")
            if high_sustained_rpe:
                reasons.append(f"tu esfuerzo percibido promedio es de {avg_rpe:.1f} en los últimos 7 días")
            deload_reason = "Descarga recomendada porque: " + ", ".join(reasons) + "."

        # Confidence: higher when multiple signals align
        confidence = min(1.0, len(triggered_signals) * 0.33) if deload_recommended else max(0.0, 1.0 - fatigue_score / 100)

        return FatigueDecision(
            fatigue_score=fatigue_score,
            fatigue_level=fatigue_level,
            deload_recommended=deload_recommended,
            deload_reason=deload_reason,
            recommendation_confidence=confidence,
            triggered_signals=triggered_signals,
        )

    async def _get_session_adherence(
        self, user_id: uuid.UUID, start: date, end: date
    ) -> tuple[int, int]:
        """Returns (planned, completed) session counts for the period."""
        sessions = await self._routine_repo.get_user_sessions_in_range(user_id, start, end)
        planned = len(sessions)
        completed = sum(1 for s in sessions if s.status == "completed")
        return planned, completed

    async def _dispatch_deload_alert(
        self,
        user_id: uuid.UUID,
        fatigue_indicator_id: int,
        decision: FatigueDecision,
        fatigue_score: float,
        acwr: Optional[float],
        background_tasks: Optional["BackgroundTasks"] = None,
    ) -> None:
        """
        Orchestrates multi-channel alert dispatch for deload recommendations.

        Channels:
          - In-app notification (persisted as PredictiveAlert row)
          - Email via Zoho Mail API      [AbstractNotificationService]
          - WhatsApp via Cloud API       [AbstractNotificationService]

        The actual HTTP calls are encapsulated in the injected
        AbstractNotificationService implementations.
        """
        alert_payload = {
            "fatigue_score": round(fatigue_score, 1),
            "acwr": round(acwr, 3) if acwr else None,
            "triggered_signals": decision.triggered_signals,
            "deload_reason": decision.deload_reason,
        }

        # Persist in-app alert and get the created alert ID
        alert_id = await self._analytics_repo.create_predictive_alert(
            user_id=user_id,
            triggered_by_fatigue_id=fatigue_indicator_id,
            alert_type="deload_recommended",
            title="🔴 Semana de Descarga Recomendada",
            message=(
                f"Tu análisis de fatiga de los últimos 7 días indica que necesitas "
                f"una semana de descarga. Puntaje de fatiga: {fatigue_score:.0f}/100. "
                f"{decision.deload_reason}"
            ),
            payload=alert_payload,
        )

        # ── PLACEHOLDER: Zoho Mail API ─────────────────────────────────────────
        # The ZohoMailNotificationService (injected) handles the actual API call.
        # See: app/integrations/zoho_mail/service.py
        if background_tasks:
            background_tasks.add_task(
                self._notifier.send_deload_email,
                user_id=user_id,
                alert_id=alert_id,
                fatigue_score=fatigue_score,
                deload_reason=decision.deload_reason,
            )
            background_tasks.add_task(
                self._notifier.send_deload_whatsapp,
                user_id=user_id,
                alert_id=alert_id,
                fatigue_score=fatigue_score,
                acwr=acwr,
            )
        else:
            await self._notifier.send_deload_email(
                user_id=user_id,
                alert_id=alert_id,
                fatigue_score=fatigue_score,
                deload_reason=decision.deload_reason,
            )

            # ── PLACEHOLDER: WhatsApp Cloud API ────────────────────────────────────
            # The WhatsAppNotificationService (injected) handles the actual API call.
            # See: app/integrations/whatsapp/service.py
            await self._notifier.send_deload_whatsapp(
                user_id=user_id,
                alert_id=alert_id,
                fatigue_score=fatigue_score,
                acwr=acwr,
            )
