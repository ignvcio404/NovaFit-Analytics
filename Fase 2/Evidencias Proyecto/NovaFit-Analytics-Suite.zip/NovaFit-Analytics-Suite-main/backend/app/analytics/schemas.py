"""
NovaFit Analytics Suite
========================
Analytics Schemas
"""

from datetime import date
from pydantic import BaseModel, Field


class VolumeProgressPoint(BaseModel):
    """Represents the total volume load for a given week or date."""
    week_start: date
    volume_load_kg: float = Field(..., description="Total weight * reps for this period")

    model_config = {
        "json_schema_extra": {
            "example": {
                "week_start": "2024-05-06",
                "volume_load_kg": 15450.5
            }
        }
    }


class PersonalRecordItem(BaseModel):
    """Represents a max weight personal record for an exercise."""
    exercise_name: str
    max_weight: float = Field(..., description="Max weight lifted in kg")

    model_config = {
        "json_schema_extra": {
            "example": {
                "exercise_name": "Bench Press",
                "max_weight": 110.0
            }
        }
    }
