import uuid
from typing import Dict, Any

class ChurnPredictionService:
    """
    Servicio de Data Science para predicción de fuga (Churn Rate).
    En una implementación más madura, aquí se cargaría un modelo `.pkl` 
    entrenado (ej. Random Forest con scikit-learn).
    """

    def predict_churn_risk(
        self, acwr: float, attendance_monthly: int, is_active: bool
    ) -> Dict[str, Any]:
        """
        Evalúa el riesgo de fuga basado en heurísticas del negocio:
        1. ACWR: Extremadamente bajo (desmotivación) o muy alto (lesión).
        2. Asistencia: < 4 sesiones mensuales indica alto riesgo.
        3. Estado de pago: Inactivo sube drásticamente el riesgo.
        """
        risk_score = 0.0
        
        # 1. Variable: ACWR (Fatiga/Carga)
        if acwr < 0.8:
            risk_score += 30.0  # Desentrenamiento / Desmotivación
        elif acwr > 1.5:
            risk_score += 15.0  # Sobrecarga / Riesgo de lesión que causa baja
            
        # 2. Variable: Asistencia Mensual
        if attendance_monthly < 4:
            risk_score += 40.0
        elif attendance_monthly < 8:
            risk_score += 20.0
            
        # 3. Variable: Estado Financiero
        if not is_active:
            risk_score += 30.0
            
        final_risk = min(100.0, risk_score)
        
        if final_risk >= 70:
            level = "Crítico"
        elif final_risk >= 40:
            level = "Moderado"
        else:
            level = "Bajo"
            
        return {
            "risk_percentage": round(final_risk, 2),
            "risk_level": level,
            "factors": {
                "acwr": acwr,
                "attendance": attendance_monthly,
                "is_active": is_active
            }
        }
