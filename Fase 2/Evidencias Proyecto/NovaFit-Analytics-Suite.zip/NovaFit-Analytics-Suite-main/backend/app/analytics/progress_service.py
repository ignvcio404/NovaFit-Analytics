"""
NovaFit Analytics Suite
========================
Progress Analytics Service
==========================

Handles fetching and mapping progress and personal record data.
"""

import uuid
from typing import List

from app.analytics.repository import AbstractAnalyticsRepository
from app.analytics.schemas import VolumeProgressPoint, PersonalRecordItem


class ProgressService:
    def __init__(self, repo: AbstractAnalyticsRepository):
        self._repo = repo

    async def get_volume_progress(self, user_id: uuid.UUID) -> List[VolumeProgressPoint]:
        """
        Retrieves weekly volume progress for a user.
        """
        raw_data = await self._repo.get_volume_progress(user_id)
        return [
            VolumeProgressPoint(week_start=date, volume_load_kg=vol)
            for date, vol in raw_data
        ]

    async def get_personal_records(self, user_id: uuid.UUID) -> List[PersonalRecordItem]:
        """
        Retrieves all-time max weights for completed exercises for a user.
        """
        raw_data = await self._repo.get_personal_records(user_id)
        return [
            PersonalRecordItem(exercise_name=name, max_weight=weight)
            for name, weight in raw_data
        ]
