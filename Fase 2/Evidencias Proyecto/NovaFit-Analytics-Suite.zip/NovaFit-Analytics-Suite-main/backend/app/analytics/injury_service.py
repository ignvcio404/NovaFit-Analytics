import math

class InjuryPredictionService:
    """
    Simulación matemática de probabilidad de lesión.
    Utiliza una regresión logística (función sigmoide) implementada en Python puro
    para no requerir dependencias externas como scikit-learn.
    """

    @staticmethod
    def sigmoid(z: float) -> float:
        """Función de activación sigmoide."""
        try:
            return 1.0 / (1.0 + math.exp(-z))
        except OverflowError:
            return 0.0 if z < 0 else 1.0

    @classmethod
    def predict_injury_risk(cls, acwr: float, recent_rpe_avg: float, consecutive_training_days: int) -> dict:
        """
        Calcula la probabilidad de lesión (0.0 a 1.0) combinando 3 características (features):
        - ACWR: Ratio > 1.5 aumenta el riesgo significativamente.
        - RPE (Rate of Perceived Exertion): Fatiga subjetiva, RPE alto aumenta riesgo.
        - Días consecutivos de entrenamiento: > 3 sin descanso eleva fatiga sistémica.
        
        Coeficientes (W) simulados empíricamente:
        W_acwr = 2.5 (Cruce de la barrera de 1.5 detona el riesgo)
        W_rpe = 0.5 
        W_days = 0.3
        Bias (b) = -6.0 (Ajuste para que el riesgo base sea bajo)
        """
        # Estandarización / Normalización simple
        # Centramos el ACWR en 1.5 para penalizar los excesos
        acwr_feature = (acwr - 1.5) * 2.5
        
        # RPE normal (0-10) -> lo centramos en 7 (umbral de sobreesfuerzo)
        rpe_feature = (recent_rpe_avg - 7.0) * 0.5
        
        # Días consecutivos de entreno, centrado en 3
        days_feature = (consecutive_training_days - 3) * 0.3

        bias = -2.0 # Ajustado para que el umbral sea un riesgo base.

        z = bias + acwr_feature + rpe_feature + days_feature
        risk_probability = cls.sigmoid(z)

        # Determinar zona de riesgo
        if risk_probability > 0.7:
            risk_level = "High"
            recommendation = "Intervenir inmediatamente. El atleta requiere descanso obligatorio (deload)."
        elif risk_probability > 0.4:
            risk_level = "Moderate"
            recommendation = "Monitorear de cerca. Reducir volumen/intensidad en la próxima sesión."
        else:
            risk_level = "Low"
            recommendation = "Riesgo controlado. Mantener progresión actual."

        return {
            "risk_probability": round(risk_probability, 3),
            "risk_level": risk_level,
            "recommendation": recommendation,
            "features_used": {
                "acwr": acwr,
                "recent_rpe_avg": recent_rpe_avg,
                "consecutive_training_days": consecutive_training_days
            }
        }
