"""
NovaFit Analytics Suite
========================
Analytics Repository
====================

Defines the persistence interface and its SQLAlchemy implementation
for the analytics domain (fatigue indicators and predictive alerts).

Clean Architecture pattern:
  - AbstractAnalyticsRepository: pure interface (no SQLAlchemy dependency)
  - SQLAlchemyAnalyticsRepository: concrete implementation using AsyncSession

The FatigueService depends exclusively on AbstractAnalyticsRepository,
which allows swapping or mocking the persistence layer in tests.
"""

import uuid
from abc import ABC, abstractmethod
from datetime import date
from decimal import Decimal
from typing import Any, Dict, List, Optional, Tuple

from sqlalchemy import select, func, and_, Date
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.biometry import FatigueIndicator, PredictiveAlert
from app.database.models.training import (
    RoutineSession,
    SessionExercise,
    ExerciseSet,
    ExerciseCatalog,
    SessionStatus,
)


# ─────────────────────────────────────────────────────────────────────────────
# Abstract Interface
# ─────────────────────────────────────────────────────────────────────────────

class AbstractAnalyticsRepository(ABC):
    """
    Port (interface) for the analytics persistence layer.

    All analytics write operations used by FatigueService are declared here.
    Business logic must depend only on this abstraction, never on the
    concrete SQLAlchemy implementation.
    """

    @abstractmethod
    async def save_fatigue_indicator(
        self,
        *,
        user_id: uuid.UUID,
        week_start_date: date,
        week_end_date: date,
        sessions_planned: int,
        sessions_completed: int,
        total_sets: int,
        total_reps: int,
        volume_load_kg: Decimal,
        avg_rpe: Optional[Decimal],
        max_rpe: Optional[Decimal],
        failure_sets_count: int,
        acute_workload: Optional[Decimal],
        chronic_workload: Optional[Decimal],
        acwr: Optional[Decimal],
        fatigue_score: Decimal,
        fatigue_level: str,
        deload_recommended: bool,
        algorithm_version: str,
        computation_metadata: Optional[Dict[str, Any]],
    ) -> FatigueIndicator:
        """
        Persist a computed FatigueIndicator row.

        Returns the newly created ORM instance (with its auto-assigned `id`).
        """
        ...

    @abstractmethod
    async def create_predictive_alert(
        self,
        *,
        user_id: uuid.UUID,
        triggered_by_fatigue_id: Optional[int],
        alert_type: str,
        title: str,
        message: str,
        payload: Optional[Dict[str, Any]],
    ) -> uuid.UUID:
        """
        Persist a PredictiveAlert and return its UUID.

        The returned UUID is used by the notification service to
        correlate subsequent email and WhatsApp delivery attempts.
        """
        ...

    @abstractmethod
    async def get_latest_fatigue_indicator(
        self, user_id: uuid.UUID
    ) -> Optional[FatigueIndicator]:
        """
        Fetch the most recent FatigueIndicator for a given user.
        """
        ...

    @abstractmethod
    async def get_volume_progress(self, user_id: uuid.UUID) -> List[Tuple[date, float]]:
        """
        Returns a list of tuples containing (week_start_date, total_volume_kg)
        for the given user based on completed sessions.
        """
        ...

    @abstractmethod
    async def get_personal_records(self, user_id: uuid.UUID) -> List[Tuple[str, float]]:
        """
        Returns a list of tuples containing (exercise_name, max_weight_kg)
        for the given user based on their completed exercises.
        """
        ...

# ─────────────────────────────────────────────────────────────────────────────
# SQLAlchemy Implementation
# ─────────────────────────────────────────────────────────────────────────────

class SQLAlchemyAnalyticsRepository(AbstractAnalyticsRepository):
    """
    SQLAlchemy (async) implementation of AbstractAnalyticsRepository.

    Injected by FastAPI's DI system via dependencies.py on each request.
    All operations share the same AsyncSession to participate in the
    request-scoped unit of work / transaction.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    # ─────────────────────────────────────────────────────────────────────────
    # save_fatigue_indicator
    # ─────────────────────────────────────────────────────────────────────────

    async def save_fatigue_indicator(
        self,
        *,
        user_id: uuid.UUID,
        week_start_date: date,
        week_end_date: date,
        sessions_planned: int,
        sessions_completed: int,
        total_sets: int,
        total_reps: int,
        volume_load_kg: Decimal,
        avg_rpe: Optional[Decimal],
        max_rpe: Optional[Decimal],
        failure_sets_count: int,
        acute_workload: Optional[Decimal],
        chronic_workload: Optional[Decimal],
        acwr: Optional[Decimal],
        fatigue_score: Decimal,
        fatigue_level: str,
        deload_recommended: bool,
        algorithm_version: str,
        computation_metadata: Optional[Dict[str, Any]],
    ) -> FatigueIndicator:
        """
        Insert a new FatigueIndicator row and flush to obtain the auto-generated PK.

        Uses flush() instead of commit() so the row is visible within
        the current transaction without releasing the unit of work —
        the request lifecycle commits (or rolls back) at the very end.
        """
        indicator = FatigueIndicator(
            user_id=user_id,
            week_start_date=week_start_date,
            week_end_date=week_end_date,
            sessions_planned=sessions_planned,
            sessions_completed=sessions_completed,
            total_sets=total_sets,
            total_reps=total_reps,
            volume_load_kg=volume_load_kg,
            avg_rpe=avg_rpe,
            max_rpe=max_rpe,
            failure_sets_count=failure_sets_count,
            acute_workload=acute_workload,
            chronic_workload=chronic_workload,
            acwr=acwr,
            fatigue_score=fatigue_score,
            fatigue_level=fatigue_level,
            deload_recommended=deload_recommended,
            algorithm_version=algorithm_version,
            computation_metadata=computation_metadata,
        )
        self._db.add(indicator)
        # Flush so the DB generates the integer PK, needed by create_predictive_alert.
        await self._db.flush()
        await self._db.refresh(indicator)
        return indicator

    # ─────────────────────────────────────────────────────────────────────────
    # create_predictive_alert
    # ─────────────────────────────────────────────────────────────────────────

    async def create_predictive_alert(
        self,
        *,
        user_id: uuid.UUID,
        triggered_by_fatigue_id: Optional[int],
        alert_type: str,
        title: str,
        message: str,
        payload: Optional[Dict[str, Any]],
    ) -> uuid.UUID:
        """
        Insert a new PredictiveAlert row and return its UUID.

        The alert is created in PENDING status with all delivery flags set
        to False. The notification service updates these flags after each
        successful channel delivery.
        """
        alert = PredictiveAlert(
            user_id=user_id,
            triggered_by_fatigue_id=triggered_by_fatigue_id,
            alert_type=alert_type,
            title=title,
            message=message,
            payload=payload,
            # Delivery flags (sent_in_app, sent_via_email, sent_via_whatsapp)
            # default to False as defined in the model.
        )
        self._db.add(alert)
        await self._db.flush()
        await self._db.refresh(alert)
        return alert.id

    async def get_volume_progress(self, user_id: uuid.UUID) -> List[Tuple[date, float]]:
        stmt = (
            select(
                func.date_trunc('week', RoutineSession.scheduled_date).cast(Date).label("week_start"),
                func.sum(ExerciseSet.weight * ExerciseSet.reps).label("volume_load")
            )
            .join(SessionExercise, SessionExercise.session_id == RoutineSession.id)
            .join(ExerciseSet, ExerciseSet.session_exercise_id == SessionExercise.id)
            .where(
                RoutineSession.user_id == user_id,
                RoutineSession.status == SessionStatus.COMPLETED,
                ExerciseSet.weight.isnot(None),
                ExerciseSet.reps.isnot(None)
            )
            .group_by("week_start")
            .order_by("week_start")
        )
        result = await self._db.execute(stmt)
        return [(row.week_start, float(row.volume_load)) for row in result.all()]

    async def get_personal_records(self, user_id: uuid.UUID) -> List[Tuple[str, float]]:
        stmt = (
            select(
                ExerciseCatalog.name,
                func.max(ExerciseSet.weight).label("max_weight")
            )
            .join(SessionExercise, SessionExercise.exercise_id == ExerciseCatalog.id)
            .join(RoutineSession, RoutineSession.id == SessionExercise.session_id)
            .join(ExerciseSet, ExerciseSet.session_exercise_id == SessionExercise.id)
            .where(
                RoutineSession.user_id == user_id,
                RoutineSession.status == SessionStatus.COMPLETED,
                ExerciseSet.weight.isnot(None),
                ExerciseSet.reps > 0
            )
            .group_by(ExerciseCatalog.id)
            .order_by(ExerciseCatalog.name)
        )
        result = await self._db.execute(stmt)
        return [(row.name, float(row.max_weight)) for row in result.all()]

    async def get_latest_fatigue_indicator(
        self, user_id: uuid.UUID
    ) -> Optional[FatigueIndicator]:
        stmt = (
            select(FatigueIndicator)
            .where(FatigueIndicator.user_id == user_id)
            .order_by(FatigueIndicator.week_end_date.desc(), FatigueIndicator.created_at.desc())
            .limit(1)
        )
        result = await self._db.execute(stmt)
        return result.scalar_one_or_none()
