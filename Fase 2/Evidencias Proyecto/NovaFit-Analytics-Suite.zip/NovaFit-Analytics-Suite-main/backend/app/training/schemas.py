"""
NovaFit Analytics Suite
========================
Training Domain — Pydantic Schemas (Request / Response DTOs)

These schemas are the contract between the API layer and clients.
They are intentionally decoupled from the ORM models.
"""

import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import List, Optional, Dict, Any

from pydantic import BaseModel, Field, computed_field, field_validator, model_validator

from app.database.models.training import TrainingGoal, DifficultyLevel


# ─────────────────────────────────────────────────────────────────────────────
# ── Exercise Set ──────────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

class ExerciseSetCreate(BaseModel):
    """Input schema for logging a single performed set."""

    set_number: int = Field(..., ge=1, le=50, description="1-based set number")
    reps: Optional[int] = Field(None, ge=0, le=200)
    weight: Optional[Decimal] = Field(Decimal("0.0"), ge=0, le=999.99)
    weight_unit: str = Field(default="kg", pattern=r"^(kg|lb|bodyweight|band)$")
    rpe: Optional[Decimal] = Field(
        None, ge=1.0, le=10.0,
        description="Rate of Perceived Exertion — Borg modified scale 1.0-10.0"
    )
    rest_seconds: Optional[int] = Field(None, ge=0, le=3600)
    duration_seconds: Optional[int] = Field(None, ge=0)
    is_warmup: bool = False
    is_failure: bool = False
    notes: Optional[str] = Field(None, max_length=255)

    model_config = {
        "json_schema_extra": {
            "example": {
                "set_number": 1,
                "reps": 10,
                "weight": 80.5,
                "weight_unit": "kg",
                "rpe": 8.0,
                "rest_seconds": 90,
                "duration_seconds": 45,
                "is_warmup": False,
                "is_failure": False,
                "notes": "Felt good, solid form."
            }
        }
    }

    @field_validator("rpe", mode="before")
    @classmethod
    def round_rpe(cls, v):
        if v is not None:
            return round(float(v), 1)
        return v


class ExerciseSetResponse(ExerciseSetCreate):
    id: int
    prescribed_reps: Optional[int] = None
    prescribed_weight_kg: Optional[Decimal] = None
    logged_at: datetime

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# ── Session Exercise ──────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

class SessionExerciseCreate(BaseModel):
    """One exercise entry within a session, with all its sets."""

    exercise_id: int = Field(..., description="ID from exercise_catalog")
    order_index: int = Field(..., ge=1, le=100)
    superset_group: Optional[int] = Field(None, ge=1)
    notes: Optional[str] = Field(None, max_length=255)
    sets: List[ExerciseSetCreate] = Field(
        ..., min_length=1, description="List of performed sets"
    )

    model_config = {
        "json_schema_extra": {
            "example": {
                "exercise_id": 1,
                "order_index": 1,
                "superset_group": None,
                "notes": "Focused on eccentric phase",
                "sets": [
                    {
                        "set_number": 1,
                        "reps": 12,
                        "weight": 60.0,
                        "weight_unit": "kg",
                        "rpe": 7.5,
                        "rest_seconds": 60,
                        "is_warmup": True,
                        "is_failure": False
                    },
                    {
                        "set_number": 2,
                        "reps": 10,
                        "weight": 80.0,
                        "weight_unit": "kg",
                        "rpe": 8.5,
                        "rest_seconds": 90,
                        "is_warmup": False,
                        "is_failure": False
                    }
                ]
            }
        }
    }


class ExerciseCatalogResponse(BaseModel):
    """
    Minimal read schema for ExerciseCatalog.

    Declared here so that SessionExerciseResponse can reference it as a typed
    field. Pydantic maps the ORM relationship into this schema automatically
    when from_attributes = True is active.
    """

    id: int
    name: str
    name_en: Optional[str] = None
    category: str
    difficulty: str
    equipment: Optional[str] = None
    video_url: Optional[str] = None
    thumbnail_url: Optional[str] = None
    is_custom: bool = False

    model_config = {"from_attributes": True}


class SessionExerciseResponse(BaseModel):
    id: int
    exercise_id: int
    order_index: int
    superset_group: Optional[int] = None
    notes: Optional[str] = None
    sets: List[ExerciseSetResponse] = []

    # Explicitly declared so Pydantic maps the ORM relationship from attributes.
    # Without this declaration, from_attributes silently ignores the relationship.
    exercise: Optional[ExerciseCatalogResponse] = None

    @computed_field
    @property
    def exercise_name(self) -> str:
        """Return the exercise name from the populated catalog relationship."""
        if self.exercise is not None:
            return self.exercise.name
        return "Unknown Exercise"

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# ── Routine Session ───────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

class RoutineSessionCreate(BaseModel):
    """
    Payload to create and log a complete hypertrophy session.

    FLOW: POST /api/v1/training/sessions
    This is the primary input for Critical Flow #1.
    """

    microcycle_id: Optional[int] = Field(
        None, description="Associate session with a weekly training block"
    )
    template_id: Optional[int] = Field(
        None, description="Optionally clone from a routine template"
    )
    name: str = Field(..., min_length=2, max_length=150, examples=["Push Day A — Hypertrophy"])
    scheduled_date: date = Field(..., description="Date the session is scheduled or was performed")
    status: str = Field(default="completed", pattern="^(pending|planned|completed|cancelled)$")
    exercises: List[SessionExerciseCreate] = Field(
        ..., min_length=1, max_length=30,
        description="Ordered list of exercises with all performed sets"
    )
    perceived_effort: Optional[Decimal] = Field(
        None, ge=1, le=10, description="Overall session RPE (1-10)"
    )
    trainer_notes: Optional[str] = None
    member_notes: Optional[str] = None

    model_config = {
        "json_schema_extra": {
            "example": {
                "microcycle_id": 1,
                "template_id": None,
                "name": "Upper Body Push",
                "scheduled_date": "2024-05-01",
                "status": "completed",
                "perceived_effort": 8,
                "trainer_notes": "Great intensity today",
                "member_notes": "Felt strong on bench press",
                "exercises": [
                    {
                        "exercise_id": 1,
                        "order_index": 1,
                        "sets": [
                            {
                                "set_number": 1,
                                "reps": 10,
                                "weight": 80.0,
                                "weight_unit": "kg",
                                "rpe": 8.0,
                                "rest_seconds": 90,
                                "is_warmup": False,
                                "is_failure": False
                            }
                        ]
                    }
                ]
            }
        }
    }

    @model_validator(mode="after")
    def validate_exercise_order(self) -> "RoutineSessionCreate":
        """Ensure order_index values are unique and contiguous."""
        indices = [ex.order_index for ex in self.exercises]
        if len(indices) != len(set(indices)):
            raise ValueError("Exercise order_index values must be unique within a session.")
        return self


class RoutineSessionResponse(BaseModel):
    id: uuid.UUID
    user_id: uuid.UUID
    name: str
    scheduled_date: date
    status: str
    perceived_effort: Optional[Decimal] = None
    actual_duration_min: Optional[int] = None
    trainer_notes: Optional[str] = None
    member_notes: Optional[str] = None
    exercises: List[SessionExerciseResponse] = []
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class RoutineSessionSummary(BaseModel):
    """Lightweight summary for list endpoints."""

    id: uuid.UUID
    name: str
    scheduled_date: date
    status: str
    perceived_effort: Optional[Decimal] = None
    exercise_count: int
    total_sets: int
    volume_load_kg: Decimal

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# ── Fatigue / Deload ──────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

class FatigueAnalysisResponse(BaseModel):
    """
    Response schema for Critical Flow #2 — Deload Recommendation endpoint.

    GET /api/v1/analytics/fatigue/{user_id}
    """

    user_id: uuid.UUID
    analysis_period_start: date
    analysis_period_end: date

    # ── Workload Summary ─────────────────────────────
    sessions_planned: int
    sessions_completed: int
    adherence_rate_pct: Decimal = Field(..., description="sessions_completed / sessions_planned × 100")
    total_sets: int
    total_reps: int
    volume_load_kg: Decimal

    # ── Intensity Signals ────────────────────────────
    avg_rpe: Optional[Decimal] = None
    max_rpe: Optional[Decimal] = None
    failure_sets_count: int

    # ── ACWR ────────────────────────────────────────
    acute_workload: Optional[Decimal] = None
    chronic_workload: Optional[Decimal] = None
    acwr: Optional[Decimal] = Field(
        None,
        description="Acute:Chronic Workload Ratio. Safe zone: 0.8-1.3. Risk zone: >1.5"
    )

    # ── Composite Score ──────────────────────────────
    fatigue_score: Decimal = Field(..., description="Composite fatigue score 0-100")
    fatigue_level: str = Field(..., description="low | moderate | high | critical")

    # ── Recommendation ───────────────────────────────
    deload_recommended: bool
    deload_reason: Optional[str] = Field(
        None,
        description="Human-readable explanation of WHY a deload is recommended"
    )
    recommendation_confidence: Decimal = Field(
        ..., description="Confidence of recommendation (0.0-1.0)"
    )

    # ── Metadata ─────────────────────────────────────
    algorithm_version: str
    computed_at: datetime
    localized_fatigue: Optional[dict] = Field(default_factory=dict)

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# ── Routine Templates ────────────────────────────────────────────────────────
# ─────────────────────────────────────────────────────────────────────────────

class TemplateExerciseSchema(BaseModel):
    """Schema for a prescribed exercise within a template (JSONB data)."""
    exercise_id: int
    order_index: int
    sets: int = Field(..., ge=1, le=20)
    reps_target: str = Field(..., description="e.g. '8-10' or '12'")
    rest_seconds: Optional[int] = None
    superset_group: Optional[int] = None
    notes: Optional[str] = None


class RoutineTemplateCreate(BaseModel):
    """Payload to create a reusable routine template."""
    name: str = Field(..., min_length=2, max_length=150)
    description: Optional[str] = None
    goal: TrainingGoal = Field(..., description="hypertrophy, strength, etc.")
    difficulty: DifficultyLevel = Field(..., description="beginner, intermediate, advanced, elite")
    estimated_duration_min: Optional[int] = Field(None, ge=1)
    is_public: bool = False
    exercises: List[TemplateExerciseSchema] = Field(..., min_length=1)

    model_config = {
        "json_schema_extra": {
            "example": {
                "name": "Hypertrophy Push Day",
                "description": "Standard push day focusing on chest, shoulders, and triceps.",
                "goal": "hypertrophy",
                "difficulty": "intermediate",
                "estimated_duration_min": 60,
                "is_public": True,
                "exercises": [
                    {
                        "exercise_id": 1,
                        "order_index": 1,
                        "sets": 4,
                        "reps_target": "8-12",
                        "rest_seconds": 90,
                        "superset_group": None,
                        "notes": "Control the eccentric"
                    },
                    {
                        "exercise_id": 2,
                        "order_index": 2,
                        "sets": 3,
                        "reps_target": "12-15",
                        "rest_seconds": 60,
                        "superset_group": 1,
                        "notes": "Squeeze at the top"
                    }
                ]
            }
        }
    }


class RoutineTemplateResponse(BaseModel):
    id: int
    branch_id: uuid.UUID
    created_by: Optional[uuid.UUID]
    name: str
    description: Optional[str]
    goal: TrainingGoal
    difficulty: DifficultyLevel
    estimated_duration_min: Optional[int]
    is_public: bool
    template_data: Any
    created_at: datetime
    updated_at: datetime

    model_config = {"from_attributes": True}


class InstantiateSessionRequest(BaseModel):
    """Request payload for instantiating a session from a template."""
    scheduled_date: Optional[date] = Field(None, description="Target date for the session")
    microcycle_id: Optional[int] = None

    @field_validator("scheduled_date", mode="before")
    @classmethod
    def parse_empty_date(cls, v):
        if v == "" or v == "null":
            return None
        return v

    model_config = {
        "json_schema_extra": {
            "example": {
                "scheduled_date": "2024-05-01",
                "microcycle_id": 5
            }
        }
    }

class ExerciseImportRequest(BaseModel):
    name: str
    category_name: str
    gif_url: str
