"""
NovaFit Analytics Suite
========================
Training Repository — Data Access Layer (Clean Architecture)

The Repository pattern abstracts all database queries from the Service layer.
Services depend on the Repository interface (ABC), not on SQLAlchemy directly.
"""

import uuid
from abc import ABC, abstractmethod
from datetime import date, timedelta
from decimal import Decimal
from typing import List, Optional, Any

from sqlalchemy import func, select, and_
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.errors import NotFoundException
from app.database.models.training import (
    ExerciseCatalog,
    ExerciseSet,
    Microcycle,
    RoutineSession,
    SessionExercise,
    RoutineTemplate,
)


# ─────────────────────────────────────────────────────────────────────────────
# Abstract Base (Interface)
# ─────────────────────────────────────────────────────────────────────────────

class AbstractRoutineRepository(ABC):
    """
    Port (interface) for training data access.
    The Service layer depends on this abstraction — not on SQLAlchemy.
    This enables easy substitution for tests (e.g. InMemoryRoutineRepository).
    """

    @abstractmethod
    async def get_exercise_by_id(self, exercise_id: int) -> ExerciseCatalog: ...

    @abstractmethod
    async def get_exercise_by_wger_id_or_local(self, identifier: int) -> ExerciseCatalog: ...

    @abstractmethod
    async def create_session(
        self, user_id: uuid.UUID, session_data: dict
    ) -> RoutineSession: ...

    @abstractmethod
    async def get_session_by_id(self, session_id: uuid.UUID) -> RoutineSession: ...

    @abstractmethod
    async def mark_session_completed(
        self, session_id: uuid.UUID, rpe: Optional[Decimal] = None
    ) -> RoutineSession: ...

    @abstractmethod
    async def delete_session(self, session_id: uuid.UUID) -> None: ...

    @abstractmethod
    async def get_user_sessions_in_range(
        self, user_id: uuid.UUID, start: date, end: date
    ) -> List[RoutineSession]: ...

    @abstractmethod
    async def get_user_sets_in_range(
        self, user_id: uuid.UUID, start: date, end: date
    ) -> List[ExerciseSet]: ...

    @abstractmethod
    async def get_microcycle_by_id(self, microcycle_id: int) -> Microcycle: ...

    @abstractmethod
    async def create_template(
        self, branch_id: uuid.UUID, created_by: uuid.UUID, template_data: dict
    ) -> RoutineTemplate: ...

    @abstractmethod
    async def get_template_by_id(self, template_id: int) -> RoutineTemplate: ...

    @abstractmethod
    async def list_branch_templates(
        self, branch_id: uuid.UUID
    ) -> List[RoutineTemplate]: ...

    @abstractmethod
    async def delete_template(self, template_id: int) -> None: ...

    @abstractmethod
    async def update_template(self, template_id: int, data: dict) -> RoutineTemplate: ...

    @abstractmethod
    async def list_exercises(self) -> List[ExerciseCatalog]: ...


# ─────────────────────────────────────────────────────────────────────────────
# SQLAlchemy Implementation
# ─────────────────────────────────────────────────────────────────────────────

class SQLAlchemyRoutineRepository(AbstractRoutineRepository):
    """
    Concrete SQLAlchemy implementation of the training repository.

    Dependency-injected via FastAPI's dependency injection system.
    Only this class interacts with the ORM directly.
    """

    def __init__(self, db: AsyncSession) -> None:
        self._db = db

    async def get_exercise_by_id(self, exercise_id: int) -> ExerciseCatalog:
        result = await self._db.get(ExerciseCatalog, exercise_id)
        if not result:
            raise NotFoundException("ExerciseCatalog", exercise_id)
        return result

    async def get_exercise_by_wger_id_or_local(self, identifier: int) -> ExerciseCatalog:
        from sqlalchemy import select
        # Primero busca por wger_exercise_id
        stmt = select(ExerciseCatalog).where(ExerciseCatalog.wger_exercise_id == identifier)
        result = await self._db.execute(stmt)
        exercise = result.scalars().first()
        if exercise:
            return exercise
            
        # Si no, asume que es el id local
        return await self.get_exercise_by_id(identifier)

    async def create_session(
        self, user_id: uuid.UUID, session_data: dict
    ) -> RoutineSession:
        """
        Persists a full session (header + exercises + sets) atomically.
        The session_data dict must already be validated by the Service.
        """
        session = RoutineSession(
            user_id=user_id,
            microcycle_id=session_data.get("microcycle_id"),
            template_id=session_data.get("template_id"),
            name=session_data["name"],
            scheduled_date=session_data["scheduled_date"],
            status=session_data.get("status", "completed"),
            perceived_effort=session_data.get("perceived_effort"),
            trainer_notes=session_data.get("trainer_notes"),
            member_notes=session_data.get("member_notes"),
        )
        self._db.add(session)
        await self._db.flush()  # Get session.id without committing

        for ex_data in session_data["exercises"]:
            session_exercise = SessionExercise(
                session_id=session.id,
                exercise_id=ex_data["exercise_id"],
                order_index=ex_data["order_index"],
                superset_group=ex_data.get("superset_group"),
                notes=ex_data.get("notes"),
            )
            self._db.add(session_exercise)
            await self._db.flush()

            for set_data in ex_data["sets"]:
                exercise_set = ExerciseSet(
                    session_exercise_id=session_exercise.id,
                    set_number=set_data["set_number"],
                    reps=set_data.get("reps"),
                    weight=set_data.get("weight"),
                    weight_unit=set_data.get("weight_unit", "kg"),
                    rpe=set_data.get("rpe"),
                    rest_seconds=set_data.get("rest_seconds"),
                    duration_seconds=set_data.get("duration_seconds"),
                    is_warmup=set_data.get("is_warmup", False),
                    is_failure=set_data.get("is_failure", False),
                    notes=set_data.get("notes"),
                )
                self._db.add(exercise_set)

        await self._db.flush()
        # Reload with full relationships for the response
        return await self.get_session_by_id(session.id)

    async def get_session_by_id(self, session_id: uuid.UUID) -> RoutineSession:
        stmt = (
            select(RoutineSession)
            .options(
                selectinload(RoutineSession.exercises)
                .selectinload(SessionExercise.sets),
                selectinload(RoutineSession.exercises)
                .selectinload(SessionExercise.exercise),
            )
            .where(RoutineSession.id == session_id)
        )
        result = await self._db.execute(stmt)
        session = result.scalar_one_or_none()
        if not session:
            raise NotFoundException("RoutineSession", session_id)
        return session

    async def get_user_sessions_in_range(
        self, user_id: uuid.UUID, start: date, end: date
    ) -> List[RoutineSession]:
        stmt = (
            select(RoutineSession)
            .options(
                selectinload(RoutineSession.exercises)
                .selectinload(SessionExercise.sets),
                selectinload(RoutineSession.exercises)
                .selectinload(SessionExercise.exercise),
            )
            .where(
                and_(
                    RoutineSession.user_id == user_id,
                    RoutineSession.scheduled_date >= start,
                    RoutineSession.scheduled_date <= end,
                )
            )
            .order_by(RoutineSession.scheduled_date)
        )
        result = await self._db.execute(stmt)
        return list(result.scalars().all())

    async def get_user_sets_in_range(
        self, user_id: uuid.UUID, start: date, end: date
    ) -> List[ExerciseSet]:
        """
        Optimized bulk query for fatigue computation.
        Retrieves all individual sets for a user within a date range.
        """
        stmt = (
            select(ExerciseSet)
            .join(SessionExercise, ExerciseSet.session_exercise_id == SessionExercise.id)
            .join(RoutineSession, SessionExercise.session_id == RoutineSession.id)
            .where(
                and_(
                    RoutineSession.user_id == user_id,
                    RoutineSession.scheduled_date >= start,
                    RoutineSession.scheduled_date <= end,
                    RoutineSession.status == "completed",
                    ExerciseSet.is_warmup.is_(False),  # Exclude warmup sets from analytics
                )
            )
        )
        result = await self._db.execute(stmt)
        return list(result.scalars().all())

    async def get_microcycle_by_id(self, microcycle_id: int) -> Microcycle:
        result = await self._db.get(Microcycle, microcycle_id)
        if not result:
            raise NotFoundException("Microcycle", microcycle_id)
        return result

    async def create_template(
        self, branch_id: uuid.UUID, created_by: uuid.UUID, template_data: dict
    ) -> RoutineTemplate:
        template = RoutineTemplate(
            branch_id=branch_id,
            created_by=created_by,
            name=template_data["name"],
            description=template_data.get("description"),
            goal=template_data["goal"],
            difficulty=template_data["difficulty"],
            estimated_duration_min=template_data.get("estimated_duration_min"),
            is_public=template_data.get("is_public", False),
            template_data={"exercises": template_data["exercises"]},
        )
        self._db.add(template)
        await self._db.flush()
        return template

    async def get_template_by_id(self, template_id: int) -> RoutineTemplate:
        result = await self._db.get(RoutineTemplate, template_id)
        if not result:
            raise NotFoundException("RoutineTemplate", template_id)
        return result

    async def list_branch_templates(
        self, branch_id: uuid.UUID
    ) -> List[RoutineTemplate]:
        stmt = (
            select(RoutineTemplate)
            .where(RoutineTemplate.branch_id == branch_id)
            .order_by(RoutineTemplate.created_at.desc())
        )
        result = await self._db.execute(stmt)
        return list(result.scalars().all())

    async def delete_template(self, template_id: int) -> None:
        template = await self._db.get(RoutineTemplate, template_id)
        if template:
            try:
                await self._db.delete(template)
                await self._db.commit()
            except Exception as e:
                await self._db.rollback()
                raise e

    async def update_template(self, template_id: int, data: dict) -> RoutineTemplate:
        template = await self._db.get(RoutineTemplate, template_id)
        if not template:
            raise ValueError("Template no encontrado")
        
        for key, value in data.items():
            setattr(template, key, value)
            
        try:
            await self._db.commit()
            await self._db.refresh(template)
            return template
        except Exception as e:
            await self._db.rollback()
            raise e

    async def list_exercises(self) -> List[ExerciseCatalog]:
        stmt = select(ExerciseCatalog).order_by(ExerciseCatalog.name)
        result = await self._db.execute(stmt)
        return list(result.scalars().all())

    async def mark_session_completed(
        self, session_id: uuid.UUID, rpe: Optional[Decimal] = None,
        updated_sets: Optional[List[Any]] = None
    ) -> RoutineSession:
        session = await self.get_session_by_id(session_id)
        if session:
            import logging
            from sqlalchemy import update
            from fastapi import HTTPException
            logger = logging.getLogger(__name__)

            # 1. FORZAR UPDATE DEL ESTADO DE LA SESIÓN Y RPE
            rpe_value = int(rpe) if rpe is not None else 1
            stmt_session = (
                update(RoutineSession)
                .where(RoutineSession.id == session_id)
                .values(
                    status="completed",
                    perceived_effort=rpe_value
                )
            )
            await self._db.execute(stmt_session)

            # 2. FORZAR UPDATE DE CADA SERIE (REPS Y PESO)
            if getattr(updated_sets, '__iter__', None):
                for uset in updated_sets:
                    set_id = uset["id"]
                    
                    # Verificamos si existe y si pertenece a ESTA sesión
                    from sqlalchemy import select
                    from app.database.models.training import SessionExercise
                    check_stmt = (
                        select(ExerciseSet)
                        .join(ExerciseSet.session_exercise)
                        .where(
                            ExerciseSet.id == set_id,
                            SessionExercise.session_id == session_id
                        )
                    )
                    result = await self._db.execute(check_stmt)
                    if not result.scalar_one_or_none():
                        logger.error(f"Fallo Crítico: Serie con ID {set_id} NO ENCONTRADA o no pertenece a la sesión {session_id}.")
                        raise HTTPException(status_code=404, detail=f"La serie con ID {set_id} no existe en esta sesión.")

                    stmt_set = (
                        update(ExerciseSet)
                        .where(ExerciseSet.id == set_id)
                        .values(
                            reps=uset["reps"],
                            weight=uset["weight"]
                        )
                    )
                    await self._db.execute(stmt_set)

            # 3. GUARDAR CAMBIOS ESTRICTAMENTE
            await self._db.commit()
            logger.warning("COMMIT EJECUTADO CON EXITO")
        await self._db.refresh(session)
        return session

    async def delete_session(self, session_id: uuid.UUID) -> None:
        session = await self.get_session_by_id(session_id)
        if session:
            await self._db.delete(session)
            await self._db.commit()
