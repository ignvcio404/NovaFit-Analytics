"""
NovaFit Analytics Suite
========================
CRITICAL FLOW #1 — Routine Service
=====================================

Business logic for creating and managing training routines.

Clean Architecture: this Service depends on abstractions (Repository, Notifier)
— never on concrete implementations or HTTP/DB directly.

Dependencies injected:
  - AbstractRoutineRepository   : data access
  - AbstractNotificationService : Zoho Mail + WhatsApp placeholders
"""

import uuid
from datetime import date, datetime, timezone
from decimal import Decimal
from typing import List, Optional, Any

from app.core.errors import RoutineException, NotFoundException
from app.training.repository import AbstractRoutineRepository
from app.training.schemas import (
    RoutineSessionCreate,
    RoutineSessionResponse,
    RoutineSessionSummary,
    RoutineTemplateCreate,
    RoutineTemplateResponse,
    InstantiateSessionRequest,
    ExerciseCatalogResponse,
)
from app.notifications.service import AbstractNotificationService


class RoutineService:
    """
    Orchestrates the business logic for training routine management.

    Critical Flow #1:
        POST /api/v1/training/sessions
        → validate member exists and has ACTIVE membership
        → validate all exercise IDs exist in the catalog
        → validate RPE values and set counts
        → persist session + exercises + sets atomically
        → trigger post-session notification (WhatsApp/Email via injected service)
        → return full session response
    """

    def __init__(
        self,
        repository: AbstractRoutineRepository,
        notification_service: AbstractNotificationService,
    ) -> None:
        self._repo = repository
        self._notifier = notification_service

    # ─────────────────────────────────────────────────────────────────────────
    # Public API
    # ─────────────────────────────────────────────────────────────────────────

    async def create_hypertrophy_session(
        self,
        user_id: uuid.UUID,
        payload: RoutineSessionCreate,
    ) -> RoutineSessionResponse:
        """
        Register a complete hypertrophy training session.

        This is the primary method for Critical Flow #1.

        Args:
            user_id:  UUID of the authenticated member logging the session.
            payload:  Validated Pydantic schema with exercises and sets.

        Returns:
            RoutineSessionResponse with the persisted session and all nested data.

        Raises:
            NotFoundException:   If any exercise_id does not exist in the catalog.
            RoutineException:    If business rules are violated (max failure sets, etc.)
        """
        # ── Step 1: Validate all referenced exercises exist ────────────────────
        await self._validate_exercise_ids(payload)

        # ── Step 2: Business rule — max 3 failure sets per session ─────────────
        self._enforce_failure_set_limit(payload)

        # ── Step 3: Validate microcycle if provided ────────────────────────────
        if payload.microcycle_id:
            await self._validate_microcycle(payload.microcycle_id, payload.scheduled_date)

        # ── Step 4: Persist session atomically ─────────────────────────────────
        session_dict = self._payload_to_dict(payload)
        session = await self._repo.create_session(user_id, session_dict)

        # ── Step 5: Persist session with status "planned" — notification fires on completion ─
        # NOTE: WhatsApp notification is sent in complete_session(), NOT here.
        # This ensures the member is notified when they actually finish the workout.

        return RoutineSessionResponse.model_validate(session)

    async def list_sessions(
        self,
        user_id: uuid.UUID,
        start_date: Optional[date] = None,
        end_date: Optional[date] = None,
    ) -> List[RoutineSessionSummary]:
        if not start_date:
            start_date = date.today().replace(day=1)
        if not end_date:
            end_date = date.today()
        
        sessions = await self._repo.get_user_sessions_in_range(user_id, start_date, end_date)
        
        summaries = []
        for s in sessions:
            total_sets = 0
            volume = 0.0
            
            for ex in s.exercises:
                total_sets += len(ex.sets)
                for st in ex.sets:
                    if st.weight is not None and st.reps is not None:
                        volume += float(st.weight) * st.reps
                        
            summary = RoutineSessionSummary(
                id=s.id,
                name=s.name,
                scheduled_date=s.scheduled_date,
                status=s.status,
                perceived_effort=s.perceived_effort,
                exercise_count=len(s.exercises),
                total_sets=total_sets,
                volume_load_kg=round(volume, 2)
            )
            summaries.append(summary)
        return summaries

    async def get_session(
        self, user_id: uuid.UUID, session_id: uuid.UUID
    ) -> RoutineSessionResponse:
        session = await self._repo.get_session_by_id(session_id)
        if session.user_id != user_id:
            # Optionally throw AuthorizationException instead
            raise NotFoundException("RoutineSession", session_id)
        return RoutineSessionResponse.model_validate(session)

    async def create_template(
        self,
        branch_id: uuid.UUID,
        created_by: uuid.UUID,
        payload: RoutineTemplateCreate,
    ) -> RoutineTemplateResponse:
        # Resolve Wger IDs to local IDs
        for ex in payload.exercises:
            local_ex = await self._repo.get_exercise_by_wger_id_or_local(ex.exercise_id)
            ex.exercise_id = local_ex.id
            
        template_dict = payload.model_dump()
        template = await self._repo.create_template(branch_id, created_by, template_dict)
        return RoutineTemplateResponse.model_validate(template)

    async def get_template(self, template_id: int) -> RoutineTemplateResponse:
        template = await self._repo.get_template_by_id(template_id)
        return RoutineTemplateResponse.model_validate(template)

    async def list_templates(self, branch_id: uuid.UUID) -> List[RoutineTemplateResponse]:
        templates = await self._repo.list_branch_templates(branch_id)
        return [RoutineTemplateResponse.model_validate(t) for t in templates]

    async def delete_template(self, template_id: int) -> None:
        await self._repo.delete_template(template_id)

    async def update_template(
        self,
        template_id: int,
        payload: RoutineTemplateCreate,
    ) -> RoutineTemplateResponse:
        data_dict = {
            "name": payload.name,
            "description": payload.description,
            "goal": payload.goal,
            "difficulty": payload.difficulty,
            "estimated_duration_min": payload.estimated_duration_min,
            "is_public": payload.is_public,
            "template_data": {"exercises": [ex.model_dump() for ex in payload.exercises]}
        }
        
        try:
            updated_template = await self._repo.update_template(template_id, data_dict)
            return RoutineTemplateResponse.model_validate(updated_template)
        except ValueError as e:
            from fastapi import HTTPException, status
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail=str(e))

    async def list_exercises(self) -> List[ExerciseCatalogResponse]:
        exercises = await self._repo.list_exercises()
        return [ExerciseCatalogResponse.model_validate(e) for e in exercises]

    async def instantiate_session_from_template(
        self,
        user_id: uuid.UUID,
        template_id: int,
        payload: InstantiateSessionRequest,
    ) -> RoutineSessionResponse:
        # 1. Get the template
        template = await self._repo.get_template_by_id(template_id)
        
        # 2. Build the list of exercises first
        exercises_list = []
        raw_data = template.template_data
        
        # Defensive parsing in case it was stored as a JSON string instead of dict
        if isinstance(raw_data, str):
            import json
            try:
                raw_data = json.loads(raw_data)
            except Exception:
                raw_data = {}
        
        if isinstance(raw_data, list):
            tpl_exercises = raw_data
        elif isinstance(raw_data, dict):
            tpl_exercises = raw_data.get("exercises", [])
        else:
            tpl_exercises = []
        
        for idx, tpl_ex in enumerate(tpl_exercises):
            sets_data = []
            # Create the prescribed number of sets
            for i in range(1, tpl_ex.get("sets", 3) + 1):
                # We leave weight and RPE empty for the user to fill.
                sets_data.append({
                    "set_number": i,
                    "prescribed_reps": None, # Could parse reps_target if it was numeric
                    "rest_seconds": tpl_ex.get("rest_seconds"),
                    "is_warmup": False,
                    "is_failure": False,
                })
                
            exercises_list.append({
                "exercise_id": tpl_ex["exercise_id"],
                "order_index": tpl_ex.get("order_index", idx + 1),
                "superset_group": tpl_ex.get("superset_group"),
                "notes": tpl_ex.get("notes"),
                "sets": sets_data,
            })
            
        if not exercises_list:
            from fastapi import HTTPException, status
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="La plantilla seleccionada no contiene ejercicios. No se puede asignar una sesión vacía."
            )
            
        # 3. Build the RoutineSessionCreate payload based on the template
        session_payload = RoutineSessionCreate(
            microcycle_id=payload.microcycle_id,
            template_id=template.id,
            name=template.name,
            scheduled_date=payload.scheduled_date,
            status="planned",
            exercises=exercises_list
        )
        
        # 4. Create the session using the existing logic (validates IDs again, etc.)
        return await self.create_hypertrophy_session(user_id, session_payload)

    async def complete_session(
        self, user_id: uuid.UUID, session_id: uuid.UUID, rpe: Optional[Decimal] = None,
        updated_sets: Optional[List[Any]] = None
    ) -> RoutineSessionResponse:
        """
        Marks a pending session as completed, optionally providing an RPE value.
        Returns the full session payload.
        """
        from fastapi import HTTPException, status
        
        # Check ownership and existing status
        session = await self._repo.get_session_by_id(session_id)
        if session.user_id != user_id:
            raise HTTPException(status_code=403, detail="Not authorized to modify this session.")
        if session.status == "completed":
            raise HTTPException(status_code=400, detail="La sesión ya fue completada.")
            
        completed_session = await self._repo.mark_session_completed(session_id, rpe, updated_sets)

        # ── Send post-completion WhatsApp notification ─────────────────────────
        try:
            # Compute real volume from the persisted session data
            total_sets = 0
            volume_load_kg = 0.0
            rpe_values = []

            for ex in completed_session.exercises:
                for s in ex.sets:
                    if not s.is_warmup:
                        total_sets += 1
                        if s.weight is not None and s.reps is not None:
                            volume_load_kg += float(s.weight) * s.reps
                        if s.rpe is not None:
                            rpe_values.append(float(s.rpe))

            avg_rpe = round(sum(rpe_values) / len(rpe_values), 1) if rpe_values else None

            volume_summary = {
                "total_sets": total_sets,
                "volume_load_kg": round(volume_load_kg, 2),
                "avg_rpe": avg_rpe,
            }

            await self._notifier.send_session_completion_notification(
                user_id=user_id,
                session_name=completed_session.name,
                volume_summary=volume_summary,
            )
        except Exception as exc:
            import logging
            logging.getLogger(__name__).error(
                "WhatsApp session-complete notification failed for user=%s: %s", user_id, exc
            )

        return RoutineSessionResponse.model_validate(completed_session)

    # ─────────────────────────────────────────────────────────────────────────
    # Private helpers
    # ─────────────────────────────────────────────────────────────────────────

    async def _validate_exercise_ids(self, payload: RoutineSessionCreate) -> None:
        """
        Ensures every referenced exercise exists in the catalog.
        Fails fast on the first missing ID.
        """
        from fastapi import HTTPException, status
        seen_ids = {ex.exercise_id for ex in payload.exercises}
        for exercise_id in seen_ids:
            # We catch the 404 and raise a 400 to prevent route-not-found confusion in the frontend
            try:
                await self._repo.get_exercise_by_id(exercise_id)
            except Exception:
                raise HTTPException(
                    status_code=status.HTTP_400_BAD_REQUEST,
                    detail=f"Validation Error: Exercise ID {exercise_id} not found in catalog."
                )

    def _enforce_failure_set_limit(
        self,
        payload: RoutineSessionCreate,
        max_failure_sets: int = 6,
    ) -> None:
        """
        Business rule: excessive sets to failure indicate overreaching.
        Alert trainer if client logs more than max_failure_sets per session.
        """
        total_failure_sets = sum(
            1
            for ex in payload.exercises
            for s in ex.sets
            if s.is_failure and not s.is_warmup
        )
        if total_failure_sets > max_failure_sets:
            raise RoutineException(
                f"Session contains {total_failure_sets} failure sets, "
                f"exceeding the maximum of {max_failure_sets}. "
                "This may indicate overreaching. Review with your trainer."
            )

    async def _validate_microcycle(
        self, microcycle_id: int, scheduled_date: date
    ) -> None:
        """
        Ensures the session's scheduled_date falls within the microcycle's week range.
        """
        microcycle = await self._repo.get_microcycle_by_id(microcycle_id)
        if not (microcycle.week_start_date <= scheduled_date <= microcycle.week_end_date):
            raise RoutineException(
                f"Session date {scheduled_date} is outside microcycle week "
                f"[{microcycle.week_start_date} – {microcycle.week_end_date}]."
            )

    def _payload_to_dict(self, payload: RoutineSessionCreate) -> dict:
        """Convert the validated Pydantic schema to a plain dict for the repository."""
        return {
            "microcycle_id": payload.microcycle_id,
            "template_id": payload.template_id,
            "name": payload.name,
            "scheduled_date": payload.scheduled_date,
            "status": "planned" if payload.status == "pending" else payload.status,
            "perceived_effort": payload.perceived_effort,
            "trainer_notes": payload.trainer_notes,
            "member_notes": payload.member_notes,
            "exercises": [
                {
                    "exercise_id": ex.exercise_id,
                    "order_index": ex.order_index,
                    "superset_group": ex.superset_group,
                    "notes": ex.notes,
                    "sets": [
                        {
                            "set_number": s.set_number,
                            "reps": s.reps,
                            "weight": float(s.weight) if s.weight else None,
                            "weight_unit": s.weight_unit,
                            "rpe": float(s.rpe) if s.rpe else None,
                            "rest_seconds": s.rest_seconds,
                            "duration_seconds": s.duration_seconds,
                            "is_warmup": s.is_warmup,
                            "is_failure": s.is_failure,
                            "notes": s.notes,
                        }
                        for s in ex.sets
                    ],
                }
                for ex in payload.exercises
            ],
        }

    def _compute_session_volume(self, payload: RoutineSessionCreate) -> dict:
        """
        Calculates session volume metrics for the notification message.

        Volume load = Σ (reps × weight_kg) across all working sets.
        """
        total_sets = 0
        total_reps = 0
        volume_load_kg = 0.0
        rpe_values = []

        for ex in payload.exercises:
            for s in ex.sets:
                if not s.is_warmup:
                    total_sets += 1
                    if s.reps is not None:
                        total_reps += s.reps
                    if s.weight is not None and s.reps is not None and s.weight_unit == "kg":
                        volume_load_kg += float(s.weight) * s.reps
                    if s.rpe is not None:
                        rpe_values.append(float(s.rpe))

        avg_rpe = round(sum(rpe_values) / len(rpe_values), 1) if rpe_values else None

        return {
            "total_sets": total_sets,
            "total_reps": total_reps,
            "volume_load_kg": round(volume_load_kg, 2),
            "avg_rpe": avg_rpe,
            "exercise_count": len(payload.exercises),
        }

    async def delete_session(self, user_id, session_id, user_roles=None) -> None:
        session_db = await self._repo.get_session_by_id(session_id)

        if not session_db:
            from fastapi import HTTPException
            raise HTTPException(status_code=404, detail='Session not found')

        is_trainer = any(r.role and r.role.name in ('super_admin', 'trainer') for r in user_roles or [])

        if session_db.user_id != user_id and not is_trainer:
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail='Not authorized to delete this session')

        if session_db.microcycle_id and not is_trainer:
            from fastapi import HTTPException
            raise HTTPException(status_code=403, detail='Cannot delete a session assigned by a trainer.')

        await self._repo.delete_session(session_id)
