"""
NovaFit Analytics Suite
========================
Email Service (SMTP)
========================

Uses aiosmtplib to send asynchronous transactional emails via Zoho Mail.
"""

import logging
from email.message import EmailMessage
from typing import Optional

import aiosmtplib

from app.core.config import settings

logger = logging.getLogger(__name__)


class EmailService:
    def __init__(self):
        self.host = settings.SMTP_HOST
        self.port = settings.SMTP_PORT
        self.user = settings.SMTP_USER
        self.password = settings.SMTP_PASSWORD
        self.from_email = settings.EMAILS_FROM_EMAIL
        self.from_name = settings.ZOHO_FROM_NAME
        # Brand colors
        self.color_primary = "#6366f1"
        self.color_bg = "#f8fafc"
        self.color_text = "#334155"
        self.color_container = "#ffffff"

    def _build_html_template(self, title: str, content: str) -> str:
        """Wraps content in a standardized responsive HTML template."""
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <meta charset="utf-8">
            <style>
                body {{
                    font-family: 'Inter', -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif;
                    background-color: {self.color_bg};
                    color: {self.color_text};
                    margin: 0;
                    padding: 40px 20px;
                }}
                .container {{
                    max-width: 600px;
                    margin: 0 auto;
                    background-color: {self.color_container};
                    border-radius: 8px;
                    padding: 40px;
                    box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
                }}
                h1 {{
                    color: {self.color_primary};
                    margin-top: 0;
                    font-size: 24px;
                }}
                .footer {{
                    margin-top: 40px;
                    font-size: 12px;
                    color: #94a3b8;
                    text-align: center;
                }}
                .btn {{
                    display: inline-block;
                    background-color: {self.color_primary};
                    color: #ffffff;
                    text-decoration: none;
                    padding: 12px 24px;
                    border-radius: 6px;
                    font-weight: 600;
                    margin: 20px 0;
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <h1>{title}</h1>
                {content}
                <div class="footer">
                    &copy; 2026 {self.from_name}. Todos los derechos reservados.
                </div>
            </div>
        </body>
        </html>
        """

    async def _send_email(self, to_email: str, subject: str, html_content: str) -> bool:
        """Internal method to send an email asynchronously."""
        message = EmailMessage()
        message["From"] = f"{self.from_name} <{self.from_email}>"
        message["To"] = to_email
        message["Subject"] = subject
        message.add_alternative(html_content, subtype="html")

        try:
            logger.info(f"Connecting to SMTP server {self.host}:{self.port} to send email to {to_email}")
            await aiosmtplib.send(
                message,
                hostname=self.host,
                port=self.port,
                username=self.user,
                password=self.password,
                use_tls=True,
                timeout=15.0
            )
            logger.info(f"Email '{subject}' successfully sent to {to_email}")
            return True
        except Exception as e:
            logger.error(f"Failed to send email to {to_email}: {str(e)}", exc_info=True)
            return False

    async def send_welcome_email(self, user_email: str, first_name: str, temp_password: str) -> None:
        """Sends a welcome email with temporary credentials to a new member."""
        title = "¡Bienvenido a NovaFit Analytics Suite!"
        content = f"""
            <p>Hola <strong>{first_name}</strong>,</p>
            <p>Nos emociona darte la bienvenida a nuestra plataforma integral de gestión deportiva. Tu cuenta ha sido creada exitosamente.</p>
            <p>Para ingresar, utiliza las siguientes credenciales temporales:</p>
            <ul>
                <li><strong>Correo:</strong> {user_email}</li>
                <li><strong>Contraseña Temporal:</strong> <code>{temp_password}</code></li>
            </ul>
            <p>Por motivos de seguridad, te recomendamos cambiar tu contraseña inmediatamente después de iniciar sesión por primera vez.</p>
            <a href="https://novafit.com/login" class="btn">Iniciar Sesión</a>
        """
        html_content = self._build_html_template(title, content)
        await self._send_email(user_email, title, html_content)

    async def send_payment_confirmation(self, user_email: str, first_name: str, plan_name: str, amount: float) -> None:
        """Sends a receipt or payment confirmation email."""
        title = "Confirmación de Pago Exitoso"
        content = f"""
            <p>Hola <strong>{first_name}</strong>,</p>
            <p>Hemos recibido tu pago correctamente. Tu membresía ha sido actualizada.</p>
            <div style="background-color: #f1f5f9; padding: 20px; border-radius: 6px; margin: 20px 0;">
                <p style="margin: 0;"><strong>Plan:</strong> {plan_name}</p>
                <p style="margin: 10px 0 0 0;"><strong>Monto pagado:</strong> ${amount:,.0f} CLP</p>
            </div>
            <p>Puedes revisar los detalles de tu plan y las sesiones disponibles en tu Dashboard.</p>
        """
        html_content = self._build_html_template(title, content)
        await self._send_email(user_email, title, html_content)

    async def send_password_recovery(self, user_email: str, reset_token: str) -> None:
        """Sends a password recovery link with a secure token."""
        title = "Recuperación de Contraseña"
        reset_link = f"{settings.FRONTEND_URL}/reset-password?token={reset_token}"
        content = f"""
            <p>Has solicitado restablecer tu contraseña en NovaFit.</p>
            <p>Haz clic en el siguiente botón para crear una nueva contraseña. Este enlace expirará en 15 minutos.</p>
            <a href="{reset_link}" class="btn">Restablecer Contraseña</a>
            <p>Si no fuiste tú quien solicitó esto, puedes ignorar este correo de forma segura.</p>
        """
        html_content = self._build_html_template(title, content)
        await self._send_email(user_email, title, html_content)
