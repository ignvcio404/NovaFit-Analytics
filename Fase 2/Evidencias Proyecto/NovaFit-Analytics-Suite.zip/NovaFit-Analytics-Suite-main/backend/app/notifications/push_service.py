import httpx
import logging
from typing import Optional

logger = logging.getLogger(__name__)

async def send_expo_push_notification(device_token: Optional[str], title: str, body: str, data: dict = None):
    """
    Sends a push notification using Expo Push API.
    """
    if not device_token:
        logger.info("Skipping push notification: No device token provided.")
        return

    if not device_token.startswith("ExponentPushToken"):
        logger.warning(f"Invalid Expo Push Token format: {device_token}")
        return

    payload = {
        "to": device_token,
        "title": title,
        "body": body,
        "data": data or {},
        "sound": "default",
    }

    try:
        async with httpx.AsyncClient() as client:
            response = await client.post(
                "https://exp.host/--/api/v2/push/send",
                json=payload,
                headers={
                    "Accept": "application/json",
                    "Accept-encoding": "gzip, deflate",
                    "Content-Type": "application/json",
                },
                timeout=5.0
            )
            response.raise_for_status()
            logger.info(f"Push notification sent successfully to {device_token}")
            return response.json()
    except Exception as e:
        logger.error(f"Error sending Expo push notification to {device_token}: {e}")
