"""
NovaFit Analytics Suite
========================
Notification Service — Abstract Interface + Placeholder Implementations

This module defines the port (interface) for all external notification
delivery. Concrete implementations for Zoho Mail and WhatsApp Cloud API
are in app/integrations/. This indirection keeps the Service layer
(RoutineService, FatigueService) decoupled from HTTP client details.
"""

import uuid
from abc import ABC, abstractmethod
from typing import Optional
import logging

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Abstract Interface (Port)
# ─────────────────────────────────────────────────────────────────────────────

class AbstractNotificationService(ABC):
    """
    Port for all external notifications.

    Implementations:
      - CompositeNotificationService  : Production (Zoho + WhatsApp)
      - SilentNotificationService     : Tests (no-op, logs only)
    """

    @abstractmethod
    async def send_session_completion_notification(
        self,
        user_id: uuid.UUID,
        session_name: str,
        volume_summary: dict,
    ) -> None:
        """Send a post-workout completion message (WhatsApp)."""
        ...

    @abstractmethod
    async def send_deload_email(
        self,
        user_id: uuid.UUID,
        alert_id: uuid.UUID,
        fatigue_score: float,
        deload_reason: Optional[str],
    ) -> None:
        """Dispatch deload recommendation email via Zoho Mail API."""
        ...

    @abstractmethod
    async def send_deload_whatsapp(
        self,
        user_id: uuid.UUID,
        alert_id: uuid.UUID,
        fatigue_score: float,
        acwr: Optional[float],
    ) -> None:
        """Dispatch deload recommendation WhatsApp message."""
        ...


# ─────────────────────────────────────────────────────────────────────────────
# Silent Implementation (Tests / Development)
# ─────────────────────────────────────────────────────────────────────────────

class SilentNotificationService(AbstractNotificationService):
    """
    No-op implementation used in tests and development.
    Logs intent but makes no actual external API calls.
    """

    async def send_session_completion_notification(
        self, user_id: uuid.UUID, session_name: str, volume_summary: dict
    ) -> None:
        logger.info(
            "[SILENT] Session completion notification for user=%s session=%r volume=%s",
            user_id, session_name, volume_summary,
        )

    async def send_deload_email(
        self, user_id, alert_id, fatigue_score, deload_reason
    ) -> None:
        logger.info(
            "[SILENT] Deload email for user=%s score=%.1f reason=%r",
            user_id, fatigue_score, deload_reason,
        )

    async def send_deload_whatsapp(
        self, user_id, alert_id, fatigue_score, acwr
    ) -> None:
        logger.info(
            "[SILENT] Deload WhatsApp for user=%s score=%.1f acwr=%s",
            user_id, fatigue_score, acwr,
        )


# ─────────────────────────────────────────────────────────────────────────────
# Composite Implementation (Production)
# ─────────────────────────────────────────────────────────────────────────────

class CompositeNotificationService(AbstractNotificationService):
    """
    Production implementation that delegates to the concrete
    Zoho Mail and WhatsApp integration services.

    Dependencies are injected so each channel can fail independently
    without blocking the other.
    """

    def __init__(
        self,
        zoho_service,      # ZohoMailService (from app/integrations/zoho_mail/)
        whatsapp_service,  # WhatsAppService (from app/integrations/whatsapp/)
        user_repo,         # To resolve user_id → email + phone_number
    ) -> None:
        self._zoho = zoho_service
        self._whatsapp = whatsapp_service
        self._user_repo = user_repo

    async def send_session_completion_notification(
        self,
        user_id: uuid.UUID,
        session_name: str,
        volume_summary: dict,
    ) -> None:
        """
        Post-workout WhatsApp notification via template 'novafit_sesion_completada'.
        Template variables: nombre, rutina, series, volumen kg.
        """
        try:
            user = await self._user_repo.get_by_id(user_id)
            if user.phone_number:
                await self._whatsapp.send_session_completion(
                    to_phone=user.phone_number,
                    member_first_name=user.first_name,
                    session_name=session_name,
                    total_sets=volume_summary.get('total_sets', 0),
                    volume_load_kg=volume_summary.get('volume_load_kg', 0),
                    avg_rpe=volume_summary.get('avg_rpe'),
                )
            else:
                logger.warning("WhatsApp session notification skipped for user=%s: no phone number registered", user_id)
        except Exception as exc:
            # Notification failures MUST NOT break the session creation flow
            logger.error("WhatsApp session notification failed for user=%s: %s", user_id, exc)

    async def send_deload_email(
        self,
        user_id: uuid.UUID,
        alert_id: uuid.UUID,
        fatigue_score: float,
        deload_reason: Optional[str],
    ) -> None:
        """
        Deload recommendation email via Zoho Mail API.
        See: app/integrations/zoho_mail/service.py → ZohoMailService.send_email()
        """
        try:
            user = await self._user_repo.get_by_id(user_id)
            await self._zoho.send_deload_recommendation(
                to_email=user.email,
                to_name=f"{user.first_name} {user.last_name}",
                fatigue_score=fatigue_score,
                deload_reason=deload_reason,
                alert_id=str(alert_id),
            )
        except Exception as exc:
            logger.error("Zoho Mail deload email failed for user=%s: %s", user_id, exc)

    async def send_deload_whatsapp(
        self,
        user_id: uuid.UUID,
        alert_id: uuid.UUID,
        fatigue_score: float,
        acwr: Optional[float],
    ) -> None:
        """
        Deload WhatsApp notification via template 'novafit_alerta_fatiga'.
        Template variables: nombre, score de fatiga, ratio ACWR.
        """
        try:
            user = await self._user_repo.get_by_id(user_id)
            if user.phone_number:
                await self._whatsapp.send_fatigue_alert(
                    phone=user.phone_number,
                    user_name=user.first_name,
                    fatigue_score=fatigue_score,
                    acwr=acwr,
                )
            else:
                logger.warning("WhatsApp deload notification skipped for user=%s: no phone number registered", user_id)
        except Exception as exc:
            logger.error("WhatsApp deload notification failed for user=%s: %s", user_id, exc)
