import time
import logging
from starlette.middleware.base import BaseHTTPMiddleware
from fastapi import Request
from sqlalchemy.ext.asyncio import AsyncSession
from app.database.session import AsyncSessionLocal
from app.database.models.core import AuditLog, AuditAction

logger = logging.getLogger("audit_middleware")

class AuditMiddleware(BaseHTTPMiddleware):
    """
    Middleware de auditoría para registrar el acceso y las modificaciones
    a la API. Registra endpoints, métodos, códigos de respuesta, y tiempo de ejecución.
    Para prevenir sobrecarga, se podría filtrar para registrar solo endpoints sensibles (ej. /admin o métodos POST/PUT/DELETE).
    """
    async def dispatch(self, request: Request, call_next):
        start_time = time.time()
        
        # Continuar con el request
        response = await call_next(request)
        
        process_time = time.time() - start_time
        
        # Filtro: Solo auditar endpoints bajo /api/v1 y operaciones que no sean GET
        # O en este caso, se puede auditar todo lo crítico.
        path = request.url.path
        method = request.method
        
        if path.startswith("/api/v1") and method in ["POST", "PUT", "DELETE", "PATCH"]:
            try:
                # Intentamos extraer un user_id si está autenticado.
                # Nota: en middlewares a veces no está disponible user.id sin forzar parseo del token.
                # Aquí lo guardamos como un registro de evento general si no hay usuario directo.
                user_id = None
                if hasattr(request.state, "user"):
                    user_id = request.state.user.id
                
                async with AsyncSessionLocal() as db:
                    action_enum = AuditAction.UPDATE if method in ["PATCH", "PUT"] else (AuditAction.CREATE if method == "POST" else AuditAction.DELETE)
                    audit_entry = AuditLog(
                        user_id=user_id,
                        action=action_enum,
                        resource_type="API",
                        resource_id=None,
                        log_metadata={
                            "path": path,
                            "method": method,
                            "status_code": response.status_code,
                            "process_time_ms": round(process_time * 1000, 2),
                            "client_ip": request.client.host if request.client else "unknown"
                        }
                    )
                    db.add(audit_entry)
                    await db.commit()
            except Exception as e:
                logger.error(f"Fallo al guardar log de auditoría: {e}")
                
        return response
