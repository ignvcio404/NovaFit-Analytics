from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Optional
from pydantic import BaseModel
from decimal import Decimal
import uuid

from app.database.session import get_db
from app.core.security import get_current_active_user
from app.database.models.core import User
from app.database.models.administrative import MembershipPlan, BillingCycle

router = APIRouter(prefix="/plans", tags=["Membership Plans"])

# ─────────────────────────────────────────────────────────────────────────────
# Schemas
# ─────────────────────────────────────────────────────────────────────────────

class PlanCreate(BaseModel):
    name: str
    description: Optional[str] = None
    billing_cycle: BillingCycle
    price: float
    currency_code: str = "CLP"
    duration_days: int
    max_freeze_days: int = 15
    is_active: bool = True

class PlanUpdate(BaseModel):
    name: Optional[str] = None
    description: Optional[str] = None
    billing_cycle: Optional[BillingCycle] = None
    price: Optional[float] = None
    currency_code: Optional[str] = None
    duration_days: Optional[int] = None
    max_freeze_days: Optional[int] = None
    is_active: Optional[bool] = None

class PlanResponse(BaseModel):
    id: int
    branch_id: uuid.UUID
    name: str
    description: Optional[str] = None
    billing_cycle: BillingCycle
    price: float
    currency_code: str
    duration_days: int
    max_freeze_days: int
    is_active: bool

    model_config = {"from_attributes": True}


# ─────────────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.get("", response_model=List[PlanResponse])
async def get_plans(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Get all membership plans for the current user's branch."""
    branch_id = current_user.branch_id or current_user.id
    
    query = select(MembershipPlan).where(MembershipPlan.branch_id == branch_id).order_by(MembershipPlan.id.asc())
    result = await db.execute(query)
    plans = result.scalars().all()
    return plans


@router.post("", response_model=PlanResponse, status_code=status.HTTP_201_CREATED)
async def create_plan(
    plan: PlanCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Create a new membership plan."""
    # Note: Using simple role check
    roles = {ur.role.name for ur in current_user.user_roles if ur.role}
    if "super_admin" not in roles and "admin" not in roles:
         raise HTTPException(status_code=403, detail="Not enough permissions")

    branch_id = current_user.branch_id or current_user.id

    new_plan = MembershipPlan(
        branch_id=branch_id,
        name=plan.name,
        description=plan.description,
        billing_cycle=plan.billing_cycle,
        price=plan.price,
        currency_code=plan.currency_code,
        duration_days=plan.duration_days,
        max_freeze_days=plan.max_freeze_days,
        is_active=plan.is_active
    )
    db.add(new_plan)
    await db.commit()
    await db.refresh(new_plan)
    return new_plan


@router.put("/{plan_id}", response_model=PlanResponse)
async def update_plan(
    plan_id: int,
    plan_update: PlanUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Update a membership plan."""
    roles = {ur.role.name for ur in current_user.user_roles if ur.role}
    if "super_admin" not in roles and "admin" not in roles:
         raise HTTPException(status_code=403, detail="Not enough permissions")

    branch_id = current_user.branch_id or current_user.id

    query = select(MembershipPlan).where(MembershipPlan.id == plan_id, MembershipPlan.branch_id == branch_id)
    result = await db.execute(query)
    db_plan = result.scalars().first()

    if not db_plan:
        raise HTTPException(status_code=404, detail="Plan not found")

    update_data = plan_update.model_dump(exclude_unset=True)
    for key, value in update_data.items():
        setattr(db_plan, key, value)

    await db.commit()
    await db.refresh(db_plan)
    return db_plan


@router.delete("/{plan_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_plan(
    plan_id: int,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    """Delete a membership plan."""
    roles = {ur.role.name for ur in current_user.user_roles if ur.role}
    if "super_admin" not in roles and "admin" not in roles:
         raise HTTPException(status_code=403, detail="Not enough permissions")

    branch_id = current_user.branch_id or current_user.id

    query = select(MembershipPlan).where(MembershipPlan.id == plan_id, MembershipPlan.branch_id == branch_id)
    result = await db.execute(query)
    db_plan = result.scalars().first()

    if not db_plan:
        raise HTTPException(status_code=404, detail="Plan not found")

    await db.delete(db_plan)
    await db.commit()
