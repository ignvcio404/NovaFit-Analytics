"""
NovaFit Analytics Suite
========================
API v1 Main Router
"""

from fastapi import APIRouter

from app.api.v1.auth_router import router as auth_router
from app.api.v1.training_router import router as training_router
from app.api.v1.analytics_router import router as analytics_router
from app.api.v1.users_router import router as users_router
from app.api.v1.billing_router import router as billing_router
from app.api.v1.billing_admin_router import router as billing_admin_router
from app.api.v1.whatsapp_router import router as whatsapp_router
from app.api.v1.exercises_router import router as exercises_router
from app.api.v1.trainer_router import router as trainer_router
from app.api.v1.athlete_router import router as athlete_router
from app.api.v1.internal_router import router as internal_router
from app.api.v1.branches_router import router as branches_router
from app.integrations.mercadopago.webhook_router import router as mercadopago_webhook_router

api_router = APIRouter()

api_router.include_router(auth_router)
api_router.include_router(training_router)
api_router.include_router(analytics_router)
api_router.include_router(users_router)
api_router.include_router(exercises_router)
api_router.include_router(trainer_router)
api_router.include_router(athlete_router)
api_router.include_router(branches_router)

from app.api.v1.plans_router import router as plans_router
api_router.include_router(plans_router)

# ── Integrations & Billing ───────────────────────────────────────────────────
api_router.include_router(billing_router)
api_router.include_router(billing_admin_router)
api_router.include_router(mercadopago_webhook_router)
api_router.include_router(whatsapp_router)

# ── Internal (QStash Cron Jobs) ───────────────────────────────────────────────
from app.api.v1.internal_router import router as internal_router
from app.api.v1.jobs_router import router as jobs_router

api_router.include_router(internal_router)
api_router.include_router(jobs_router)

# Additional routers will be added in subsequent phases:
# from app.api.v1.membership_router import router as membership_router
# from app.api.v1.biometry_router  import router as biometry_router
# from app.api.v1.wger_router      import router as wger_router
