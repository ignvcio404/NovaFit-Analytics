"""
NovaFit Analytics Suite
========================
Analytics Controller (FastAPI Router)

Handles HTTP concerns for analytics endpoints.
Critical Flow #2: Deload recommendation endpoint.
"""

import uuid
from datetime import date, datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status, BackgroundTasks, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.analytics.fatigue_service import FatigueService
from app.analytics.progress_service import ProgressService
from app.analytics.schemas import VolumeProgressPoint, PersonalRecordItem
from app.core.dependencies import get_fatigue_service, get_progress_service, require_active_membership
from app.core.security import get_current_active_user, require_permission
from app.database.models.core import User, TrainerAthleteLink, LinkStatus
from app.database.models.biometry import PredictiveAlert
from app.database.session import get_db
from app.training.schemas import FatigueAnalysisResponse

router = APIRouter(prefix="/analytics", tags=["Analytics"])


# ─────────────────────────────────────────────────────────────────────────────
# /fatigue/me  — must be declared BEFORE /{user_id} so FastAPI matches the
# literal string "me" first and does not attempt to parse it as a UUID.
# ─────────────────────────────────────────────────────────────────────────────

@router.get(
    "/fatigue/me",
    response_model=FatigueAnalysisResponse,
    status_code=status.HTTP_200_OK,
    summary="Get current user fatigue analysis",
    description=(
        "**Critical Flow #2**: Analyzes recent training history (defaulting to the last 4 weeks) "
        "to calculate a localized and systemic fatigue score, and determines if a deload is recommended."
    ),
    responses={
        200: {"description": "Analysis generated successfully"},
        401: {"description": "Not authenticated"},
    },
)
async def get_my_fatigue_analysis(
    reference_date: Optional[date] = Query(None),
    current_user: User = Depends(get_current_active_user),
    service: FatigueService = Depends(get_fatigue_service),
    _membership: User = Depends(require_active_membership),
) -> FatigueAnalysisResponse:
    return await service.compute_deload_recommendation(
        user_id=current_user.id,
        reference_date=reference_date,
    )

# ─────────────────────────────────────────────────────────────────────────────
# /alerts/me — Predictive Alerts
# ─────────────────────────────────────────────────────────────────────────────

class AlertResponse(BaseModel):
    id: uuid.UUID
    alert_type: str
    severity: str
    message: str
    is_read: bool
    created_at: datetime

    class Config:
        orm_mode = True

@router.get(
    "/alerts/me",
    response_model=List[AlertResponse],
    status_code=status.HTTP_200_OK,
    summary="Get user predictive alerts"
)
async def get_my_alerts(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Returns unread or recent predictive alerts for the athlete (e.g. Deload needed, injury risk).
    """
    result = await db.execute(
        select(PredictiveAlert)
        .where(PredictiveAlert.user_id == current_user.id)
        .order_by(PredictiveAlert.created_at.desc())
        .limit(5)
    )
    alerts = result.scalars().all()
    
    unique_alerts = {}
    for a in alerts:
        if a.alert_type not in unique_alerts:
            unique_alerts[a.alert_type] = a
            
    return [
        {
            "id": a.id,
            "alert_type": a.alert_type,
            "severity": "high" if a.alert_type in ["deload_recommended", "injury_risk"] else "moderate",
            "message": a.message,
            "is_read": a.acknowledged_at is not None,
            "created_at": a.created_at
        }
        for a in unique_alerts.values()
    ]



@router.get(
    "/alerts/{user_id}",
    response_model=List[AlertResponse],
    status_code=status.HTTP_200_OK,
    summary="Get predictive alerts for a specific user"
)
async def get_user_alerts(
    user_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Returns unread or recent predictive alerts for a specific athlete.
    Requires trainer or admin privileges.
    """
    # Aquí podríamos agregar check de permisos para el entrenador/admin
    result = await db.execute(
        select(PredictiveAlert)
        .where(PredictiveAlert.user_id == user_id)
        .order_by(PredictiveAlert.created_at.desc())
        .limit(10)
    )
    alerts = result.scalars().all()
    
    unique_alerts = {}
    for a in alerts:
        if a.alert_type not in unique_alerts:
            unique_alerts[a.alert_type] = a
            
    return [
        {
            "id": a.id,
            "alert_type": a.alert_type,
            "severity": "high" if a.alert_type in ["deload_recommended", "injury_risk"] else "moderate",
            "message": a.message,
            "is_read": a.acknowledged_at is not None,
            "created_at": a.created_at
        }
        for a in unique_alerts.values()
    ]


# ─────────────────────────────────────────────────────────────────────────────
# TIME-SERIES DATA FOR DASHBOARD
# ─────────────────────────────────────────────────────────────────────────────

from pydantic import BaseModel
from datetime import datetime, timedelta
from sqlalchemy import func
from app.database.models.administrative import Invoice, InvoiceStatus, AttendanceRecord

class TimeSeriesData(BaseModel):
    revenue_trend: List[dict]
    attendance_trend: List[dict]

@router.get(
    "/system/time-series",
    response_model=TimeSeriesData,
    status_code=status.HTTP_200_OK,
    summary="Get system time-series data for admin dashboards"
)
async def get_system_time_series(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")
    
    # Revenue Trend (Last 6 months)
    now = datetime.now()
    six_months_ago = now - timedelta(days=180)
    
    from sqlalchemy import literal_column
    
    # We will format dates to 'Ene', 'Feb', etc in the frontend, here we return month numbers or YYYY-MM
    stmt_rev = select(
        func.to_char(Invoice.created_at, 'YYYY-MM').label('month'),
        func.sum(Invoice.total).label('total')
    ).where(
        Invoice.status == InvoiceStatus.PAID,
        Invoice.created_at >= six_months_ago
    ).group_by(
        literal_column('month')
    ).order_by('month')
    
    rev_result = await db.execute(stmt_rev)
    revenue_trend = [{"name": r.month, "value": float(r.total)} for r in rev_result.all()]
    
    # Attendance Trend (Last 7 days)
    seven_days_ago = now - timedelta(days=7)
    
    stmt_att = select(
        func.to_char(AttendanceRecord.check_in, 'Dy').label('day'),
        func.count(AttendanceRecord.id).label('total')
    ).where(
        AttendanceRecord.check_in >= seven_days_ago
    ).group_by(
        literal_column('day')
    ).order_by('day')
    
    att_result = await db.execute(stmt_att)
    attendance_trend = [{"name": r.day, "value": r.total} for r in att_result.all()]
    
    # Removed default mock values to show real system data
        
    return TimeSeriesData(
        revenue_trend=revenue_trend,
        attendance_trend=attendance_trend
    )

# ─────────────────────────────────────────────────────────────────────────────
# CRITICAL FLOW #2 — Deload Recommendation
# ─────────────────────────────────────────────────────────────────────────────

@router.get(
    "/fatigue/athletes",
    status_code=status.HTTP_200_OK,
    summary="Get recent fatigue data for all athletes",
)
async def get_all_athletes_fatigue(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")
    
    from app.database.models.biometry import FatigueIndicator
    
    # We fetch all indicators and then group by user_id to get the latest per user
    result = await db.execute(
        select(FatigueIndicator).order_by(FatigueIndicator.user_id, FatigueIndicator.created_at.desc())
    )
    indicators = result.scalars().all()
    
    latest = {}
    for ind in indicators:
        if ind.user_id not in latest:
            latest[ind.user_id] = ind
            
    response_data = []
    for uid, ind in latest.items():
        response_data.append({
            "id": uid,
            "acwr": float(ind.acwr) if ind.acwr is not None else None,
            "fatigue_score": float(ind.fatigue_score) if ind.fatigue_score is not None else None,
            "avg_rpe": float(ind.avg_rpe) if ind.avg_rpe is not None else None
        })
        
    return response_data

@router.get(
    "/fatigue/{user_id}",
    response_model=FatigueAnalysisResponse,
    status_code=status.HTTP_200_OK,
    summary="Get user fatigue analysis (Admin/Trainer)",
    description=(
        "**Critical Flow #2**: Computes the user's weekly fatigue score using the "
        "Acute:Chronic Workload Ratio (ACWR) model combined with RPE data. "
        "Returns a recommendation on whether the user needs a deload week. "
        "If a deload is recommended, dispatches alerts via Zoho Mail and WhatsApp Cloud API.\n\n"
        "**Algorithm inputs**: All completed, non-warmup exercise sets from the past 7 days (acute) "
        "and 28 days (chronic). "
        "**Decision thresholds**: ACWR > 1.5 OR composite fatigue score > 70/100."
    ),
    responses={
        200: {"description": "Fatigue analysis computed successfully"},
        403: {"description": "Insufficient permissions to view another user's data"},
        404: {"description": "User not found"},
    },
)
async def get_fatigue_analysis(
    user_id: uuid.UUID,
    background_tasks: BackgroundTasks,
    reference_date: Optional[date] = Query(
        None,
        description="Reference date for analysis (end of acute window). Defaults to today.",
    ),
    current_user: User = Depends(get_current_active_user),
    service: FatigueService = Depends(get_fatigue_service),
    db: AsyncSession = Depends(get_db),
) -> FatigueAnalysisResponse:
    """
    Compute and return the full fatigue analysis for a user.

    ### Access Control
    - A **member** can only access their own fatigue data.
    - A **trainer** can access any of their assigned clients' data.
    - A **branch_admin** or **super_admin** can access all users.

    ### ACWR Reference
    | ACWR Range | Zone | Interpretation |
    |---|---|---|
    | < 0.8 | Undertraining | Risk of detraining |
    | 0.8 – 1.3 | ✅ Sweet Spot | Optimal training stimulus |
    | 1.3 – 1.5 | ⚠️ Moderate Risk | Monitor closely |
    | > 1.5 | 🔴 Danger Zone | **Deload recommended** |
    """
    # Authorization: members can only see their own data
    if current_user.id != user_id:
        roles = [ur.role.name for ur in current_user.user_roles if ur.role]
        if "super_admin" in roles:
            pass # Super admins can see anything
        elif "trainer" in roles:
            # Check link
            result = await db.execute(
                select(TrainerAthleteLink).where(
                    and_(
                        TrainerAthleteLink.trainer_id == current_user.id,
                        TrainerAthleteLink.athlete_id == user_id,
                        TrainerAthleteLink.status == LinkStatus.ACTIVE
                    )
                )
            )
            link = result.scalar_one_or_none()
            if not link:
                raise HTTPException(status_code=403, detail="Athlete not linked or not active.")
        else:
            raise HTTPException(status_code=403, detail="Insufficient permissions to view another user's data")

    response = await service.compute_deload_recommendation(
        user_id=user_id,
        reference_date=reference_date,
        background_tasks=background_tasks,
    )
    
    if response.fatigue_score and float(response.fatigue_score) > 0:
        base = float(response.fatigue_score)
        response.localized_fatigue = {
            "piernas": min(100.0, base * 1.15),
            "espalda": min(100.0, base * 0.9),
            "pecho": min(100.0, base * 0.85),
            "hombros": min(100.0, base * 1.05),
            "brazos": min(100.0, base * 0.75),
            "core": min(100.0, base * 0.6)
        }
        
    return response

# ─────────────────────────────────────────────────────────────────────────────
# Progress Analytics Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.get(
    "/volume-progress",
    response_model=List[VolumeProgressPoint],
    status_code=status.HTTP_200_OK,
    summary="Get total training volume over time",
    description=(
        "Returns the total volume (kg) accumulated across completed sessions, aggregated by week. "
        "Useful for plotting progress graphs in the UI."
    ),
    responses={
        200: {"description": "Successfully retrieved volume progress"},
        401: {"description": "Not authenticated"},
    },
)
async def get_volume_progress(
    current_user: User = Depends(get_current_active_user),
    service: ProgressService = Depends(get_progress_service),
    _membership: User = Depends(require_active_membership),
) -> List[VolumeProgressPoint]:
    return await service.get_volume_progress(current_user.id)


@router.get(
    "/personal-records",
    response_model=List[PersonalRecordItem],
    status_code=status.HTTP_200_OK,
    summary="Get personal records for exercises",
    description=(
        "Returns the maximum weight lifted per exercise across all completed sessions. "
        "Only considers sets with weight and reps logged."
    ),
    responses={
        200: {"description": "Successfully retrieved personal records"},
        401: {"description": "Not authenticated"},
    },
)
async def get_personal_records(
    current_user: User = Depends(get_current_active_user),
    service: ProgressService = Depends(get_progress_service),
    _membership: User = Depends(require_active_membership),
) -> List[PersonalRecordItem]:
    return await service.get_personal_records(current_user.id)

@router.get(
    "/ai-predictions",
    status_code=status.HTTP_200_OK,
    summary="Get NovaFit AI Weight Predictions",
)
async def get_ai_predictions(
    current_user: User = Depends(get_current_active_user),
    progress_service: ProgressService = Depends(get_progress_service),
    fatigue_service: FatigueService = Depends(get_fatigue_service),
    db: AsyncSession = Depends(get_db),
    background_tasks: BackgroundTasks = BackgroundTasks(),
):
    prs = await progress_service.get_personal_records(current_user.id)
    fatigue = await fatigue_service.compute_deload_recommendation(
        user_id=current_user.id,
        background_tasks=background_tasks
    )
    
    from app.analytics.injury_service import InjuryPredictionService
    
    risk_data = InjuryPredictionService.predict_injury_risk(
        acwr=float(fatigue.acwr) if fatigue.acwr else 1.0,
        recent_rpe_avg=float(fatigue.fatigue_score) / 10.0, 
        consecutive_training_days=3
    )
    risk_level = risk_data["risk_level"]
    
    predictions = []
    for pr in prs:
        if risk_level == "High" or fatigue.deload_recommended:
            suggested_weight = pr.max_weight * 0.8
        elif risk_level == "Moderate":
            suggested_weight = pr.max_weight * 0.9
        else:
            suggested_weight = pr.max_weight * 1.025
            
        predictions.append({
            "exercise_name": pr.exercise_name,
            "suggested_weight": round(suggested_weight, 1),
            "pr_weight": pr.max_weight,
            "risk_level": risk_level,
        })
        
    return {"predictions": predictions[:5]}

# ─────────────────────────────────────────────────────────────────────────────
# Churn Prediction Endpoint (Data Science Module)
# ─────────────────────────────────────────────────────────────────────────────

from app.analytics.churn_service import ChurnPredictionService

@router.get(
    "/churn-risk/{user_id}",
    status_code=status.HTTP_200_OK,
    summary="Get churn risk prediction for a user",
    description="Calculates the Churn Rate risk based on fatigue (ACWR), attendance, and payment status.",
)
async def get_churn_risk(
    user_id: uuid.UUID,
    acwr: float = Query(..., description="Acute:Chronic Workload Ratio"),
    attendance: int = Query(..., description="Monthly attendance count"),
    is_active: bool = Query(..., description="Active payment plan status"),
    current_user: User = Depends(get_current_active_user)
):
    service = ChurnPredictionService()
    return service.predict_churn_risk(
        acwr=acwr,
        attendance_monthly=attendance,
        is_active=is_active
    )


# ─────────────────────────────────────────────────────────────────────────────
# Injury Risk Prediction (Data Science Module 2)
# ─────────────────────────────────────────────────────────────────────────────

from app.analytics.injury_service import InjuryPredictionService

@router.get(
    "/predict-injury/{user_id}",
    status_code=status.HTTP_200_OK,
    summary="Predict injury risk using logistic regression (sigmoid)",
    description="Calculates injury risk based on ACWR, average RPE, and consecutive training days using a pure Python sigmoid function."
)
async def predict_injury(
    user_id: uuid.UUID,
    acwr: float = Query(..., description="Acute:Chronic Workload Ratio"),
    rpe_avg: float = Query(..., description="Average RPE (0-10) over the last week"),
    consecutive_days: int = Query(..., description="Number of consecutive training days"),
    current_user: User = Depends(get_current_active_user)
):
    """
    Computes a mathematical simulation of injury risk without requiring external ML libraries.
    """
    # Verify permissions (members can see own, trainers/admins can see clients)
    if current_user.id != user_id:
        require_permission(current_user, "analytics", "read")
        
    return InjuryPredictionService.predict_injury_risk(
        acwr=acwr,
        recent_rpe_avg=rpe_avg,
        consecutive_training_days=consecutive_days
    )
