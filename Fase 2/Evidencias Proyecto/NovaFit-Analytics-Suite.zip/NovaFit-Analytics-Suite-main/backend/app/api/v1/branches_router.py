from typing import List, Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import get_current_active_user, require_permission
from app.database.session import get_db
from app.database.models.core import Branch, User
from pydantic import BaseModel, Field

router = APIRouter(prefix="/branches", tags=["Branches"])

class BranchCreate(BaseModel):
    name: str = Field(..., min_length=1, max_length=120)
    code: str = Field(..., min_length=2, max_length=10)
    address: Optional[str] = None
    city: Optional[str] = None
    country_code: str = "ARG"
    phone: Optional[str] = None
    email: Optional[str] = None
    timezone: str = "America/Argentina/Buenos_Aires"

class BranchUpdate(BaseModel):
    name: Optional[str] = None
    code: Optional[str] = None
    address: Optional[str] = None
    city: Optional[str] = None
    country_code: Optional[str] = None
    phone: Optional[str] = None
    email: Optional[str] = None
    timezone: Optional[str] = None
    is_active: Optional[bool] = None

class BranchResponse(BaseModel):
    id: uuid.UUID
    name: str
    code: str
    address: Optional[str] = None
    city: Optional[str] = None
    country_code: str
    phone: Optional[str] = None
    email: Optional[str] = None
    timezone: str
    is_active: bool

    model_config = {"from_attributes": True}

@router.get("", response_model=List[BranchResponse])
async def get_branches(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read") # Using users:read as proxy for branch read
    result = await db.execute(select(Branch))
    return result.scalars().all()

@router.post("", response_model=BranchResponse, status_code=status.HTTP_201_CREATED)
async def create_branch(
    branch_in: BranchCreate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "write")
    
    # Check if code exists
    res = await db.execute(select(Branch).where(Branch.code == branch_in.code))
    if res.scalars().first():
        raise HTTPException(status_code=400, detail="Branch code already exists")
        
    branch = Branch(**branch_in.model_dump())
    db.add(branch)
    await db.commit()
    await db.refresh(branch)
    return branch

@router.put("/{branch_id}", response_model=BranchResponse)
async def update_branch(
    branch_id: uuid.UUID,
    branch_in: BranchUpdate,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "write")
    
    res = await db.execute(select(Branch).where(Branch.id == branch_id))
    branch = res.scalars().first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
        
    update_data = branch_in.model_dump(exclude_unset=True)
    for field, value in update_data.items():
        setattr(branch, field, value)
        
    await db.commit()
    await db.refresh(branch)
    return branch

@router.delete("/{branch_id}", status_code=status.HTTP_204_NO_CONTENT)
async def delete_branch(
    branch_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "write")
    
    res = await db.execute(select(Branch).where(Branch.id == branch_id))
    branch = res.scalars().first()
    if not branch:
        raise HTTPException(status_code=404, detail="Branch not found")
        
    await db.delete(branch)
    await db.commit()
    return None
