from typing import List, Optional
import uuid
from fastapi import APIRouter, Depends, HTTPException, status
from pydantic import BaseModel, Field
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.database.session import get_db
from app.database.models.core import TrainerAthleteLink, User, LinkStatus
from app.core.security import get_current_active_user
from app.core.dependencies import get_routine_service
from app.training.schemas import RoutineSessionResponse, InstantiateSessionRequest
from app.training.service import RoutineService
from datetime import date

def check_trainer_role(user: User):
    roles = [ur.role.name for ur in user.user_roles if ur.role]
    if "trainer" not in roles and "super_admin" not in roles:
        raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="No tienes los privilegios necesarios para acceder al panel de entrenador.")
router = APIRouter(prefix="/trainer", tags=["Trainer & Athlete Linking"])


# ─────────────────────────────────────────────────────────────────────────────
# Schemas
# ─────────────────────────────────────────────────────────────────────────────

class InviteAthleteRequest(BaseModel):
    athlete_email: str = Field(..., description="Email del atleta a invitar")

class InviteAthleteResponse(BaseModel):
    message: str
    link_id: uuid.UUID

class AthleteDashboardSchema(BaseModel):
    """
    Strict response model for the trainer dashboard.
    Ensures sensitive data (passwords, tokens, etc.) are never exposed.
    """
    id: uuid.UUID
    first_name: str
    last_name: str
    acwr: Optional[float] = None 
    fatigue_score: Optional[float] = None
    status: str

    class Config:
        from_attributes = True


class TrainerDashboardResponse(BaseModel):
    active_athletes: List[AthleteDashboardSchema]
    pending_athletes: List[AthleteDashboardSchema]


class PendingInvitationSchema(BaseModel):
    link_id: uuid.UUID
    trainer_id: uuid.UUID
    trainer_first_name: str
    trainer_last_name: str
    trainer_email: str
    status: str

from pydantic import BaseModel, Field, field_validator

class AssignTemplateRequest(BaseModel):
    athlete_id: uuid.UUID
    template_id: int
    scheduled_date: Optional[date] = None

    @field_validator("scheduled_date", mode="before")
    @classmethod
    def parse_empty_date(cls, v):
        if v == "" or v == "null":
            return None
        return v


# ─────────────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/invite-athlete", response_model=InviteAthleteResponse)
async def invite_athlete(
    request: InviteAthleteRequest,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Invita a un atleta. Solo accesible para roles de tipo trainer."""
    check_trainer_role(current_user)
    
    result = await db.execute(select(User).where(User.email == request.athlete_email))
    athlete = result.scalar_one_or_none()
    
    if not athlete:
        raise HTTPException(status_code=404, detail="Athlete not found")
        
    link_result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.trainer_id == current_user.id,
                TrainerAthleteLink.athlete_id == athlete.id
            )
        )
    )
    existing_link = link_result.scalar_one_or_none()
    
    if existing_link:
        raise HTTPException(status_code=400, detail="Link already exists (active or pending)")
        
    new_link = TrainerAthleteLink(
        trainer_id=current_user.id,
        athlete_id=athlete.id,
        status=LinkStatus.PENDING
    )
    db.add(new_link)
    await db.commit()
    await db.refresh(new_link)
    
    # Send Push Notification
    from app.notifications.push_service import send_expo_push_notification
    import asyncio
    
    asyncio.create_task(
        send_expo_push_notification(
            device_token=athlete.device_token,
            title="¡Nueva Invitación!",
            body=f"{current_user.first_name} {current_user.last_name} te ha invitado a ser tu entrenador.",
            data={"type": "trainer_invite", "link_id": str(new_link.id)}
        )
    )
    
    return InviteAthleteResponse(message="Invitation sent", link_id=new_link.id)


@router.delete("/remove-athlete/{athlete_id}")
async def remove_athlete(
    athlete_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Desvincula a un atleta de su entrenador."""
    check_trainer_role(current_user)
    
    result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.trainer_id == current_user.id,
                TrainerAthleteLink.athlete_id == athlete_id
            )
        )
    )
    link = result.scalar_one_or_none()
    
    if not link:
        raise HTTPException(status_code=404, detail="Link not found")
        
    await db.delete(link)
    await db.commit()
    return {"message": "Athlete removed successfully"}


@router.get("/dashboard", response_model=TrainerDashboardResponse)
async def trainer_dashboard(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Retorna los atletas vinculados.
    Evita exponer información privada usando AthleteDashboardSchema.
    """
    check_trainer_role(current_user)
    
    result = await db.execute(
        select(TrainerAthleteLink, User)
        .join(User, User.id == TrainerAthleteLink.athlete_id)
        .where(TrainerAthleteLink.trainer_id == current_user.id)
    )
    
    rows = result.all()
    
    active_athletes = []
    pending_athletes = []
    
    # Extract athlete IDs
    athlete_ids = [user.id for link, user in rows if link.status == LinkStatus.ACTIVE]
    
    latest_indicators = {}
    if athlete_ids:
        from app.database.models.biometry import FatigueIndicator
        from sqlalchemy import desc
        
        # In PostgreSQL we can use distinct(user_id) with order_by
        fi_stmt = (
            select(FatigueIndicator)
            .where(FatigueIndicator.user_id.in_(athlete_ids))
            .order_by(FatigueIndicator.user_id, desc(FatigueIndicator.created_at))
            .distinct(FatigueIndicator.user_id)
        )
        fi_result = await db.execute(fi_stmt)
        for fi in fi_result.scalars():
            latest_indicators[fi.user_id] = fi
    
    for link, user in rows:
        fi = latest_indicators.get(user.id)
        dto = AthleteDashboardSchema(
            id=user.id,
            first_name=user.first_name,
            last_name=user.last_name,
            acwr=float(fi.acwr) if fi and fi.acwr is not None else None,
            fatigue_score=float(fi.fatigue_score) if fi and fi.fatigue_score is not None else None,
            status=link.status.value
        )
        if link.status == LinkStatus.ACTIVE:
            active_athletes.append(dto)
        else:
            pending_athletes.append(dto)
            
    return TrainerDashboardResponse(
        active_athletes=active_athletes,
        pending_athletes=pending_athletes
    )


@router.post("/assign-template", response_model=RoutineSessionResponse)
async def assign_template(
    payload: AssignTemplateRequest,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    routine_service = Depends(get_routine_service)
):
    """Asigna (instancia) una plantilla a un atleta vinculado."""
    try:
        check_trainer_role(current_user)
        
        result = await db.execute(
            select(TrainerAthleteLink).where(
                and_(
                    TrainerAthleteLink.trainer_id == current_user.id,
                    TrainerAthleteLink.athlete_id == payload.athlete_id,
                    TrainerAthleteLink.status == LinkStatus.ACTIVE
                )
            )
        )
        link = result.scalar_one_or_none()
        if not link:
            raise HTTPException(status_code=403, detail="Athlete not linked or not active.")
            
        final_date = payload.scheduled_date
        if not final_date:
            from datetime import date
            final_date = date.today()
            
        instantiate_payload = InstantiateSessionRequest(
            scheduled_date=final_date,
            microcycle_id=None
        )
        
        return await routine_service.instantiate_session_from_template(
            user_id=payload.athlete_id,
            template_id=payload.template_id,
            payload=instantiate_payload
        )
    except HTTPException:
        raise
    except Exception as e:
        import logging
        logging.error(f"Error in assign_template: {str(e)}")
        raise HTTPException(status_code=500, detail=str(e))


# --- Athlete Endpoints for Invitations ---

@router.get("/invitations/pending", response_model=List[PendingInvitationSchema])
async def get_pending_invitations(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Lista las invitaciones pendientes recibidas por el atleta autenticado.
    """
    result = await db.execute(
        select(TrainerAthleteLink, User)
        .join(User, User.id == TrainerAthleteLink.trainer_id)
        .where(
            and_(
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.status == LinkStatus.PENDING
            )
        )
    )
    rows = result.all()
    
    invitations = []
    for link, trainer in rows:
        invitations.append(
            PendingInvitationSchema(
                link_id=link.id,
                trainer_id=trainer.id,
                trainer_first_name=trainer.first_name,
                trainer_last_name=trainer.last_name,
                trainer_email=trainer.email,
                status=link.status.value
            )
        )
    return invitations


@router.post("/invitations/{link_id}/accept")
async def accept_invitation(
    link_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Permite a un atleta aceptar una invitación de un entrenador.
    """
    result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.id == link_id,
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.status == LinkStatus.PENDING
            )
        )
    )
    link = result.scalar_one_or_none()
    if not link:
        raise HTTPException(status_code=404, detail="Invitation not found or not pending")
        
    link.status = LinkStatus.ACTIVE
    await db.commit()
    return {"message": "Invitation accepted successfully"}


@router.post("/invitations/{link_id}/reject")
async def reject_invitation(
    link_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Permite a un atleta rechazar (eliminar) una invitación de un entrenador.
    """
    result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.id == link_id,
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.status == LinkStatus.PENDING
            )
        )
    )
    link = result.scalar_one_or_none()
    if not link:
        raise HTTPException(status_code=404, detail="Invitation not found or not pending")
        
    await db.delete(link)
    await db.commit()
    return {"message": "Invitation rejected successfully"}

from app.training.schemas import RoutineSessionSummary

@router.get(
    "/athletes/{athlete_id}/sessions",
    response_model=List[RoutineSessionSummary],
    status_code=status.HTTP_200_OK,
    summary="Obtener historial y sesiones pendientes del atleta",
)
async def get_athlete_sessions(
    athlete_id: uuid.UUID,
    db: AsyncSession = Depends(get_db),
    current_trainer: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
):
    """
    Returns all sessions (completed and pending) for a given athlete,
    provided the trainer has an ACTIVE link with them.
    """
    check_trainer_role(current_trainer)

    stmt = select(TrainerAthleteLink).where(
        and_(
            TrainerAthleteLink.trainer_id == current_trainer.id,
            TrainerAthleteLink.athlete_id == athlete_id,
            TrainerAthleteLink.status == LinkStatus.ACTIVE,
        )
    )
    result = await db.execute(stmt)
    link = result.scalars().first()
    if not link:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="No tienes un vínculo activo con este atleta.",
        )

    return await service.list_sessions(user_id=athlete_id)
