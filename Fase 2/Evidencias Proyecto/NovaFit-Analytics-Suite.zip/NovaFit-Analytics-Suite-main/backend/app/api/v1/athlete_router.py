import uuid
from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, and_

from app.database.session import get_db
from app.database.models.core import TrainerAthleteLink, User, LinkStatus
from app.database.models.biometry import WeightHistory
from app.database.models.administrative import AttendanceRecord, CheckInMethod, Membership
from app.core.security import get_current_active_user, require_permission
from datetime import datetime
from typing import Optional, List

router = APIRouter(prefix="/athlete", tags=["Athlete & Trainer Linking"])

class AcceptTrainerResponse(BaseModel):
    message: str

class TrainerInvitationSchema(BaseModel):
    trainer_id: uuid.UUID
    first_name: str
    last_name: str
    email: str

class WeightHistorySchema(BaseModel):
    id: int
    weight_kg: float
    measured_at: datetime
    notes: Optional[str] = None
    
    class Config:
        orm_mode = True

class WeightLogCreate(BaseModel):
    weight_kg: float
    notes: Optional[str] = None

class AttendanceResponse(BaseModel):
    id: uuid.UUID
    branch_id: uuid.UUID
    check_in: datetime
    check_out: Optional[datetime]
    method: str
    
    class Config:
        orm_mode = True

@router.get("/invitations", response_model=list[TrainerInvitationSchema])
async def get_invitations(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Obtiene las invitaciones pendientes de entrenadores."""

    
    result = await db.execute(
        select(TrainerAthleteLink, User)
        .join(User, User.id == TrainerAthleteLink.trainer_id)
        .where(
            and_(
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.status == LinkStatus.PENDING
            )
        )
    )
    
    invitations = []
    for link, trainer in result.all():
        invitations.append({
            "trainer_id": trainer.id,
            "first_name": trainer.first_name,
            "last_name": trainer.last_name,
            "email": trainer.email
        })
        
    return invitations

@router.post("/accept-trainer/{trainer_id}", response_model=AcceptTrainerResponse)
async def accept_trainer(
    trainer_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Acepta una solicitud pendiente de un entrenador."""

    
    result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.trainer_id == trainer_id,
                TrainerAthleteLink.status == LinkStatus.PENDING
            )
        )
    )
    link = result.scalar_one_or_none()
    
    if not link:
        raise HTTPException(status_code=404, detail="Pending link not found")
        
    link.status = LinkStatus.ACTIVE
    await db.commit()
    return {"message": "Trainer accepted successfully"}


@router.delete("/remove-trainer/{trainer_id}")
async def remove_trainer(
    trainer_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Desvincula a un entrenador (revocación de acceso)."""

    
    result = await db.execute(
        select(TrainerAthleteLink).where(
            and_(
                TrainerAthleteLink.athlete_id == current_user.id,
                TrainerAthleteLink.trainer_id == trainer_id
            )
        )
    )
    link = result.scalar_one_or_none()
    
    if not link:
        raise HTTPException(status_code=404, detail="Link not found")
        
    await db.delete(link)
    await db.commit()
    return {"message": "Trainer removed successfully"}


# ─────────────────────────────────────────────────────────────────────────────
# Weight History
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/weight-history/me", response_model=List[WeightHistorySchema])
async def get_my_weight_history(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Obtiene el historial de peso del atleta logueado, ordenado cronológicamente."""
    result = await db.execute(
        select(WeightHistory)
        .where(WeightHistory.user_id == current_user.id)
        .order_by(WeightHistory.measured_at.asc())
    )
    items = result.scalars().all()
    if not items:
        # Mock data for demonstration when no real data is available
        from datetime import timedelta, datetime
        base_weight = 75.0
        now = datetime.utcnow()
        mock_items = []
        for i in range(8):
            mock_items.append({
                "id": i + 1,
                "weight_kg": round(base_weight + (i * 0.5) - 1.0, 1),
                "measured_at": now - timedelta(days=(7-i)*7),
                "notes": "Mock data"
            })
        return mock_items
    return items

@router.get("/weight-history/{user_id}", response_model=List[WeightHistorySchema])
async def get_user_weight_history(
    user_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Obtiene el historial de peso de un atleta (requiere admin/trainer)."""
    result = await db.execute(
        select(WeightHistory)
        .where(WeightHistory.user_id == user_id)
        .order_by(WeightHistory.measured_at.asc())
    )
    items = result.scalars().all()
    if not items:
        # Mock data for demonstration when no real data is available
        from datetime import timedelta, datetime
        base_weight = 75.0
        now = datetime.utcnow()
        mock_items = []
        for i in range(8):
            mock_items.append({
                "id": i + 1,
                "weight_kg": round(base_weight + (i * 0.5) - 1.0, 1),
                "measured_at": now - timedelta(days=(7-i)*7),
                "notes": "Mock data"
            })
        return mock_items
    return items

@router.post("/weight-history", response_model=WeightHistorySchema)
async def log_weight(
    data: WeightLogCreate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """Registra un nuevo peso en el historial del atleta."""
    new_weight = WeightHistory(
        user_id=current_user.id,
        weight_kg=data.weight_kg,
        notes=data.notes,
        measured_at=datetime.utcnow()
    )
    db.add(new_weight)
    
    # Actualizar también el current_weight en el usuario si existe
    # current_user.current_weight = data.weight_kg
    
    await db.commit()
    await db.refresh(new_weight)
    return new_weight

# ─────────────────────────────────────────────────────────────────────────────
# Attendance (Check-In)
# ─────────────────────────────────────────────────────────────────────────────

@router.post("/attendance/check-in", response_model=AttendanceResponse)
async def check_in_gym(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    """
    Registra un check-in del atleta.
    Para MVP, asume la sucursal de su membresía activa.
    """
    # 1. Buscar membresía activa para obtener la sucursal
    result = await db.execute(
        select(Membership)
        .where(
            and_(
                Membership.user_id == current_user.id,
                Membership.status == "active"
            )
        )
    )
    membership = result.scalar_one_or_none()
    if not membership:
        raise HTTPException(status_code=403, detail="No active membership found to check-in.")
        
    # 2. Registrar el check-in
    attendance = AttendanceRecord(
        user_id=current_user.id,
        branch_id=membership.branch_id,
        check_in=datetime.utcnow(),
        method=CheckInMethod.MANUAL
    )
    db.add(attendance)
    await db.commit()
    await db.refresh(attendance)
    
    return attendance

