"""
NovaFit Analytics Suite
========================
Training Controller (FastAPI Router)

Handles HTTP concerns ONLY:
  - Route definitions
  - Auth token validation (via dependency)
  - Request deserialization
  - Response serialization
  - HTTP status codes

NO business logic lives here. All domain logic is in RoutineService.
"""

import uuid
from datetime import date
from typing import List, Optional

from fastapi import APIRouter, Depends, HTTPException, status, Query
from pydantic import BaseModel, Field

from app.core.dependencies import get_routine_service, require_active_membership
from app.core.security import get_current_active_user
from app.database.models.core import User
from app.training.schemas import (
    RoutineSessionCreate,
    RoutineSessionResponse,
    RoutineSessionSummary,
    RoutineTemplateCreate,
    RoutineTemplateResponse,
    InstantiateSessionRequest,
    ExerciseCatalogResponse,
)
from app.training.service import RoutineService

router = APIRouter(prefix="/training", tags=["Training"])


# ─────────────────────────────────────────────────────────────────────────────
# CRITICAL FLOW #1 — Register Hypertrophy Session
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/sessions",
    response_model=RoutineSessionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a training session",
    description=(
        "**Critical Flow #1**: Log a complete training session with all exercises and sets. "
        "Validates exercise IDs, enforces failure-set limits, and optionally links to a microcycle. "
        "Triggers a WhatsApp completion notification after successful persistence."
    ),
    responses={
        201: {"description": "Session created successfully"},
        400: {"description": "Business rule violation (e.g. too many failure sets)"},
        404: {"description": "Referenced exercise_id not found in catalog"},
        422: {"description": "Schema validation error"},
    },
)
async def create_training_session(
    payload: RoutineSessionCreate,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> RoutineSessionResponse:
    """
    Register a complete hypertrophy (or any goal) training session.

    ### Request Body
    Include all exercises in order, with each set's weight, reps, and RPE.
    The `rpe` field (1.0-10.0 Borg scale) is the primary input for
    the deload prediction algorithm.

    ### Auth
    Requires a valid JWT Bearer token. The session is automatically
    associated with the authenticated user.
    """
    return await service.create_hypertrophy_session(
        user_id=current_user.id,
        payload=payload,
    )


@router.get(
    "/sessions",
    response_model=List[RoutineSessionSummary],
    status_code=status.HTTP_200_OK,
    summary="List user sessions",
    description=(
        "Retrieves a paginated list of summarized training sessions for the authenticated user. "
        "Can be filtered by an optional start and end date."
    ),
    responses={
        200: {"description": "Successfully retrieved session summaries"},
        401: {"description": "Not authenticated"},
    },
)
async def list_user_sessions(
    start_date: Optional[date] = Query(None, description="Filter from date (inclusive)"),
    end_date: Optional[date] = Query(None, description="Filter to date (inclusive)"),
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> List[RoutineSessionSummary]:
    return await service.list_sessions(
        user_id=current_user.id,
        start_date=start_date,
        end_date=end_date,
    )


@router.get(
    "/sessions/{session_id}",
    response_model=RoutineSessionResponse,
    status_code=status.HTTP_200_OK,
    summary="Get session detail",
    description="Retrieves the full details of a specific training session, including all logged exercises and sets.",
    responses={
        200: {"description": "Successfully retrieved the session"},
        401: {"description": "Not authenticated"},
        404: {"description": "Session not found or does not belong to the user"},
    },
)
async def get_session_detail(
    session_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> RoutineSessionResponse:
    return await service.get_session(
        user_id=current_user.id,
        session_id=session_id,
    )


@router.get(
    "/exercises",
    response_model=List[ExerciseCatalogResponse],
    status_code=status.HTTP_200_OK,
    summary="List all exercises",
)
async def list_exercises(
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
) -> List[ExerciseCatalogResponse]:
    return await service.list_exercises()

class SessionCompleteSet(BaseModel):
    id: int = Field(..., description="The ID of the ExerciseSet")
    reps: Optional[int] = None
    weight: Optional[float] = None
    rpe: Optional[float] = None

from typing import Dict, Any

class SessionCompleteRequest(BaseModel):
    rpe: Optional[int] = None
    updated_sets: Optional[List[Dict[str, Any]]] = None

@router.patch(
    "/sessions/{session_id}/complete",
    response_model=RoutineSessionResponse,
    status_code=status.HTTP_200_OK,
    summary="Marcar sesión pendiente como completada",
)
async def complete_session(
    session_id: uuid.UUID,
    payload: SessionCompleteRequest,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> RoutineSessionResponse:
    """
    Mark a pending session as completed.
    Optionally provide an RPE value to track fatigue.
    """
    from decimal import Decimal
    rpe_dec = Decimal(str(payload.rpe)) if payload.rpe is not None else None
    
    return await service.complete_session(
        user_id=current_user.id,
        session_id=session_id,
        rpe=rpe_dec,
        updated_sets=payload.updated_sets,
    )

@router.delete(
    "/sessions/{session_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a routine session",
    description="Deletes a routine session if the user has permission to do so. Trainer-assigned sessions cannot be deleted by athletes.",
    responses={
        204: {"description": "Session successfully deleted"},
        403: {"description": "Not authorized to delete this session"},
        404: {"description": "Session not found"},
    },
)
async def delete_session(
    session_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
) -> None:
    await service.delete_session(user_id=current_user.id, session_id=session_id, user_roles=current_user.user_roles)

# ─────────────────────────────────────────────────────────────────────────────
# CRITICAL FLOW #2 — Routine Templates
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/templates",
    response_model=RoutineTemplateResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create a routine template",
    description=(
        "Creates a new training template pre-populated with exercises and target rep ranges. "
        "The user must be associated with a valid branch to create a template."
    ),
    responses={
        201: {"description": "Template created successfully"},
        400: {"description": "User is not associated with a branch"},
        422: {"description": "Schema validation error"},
    },
)
async def create_template(
    payload: RoutineTemplateCreate,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
) -> RoutineTemplateResponse:
    # Explicitly check if user is trainer or super_admin
    has_permission = False
    for ur in current_user.user_roles:
        if ur.role and ur.role.name in ("super_admin", "trainer"):
            has_permission = True
            break
            
    if not has_permission:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only trainers and administrators can create templates."
        )
        
    if not current_user.branch_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="You must belong to a branch to create a template."
        )
    return await service.create_template(
        branch_id=current_user.branch_id,
        created_by=current_user.id,
        payload=payload,
    )


@router.get(
    "/templates",
    response_model=List[RoutineTemplateResponse],
    status_code=status.HTTP_200_OK,
    summary="List routine templates",
    description="Returns all available training templates for the authenticated user's branch.",
    responses={
        200: {"description": "Successfully retrieved templates"},
        401: {"description": "Not authenticated"},
    },
)
async def list_templates(
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> List[RoutineTemplateResponse]:
    if not current_user.branch_id:
        return []
    return await service.list_templates(
        branch_id=current_user.branch_id,
    )


@router.get(
    "/templates/{template_id}",
    response_model=RoutineTemplateResponse,
    status_code=status.HTTP_200_OK,
    summary="Get routine template detail",
    description="Retrieves the full details of a specific training template.",
    responses={
        200: {"description": "Successfully retrieved the template"},
        404: {"description": "Template not found or inaccessible"},
    },
)
async def get_template_detail(
    template_id: int,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
) -> RoutineTemplateResponse:
    return await service.get_template(template_id=template_id)


@router.put(
    "/templates/{template_id}",
    response_model=RoutineTemplateResponse,
    status_code=status.HTTP_200_OK,
    summary="Update a routine template",
    responses={
        403: {"description": "Not authorized to update templates"},
        404: {"description": "Template not found"},
    },
)
async def update_template(
    template_id: int,
    payload: RoutineTemplateCreate,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
) -> RoutineTemplateResponse:
    has_permission = False
    for ur in current_user.user_roles:
        if ur.role and ur.role.name in ("super_admin", "trainer"):
            has_permission = True
            break
            
    if not has_permission:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Only trainers and admins can edit templates"
        )
        
    return await service.update_template(template_id, payload)


@router.post(
    "/templates/{template_id}/instantiate",
    response_model=RoutineSessionResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Instantiate a session from a template",
    description=(
        "Creates a new training session pre-filled with the template's prescribed exercises, "
        "target sets, and target rep ranges."
    ),
    responses={
        201: {"description": "Session successfully instantiated"},
        404: {"description": "Template not found"},
        422: {"description": "Schema validation error"},
    },
)
async def instantiate_session(
    template_id: int,
    payload: InstantiateSessionRequest,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
    _membership: User = Depends(require_active_membership),
) -> RoutineSessionResponse:
    return await service.instantiate_session_from_template(
        user_id=current_user.id,
        template_id=template_id,
        payload=payload,
    )


@router.delete(
    "/templates/{template_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a routine template",
)
async def delete_template(
    template_id: int,
    current_user: User = Depends(get_current_active_user),
    service: RoutineService = Depends(get_routine_service),
):
    try:
        await service.delete_template(template_id)
    except Exception as e:
        from fastapi import HTTPException
        raise HTTPException(status_code=400, detail=f"No se pudo eliminar la plantilla: {str(e)}")
