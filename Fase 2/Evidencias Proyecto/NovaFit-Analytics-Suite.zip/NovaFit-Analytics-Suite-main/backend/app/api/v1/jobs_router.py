"""
NovaFit Analytics Suite — Backend
===================================
Jobs Router — External Cron Automations

Handles automated background jobs triggered by external cron services 
(like Upstash QStash, Render Cron, or GitHub Actions).
"""

import asyncio
import logging
from typing import Dict, Any

from fastapi import APIRouter, Depends, Header, HTTPException, status, BackgroundTasks
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from datetime import date

from app.core.config import settings
from app.database.session import get_db
from app.database.models.administrative import Membership, MembershipStatus
from app.database.models.core import User

router = APIRouter(prefix="/jobs", tags=["Jobs"])
logger = logging.getLogger(__name__)

async def send_whatsapp_reminder(phone: str, name: str, amount: float, link: str):
    """
    Simulated mock for sending a WhatsApp reminder via Meta Cloud API.
    In a real scenario, this would use a proper httpx client to hit Graph API.
    """
    logger.info(f"Preparing to send WhatsApp to {phone} for {name}...")
    await asyncio.sleep(1) # Simulate network delay
    logger.info(f"WhatsApp sent successfully to {phone}: 'Hola {name}, tu mensualidad de ${amount} ha vencido. Paga aquí: {link}'")


@router.post(
    "/billing-reminders",
    status_code=status.HTTP_200_OK,
    summary="Trigger billing reminders for expired memberships",
    description="Finds expired memberships and sends a WhatsApp reminder asynchronously."
)
async def trigger_billing_reminders(
    background_tasks: BackgroundTasks,
    x_cron_api_key: str = Header(..., description="API Key for Cron Jobs"),
    db: AsyncSession = Depends(get_db),
) -> Dict[str, Any]:
    
    # 1. Verify static API Key
    # In a real environment, this should be in settings.CRON_API_KEY
    expected_key = getattr(settings, "CRON_API_KEY", "novafit-secret-cron-key")
    if x_cron_api_key != expected_key:
        logger.warning("Unauthorized attempt to trigger billing reminders")
        raise HTTPException(status_code=401, detail="Invalid Cron API Key")

    # 2. Find expired memberships
    today = date.today()
    stmt = (
        select(Membership, User)
        .join(User, User.id == Membership.user_id)
        .where(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date < today
        )
    )
    result = await db.execute(stmt)
    records = result.all()

    reminders_queued = 0

    # 3. Queue background tasks
    for membership, user in records:
        if user.phone:
            # We mock the amount and link for demonstration.
            # In a full system, we would query the pending invoice for this membership.
            amount = 30000.0 
            link = f"{settings.FRONTEND_URL}/billing/payment/{membership.id}"
            
            background_tasks.add_task(
                send_whatsapp_reminder,
                phone=user.phone,
                name=user.first_name or "Socio",
                amount=amount,
                link=link
            )
            reminders_queued += 1

        # Optionally, mark the membership as EXPIRED in DB
        membership.status = MembershipStatus.EXPIRED
        db.add(membership)

    if records:
        await db.commit()

    logger.info(f"Billing reminders cron executed. {reminders_queued} WhatsApp messages queued.")
    
    return {
        "status": "success",
        "reminders_queued": reminders_queued,
        "memberships_expired": len(records)
    }
