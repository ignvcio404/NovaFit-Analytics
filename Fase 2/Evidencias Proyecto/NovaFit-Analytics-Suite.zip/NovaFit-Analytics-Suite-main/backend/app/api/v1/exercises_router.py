"""
NovaFit Analytics Suite
========================
Exercises Router (ExerciseDB + Wger Integration)
========================

Provides endpoints to search and retrieve exercise details
using the public Wger API and ExerciseDB API via RapidAPI.
"""

from typing import List, Dict, Any
from fastapi import APIRouter, Depends, Query, status, HTTPException

from app.core.security import get_current_active_user
from app.database.models.core import User
from app.integrations.wger.wger_client import WgerService, WgerExercise
from app.integrations.exercisedb.exercisedb_client import ExerciseDBClient, ExerciseDBExercise

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.database.session import get_db
from app.database.models.training import ExerciseCatalog, ExerciseCategory
from app.training.schemas import ExerciseCatalogResponse, ExerciseImportRequest

router = APIRouter(prefix="/exercises", tags=["Exercises"])

def get_wger_client() -> WgerService:
    return WgerService()

def get_exercisedb_client() -> ExerciseDBClient:
    return ExerciseDBClient()

@router.get(
    "/search",
    response_model=List[WgerExercise],
    status_code=status.HTTP_200_OK,
    summary="Search exercises in Wger",
    description="Searches the Wger open-source database for exercises matching a query.",
)
async def search_exercises(
    query: str = Query(..., min_length=2, description="Search term for the exercise"),
    language_id: int = Query(2, description="Language ID (2=Spanish)"),
    limit: int = Query(20, description="Max results"),
    current_user: User = Depends(get_current_active_user),
    wger_client: WgerService = Depends(get_wger_client),
    db: AsyncSession = Depends(get_db),
) -> List[WgerExercise]:
    wger_results = await wger_client.search_exercises(query, language_id=language_id, limit=limit)
    if not wger_results:
        # Fallback a la base de datos local
        stmt = select(ExerciseCatalog).where(ExerciseCatalog.name.ilike(f"%{query}%")).limit(limit)
        result = await db.execute(stmt)
        local_exercises = result.scalars().all()
        
        # Mapeamos a WgerExercise para mantener el contrato del endpoint
        wger_results = []
        for ex in local_exercises:
            wger_results.append(WgerExercise(
                wger_id=ex.wger_exercise_id or ex.id,
                name=ex.name,
                description_html=ex.description or "",
                category_id=1,  # Default para evitar errores si no hay categoría mapped exacta
                category_name=ex.category.name if ex.category else "Custom",
                language_code="es",
                primary_muscles=[],
                secondary_muscles=[],
            ))
    return wger_results


@router.get(
    "/external/search",
    response_model=List[ExerciseDBExercise],
    status_code=status.HTTP_200_OK,
    summary="Search exercises in ExerciseDB",
    description="Searches the ExerciseDB API via RapidAPI.",
)
async def search_external_exercises(
    query: str = Query(..., min_length=2, description="Search term for the exercise"),
    limit: int = Query(20, description="Max results"),
    current_user: User = Depends(get_current_active_user),
    exercisedb_client: ExerciseDBClient = Depends(get_exercisedb_client),
) -> List[ExerciseDBExercise]:
    results = await exercisedb_client.search_exercises(query, limit=limit)
    return results

@router.post(
    "/import",
    response_model=ExerciseCatalogResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Import exercise from external API",
    description="Saves an external exercise into the local database.",
)
async def import_exercise(
    payload: ExerciseImportRequest,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
) -> ExerciseCatalog:
    
    new_exercise = ExerciseCatalog(
        name=payload.name,
        category=ExerciseCategory.ISOLATION,
        video_url=payload.gif_url,
        is_custom=False
    )
    db.add(new_exercise)
    await db.commit()
    await db.refresh(new_exercise)
    
    return new_exercise

@router.get(
    "/{wger_id}",
    response_model=WgerExercise,
    status_code=status.HTTP_200_OK,
    summary="Get exercise details from Wger",
    description="Retrieves the full details (muscles, equipment, translations) of a specific exercise.",
)
async def get_exercise_detail(
    wger_id: int,
    current_user: User = Depends(get_current_active_user),
    wger_client: WgerService = Depends(get_wger_client),
) -> WgerExercise:
    return await wger_client.get_exercise_detail(wger_id)
