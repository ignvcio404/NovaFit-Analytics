"""
NovaFit Analytics Suite — Backend
===================================
Billing Router — Payment Preferences

Exposes endpoints for the billing flow:
  - Create MercadoPago preference (checkout URL)
  - Register manual cash payment
  - Query invoice status

All logic is delegated to BillingService.
"""

import uuid
from decimal import Decimal
from typing import Optional

from fastapi import APIRouter, Depends, status, BackgroundTasks, HTTPException, Request
from fastapi.responses import RedirectResponse
from pydantic import BaseModel, Field
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.dependencies import get_mercadopago_service, get_billing_service, get_db, get_whatsapp_service
from app.core.security import get_current_active_user, require_permission
from app.core.config import settings
from app.database.models.core import User
from app.database.models.administrative import InvoiceStatus
from app.integrations.mercadopago.service import (
    MercadoPagoService,
    MPItem,
    MPPayer,
    MPPreferenceResult,
)
from app.integrations.zoho_mail.service import ZohoMailService
from app.billing.service import BillingService

router = APIRouter(prefix="/billing", tags=["Billing"])


# ─────────────────────────────────────────────────────────────────────────────
# Schemas
# ─────────────────────────────────────────────────────────────────────────────

class CreatePreferenceRequest(BaseModel):
    member_id: uuid.UUID
    plan_id: int
    plan_name: str = Field(..., min_length=2)
    amount: Decimal = Field(..., gt=0)
    back_url_success: str = f"{settings.FRONTEND_URL}{settings.API_V1_PREFIX}/billing/payment/success"
    back_url_failure: str  = f"{settings.FRONTEND_URL}{settings.API_V1_PREFIX}/billing/payment/failure"


class CreatePreferenceResponse(BaseModel):
    preference_id: str
    checkout_url: str
    init_point: str
    sandbox_init_point: str
    external_reference: str

class GenerateManualInvoiceRequest(BaseModel):
    member_id: uuid.UUID
    plan_id: int
    plan_name: str
    amount: Decimal = Field(..., gt=0)

from datetime import date
class InvoiceResponse(BaseModel):
    id: uuid.UUID
    invoice_number: str
    status: InvoiceStatus
    total: Decimal
    due_date: date
    payment_link: Optional[str] = None
    
    class Config:
        from_attributes = True

# ─────────────────────────────────────────────────────────────────────────────
# Endpoints
# ─────────────────────────────────────────────────────────────────────────────

@router.get("/my-invoices", response_model=list[InvoiceResponse])
async def get_my_invoices(
    current_user: User = Depends(get_current_active_user),
    billing_service: BillingService = Depends(get_billing_service),
):
    """Get pending and past invoices for the current member."""
    return await billing_service.get_my_invoices(current_user.id)

@router.post(
    "/mercadopago/preference",
    response_model=CreatePreferenceResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Create MercadoPago payment preference",
    description=(
        "Creates a MercadoPago checkout Preference for a membership plan. "
        "Returns `checkout_url` to redirect the member to the MercadoPago payment page. "
        "The `external_reference` contains the invoice UUID for webhook matching."
    ),
)
async def create_mercadopago_preference(
    request: CreatePreferenceRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user),
    mp_service: MercadoPagoService = Depends(get_mercadopago_service),
    billing_service: BillingService = Depends(get_billing_service),
) -> CreatePreferenceResponse:
    """
    Creates a MercadoPago payment preference.

    ### Flow
    1. Backend creates an Invoice and Membership in PENDING state.
    2. Backend creates a Preference via MercadoPago API using the invoice_id.
    3. Returns `checkout_url` (the MercadoPago payment page).
    4. Admin/client redirects member to that URL.
    """
    # Use fallback branch if current user lacks one
    # Note: A real implementation might enforce the member's branch, but for now we fallback
    branch_id = current_user.branch_id or current_user.id 

    # Generate Invoice and Membership records in DB
    invoice_id = await billing_service.create_invoice_and_membership(
        user_id=request.member_id,
        plan_id=request.plan_id,
        branch_id=branch_id,
        amount=request.amount,
    )

    payer = MPPayer(
        name=current_user.first_name or "Socio",
        surname=current_user.last_name or "NovaFit",
        email=current_user.email,
    )

    items = [
        MPItem(
            title=request.plan_name,
            quantity=1,
            unit_price=request.amount,
            description=f"Membresía NovaFit — {request.plan_name}",
        )
    ]

    result: MPPreferenceResult = await mp_service.create_preference(
        invoice_id=invoice_id,
        items=items,
        payer=payer,
        back_url_success=request.back_url_success,
        back_url_failure=request.back_url_failure,
    )

    # Save payment link to database
    invoice = await billing_service.get_invoice_by_id(invoice_id)
    if invoice:
        invoice.payment_link = result.init_point
        await billing_service.db.commit()

    # Send the link via email asynchronously
    try:
        # Assuming we can get user email. We don't have member's email in request,
        # but we might be able to get it from current_user if current_user IS the member
        # or we should fetch the member. Since current_user is passed to MP payer,
        # let's use current_user's email for now.
        email_service = ZohoMailService()
        background_tasks.add_task(
            email_service.send_payment_link,
            to_email=current_user.email,
            to_name=f"{current_user.first_name} {current_user.last_name}",
            plan_name=request.plan_name,
            amount=float(request.amount),
            payment_link=result.init_point,
        )
    except Exception as e:
        import logging
        logging.getLogger(__name__).warning(f"Could not queue email task: {e}")

    return CreatePreferenceResponse(
        preference_id=result.preference_id,
        checkout_url=result.checkout_url,
        init_point=result.init_point,
        sandbox_init_point=result.sandbox_init_point,
        external_reference=result.external_reference,
    )

class PayInvoiceRequest(BaseModel):
    member_id: uuid.UUID
    invoice_id: uuid.UUID
    amount: Decimal = Field(..., gt=0)
    payment_method: str = Field(..., min_length=2)
    notes: Optional[str] = None

@router.post(
    "/pay",
    status_code=status.HTTP_200_OK,
    summary="Process a payment for an invoice",
)
async def process_payment(
    request: PayInvoiceRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    mp_service: MercadoPagoService = Depends(get_mercadopago_service),
    billing_service: BillingService = Depends(get_billing_service),
    whatsapp_service = Depends(get_whatsapp_service),
):
    import logging
    _log = logging.getLogger(__name__)

    require_permission(current_user, "users", "update")

    # 1. Verify invoice exists
    invoice = await billing_service.get_invoice_by_id(request.invoice_id)
    if not invoice:
        raise HTTPException(status_code=404, detail="Factura no encontrada.")

    # 2. Get Member Info
    member_result = await db.execute(select(User).where(User.id == request.member_id))
    member = member_result.scalars().first()
    if not member:
        raise HTTPException(status_code=404, detail="Socio no encontrado.")

    if request.payment_method.lower() == "mercadopago":
        payer = MPPayer(
            name=member.first_name or "Socio",
            surname=member.last_name or "NovaFit",
            email=member.email,
        )
        items = [
            MPItem(
                title="Pago Membresía",
                quantity=1,
                unit_price=request.amount,
                description=f"Pago Factura {invoice.invoice_number}"
            )
        ]

        invoice.status = InvoiceStatus.ISSUED
        await db.commit()

        result: MPPreferenceResult = await mp_service.create_preference(
            invoice_id=str(invoice.id),
            items=items,
            payer=payer,
            back_url_success=f"{settings.FRONTEND_URL}{settings.API_V1_PREFIX}/billing/payment/success",
            back_url_failure=f"{settings.FRONTEND_URL}{settings.API_V1_PREFIX}/billing/payment/failure",
        )
        invoice.payment_link = result.init_point
        await db.commit()

        try:
            email_service = ZohoMailService()
            background_tasks.add_task(
                email_service.send_payment_link,
                to_email=member.email,
                to_name=f"{member.first_name} {member.last_name}",
                plan_name="Membresía",
                amount=float(request.amount),
                payment_link=result.init_point,
            )
        except Exception as e:
            _log.warning(f"Could not queue email task: {e}")

        return {
            "message": "El correo con el link de pago fue enviado al socio exitosamente",
            "invoice_id": str(invoice.id),
            "payment_url": result.init_point
        }

    else:
        # ── Cash payment ──────────────────────────────────────────────────────
        await billing_service.mark_invoice_paid(
            invoice_id=request.invoice_id,
            gateway="cash",
            transaction_amount=request.amount,
            gateway_payment_id="MANUAL_CASH",
        )

        # ── WhatsApp: novafit_pago_confirmado ─────────────────────────────────
        if member.phone_number:
            async def _send_payment_whatsapp():
                try:
                    await whatsapp_service.send_payment_confirmation(
                        to_phone=member.phone_number,
                        member_first_name=member.first_name or "Socio",
                        invoice_number=invoice.invoice_number,
                        amount=request.amount,
                        plan_name=request.notes or "Plan NovaFit",
                    )
                    _log.info(
                        "WhatsApp pago_confirmado sent to user=%s invoice=%s",
                        member.id, invoice.invoice_number,
                    )
                except Exception as exc:
                    _log.error(
                        "WhatsApp pago_confirmado failed for user=%s: %s",
                        member.id, exc,
                    )
            background_tasks.add_task(_send_payment_whatsapp)
        else:
            _log.warning(
                "WhatsApp pago_confirmado skipped for user=%s: no phone number registered",
                member.id,
            )

        return {
            "message": "Pago en efectivo registrado correctamente.",
            "invoice_id": str(invoice.id)
        }



@router.get("/payment/success")
async def payment_success():
    return RedirectResponse(url="https://nova-fit-analytics-suite.vercel.app/billing")

@router.get("/payment/failure")
async def payment_failure():
    return RedirectResponse(url="https://nova-fit-analytics-suite.vercel.app/billing")

@router.get("/payment/pending")
async def payment_pending():
    return RedirectResponse(url="https://nova-fit-analytics-suite.vercel.app/billing")

@router.post(
    "/admin/generate-invoice",
    status_code=status.HTTP_201_CREATED,
    summary="Generate manual invoice for member",
)
async def generate_manual_invoice(
    request: GenerateManualInvoiceRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    billing_service: BillingService = Depends(get_billing_service),
    whatsapp_service = Depends(get_whatsapp_service),
):
    require_permission(current_user, "users", "update")
    import logging
    _log = logging.getLogger(__name__)

    # Fetch member
    member_result = await db.execute(select(User).where(User.id == request.member_id))
    member = member_result.scalars().first()
    if not member:
        raise HTTPException(status_code=404, detail="Socio no encontrado.")
        
    branch_id = member.branch_id or current_user.branch_id or current_user.id
    
    # 1. Create Invoice and Membership (PENDING)
    invoice_id = await billing_service.create_invoice_and_membership(
        user_id=request.member_id,
        plan_id=request.plan_id,
        branch_id=branch_id,
        amount=request.amount,
    )
    
    # 2. WhatsApp Notification (Aviso de cobro / Vencimiento)
    if member.phone_number:
        async def _send_reminder():
            try:
                # We use send_plan_expiration_reminder as an "Aviso de Cobro"
                # Since the plan is expired or we just generated it, days_left = 0
                await whatsapp_service.send_plan_expiration_reminder(
                    phone=member.phone_number,
                    member_first_name=member.first_name or "Socio",
                    plan_name=request.plan_name,
                    days_left=0,
                    renewal_url=f"{settings.FRONTEND_URL}/billing"
                )
                _log.info(f"WhatsApp billing reminder sent to {member.phone_number}")
            except Exception as exc:
                _log.error(f"Failed to send WhatsApp billing reminder: {exc}")
                
        background_tasks.add_task(_send_reminder)
        
    return {
        "message": "Factura generada y recordatorio enviado exitosamente.",
        "invoice_id": str(invoice_id)
    }

