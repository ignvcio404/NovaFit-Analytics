"""
NovaFit Analytics Suite
========================
Authentication Router  —  POST /auth/register  &  POST /auth/login
===================================================================

Endpoints:
  POST /api/v1/auth/register  — Create a new user account (returns tokens immediately)
  POST /api/v1/auth/login     — Verify credentials via OAuth2PasswordRequestForm → JWT

Design notes:
  - /login uses OAuth2PasswordRequestForm so Swagger UI's "Authorize" button works
    out of the box (it POSTs username + password as form-data to this URL).
  - Passwords are hashed with bcrypt via security.hash_password().
  - On successful login, both access_token and refresh_token are returned.
  - Email uniqueness and username uniqueness are enforced at the DB level;
    a caught IntegrityError is surfaced as HTTP 409 Conflict.
  - No email-verification flow is included here; the new user is created with
    status ACTIVE so they can log in immediately (adjust for production).
"""

import uuid
from datetime import datetime, timezone
from typing import Optional, List

from fastapi import APIRouter, Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordRequestForm
from pydantic import BaseModel, EmailStr, Field, field_validator
from sqlalchemy import select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.security import (
    create_access_token,
    create_refresh_token,
    hash_password,
    verify_password,
    get_current_active_user,
)
from app.database.models.core import User, UserStatus
from app.database.session import get_db
from jose import jwt, JWTError
from app.integrations.zoho_mail.service import ZohoMailService

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ─────────────────────────────────────────────────────────────────────────────
# Pydantic Schemas (local to this router — no separate schemas file needed yet)
# ─────────────────────────────────────────────────────────────────────────────

class RegisterRequest(BaseModel):
    """Body for POST /auth/register."""

    email: EmailStr = Field(..., description="Unique email address")
    username: str = Field(..., min_length=3, max_length=50, description="Unique username (3–50 chars)")
    password: str = Field(..., min_length=8, description="Plain-text password (min 8 chars)")
    first_name: str = Field(..., min_length=1, max_length=80)
    last_name: str = Field(..., min_length=1, max_length=80)
    phone_number: Optional[str] = Field(None, description="E.164 format — optional")
    branch_id: Optional[uuid.UUID] = None
    role: Optional[str] = Field("athlete", description="Role to assign (default: athlete)")

    @field_validator("username")
    @classmethod
    def username_alphanumeric(cls, v: str) -> str:
        if not v.replace("_", "").replace("-", "").isalnum():
            raise ValueError("Username may only contain letters, numbers, hyphens, and underscores.")
        return v.lower()


class TokenResponse(BaseModel):
    """Standard OAuth2 token response + refresh token."""

    access_token: str
    refresh_token: str
    token_type: str = "bearer"
    expires_in: int = Field(description="Access token lifetime in seconds")


class UserPublic(BaseModel):
    """Minimal public representation of a user returned after register/login."""

    id: uuid.UUID
    email: str
    username: str
    first_name: str
    last_name: str
    status: UserStatus
    roles: List[str] = Field(default_factory=list)

    model_config = {"from_attributes": True}
    
class UserMeResponse(UserPublic):
    membership: Optional[dict] = None

class RegisterResponse(BaseModel):
    """Combined response for POST /auth/register."""

    user: UserPublic
    tokens: TokenResponse

class ForgotPasswordRequest(BaseModel):
    email: EmailStr

class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str = Field(..., min_length=8)


# ─────────────────────────────────────────────────────────────────────────────
# POST /auth/register
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/register",
    response_model=RegisterResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Register a new user account",
    description=(
        "Create a new NovaFit user and return an access + refresh token pair. "
        "The account is immediately set to **ACTIVE** status so the user can log "
        "in without a separate email-verification step. "
        "Returns HTTP **409** if the email or username is already taken."
    ),
    responses={
        201: {"description": "User created and tokens issued"},
        409: {"description": "Email or username already registered"},
        422: {"description": "Validation error in the request body"},
    },
)
async def register(
    body: RegisterRequest,
    db: AsyncSession = Depends(get_db),
) -> RegisterResponse:
    """
    Register a new user.

    Steps:
      1. Check that email and username are not already taken.
      2. Hash the password with bcrypt.
      3. Persist the User row.
      4. Issue access + refresh tokens.
      5. Return the public user representation and token pair.
    """
    # ── 1. Pre-flight uniqueness checks (friendly 409 before hitting DB) ────────
    existing_email = await db.scalar(select(User).where(User.email == body.email))
    if existing_email:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El usuario o correo ya se encuentra registrado",
        )

    existing_username = await db.scalar(select(User).where(User.username == body.username))
    if existing_username:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El usuario o correo ya se encuentra registrado",
        )

    # ── 1.5. Asignar Sucursal por defecto si no existe ───────────────────────
    assigned_branch_id = body.branch_id
    if not assigned_branch_id:
        from app.database.models.core import Branch
        first_branch = await db.scalar(select(Branch).where(Branch.is_active == True))
        if first_branch:
            assigned_branch_id = first_branch.id

    # ── 2. Create user ──────────────────────────────────────────────────────────
    new_user = User(
        email=body.email,
        username=body.username,
        password_hash=hash_password(body.password),
        first_name=body.first_name,
        last_name=body.last_name,
        phone_number=body.phone_number,
        branch_id=assigned_branch_id,
        # Skip email verification for initial development — set to ACTIVE directly.
        status=UserStatus.ACTIVE,
        email_verified=False,
    )
    db.add(new_user)

    try:
        await db.commit()
        await db.refresh(new_user)
        
        # ── 2.5 Assign role ────────────────────────────────────────────────────────
        from app.database.models.core import Role, UserRole
        role_record = await db.scalar(select(Role).where(Role.name == body.role))
        if role_record:
            new_user_role = UserRole(user_id=new_user.id, role_id=role_record.id)
            db.add(new_user_role)
            await db.commit()
    except IntegrityError:
        await db.rollback()
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="El usuario o correo ya se encuentra registrado",
        )

    # ── 3. Issue tokens ─────────────────────────────────────────────────────────
    access_token = create_access_token(subject=new_user.id)
    refresh_token = create_refresh_token(subject=new_user.id)

    from app.core.config import settings  # avoid circular at module level

    user_out = UserPublic.model_validate(new_user)
    if role_record:
        user_out.roles = [role_record.name]

    return RegisterResponse(
        user=user_out,
        tokens=TokenResponse(
            access_token=access_token,
            refresh_token=refresh_token,
            expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
        ),
    )


# ─────────────────────────────────────────────────────────────────────────────
# POST /auth/login
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/login",
    response_model=TokenResponse,
    summary="Login — obtain JWT access token",
    description=(
        "Authenticates a user with **email or username** + password using the "
        "standard OAuth2 password flow. "
        "The `username` field accepts both the user's username **and** their email address. "
        "Returns a bearer token to use in the `Authorization` header for all protected endpoints. "
        "This URL is also the `tokenUrl` for Swagger UI's **Authorize** button."
    ),
    responses={
        200: {"description": "Credentials valid — tokens returned"},
        401: {"description": "Invalid credentials"},
        403: {"description": "Account is suspended or inactive"},
    },
)
async def login(
    form: OAuth2PasswordRequestForm = Depends(),
    db: AsyncSession = Depends(get_db),
) -> TokenResponse:
    """
    Authenticate a user and return JWT tokens.

    Accepts `username` (the OAuth2 form field) as either the user's
    **username** or **email address** for convenience.

    Steps:
      1. Look up the user by username or email.
      2. Verify the bcrypt password hash.
      3. Assert the account is ACTIVE.
      4. Update `last_login_at`.
      5. Return access + refresh tokens.
    """
    identifier = form.username.strip().lower()

    from sqlalchemy.orm import selectinload
    from app.database.models.core import UserRole, Role

    # ── 1. Resolve user by username or email ────────────────────────────────────
    user: Optional[User] = await db.scalar(
        select(User).where(
            (User.username == identifier) | (User.email == identifier)
        ).options(
            selectinload(User.user_roles).selectinload(UserRole.role)
        )
    )

    # ── 2. Check user exists, then verify password ───────────────────────────────
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    if not verify_password(form.password, user.password_hash):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Incorrect username/email or password.",
            headers={"WWW-Authenticate": "Bearer"},
        )

    # ── 3. Account status check ─────────────────────────────────────────────────
    if user.status != UserStatus.ACTIVE:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=(
                f"Account is not active (status: {user.status.value}). "
                "Please contact your administrator."
            ),
        )

    # ── 4. Update last_login_at (best-effort, non-blocking) ─────────────────────
    user.last_login_at = datetime.now(timezone.utc)
    try:
        await db.commit()
    except Exception:
        await db.rollback()
        # Non-critical — do not fail the login if this update fails.

    # ── 5. Issue tokens ─────────────────────────────────────────────────────────
    from app.core.config import settings

    roles = [ur.role.name for ur in user.user_roles if ur.role]
    access_token = create_access_token(
        subject=user.id,
        extra_claims={"roles": roles}
    )
    refresh_token = create_refresh_token(subject=user.id)

    return TokenResponse(
        access_token=access_token,
        refresh_token=refresh_token,
        expires_in=settings.ACCESS_TOKEN_EXPIRE_MINUTES * 60,
    )


# ─────────────────────────────────────────────────────────────────────────────
# GET /auth/me
# ─────────────────────────────────────────────────────────────────────────────

@router.get(
    "/me",
    response_model=UserMeResponse,
    summary="Get current authenticated user",
    description="Returns the details of the currently authenticated user.",
    responses={
        200: {"description": "User details returned"},
        401: {"description": "Not authenticated"},
    },
)
async def get_current_user_profile(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
) -> UserPublic:
    """
    Get the currently logged in user based on the provided Bearer token, including up-to-date roles.
    """
    from sqlalchemy.orm import selectinload
    from app.database.models.core import UserRole
    
    user_with_roles = await db.scalar(
        select(User).where(User.id == current_user.id).options(
            selectinload(User.user_roles).selectinload(UserRole.role)
        )
    )
    
    if not user_with_roles:
        raise HTTPException(status_code=404, detail="User not found")
        
    roles = [ur.role.name for ur in user_with_roles.user_roles]
    
    # Query active membership
    from app.database.models.administrative import Membership, MembershipPlan
    stmt_mem = select(Membership).options(selectinload(Membership.plan)).where(
        Membership.user_id == current_user.id,
        Membership.status == "active"
    ).order_by(Membership.end_date.desc()).limit(1)
    
    active_membership = await db.scalar(stmt_mem)
    membership_data = None
    if active_membership:
        days_remaining = (active_membership.end_date - datetime.utcnow().date()).days
        membership_data = {
            "plan_name": active_membership.plan.name,
            "status": active_membership.status,
            "days_remaining": days_remaining,
            "end_date": str(active_membership.end_date)
        }
        
    return UserMeResponse(
        id=user_with_roles.id,
        email=user_with_roles.email,
        username=user_with_roles.username,
        first_name=user_with_roles.first_name,
        last_name=user_with_roles.last_name,
        status=user_with_roles.status,
        roles=roles,
        membership=membership_data
    )


# ─────────────────────────────────────────────────────────────────────────────
# POST /auth/forgot-password
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/forgot-password",
    status_code=status.HTTP_200_OK,
    summary="Request a password reset link",
    description="Sends an email with a reset link if the user exists.",
)
async def forgot_password(
    body: ForgotPasswordRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    from app.core.config import settings
    
    user = await db.scalar(select(User).where(User.email == body.email))
    if user and user.status == UserStatus.ACTIVE:
        # Generate temporary JWT for reset
        to_encode = {"sub": str(user.id), "type": "reset"}
        expire = datetime.now(timezone.utc) + datetime.timedelta(minutes=15)
        to_encode.update({"exp": expire})
        reset_token = jwt.encode(to_encode, settings.SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
        
        email_service = ZohoMailService()
        await email_service.send_password_recovery(user.email, reset_token)
    
    # Always return 200 to prevent email enumeration
    return {"message": "Si el correo está registrado, se enviaron instrucciones de recuperación."}


# ─────────────────────────────────────────────────────────────────────────────
# POST /auth/reset-password
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/reset-password",
    status_code=status.HTTP_200_OK,
    summary="Reset password using a valid token",
)
async def reset_password(
    body: ResetPasswordRequest,
    db: AsyncSession = Depends(get_db),
) -> dict:
    from app.core.config import settings
    
    try:
        payload = jwt.decode(body.token, settings.SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])
        user_id_str = payload.get("sub")
        token_type = payload.get("type")
        if not user_id_str or token_type != "reset":
            raise JWTError()
    except JWTError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Token inválido o expirado.",
        )
        
    user = await db.scalar(select(User).where(User.id == uuid.UUID(user_id_str)))
    if not user:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Usuario no encontrado.")
        
    user.password_hash = hash_password(body.new_password)
    try:
        await db.commit()
    except Exception:
        await db.rollback()
        raise HTTPException(status_code=status.HTTP_500_INTERNAL_SERVER_ERROR, detail="Error al actualizar contraseña.")
        
    return {"message": "Contraseña actualizada exitosamente."}
