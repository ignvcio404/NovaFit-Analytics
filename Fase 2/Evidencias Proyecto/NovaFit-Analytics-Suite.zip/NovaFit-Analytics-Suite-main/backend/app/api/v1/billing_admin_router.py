import uuid
from datetime import datetime
from typing import List, Optional

from fastapi import APIRouter, Depends, Query, status, BackgroundTasks, HTTPException
from pydantic import BaseModel
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.dependencies import get_db, get_billing_service, get_whatsapp_service
from app.core.security import get_current_active_user, require_permission
from app.database.models.core import User
from app.database.models.administrative import Invoice, InvoiceStatus, Membership, MembershipStatus

router = APIRouter(prefix="/billing/admin", tags=["Billing Admin"])

# ── Schemas ─────────────────────────────────────────────────────────────────

class InvoiceResponse(BaseModel):
    id: uuid.UUID
    invoice_number: str
    member_id: uuid.UUID
    member_name: str
    member_email: str
    due_date: Optional[datetime]
    total: float
    status: str
    payment_link: Optional[str]

class DelinquentResponse(BaseModel):
    id: uuid.UUID
    first_name: str
    last_name: str
    email: str
    end_date: Optional[datetime]

class BillingSummaryResponse(BaseModel):
    total_collected: float
    total_pending: float
    delinquent_count: int
    payment_rate: float

class RevenueTrendResponse(BaseModel):
    month: str
    revenue: float
    invoices: int

# ── Endpoints ───────────────────────────────────────────────────────────────

@router.get("/invoices", response_model=List[InvoiceResponse])
async def get_admin_invoices(
    status_filter: Optional[str] = Query(None, alias="status"),
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")

    query = select(Invoice).options(selectinload(Invoice.membership).selectinload(Membership.user)).order_by(desc(Invoice.created_at))
    
    if status_filter and status_filter.upper() != "TODOS":
        query = query.where(Invoice.status == status_filter.lower())
        
    result = await db.execute(query)
    invoices = result.scalars().all()
    
    return [
        InvoiceResponse(
            id=inv.id,
            invoice_number=inv.invoice_number,
            member_id=inv.membership.user.id if inv.membership and inv.membership.user else uuid.UUID(int=0),
            member_name=f"{inv.membership.user.first_name} {inv.membership.user.last_name}" if inv.membership and inv.membership.user else "Desconocido",
            member_email=inv.membership.user.email if inv.membership and inv.membership.user else "",
            due_date=inv.membership.end_date if inv.membership else inv.due_date,
            total=float(inv.total),
            status=inv.status.value if hasattr(inv.status, 'value') else str(inv.status),
            payment_link=inv.payment_link
        )
        for inv in invoices
    ]

@router.get("/delinquent", response_model=List[DelinquentResponse])
async def get_admin_delinquent(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")
    
    # Identify users who have an active membership valid today
    active_users_subquery = (
        select(Membership.user_id)
        .where(
            (Membership.status == MembershipStatus.ACTIVE) &
            (Membership.end_date >= datetime.now().date())
        )
    )

    query = (
        select(Membership)
        .options(selectinload(Membership.user))
        .where(~Membership.user_id.in_(active_users_subquery))
        .order_by(Membership.user_id, Membership.end_date.desc())
        .distinct(Membership.user_id)
    )
    result = await db.execute(query)
    memberships = result.scalars().all()
    
    delinquent = []
    seen_users = set()
    for mem in memberships:
        if mem.user_id not in seen_users and mem.user:
            delinquent.append(
                DelinquentResponse(
                    id=mem.user.id,
                    first_name=mem.user.first_name or "",
                    last_name=mem.user.last_name or "",
                    email=mem.user.email or "",
                    end_date=mem.end_date
                )
            )
            seen_users.add(mem.user_id)
            
    return delinquent

@router.get("/summary", response_model=BillingSummaryResponse)
async def get_admin_summary(
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")
    
    # Total Collected (Paid Invoices)
    paid_query = select(func.sum(Invoice.total)).where(Invoice.status == InvoiceStatus.PAID)
    total_collected = (await db.execute(paid_query)).scalar() or 0.0
    
    # Total Pending (Issued / Overdue Invoices)
    pending_query = select(func.sum(Invoice.total)).where(Invoice.status.in_([InvoiceStatus.ISSUED, InvoiceStatus.OVERDUE]))
    total_pending = (await db.execute(pending_query)).scalar() or 0.0
    
    # Delinquent Count
    active_users_subquery = (
        select(Membership.user_id)
        .where(
            (Membership.status == MembershipStatus.ACTIVE) &
            (Membership.end_date >= datetime.now().date())
        )
    )
    delinq_query = select(func.count(func.distinct(Membership.user_id))).where(
        ~Membership.user_id.in_(active_users_subquery)
    )
    delinquent_count = (await db.execute(delinq_query)).scalar() or 0
    
    # Payment Rate
    total_invoices_query = select(func.count(Invoice.id))
    total_invoices = (await db.execute(total_invoices_query)).scalar() or 0
    
    paid_invoices_query = select(func.count(Invoice.id)).where(Invoice.status == InvoiceStatus.PAID)
    paid_invoices = (await db.execute(paid_invoices_query)).scalar() or 0
    
    payment_rate = (paid_invoices / total_invoices * 100) if total_invoices > 0 else 0.0
    
    return BillingSummaryResponse(
        total_collected=float(total_collected),
        total_pending=float(total_pending),
        delinquent_count=delinquent_count,
        payment_rate=round(float(payment_rate), 1)
    )

@router.get("/revenue-trend", response_model=List[RevenueTrendResponse])
async def get_admin_revenue_trend(
    months: int = 6,
    db: AsyncSession = Depends(get_db),
    current_user: User = Depends(get_current_active_user)
):
    require_permission(current_user, "users", "read")
    
    # Calculate date limit
    from dateutil.relativedelta import relativedelta
    from collections import defaultdict
    import calendar
    
    limit_date = datetime.now() - relativedelta(months=months)
    
    query = select(Invoice).where(
        (Invoice.status == InvoiceStatus.PAID) & 
        (Invoice.created_at >= limit_date)
    )
    result = await db.execute(query)
    invoices = result.scalars().all()
    
    # Group in Python to be DB-agnostic (supports SQLite and Postgres)
    grouped_data = defaultdict(lambda: {"revenue": 0.0, "invoices": 0})
    
    for inv in invoices:
        month_key = inv.created_at.strftime("%b %Y") # e.g. "Aug 2026"
        grouped_data[month_key]["revenue"] += float(inv.total)
        grouped_data[month_key]["invoices"] += 1
        
    # Format and sort by date
    # To keep chronological order, we sort by parsing the string back to date
    sorted_keys = sorted(grouped_data.keys(), key=lambda d: datetime.strptime(d, "%b %Y"))
    
    return [
        RevenueTrendResponse(
            month=k,
            revenue=grouped_data[k]["revenue"],
            invoices=grouped_data[k]["invoices"]
        )
        for k in sorted_keys
    ]

class RegisterManualPaymentRequest(BaseModel):
    member_id: uuid.UUID
    plan_id: int
    plan_name: str
    amount: float

@router.post("/register-manual-payment", status_code=status.HTTP_201_CREATED)
async def register_manual_payment(
    request: RegisterManualPaymentRequest,
    background_tasks: BackgroundTasks,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    billing_service = Depends(get_billing_service),
    whatsapp_service = Depends(get_whatsapp_service)
):
    require_permission(current_user, "users", "update")
    import logging
    _log = logging.getLogger(__name__)

    member_result = await db.execute(select(User).where(User.id == request.member_id))
    member = member_result.scalars().first()
    if not member:
        raise HTTPException(status_code=404, detail="Socio no encontrado.")

    branch_id = member.branch_id or current_user.branch_id or current_user.id
    
    # Create Invoice and Membership (PENDING)
    invoice_id = await billing_service.create_invoice_and_membership(
        user_id=request.member_id,
        plan_id=request.plan_id,
        branch_id=branch_id,
        amount=request.amount,
    )

    # Mark as Paid which will activate the membership
    await billing_service.mark_invoice_paid(
        invoice_id=str(invoice_id),
        gateway="cash",
        transaction_amount=request.amount,
        gateway_payment_id="MANUAL_CASH"
    )

    # Fetch updated invoice to get the number
    invoice = await billing_service.get_invoice_by_id(str(invoice_id))

    # Send WhatsApp notification
    if member.phone_number:
        async def _send_payment_whatsapp():
            try:
                await whatsapp_service.send_payment_confirmation(
                    to_phone=member.phone_number,
                    member_first_name=member.first_name or "Socio",
                    invoice_number=invoice.invoice_number if invoice else "MANUAL",
                    amount=request.amount,
                    plan_name=request.plan_name,
                )
            except Exception as exc:
                _log.error("WhatsApp pago_confirmado failed for user=%s: %s", member.id, exc)
        background_tasks.add_task(_send_payment_whatsapp)

    return {
        "message": "Pago en efectivo registrado y membresía activada.",
        "invoice_id": str(invoice_id)
    }

