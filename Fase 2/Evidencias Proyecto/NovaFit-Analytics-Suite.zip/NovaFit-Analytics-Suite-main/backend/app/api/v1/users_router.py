import uuid
from typing import List, Optional
from datetime import datetime

from fastapi import APIRouter, Depends, Query, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm import selectinload

from app.core.security import get_current_active_user, require_permission, hash_password
from app.database.session import get_db
from app.database.models.core import User, UserRole, Role, Branch, UserStatus, AuditLog
from app.database.models.administrative import Invoice, InvoiceStatus, Membership, MembershipPlan, Transaction, TransactionStatus, TransactionType, AttendanceRecord
from app.core.dependencies import get_billing_service
from app.billing.service import BillingService
from pydantic import BaseModel, EmailStr, Field

class AdvancedUserCreate(BaseModel):
    email: EmailStr
    first_name: str
    last_name: str
    password: str
    branch_id: uuid.UUID
    plan_id: int
    amount: float
    phone_number: Optional[str] = Field(None, pattern=r"^\+[1-9]\d{1,14}$")

class AdvancedUserUpdate(BaseModel):
    email: Optional[EmailStr] = None
    first_name: Optional[str] = None
    last_name: Optional[str] = None
    status: Optional[str] = None
    plan_id: Optional[int] = None
    phone_number: Optional[str] = Field(None, pattern=r"^\+[1-9]\d{1,14}$")

class DeviceTokenUpdate(BaseModel):
    token: str

router = APIRouter(prefix="/users", tags=["Users"])

@router.post("/device-token", status_code=status.HTTP_200_OK)
async def update_device_token(
    data: DeviceTokenUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    """Guarda el push token de Expo para el usuario actual."""
    current_user.device_token = data.token
    await db.commit()
    return {"message": "Device token updated successfully"}

@router.get(
    "/dashboard/kpis",
    status_code=status.HTTP_200_OK,
    summary="Get dashboard KPIs",
)
async def get_dashboard_kpis(
    branch_id: Optional[uuid.UUID] = None,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    require_permission(current_user, "users", "read")
    
    from datetime import datetime, timedelta
    from sqlalchemy import func
    
    now = datetime.now()
    start_of_month = now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)
    start_of_week = now - timedelta(days=now.weekday())
    start_of_week = start_of_week.replace(hour=0, minute=0, second=0, microsecond=0)
    
    # Active members
    stmt_active = select(func.count(User.id)).join(User.user_roles).join(UserRole.role).where(User.status == "active", Role.name == "member")
    if branch_id:
        stmt_active = stmt_active.where(User.branch_id == branch_id)
    active_members = (await db.execute(stmt_active)).scalar() or 0
    
    # Revenue this month
    stmt_rev = select(func.sum(Invoice.total)).where(Invoice.status == InvoiceStatus.PAID, Invoice.created_at >= start_of_month)
    if branch_id:
        stmt_rev = stmt_rev.where(Invoice.branch_id == branch_id)
    revenue_this_month = (await db.execute(stmt_rev)).scalar() or 0.0
    
    # New members this month
    stmt_new = select(func.count(User.id)).join(User.user_roles).join(UserRole.role).where(Role.name == "member", User.created_at >= start_of_month)
    if branch_id:
        stmt_new = stmt_new.where(User.branch_id == branch_id)
    new_members_this_month = (await db.execute(stmt_new)).scalar() or 0
    
    # Sessions this week
    stmt_sess = select(func.count(AttendanceRecord.id)).where(AttendanceRecord.check_in >= start_of_week)
    if branch_id:
        stmt_sess = stmt_sess.where(AttendanceRecord.branch_id == branch_id)
    sessions_logged_this_week = (await db.execute(stmt_sess)).scalar() or 0
    
    from app.database.models.biometry import PredictiveAlert, AlertStatus
    stmt_alerts = select(func.count(PredictiveAlert.id)).where(PredictiveAlert.status == AlertStatus.PENDING)
    if branch_id:
        stmt_alerts = stmt_alerts.join(User).where(User.branch_id == branch_id)
    alerts_pending = (await db.execute(stmt_alerts)).scalar() or 0
    
    return {
        "active_members": active_members,
        "active_members_delta": 0,
        "revenue_this_month": float(revenue_this_month),
        "revenue_delta_pct": 0.0,
        "new_members_this_month": new_members_this_month,
        "sessions_logged_this_week": sessions_logged_this_week,
        "pending_invoices": 0,
        "alerts_pending": alerts_pending
    }

@router.get(
    "",
    status_code=status.HTTP_200_OK,
    summary="List all users",
    description="Retrieves a paginated list of all users. Requires users:read permission (Admins).",
)
async def list_users(
    status_filter: Optional[str] = Query(None, alias="status"),
    role: Optional[str] = Query(None, alias="role"),
    search: Optional[str] = Query(None),
    page: int = Query(1, ge=1),
    page_size: int = Query(50, ge=1, le=100),
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    # Security: Ensure only admins can read users
    # We require the 'users:read' permission (or similar based on your RBAC)
    # Alternatively, you could check roles directly if permissions aren't fully populated.
    require_permission(current_user, "users", "read")

    query = select(User).options(
        selectinload(User.user_roles).selectinload(UserRole.role),
        selectinload(User.branch)
    )

    if status_filter:
        query = query.where(User.status == status_filter.lower())

    if role:
        query = query.join(User.user_roles).join(UserRole.role).where(Role.name == role.lower())

    if search:
        search_term = f"%{search.lower()}%"
        query = query.where(
            (User.email.ilike(search_term)) |
            (User.first_name.ilike(search_term)) |
            (User.last_name.ilike(search_term))
        )

    # Simple pagination
    offset = (page - 1) * page_size
    query = query.offset(offset).limit(page_size)

    result = await db.execute(query)
    users = result.scalars().all()

    # Count total for pagination (simplistic approach for now)
    total = len(users)

    # Fetch latest memberships for the page of users
    user_ids = [u.id for u in users]
    membership_map = {}
    if user_ids:
        mem_stmt = (
            select(Membership)
            .options(selectinload(Membership.plan))
            .where(Membership.user_id.in_(user_ids))
            .order_by(Membership.user_id, Membership.created_at.desc())
        )
        mem_res = await db.execute(mem_stmt)
        for m in mem_res.scalars().all():
            if m.user_id not in membership_map:
                membership_map[m.user_id] = m

    items = []
    for u in users:
        roles = [ur.role.name for ur in u.user_roles if getattr(ur, 'role', None)] if getattr(u, 'user_roles', None) else []
        status_val = u.status.value.lower() if hasattr(u.status, 'value') else (str(u.status).lower() if u.status else "pending")
        
        mem = membership_map.get(u.id)
        if mem:
            mem_status = mem.status.value.lower() if hasattr(mem.status, 'value') else str(mem.status).lower()
            plan_name = mem.plan.name if mem.plan else "Sin plan"
            end_date = mem.end_date.isoformat() if mem.end_date else ""
            days_remaining = (mem.end_date - datetime.now().date()).days if mem.end_date else 0
            if days_remaining < 0:
                days_remaining = 0
        else:
            mem_status = "none"
            plan_name = "Sin plan"
            end_date = ""
            days_remaining = 0

        items.append({
            "id": str(u.id),
            "first_name": u.first_name or "",
            "last_name": u.last_name or "",
            "email": u.email or "Sin correo",
            "phone_number": u.phone_number or "Sin teléfono",
            "roles": roles,
            "last_visit": u.last_login_at.isoformat() if getattr(u, 'last_login_at', None) else None,
            "branch_name": u.branch.name if getattr(u, 'branch', None) else "N/A",
            "membership": {
                "status": mem_status,
                "plan_name": plan_name,
                "end_date": end_date,
                "days_remaining": days_remaining
            }
        })

    return {
        "items": items,
        "total": total,
        "page": page,
        "page_size": page_size
    }

@router.post(
    "/advanced",
    status_code=status.HTTP_201_CREATED,
    summary="Advanced user creation with membership",
)
async def create_advanced_user(
    request: AdvancedUserCreate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    billing_service: BillingService = Depends(get_billing_service),
):
    require_permission(current_user, "users", "write")
    
    # Check if email exists
    stmt = select(User).where(User.email == request.email.lower())
    res = await db.execute(stmt)
    if res.scalars().first():
        from fastapi import HTTPException
        raise HTTPException(status_code=409, detail="Email already registered")

    user_id = uuid.uuid4()
    # Dummy username for now
    username = request.email.split("@")[0].lower() + str(user_id)[:4]

    new_user = User(
        id=user_id,
        email=request.email.lower(),
        username=username,
        password_hash=hash_password(request.password),
        first_name=request.first_name,
        last_name=request.last_name,
        phone_number=request.phone_number,
        status=UserStatus.ACTIVE,
        branch_id=request.branch_id
    )
    db.add(new_user)
    
    # Assign member role
    role_result = await db.execute(select(Role).where(Role.name == "member"))
    member_role = role_result.scalars().first()
    if member_role:
        db.add(UserRole(user_id=new_user.id, role_id=member_role.id))
        
    # We do NOT commit yet. We let billing_service.create_invoice_and_membership 
    # commit everything in a single transaction.

    # Create membership and invoice
    from sqlalchemy.exc import IntegrityError
    from fastapi import HTTPException
    try:
        invoice_id = await billing_service.create_invoice_and_membership(
            user_id=new_user.id,
            plan_id=request.plan_id,
            branch_id=request.branch_id,
            amount=request.amount,
        )
    except IntegrityError:
        await db.rollback()
        raise HTTPException(status_code=409, detail="El correo o teléfono ya se encuentra registrado.")

    return {
        "user_id": str(new_user.id),
        "invoice_id": str(invoice_id),
        "message": "User, membership and invoice created successfully"
    }

@router.put(
    "/{user_id}",
    status_code=status.HTTP_200_OK,
    summary="Update a user",
)
async def update_user(
    user_id: uuid.UUID,
    request: AdvancedUserUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    require_permission(current_user, "users", "write")

    stmt = select(User).where(User.id == user_id)
    res = await db.execute(stmt)
    user = res.scalars().first()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="User not found")

    if request.email:
        user.email = request.email.lower()
    if request.first_name:
        user.first_name = request.first_name
    if request.last_name:
        user.last_name = request.last_name
    if request.phone_number:
        user.phone_number = request.phone_number
    if request.status:
        try:
            user.status = UserStatus(request.status.lower())
        except ValueError:
            pass

    # Update plan_id if provided
    if request.plan_id:
        mem_stmt = select(Membership).where(Membership.user_id == user.id)
        mem_res = await db.execute(mem_stmt)
        membership = mem_res.scalars().first()
        if membership:
            membership.plan_id = request.plan_id
            
    await db.commit()
    return {"message": "User updated successfully"}

@router.delete(
    "/{user_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Delete a user",
)
async def delete_user(
    user_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    require_permission(current_user, "users", "write")

    stmt = select(User).where(User.id == user_id)
    res = await db.execute(stmt)
    user = res.scalars().first()
    if not user:
        from fastapi import HTTPException
        raise HTTPException(status_code=404, detail="User not found")

    try:
        from sqlalchemy import delete, update, text
        from app.database.models.administrative import (
            Invoice, Membership, AttendanceRecord, Transaction,
            PaymentMethod, MembershipFreeze, MercadoPagoTransaction,
        )
        from app.database.models.training import (
            RoutineSession, SessionExercise, ExerciseSet,
            Mesocycle, RoutineTemplate, ExerciseCatalog,
        )
        from app.database.models.biometry import (
            WeightHistory, AnthropometricMeasurement,
            SupplementConsumption, PredictiveAlert, FatigueIndicator,
        )
        from app.database.models.core import UserRole, AuditLog

        # ── Step 0: Nullify self-referential FK columns (SET NULL semantics) ─
        # These columns use ondelete=SET NULL on the DB level, but Supabase's
        # FK enforcement may still fire before our subsequent DELETEs unless we
        # proactively null them out first.
        await db.execute(
            update(AnthropometricMeasurement)
            .where(AnthropometricMeasurement.measured_by == user_id)
            .values(measured_by=None)
        )
        await db.execute(
            update(MembershipFreeze)
            .where(MembershipFreeze.requested_by == user_id)
            .values(requested_by=None)
        )
        await db.execute(
            update(RoutineTemplate)
            .where(RoutineTemplate.created_by == user_id)
            .values(created_by=None)
        )
        await db.execute(
            update(ExerciseCatalog)
            .where(ExerciseCatalog.created_by == user_id)
            .values(created_by=None)
        )
        await db.flush()  # persist nullifications before any DELETEs

        # ── Step 1: Biometry & Predictive Alerts ─────────────────────────────
        await db.execute(delete(PredictiveAlert).where(PredictiveAlert.user_id == user_id))
        await db.execute(delete(FatigueIndicator).where(FatigueIndicator.user_id == user_id))
        await db.execute(delete(SupplementConsumption).where(SupplementConsumption.user_id == user_id))
        await db.execute(delete(AnthropometricMeasurement).where(AnthropometricMeasurement.user_id == user_id))
        await db.execute(delete(WeightHistory).where(WeightHistory.user_id == user_id))
        await db.flush()

        # ── Step 2: Training (leaf → parent) — raw SQL subqueries for speed ──
        await db.execute(
            text(
                "DELETE FROM exercise_sets "
                "WHERE session_exercise_id IN ("
                "  SELECT se.id FROM session_exercises se "
                "  JOIN routine_sessions rs ON rs.id = se.session_id "
                "  WHERE rs.user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(
            text(
                "DELETE FROM session_exercises "
                "WHERE session_id IN ("
                "  SELECT id FROM routine_sessions WHERE user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(delete(RoutineSession).where(RoutineSession.user_id == user_id))
        await db.execute(delete(Mesocycle).where(Mesocycle.member_id == user_id))
        await db.flush()

        # ── Step 3: Attendance ────────────────────────────────────────────────
        await db.execute(delete(AttendanceRecord).where(AttendanceRecord.user_id == user_id))
        await db.flush()

        # ── Step 4: Billing (deepest leaf → root) ────────────────────────────
        await db.execute(delete(PaymentMethod).where(PaymentMethod.user_id == user_id))
        await db.execute(
            text(
                "DELETE FROM mercadopago_transactions "
                "WHERE transaction_id IN ("
                "  SELECT t.id FROM transactions t "
                "  JOIN invoices i ON i.id = t.invoice_id "
                "  JOIN memberships m ON m.id = i.membership_id "
                "  WHERE m.user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(
            text(
                "DELETE FROM transactions "
                "WHERE invoice_id IN ("
                "  SELECT i.id FROM invoices i "
                "  JOIN memberships m ON m.id = i.membership_id "
                "  WHERE m.user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(
            text(
                "DELETE FROM invoices "
                "WHERE membership_id IN ("
                "  SELECT id FROM memberships WHERE user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(
            text(
                "DELETE FROM membership_freezes "
                "WHERE membership_id IN ("
                "  SELECT id FROM memberships WHERE user_id = :uid"
                ")"
            ),
            {"uid": str(user_id)},
        )
        await db.execute(delete(Membership).where(Membership.user_id == user_id))
        await db.flush()

        # ── Step 5: Core (audit → roles → user) ──────────────────────────────
        await db.execute(delete(AuditLog).where(AuditLog.user_id == user_id))
        await db.execute(delete(UserRole).where(UserRole.user_id == user_id))
        await db.flush()

        await db.delete(user)
        await db.commit()

    except Exception as e:
        await db.rollback()
        from fastapi import HTTPException
        raise HTTPException(
            status_code=400,
            detail=f"Failed to delete user — cascading cleanup error: {type(e).__name__}: {e}",
        )

    return None


@router.get(
    "/{user_id}/pending",
    status_code=status.HTTP_200_OK,
    summary="Get pending invoice and membership for user",
)
async def get_user_pending(
    user_id: uuid.UUID,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    if current_user.id != user_id:
        require_permission(current_user, "users", "read")
        
    stmt = (
        select(Invoice)
        .join(Membership)
        .join(MembershipPlan)
        .where(Membership.user_id == user_id)
        .where(Invoice.status == InvoiceStatus.ISSUED)
        .options(selectinload(Invoice.membership).selectinload(Membership.plan))
    )
    result = await db.execute(stmt)
    invoices = result.scalars().all()
    
    if not invoices:
        return {"items": []}
    
    items = []
    for inv in invoices:
        items.append({
            "invoice_id": str(inv.id),
            "amount": float(inv.total),
            "plan_id": inv.membership.plan_id,
            "plan_name": inv.membership.plan.name,
            "due_date": inv.due_date.isoformat() if inv.due_date else None,
        })
    return {"items": items}

@router.get(
    "/metadata/options",
    status_code=status.HTTP_200_OK,
    summary="Get branches and plans for user creation",
)
async def get_user_metadata(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
):
    require_permission(current_user, "users", "read")
    branches = await db.execute(select(Branch))
    plans = await db.execute(select(MembershipPlan).where(MembershipPlan.currency_code == "CLP"))
    
    return {
        "branches": [{"id": str(b.id), "name": b.name} for b in branches.scalars().all()],
        "plans": [{"id": p.id, "name": p.name, "price": float(p.price)} for p in plans.scalars().all()]
    }

@router.get(
    "/audit",
    status_code=status.HTTP_200_OK,
    summary="Get system audit logs",
)
async def get_audit_logs(
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db),
    limit: int = 50
):
    require_permission(current_user, "users", "read")
    
    stmt = (
        select(AuditLog)
        .options(selectinload(AuditLog.user))
        .order_by(AuditLog.occurred_at.desc())
        .limit(limit)
    )
    result = await db.execute(stmt)
    logs = result.scalars().all()
    
    items = []
    for log in logs:
        user_email = log.user.email if log.user else "System"
        items.append({
            "occurred_at": log.occurred_at.strftime("%Y-%m-%d %H:%M:%S"),
            "user_email": user_email,
            "action": log.action.value if hasattr(log.action, 'value') else str(log.action),
            "ip_address": log.ip_address or "Unknown"
        })
        
    return {"items": items}

class PasswordUpdate(BaseModel):
    new_password: str

@router.put(
    "/me/password",
    status_code=status.HTTP_200_OK,
    summary="Update current user password",
)
async def update_password(
    payload: PasswordUpdate,
    current_user: User = Depends(get_current_active_user),
    db: AsyncSession = Depends(get_db)
):
    current_user.password_hash = hash_password(payload.new_password)
    db.add(current_user)
    
    # Audit log
    audit_log = AuditLog(
        user_id=current_user.id,
        branch_id=current_user.branch_id,
        action="update",
        resource_type="user",
        resource_id=str(current_user.id),
        log_metadata={"field": "password_hash"}
    )
    db.add(audit_log)
    await db.commit()
    
    return {"message": "Contraseña actualizada correctamente"}
