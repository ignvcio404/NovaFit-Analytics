﻿"""
NovaFit Analytics Suite
========================
Internal Router — QStash Cron Jobs

Protected endpoints called exclusively by Upstash QStash.
Every request is validated via HMAC signature verification using
QSTASH_CURRENT_SIGNING_KEY / QSTASH_NEXT_SIGNING_KEY.

Endpoints:
  POST /api/v1/internal/membership-expiry-check
      Queries memberships expiring in 3 or 7 days
      Sends WhatsApp template novafit_membresia_vence to each member
"""

import hashlib
import hmac
import logging
from datetime import date, timedelta

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.core.config import settings
from app.core.dependencies import get_db, get_whatsapp_service
from app.database.models.administrative import Membership, MembershipStatus, MembershipPlan
from app.database.models.core import User

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/internal", tags=["Internal — Cron Jobs"])

_EXPIRY_DAYS = (3, 7)


# ─────────────────────────────────────────────────────────────────────────────
# HMAC Signature Validation
# ─────────────────────────────────────────────────────────────────────────────

async def _verify_qstash_signature(
    request: Request,
    upstash_signature: str = Header(None, alias="Upstash-Signature"),
) -> None:
    """
    Validates that the incoming request was signed by Upstash QStash.
    In non-production environments, X-Internal-Override: true bypasses this check.
    """
    override = request.headers.get("X-Internal-Override")
    if settings.ENVIRONMENT != "production" and override == "true":
        logger.warning(
            "QStash signature check bypassed via X-Internal-Override "
            "(only allowed in non-production environments)"
        )
        return

    if not upstash_signature:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Missing Upstash-Signature header.",
        )

    body = await request.body()
    url = str(request.url)

    def _check_key(signing_key: str) -> bool:
        if not signing_key:
            return False
        try:
            expected = hmac.new(
                signing_key.encode(),
                f"{url}{body.decode()}".encode(),
                hashlib.sha256,
            ).hexdigest()
            return hmac.compare_digest(expected, upstash_signature)
        except Exception:
            return False

    valid = (
        _check_key(settings.QSTASH_CURRENT_SIGNING_KEY)
        or _check_key(settings.QSTASH_NEXT_SIGNING_KEY)
    )

    if not valid:
        logger.warning(
            "Rejected request to internal endpoint — invalid QStash signature. URL=%s", url
        )
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid QStash signature.",
        )


# ─────────────────────────────────────────────────────────────────────────────
# Cron Endpoint
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "/membership-expiry-check",
    status_code=status.HTTP_200_OK,
    summary="[QStash Cron] Send WhatsApp reminders for expiring memberships",
    description=(
        "Triggered daily by Upstash QStash at 13:00 (America/Santiago). "
        "Sends novafit_membresia_vence to members expiring in 3 or 7 days."
    ),
    dependencies=[Depends(_verify_qstash_signature)],
)
async def membership_expiry_check(
    db: AsyncSession = Depends(get_db),
    whatsapp_service=Depends(get_whatsapp_service),
):
    """
    Daily membership expiry reminder job.

    Returns:
      - checked: total memberships evaluated
      - sent:    WhatsApp messages successfully dispatched
      - skipped: members without a phone number
      - failed:  send attempts that raised an exception
    """
    today = date.today()
    target_dates = [today + timedelta(days=d) for d in _EXPIRY_DAYS]

    stmt = (
        select(Membership, User, MembershipPlan)
        .join(User, User.id == Membership.user_id)
        .join(MembershipPlan, MembershipPlan.id == Membership.plan_id)
        .where(
            Membership.status == MembershipStatus.ACTIVE,
            Membership.end_date.in_(target_dates),
        )
    )
    result = await db.execute(stmt)
    rows = result.all()

    checked = len(rows)
    sent = 0
    skipped = 0
    failed = 0
    renewal_url = "https://nova-fit-analytics-suite.vercel.app/billing"

    for membership, user, plan in rows:
        days_remaining = (membership.end_date - today).days

        if not user.phone_number:
            logger.info(
                "Expiry reminder skipped — no phone: user=%s days=%d",
                user.id, days_remaining,
            )
            skipped += 1
            continue

        try:
            await whatsapp_service.send_membership_expiry_reminder(
                to_phone=user.phone_number,
                member_first_name=user.first_name or "Socio",
                days_remaining=days_remaining,
                plan_name=plan.name,
                renewal_url=renewal_url,
            )
            logger.info(
                "Expiry reminder sent: user=%s days=%d plan=%r",
                user.id, days_remaining, plan.name,
            )
            sent += 1
        except Exception as exc:
            logger.error(
                "Expiry reminder failed: user=%s days=%d error=%s",
                user.id, days_remaining, exc,
            )
            failed += 1

    logger.info(
        "Membership expiry check complete: checked=%d sent=%d skipped=%d failed=%d",
        checked, sent, skipped, failed,
    )

    return {
        "checked": checked,
        "sent": sent,
        "skipped": skipped,
        "failed": failed,
        "target_dates": [str(d) for d in target_dates],
    }
