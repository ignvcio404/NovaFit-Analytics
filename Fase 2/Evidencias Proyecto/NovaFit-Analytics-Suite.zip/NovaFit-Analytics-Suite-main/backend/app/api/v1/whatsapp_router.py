"""
NovaFit Analytics Suite
========================
WhatsApp Webhook Router
========================

Handles incoming webhooks from Meta (WhatsApp Cloud API).
- Verification (GET)
- Event reception (POST)
"""

import logging
from typing import Any, Dict

from fastapi import APIRouter, HTTPException, Query, Request, Response, status, Depends

from app.core.config import settings
from app.core.security import get_current_active_user
from app.core.dependencies import get_whatsapp_service

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/whatsapp", tags=["Webhooks — WhatsApp"])


@router.get(
    "/webhook",
    status_code=status.HTTP_200_OK,
    summary="Meta Webhook Verification",
    description="Endpoint used by Meta to verify the webhook URL setup.",
)
async def verify_whatsapp_webhook(
    mode: str = Query(None, alias="hub.mode"),
    token: str = Query(None, alias="hub.verify_token"),
    challenge: str = Query(None, alias="hub.challenge"),
) -> Response:
    """
    Verifies the webhook endpoint according to Meta's requirements.
    It expects hub.mode="subscribe" and a matching hub.verify_token.
    If valid, returns the hub.challenge as an integer.
    """
    if mode == "subscribe" and token == settings.WHATSAPP_VERIFY_TOKEN:
        logger.info("WhatsApp webhook verification successful.")
        # Meta expects the challenge to be returned as plain text/int, not JSON.
        return Response(content=challenge, media_type="text/plain")
    
    logger.warning("WhatsApp webhook verification failed. Token mismatch.")
    raise HTTPException(status_code=403, detail="Forbidden: Invalid verify token")


@router.post(
    "/webhook",
    status_code=status.HTTP_200_OK,
    summary="Receive WhatsApp Events",
    description="Endpoint used by Meta to send message events (sent, delivered, read) and incoming messages.",
)
async def receive_whatsapp_webhook(
    request: Request,
    payload: Dict[str, Any],
) -> Dict[str, str]:
    """
    Receives events from WhatsApp Cloud API.
    Currently, we only log the incoming events for auditing purposes.
    Future iterations can parse incoming messages or update message delivery status in the DB.
    
    IMPORTANT: Must always return HTTP 200 immediately to acknowledge receipt.
    """
    try:
        # Check if this is a WhatsApp Business Account event
        if payload.get("object") == "whatsapp_business_account":
            for entry in payload.get("entry", []):
                for change in entry.get("changes", []):
                    value = change.get("value", {})
                    
                    # Handle message statuses (sent, delivered, read, failed)
                    if "statuses" in value:
                        for status_update in value["statuses"]:
                            msg_id = status_update.get("id")
                            status_str = status_update.get("status")
                            recipient_id = status_update.get("recipient_id")
                            logger.info(
                                f"WhatsApp Status Update: Message {msg_id} to {recipient_id} is now '{status_str}'."
                            )
                    
                    # Handle incoming messages
                    if "messages" in value:
                        for message in value["messages"]:
                            from_phone = message.get("from")
                            msg_type = message.get("type")
                            logger.info(
                                f"WhatsApp Incoming Message: Received a '{msg_type}' message from {from_phone}."
                            )
                            # E.g. trigger bot logic or support ticket creation here.
        else:
            logger.warning("Received unknown webhook event object type.")
            
    except Exception as e:
        logger.error(f"Error processing WhatsApp webhook: {str(e)}", exc_info=True)
    
    # Always acknowledge receipt to prevent Meta from retrying
    return {"status": "success"}

@router.post(
    "/test-alert",
    status_code=status.HTTP_200_OK,
    summary="Test WhatsApp Alert",
    description="Envía un mensaje de prueba usando el template 'hello_world' de Meta, que funciona sin restricción de ventana 24h.",
)
async def test_whatsapp_alert(
    current_user: Any = Depends(get_current_active_user),
    whatsapp_service: Any = Depends(get_whatsapp_service),
) -> Dict[str, Any]:
    """
    Envía un WhatsApp de prueba al usuario logueado usando el template 'hello_world'.

    IMPORTANTE — Por qué usamos un template:
    WhatsApp Cloud API tiene una regla de ventana de 24 horas: solo se pueden
    enviar mensajes de texto libre si el destinatario escribió primero en las
    últimas 24 horas. Fuera de ese período, Meta ACEPTA la llamada API
    (devuelve success=True y wamid) pero descarta el mensaje silenciosamente.

    Los TEMPLATES están pre-aprobados por Meta y se entregan en cualquier momento
    sin importar si hay conversación activa. 'hello_world' es el template por
    defecto disponible en todas las cuentas de WhatsApp Business.
    """
    if not current_user.phone_number:
        raise HTTPException(
            status_code=400,
            detail="El usuario no tiene número de teléfono registrado para WhatsApp."
        )

    phone = current_user.phone_number

    try:
        # Usamos el template 'hello_world' (pre-aprobado por Meta).
        # Esto garantiza la entrega sin depender de la ventana de 24h.
        result = await whatsapp_service.send_template_message(
            to_phone=phone,
            template_name="hello_world",
            template_language="en_US",
        )
    except Exception as exc:
        raise HTTPException(
            status_code=503,
            detail=f"Error al contactar WhatsApp API: {str(exc)}"
        )

    if result.status == "accepted":
        return {
            "success": True,
            "message_id": result.message_id,
            "recipient": result.recipient,
            "template": "hello_world",
        }
    else:
        raise HTTPException(
            status_code=500,
            detail=f"WhatsApp API devolvio estado inesperado: {result.status}"
        )
