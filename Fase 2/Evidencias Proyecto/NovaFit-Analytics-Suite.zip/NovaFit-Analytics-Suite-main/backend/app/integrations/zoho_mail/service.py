"""
NovaFit Analytics Suite
========================
INTEGRACIÓN 2 — Zoho Mail API
================================

Envío de emails transaccionales usando la Zoho Mail REST API v1.
Implementa OAuth2 Client Credentials para token management.

Emails enviados:
  - Bienvenida a nuevo socio
  - Comprobante de pago / factura (PDF adjunto)
  - Alerta de semana de descarga (deload)
  - Vencimiento de membresía (7 días / 1 día antes)
  - Recibo de pago en efectivo

Documentación: https://www.zoho.com/mail/help/api/

Autenticación:
  Zoho Mail usa OAuth2 con refresh tokens.
  Primero se genera el refresh_token desde la consola de Zoho API Console.
  El access_token se regenera automáticamente cuando expira (cada 60 minutos).
"""

import logging
from base64 import b64encode
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Any, Dict, List, Optional
from uuid import UUID

import httpx

from app.core.config import settings
from app.core.errors import ZohoMailException

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class EmailAddress:
    """Represents an email address with optional display name."""
    email: str
    name: Optional[str] = None

    def to_zoho_format(self) -> str:
        """Returns 'Name <email>' or just 'email' if no name."""
        if self.name:
            return f"{self.name} <{self.email}>"
        return self.email


@dataclass
class EmailAttachment:
    """An email attachment (e.g. invoice PDF)."""
    filename: str
    content: bytes
    content_type: str = "application/pdf"

    @property
    def content_base64(self) -> str:
        return b64encode(self.content).decode("utf-8")


@dataclass
class ZohoSendResult:
    """Result of a send_email call."""
    message_id: Optional[str]
    status: str                  # success | failed
    recipient: str
    subject: str
    sent_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))


# ─────────────────────────────────────────────────────────────────────────────
# Zoho OAuth Token Manager
# ─────────────────────────────────────────────────────────────────────────────

class ZohoTokenManager:
    """
    Manages OAuth2 access token lifecycle for Zoho API.

    Zoho access tokens expire in 3600 seconds (60 minutes).
    This manager automatically refreshes the token before each API call.

    To generate the initial REFRESH TOKEN:
      1. Go to https://api-console.zoho.com/
      2. Create a "Server-based Application"
      3. Scopes: ZohoMail.messages.CREATE, ZohoMail.accounts.READ
      4. Generate the authorization code → exchange for refresh_token
      5. Store in ZOHO_REFRESH_TOKEN environment variable
    """

    _ZOHO_OAUTH_URL = "https://accounts.zoho.com/oauth/v2/token"

    def __init__(self) -> None:
        self._client_id     = settings.ZOHO_CLIENT_ID
        self._client_secret = settings.ZOHO_CLIENT_SECRET
        self._refresh_token = settings.ZOHO_REFRESH_TOKEN
        self._access_token: Optional[str] = None
        self._token_expires_at: Optional[datetime] = None

    async def get_access_token(self) -> str:
        """
        Returns a valid access token, refreshing if expired or missing.
        Thread-safe for single-worker setups.
        """
        # Add 60-second buffer to prevent edge-case expiration mid-request
        if self._access_token and self._token_expires_at:
            if datetime.now(timezone.utc) < self._token_expires_at - timedelta(seconds=60):
                return self._access_token

        return await self._refresh_access_token()

    async def _refresh_access_token(self) -> str:
        """Exchange refresh_token for a new access_token."""
        logger.info("Refreshing Zoho OAuth2 access token…")

        payload = {
            "grant_type":    "refresh_token",
            "refresh_token": self._refresh_token,
            "client_id":     self._client_id,
            "client_secret": self._client_secret,
        }
        
        # EXPLICIT LOG FOR DEBUGGING ZOHO INVALID_CODE ERROR
        logger.info(f"OAUTH REFRESH PAYLOAD: grant_type={payload['grant_type']}, "
                    f"client_id={payload['client_id']}, "
                    f"refresh_token={payload['refresh_token'][:15]}... (truncated for security)")

        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    self._ZOHO_OAUTH_URL,
                    data=payload,
                    timeout=15.0,
                )

                if response.status_code != 200:
                    logger.error(f"ZOHO OAUTH FATAL ERROR (HTTP {response.status_code}):\n{response.text}")
                    raise ZohoMailException(
                        f"Zoho OAuth token refresh failed: HTTP {response.status_code} — "
                        f"{response.text[:200]}"
                    )

                data = response.json()
                if "error" in data:
                    logger.error(f"ZOHO OAUTH LOGICAL ERROR:\n{response.text}")
                    raise ZohoMailException(
                        f"Zoho OAuth error: {data['error']} — "
                        f"Regenerate the refresh token in the Zoho API Console."
                    )

                self._access_token = data["access_token"]
                expires_in = int(data.get("expires_in", 3600))
                self._token_expires_at = datetime.now(timezone.utc) + timedelta(seconds=expires_in)

                logger.info(
                    "Zoho access token refreshed. Expires in %ds (%s UTC)",
                    expires_in,
                    self._token_expires_at.strftime("%H:%M:%S"),
                )
                return self._access_token

            except httpx.ConnectError as exc:
                raise ZohoMailException(
                    "Cannot connect to Zoho OAuth server. Check network connectivity."
                ) from exc


# ─────────────────────────────────────────────────────────────────────────────
# Zoho Mail Service
# ─────────────────────────────────────────────────────────────────────────────

class ZohoMailService:
    """
    Functional Zoho Mail integration service.

    Sends transactional emails using the Zoho Mail REST API v1.
    Handles OAuth2 token refresh automatically.

    Usage:
        service = ZohoMailService()
        result = await service.send_payment_receipt(
            to_email="member@example.com",
            to_name="Juan Pérez",
            invoice_number="INV-2024-001",
            amount=Decimal("9999.00"),
            plan_name="Plan Premium",
        )
    """

    _ZOHO_API_BASE = "https://mail.zoho.com/api"

    def __init__(self) -> None:
        self._token_manager = ZohoTokenManager()
        self._from_email    = settings.EMAILS_FROM_EMAIL
        self._from_name     = settings.ZOHO_FROM_NAME
        self._account_id    = settings.ZOHO_ACCOUNT_ID  # Zoho Mail account ID

    # ─────────────────────────────────────────────────────────────────────────
    # Public send methods
    # ─────────────────────────────────────────────────────────────────────────

    async def send_welcome_email(
        self,
        to_email: str,
        to_name: str,
        plan_name: str,
        temp_password: Optional[str] = None,
    ) -> ZohoSendResult:
        """
        Sends a welcome email to a new member upon registration.

        Includes: login link, plan details, and temporary password if provided.
        """
        subject = "¡Bienvenido a NovaFit! Tu cuenta está lista."
        body_html = self._render_welcome_template(
            member_name=to_name,
            plan_name=plan_name,
            temp_password=temp_password,
        )
        return await self._send_email(
            to=EmailAddress(email=to_email, name=to_name),
            subject=subject,
            body_html=body_html,
        )

    async def send_password_recovery(
        self,
        to_email: str,
        reset_token: str,
    ) -> ZohoSendResult:
        """
        Sends a password recovery email.
        """
        subject = "Recuperación de contraseña — NovaFit"
        reset_link = f"{settings.FRONTEND_URL}/reset-password?token={reset_token}"
        body_html = f"""
        <html>
            <body>
                <h2>Recuperación de Contraseña</h2>
                <p>Has solicitado restablecer tu contraseña en NovaFit.</p>
                <p>Haz clic en el siguiente enlace para crear una nueva contraseña:</p>
                <p><a href="{reset_link}">Restablecer contraseña</a></p>
                <p>Si no solicitaste este cambio, puedes ignorar este correo.</p>
            </body>
        </html>
        """
        return await self._send_email(
            to=EmailAddress(email=to_email, name="Usuario NovaFit"),
            subject=subject,
            body_html=body_html,
        )

    async def send_payment_receipt(
        self,
        to_email: str,
        to_name: str,
        invoice_number: str,
        amount,  # Decimal
        plan_name: str,
        payment_date: Optional[datetime] = None,
        next_due_date: Optional[str] = None,
        attachment_pdf: Optional[EmailAttachment] = None,
    ) -> ZohoSendResult:
        """
        Sends a payment receipt/invoice email after a successful payment.

        Optionally attaches a PDF invoice.
        This is triggered by:
          - MercadoPago approved webhook
          - Manual cash payment registration (from desktop app)
        """
        pay_date = (payment_date or datetime.now(timezone.utc)).strftime("%d/%m/%Y %H:%M")
        subject = f"Comprobante de Pago #{invoice_number} — NovaFit"
        body_html = self._render_payment_receipt_template(
            member_name=to_name,
            invoice_number=invoice_number,
            amount=amount,
            plan_name=plan_name,
            payment_date=pay_date,
            next_due_date=next_due_date,
        )

        attachments = [attachment_pdf] if attachment_pdf else []

        return await self._send_email(
            to=EmailAddress(email=to_email, name=to_name),
            subject=subject,
            body_html=body_html,
            attachments=attachments,
        )

    async def send_deload_recommendation(
        self,
        to_email: str,
        to_name: str,
        fatigue_score: float,
        deload_reason: Optional[str],
        acwr: Optional[float] = None,
        alert_id: Optional[str] = None,
    ) -> ZohoSendResult:
        """
        Sends the deload week recommendation email (Critical Flow #2 alert).

        Triggered by FatigueService when:
          - fatigue_score >= DELOAD_FATIGUE_THRESHOLD (default 70)
          - OR ACWR > DELOAD_ACWR_UPPER_LIMIT (default 1.5)
        """
        subject = "NovaFit: Tu análisis indica que necesitas una semana de descarga"
        body_html = self._render_deload_template(
            member_name=to_name,
            fatigue_score=fatigue_score,
            deload_reason=deload_reason,
            acwr=acwr,
            alert_id=alert_id,
        )
        return await self._send_email(
            to=EmailAddress(email=to_email, name=to_name),
            subject=subject,
            body_html=body_html,
        )

    async def send_membership_expiry_reminder(
        self,
        to_email: str,
        to_name: str,
        plan_name: str,
        expiry_date: str,
        days_remaining: int,
        renewal_link: str,
    ) -> ZohoSendResult:
        """Membership expiry reminder — sent 7 days and 1 day before expiry."""
        urgency = "hoy" if days_remaining <= 1 else f"en {days_remaining} días"
        subject = f"Tu membresía vence {urgency} — NovaFit"
        body_html = self._render_expiry_template(
            member_name=to_name,
            plan_name=plan_name,
            expiry_date=expiry_date,
            days_remaining=days_remaining,
            renewal_link=renewal_link,
        )
        return await self._send_email(
            to=EmailAddress(email=to_email, name=to_name),
            subject=subject,
            body_html=body_html,
        )

    async def send_payment_link(
        self,
        to_email: str,
        to_name: str,
        plan_name: str,
        amount: float,
        payment_link: str,
    ) -> ZohoSendResult:
        """Sends the MercadoPago payment link to the member."""
        
        # EXPLICIT LOG FOR RENDER DEPLOYMENT
        logger.info(f"MERCADOPAGO PAYMENT LINK GENERATED FOR {to_email}: {payment_link}")
        
        subject = f"Link de pago para tu plan {plan_name} — NovaFit"
        body_html = self._render_payment_link_template(
            member_name=to_name,
            plan_name=plan_name,
            amount=amount,
            payment_link=payment_link,
        )
        return await self._send_email(
            to=EmailAddress(email=to_email, name=to_name),
            subject=subject,
            body_html=body_html,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Core send method
    # ─────────────────────────────────────────────────────────────────────────

    async def _send_email(
        self,
        to: EmailAddress,
        subject: str,
        body_html: str,
        cc: Optional[List[EmailAddress]] = None,
        bcc: Optional[List[EmailAddress]] = None,
        attachments: Optional[List[EmailAttachment]] = None,
        reply_to: Optional[EmailAddress] = None,
    ) -> ZohoSendResult:
        """
        Core method that calls the Zoho Mail Send API.

        Zoho Mail API endpoint:
            POST /api/accounts/{account_id}/messages

        Request body structure follows the Zoho Mail REST API v1 spec.
        """
        access_token = await self._token_manager.get_access_token()

        # ── Build request body ──────────────────────────────────────────────
        mail_body: Dict[str, Any] = {
            "fromAddress": EmailAddress(
                email=self._from_email, name=self._from_name
            ).to_zoho_format(),
            "toAddress": to.to_zoho_format(),
            "subject": subject,
            "content": body_html,
            "mailFormat": "html",
        }

        if cc:
            mail_body["ccAddress"] = ",".join(addr.to_zoho_format() for addr in cc)
        if bcc:
            mail_body["bccAddress"] = ",".join(addr.to_zoho_format() for addr in bcc)
        if reply_to:
            mail_body["replyTo"] = reply_to.to_zoho_format()

        # Attachments: Zoho requires multipart/form-data if present
        # For simplicity, we use base64-encoded inline attachments
        if attachments:
            mail_body["attachments"] = [
                {
                    "name": att.filename,
                    "content": att.content_base64,
                    "contentType": att.content_type,
                }
                for att in attachments
            ]

        # ── HTTP request ────────────────────────────────────────────────────
        logger.info(
            "Sending Zoho Mail: to=%s subject=%r",
            to.email, subject
        )

        async with httpx.AsyncClient(timeout=20.0) as client:
            try:
                response = await client.post(
                    f"{self._ZOHO_API_BASE}/accounts/{self._account_id}/messages",
                    headers={
                        "Authorization": f"Zoho-oauthtoken {access_token}",
                        "Content-Type": "application/json",
                    },
                    json=mail_body,
                )
            except httpx.ConnectError as exc:
                raise ZohoMailException(
                    f"Cannot connect to Zoho Mail API: {exc}"
                ) from exc
            except httpx.TimeoutException as exc:
                raise ZohoMailException("Zoho Mail API timed out.") from exc

        # ── Parse response ──────────────────────────────────────────────────
        if response.status_code == 200:
            data = response.json()
            zoho_status = data.get("status", {}).get("description", "unknown")
            message_id  = data.get("data", {}).get("messageId")

            if zoho_status == "success":
                logger.info(
                    "Email sent successfully: to=%s message_id=%s",
                    to.email, message_id,
                )
                return ZohoSendResult(
                    message_id=str(message_id) if message_id else None,
                    status="success",
                    recipient=to.email,
                    subject=subject,
                )
            else:
                logger.error("Zoho Mail returned non-success status: %s", data)
                raise ZohoMailException(
                    f"Zoho Mail send failed. Status: {zoho_status}. Response: {data}"
                )

        elif response.status_code == 401:
            # Token expired mid-request — clear cache and let caller retry once
            self._token_manager._access_token = None
            raise ZohoMailException(
                "Zoho Mail authorization failed. Token may have been revoked. "
                "Refresh token in Zoho API Console."
            )
        else:
            error_text = response.text
            logger.error(
                "Zoho Mail API error: HTTP %d — %s", response.status_code, error_text
            )
            raise ZohoMailException(
                f"Zoho Mail API error HTTP {response.status_code}: {error_text[:300]}"
            )

    # ─────────────────────────────────────────────────────────────────────────
    # HTML Email Templates
    # ─────────────────────────────────────────────────────────────────────────

    def _render_welcome_template(
        self, member_name: str, plan_name: str, temp_password: Optional[str]
    ) -> str:
        password_block = (
            f"<p>Tu contraseña temporal: <strong>{temp_password}</strong><br>"
            "Por favor, cámbiala al iniciar sesión por primera vez.</p>"
            if temp_password else ""
        )
        return f"""
        {self._email_header()}
        <div style="padding: 32px 40px;">
          <h2 style="color: #6C63FF; margin: 0 0 8px;">¡Bienvenido a NovaFit, {member_name}!</h2>
          <p style="color: #9090B0; margin: 0 0 24px;">Tu cuenta ha sido creada exitosamente.</p>

          <div style="background: #22223A; border-radius: 10px; padding: 20px; margin-bottom: 24px;">
            <p style="margin: 0 0 8px; color: #9090B0; font-size: 12px; text-transform: uppercase; letter-spacing: 0.5px;">TU PLAN</p>
            <p style="margin: 0; font-size: 20px; font-weight: 700; color: #F0F0F8;">{plan_name}</p>
          </div>

          {password_block}

          <p style="color: #9090B0;">Podés iniciar sesión desde la app o la plataforma web.</p>

          <a href="https://app.novafit.com/login"
             style="display: inline-block; background: #6C63FF; color: #fff;
                    padding: 12px 28px; border-radius: 8px; text-decoration: none;
                    font-weight: 600; margin-top: 16px;">
            Ir a NovaFit →
          </a>
        </div>
        {self._email_footer()}
        """

    def _render_payment_receipt_template(
        self,
        member_name: str,
        invoice_number: str,
        amount,
        plan_name: str,
        payment_date: str,
        next_due_date: Optional[str],
    ) -> str:
        next_due_block = (
            f"<tr><td style='color:#9090B0; padding: 8px 0;'>Próximo vencimiento</td>"
            f"<td style='font-weight:600; color:#F0F0F8; text-align:right;'>{next_due_date}</td></tr>"
            if next_due_date else ""
        )
        return f"""
        {self._email_header()}
        <div style="padding: 32px 40px;">
          <h2 style="color: #22D3A0; margin: 0 0 8px;">Pago confirmado</h2>
          <p style="color: #9090B0; margin: 0 0 24px;">Hola {member_name}, tu pago fue procesado correctamente.</p>

          <div style="background: #22223A; border-radius: 10px; padding: 20px; margin-bottom: 24px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="color:#9090B0; padding: 8px 0; font-size: 13px;">Número de comprobante</td>
                <td style="font-weight:600; color:#F0F0F8; text-align:right;">{invoice_number}</td>
              </tr>
              <tr>
                <td style="color:#9090B0; padding: 8px 0;">Plan</td>
                <td style="font-weight:600; color:#F0F0F8; text-align:right;">{plan_name}</td>
              </tr>
              <tr>
                <td style="color:#9090B0; padding: 8px 0;">Monto pagado</td>
                <td style="font-size: 22px; font-weight:700; color:#22D3A0; text-align:right;">$ {amount:,.2f} ARS</td>
              </tr>
              <tr>
                <td style="color:#9090B0; padding: 8px 0;">Fecha de pago</td>
                <td style="font-weight:600; color:#F0F0F8; text-align:right;">{payment_date}</td>
              </tr>
              {next_due_block}
            </table>
          </div>

          <p style="color: #9090B0; font-size: 12px;">
            Conservá este comprobante como respaldo. Para consultas, respondé este email
            o contactanos por WhatsApp.
          </p>
        </div>
        {self._email_footer()}
        """

    def _render_deload_template(
        self,
        member_name: str,
        fatigue_score: float,
        deload_reason: Optional[str],
        acwr: Optional[float],
        alert_id: Optional[str],
    ) -> str:
        acwr_row = (
            f"<tr><td style='color:#9090B0;'>ACWR (Ratio de Carga)</td>"
            f"<td style='color:#EF4444; font-weight:700; text-align:right;'>{acwr:.2f}</td></tr>"
            if acwr else ""
        )
        score_color = "#EF4444" if fatigue_score >= 85 else "#F59E0B" if fatigue_score >= 65 else "#22D3A0"

        return f"""
        {self._email_header()}
        <div style="padding: 32px 40px;">
          <h2 style="color: #EF4444; margin: 0 0 8px;">Alerta: Semana de Descarga Recomendada</h2>
          <p style="color: #9090B0; margin: 0 0 24px;">
            Hola {member_name}, tu análisis de fatiga de los últimos 7 días indica que tu cuerpo necesita recuperación.
          </p>

          <div style="background: #22223A; border-radius: 10px; padding: 20px; margin-bottom: 24px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="color:#9090B0; padding: 8px 0;">Puntaje de fatiga</td>
                <td style="font-size: 28px; font-weight: 700; color: {score_color}; text-align:right;">{fatigue_score:.0f} / 100</td>
              </tr>
              {acwr_row}
            </table>
          </div>

          <div style="background: #EF444415; border: 1px solid #EF444433; border-radius: 10px; padding: 16px; margin-bottom: 24px;">
            <p style="color: #F0F0F8; margin: 0; font-size: 13px; line-height: 1.6;">
              {deload_reason or "Múltiples indicadores de fatiga acumulada detectados."}
            </p>
          </div>

          <h3 style="color: #6C63FF; margin: 0 0 12px;">¿Qué hacer esta semana?</h3>
          <ul style="color: #9090B0; padding-left: 20px; line-height: 1.8;">
            <li>Reducí el volumen total un <strong style="color:#F0F0F8;">40-50%</strong></li>
            <li>Mantené la intensidad (peso) pero bajá las series</li>
            <li>Priorizá el sueño y la nutrición</li>
            <li>Realizá cardio ligero o movilidad articular</li>
          </ul>

          <p style="color: #5A5A78; font-size: 11px; margin-top: 24px;">
            Alert ID: {alert_id or 'N/A'} — Generado automáticamente por NovaFit Analytics Engine
          </p>
        </div>
        {self._email_footer()}
        """

    def _render_expiry_template(
        self,
        member_name: str,
        plan_name: str,
        expiry_date: str,
        days_remaining: int,
        renewal_link: str,
    ) -> str:
        urgency_color = "#EF4444" if days_remaining <= 1 else "#F59E0B"
        urgency_text = "¡Tu membresía vence HOY!" if days_remaining <= 1 else f"Tu membresía vence en {days_remaining} días"
        return f"""
        {self._email_header()}
        <div style="padding: 32px 40px;">
          <h2 style="color: {urgency_color}; margin: 0 0 8px;">{urgency_text}</h2>
          <p style="color: #9090B0; margin: 0 0 24px;">
            Hola {member_name}, tu plan <strong style="color:#F0F0F8">{plan_name}</strong>
            vence el <strong style="color:#F0F0F8">{expiry_date}</strong>.
          </p>
          <a href="{renewal_link}"
             style="display: inline-block; background: #6C63FF; color: #fff;
                    padding: 12px 28px; border-radius: 8px; text-decoration: none;
                    font-weight: 600;">
            Renovar Membresía →
          </a>
          <p style="color: #5A5A78; font-size: 12px; margin-top: 24px;">
            Si ya renovaste, ignorá este mensaje.
          </p>
        </div>
        {self._email_footer()}
        """

    def _render_payment_link_template(
        self,
        member_name: str,
        plan_name: str,
        amount: float,
        payment_link: str,
    ) -> str:
        return f"""
        {self._email_header()}
        <div style="padding: 32px 40px;">
          <h2 style="color: #6C63FF; margin: 0 0 8px;">Tu link de pago está listo</h2>
          <p style="color: #9090B0; margin: 0 0 24px;">
            Hola {member_name}, acá tenés el link oficial para abonar tu plan 
            <strong style="color:#F0F0F8">{plan_name}</strong>.
          </p>
          <div style="background: #22223A; border-radius: 10px; padding: 20px; margin-bottom: 24px;">
            <table style="width: 100%; border-collapse: collapse;">
              <tr>
                <td style="color:#9090B0; padding: 8px 0;">Total a pagar</td>
                <td style="font-size: 22px; font-weight:700; color:#22D3A0; text-align:right;">$ {amount:,.2f} CLP</td>
              </tr>
            </table>
          </div>
          <a href="{payment_link}"
             style="display: inline-block; background: #22D3A0; color: #0F0F13;
                    padding: 12px 28px; border-radius: 8px; text-decoration: none;
                    font-weight: 700;">
            Pagar ahora con MercadoPago →
          </a>
          <p style="color: #5A5A78; font-size: 12px; margin-top: 24px;">
            Este enlace es seguro y procesado por MercadoPago. Si tienes dudas, contáctanos.
          </p>
        </div>
        {self._email_footer()}
        """

    # ─────────────────────────────────────────────────────────────────────────
    # Template parts
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _email_header() -> str:
        return """
        <div style="font-family: 'Inter', 'Segoe UI', sans-serif; background: #0F0F13;
                    max-width: 600px; margin: 0 auto; border-radius: 14px; overflow: hidden;
                    border: 1px solid #2E2E48;">
          <div style="background: linear-gradient(135deg, #13131E 0%, #1A1042 100%);
                      padding: 28px 40px; border-bottom: 1px solid #2E2E48;">
            <div style="display: flex; align-items: center; gap: 12px;">
              <div>
                <div style="color: #6C63FF; font-size: 20px; font-weight: 800; letter-spacing: 0.5px;">NovaFit</div>
                <div style="color: #5A5A78; font-size: 10px; letter-spacing: 2px;">ANALYTICS SUITE</div>
              </div>
            </div>
          </div>
        """

    @staticmethod
    def _email_footer() -> str:
        return """
          <div style="background: #13131E; padding: 20px 40px;
                      border-top: 1px solid #2E2E48; text-align: center;">
            <p style="color: #5A5A78; font-size: 11px; margin: 0;">
              NovaFit Analytics Suite · Todos los derechos reservados<br>
              Para dejar de recibir estos emails, contactá a tu administrador.
            </p>
          </div>
        </div>
        """
