"""
NovaFit Analytics Suite
========================
INTEGRACIÓN 1b — MercadoPago Webhook Router
=============================================

Handles incoming IPN (Instant Payment Notifications) from MercadoPago.

Webhook flow:
  1. MercadoPago POSTs to /api/v1/webhooks/mercadopago
  2. We verify the HMAC-SHA256 signature
  3. We query the payment by ID to get the current status
  4. We dispatch the event to the appropriate handler based on topic

Reference: https://www.mercadopago.com.ar/developers/es/docs/notifications/webhooks
"""

import logging
from typing import Any, Dict, Optional

from fastapi import APIRouter, Depends, Header, HTTPException, Request, status
from pydantic import BaseModel

from app.core.dependencies import get_mercadopago_service, get_billing_service, get_membership_service
from app.integrations.mercadopago.service import MercadoPagoService
from app.billing.service import BillingService, MembershipService

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/webhooks/mercadopago", tags=["Webhooks — MercadoPago"])


# ─────────────────────────────────────────────────────────────────────────────
# Webhook Payload Schema
# ─────────────────────────────────────────────────────────────────────────────

class MercadoPagoWebhookPayload(BaseModel):
    """MercadoPago IPN notification body."""
    id: Optional[int] = None
    live_mode: Optional[bool] = None
    type: Optional[str] = None          # payment | subscription_preapproval | ...
    date_created: Optional[str] = None
    user_id: Optional[str] = None
    api_version: Optional[str] = None
    action: Optional[str] = None        # payment.created | payment.updated
    data: Optional[Dict[str, Any]] = None


# ─────────────────────────────────────────────────────────────────────────────
# Webhook Endpoint
# ─────────────────────────────────────────────────────────────────────────────

@router.post(
    "",
    status_code=status.HTTP_200_OK,
    summary="MercadoPago IPN Webhook",
    description=(
        "Receives Instant Payment Notifications (IPN) from MercadoPago. "
        "Validates the HMAC-SHA256 signature before processing. "
        "Always returns 200 OK to acknowledge receipt (even on processing errors)."
    ),
    include_in_schema=False,  # Hide from public API docs
)
async def mercadopago_webhook(
    request: Request,
    payload: MercadoPagoWebhookPayload,
    x_signature: Optional[str] = Header(None, alias="x-signature"),
    x_request_id: Optional[str] = Header(None, alias="x-request-id"),
    mp_service: MercadoPagoService = Depends(get_mercadopago_service),
    billing_service: BillingService = Depends(get_billing_service),
    membership_service: MembershipService = Depends(get_membership_service),
) -> Dict[str, str]:
    """
    MercadoPago Webhook handler.

    IMPORTANT: Must always return HTTP 200.
    If we return non-200, MercadoPago will retry the notification
    exponentially for up to 72 hours, flooding our endpoint.

    Processing failures are logged and handled asynchronously.
    """
    data_id = str((payload.data or {}).get("id", ""))

    # ── Signature verification ─────────────────────────────────────────────────
    if x_signature and x_request_id and data_id:
        is_valid = mp_service.verify_webhook_signature(
            x_signature=x_signature,
            x_request_id=x_request_id,
            data_id=data_id,
        )
        if not is_valid:
            logger.warning(
                "Invalid MercadoPago webhook signature — ignoring. "
                "action=%s data_id=%s", payload.action, data_id
            )
            # Return 200 to avoid MercadoPago retries, but don't process
            return {"status": "ignored", "reason": "invalid_signature"}
    else:
        logger.warning(
            "MercadoPago webhook missing signature headers. action=%s", payload.action
        )

    # ── Route by event type ────────────────────────────────────────────────────
    logger.info(
        "MercadoPago webhook received: type=%s action=%s data_id=%s",
        payload.type, payload.action, data_id,
    )

    try:
        if payload.type == "payment" and data_id:
            await _handle_payment_notification(data_id, mp_service, billing_service)
        elif payload.type == "subscription_preapproval":
            await _handle_subscription_notification(data_id, payload.action, membership_service)
        else:
            logger.info(
                "Unhandled MercadoPago webhook type=%s — acknowledged but not processed.",
                payload.type,
            )
    except Exception as exc:
        # Log but NEVER raise — must return 200
        logger.error(
            "Error processing MercadoPago webhook type=%s data_id=%s: %s",
            payload.type, data_id, exc, exc_info=True,
        )

    return {"status": "received"}


async def _handle_payment_notification(
    payment_id: str,
    mp_service: MercadoPagoService,
    billing_service: BillingService,
) -> None:
    """
    Queries MercadoPago for the full payment status and dispatches
    the appropriate internal event.

    Flow:
      1. Query MP for payment status (approved/rejected/pending)
      2. Find our invoice by external_reference (= invoice UUID)
      3. If approved → mark invoice PAID, activate/renew membership
      4. If rejected → mark invoice FAILED, send alert notification
    """
    payment = await mp_service.get_payment_status(payment_id)

    logger.info(
        "Payment notification: id=%s status=%s external_ref=%s amount=%s",
        payment.payment_id,
        payment.status,
        payment.external_reference,
        payment.transaction_amount,
    )

    if not payment.external_reference:
        logger.warning(f"Payment {payment.payment_id} has no external_reference. Skipping.")
        return

    try:
        invoice_uuid = uuid.UUID(payment.external_reference)
    except ValueError:
        logger.warning(f"Payment external_reference '{payment.external_reference}' is not a valid UUID.")
        return

    invoice = await billing_service.get_invoice_by_id(invoice_uuid)
    if not invoice:
        logger.warning(f"Invoice {invoice_uuid} not found for payment {payment.payment_id}.")
        return

    if payment.is_approved:
        await billing_service.mark_invoice_paid(
            invoice_id=invoice.id,
            gateway="mercadopago",
            transaction_amount=payment.transaction_amount,
            gateway_payment_id=payment.payment_id,
            date_approved=payment.date_approved,
        )
    elif payment.is_failed:
        await billing_service.mark_invoice_failed(invoice.id, payment.status_detail or "Failed")


async def _handle_subscription_notification(
    preapproval_id: str,
    action: Optional[str],
    membership_service: MembershipService,
) -> None:
    """
    Handles preapproval (subscription) lifecycle events.

    Actions: created | updated | cancelled
    """
    logger.info(
        "Subscription notification: preapproval_id=%s action=%s",
        preapproval_id, action,
    )
    await membership_service.sync_subscription_status(preapproval_id, action)
