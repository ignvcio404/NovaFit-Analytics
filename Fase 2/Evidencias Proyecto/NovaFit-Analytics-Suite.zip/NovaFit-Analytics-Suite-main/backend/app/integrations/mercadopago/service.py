"""
NovaFit Analytics Suite
========================
INTEGRACIÓN 1 — MercadoPago API
=================================

Implementa el SDK de MercadoPago usando su API REST directamente via httpx.
Se evita el SDK oficial para mayor control sobre errores, logging y retries.

Endpoints cubiertos:
  - Crear Preference (checkout button / QR)
  - Crear Preapproval (suscripción recurrente)
  - Consultar estado de pago
  - Manejar webhooks IPN

Documentación oficial: https://www.mercadopago.com.ar/developers/es/reference
"""

import hashlib
import hmac
import logging
from dataclasses import dataclass, field
from datetime import datetime, timedelta, timezone
from decimal import Decimal
from typing import Any, Dict, List, Optional
from uuid import UUID

import httpx

from app.core.config import settings
from app.core.errors import MercadoPagoException

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class MPItem:
    """A line item within a MercadoPago Preference."""
    title: str
    quantity: int
    unit_price: Decimal
    currency_id: str = "ARS"
    description: Optional[str] = None
    category_id: Optional[str] = "services"  # MercadoPago category


@dataclass
class MPPayer:
    """Payer information attached to a Preference."""
    name: str
    surname: str
    email: str
    phone_number: Optional[str] = None
    identification_type: Optional[str] = "DNI"
    identification_number: Optional[str] = None


@dataclass
class MPPreferenceResult:
    """Parsed result after creating a MercadoPago Preference."""
    preference_id: str
    init_point: str           # Production checkout URL
    sandbox_init_point: str   # Sandbox checkout URL
    external_reference: str   # Our invoice UUID echoed back
    date_created: str
    raw_response: Dict[str, Any]

    @property
    def checkout_url(self) -> str:
        """Returns the correct URL based on sandbox setting."""
        return self.sandbox_init_point if settings.MERCADOPAGO_SANDBOX else self.init_point


@dataclass
class MPPaymentStatus:
    """Payment status queried from MercadoPago."""
    payment_id: str
    status: str               # approved | pending | rejected | cancelled | in_process
    status_detail: str
    external_reference: Optional[str]
    transaction_amount: Decimal
    currency_id: str
    payment_method_id: Optional[str]
    payment_type_id: Optional[str]
    installments: Optional[int]
    payer_email: Optional[str]
    date_approved: Optional[datetime]
    raw_response: Dict[str, Any]

    @property
    def is_approved(self) -> bool:
        return self.status == "approved"

    @property
    def is_pending(self) -> bool:
        return self.status in ("pending", "in_process", "authorized")

    @property
    def is_failed(self) -> bool:
        return self.status in ("rejected", "cancelled", "refunded", "charged_back")


@dataclass
class MPPreapprovalResult:
    """Result of creating a recurring subscription (preapproval)."""
    preapproval_id: str
    status: str
    init_point: str
    external_reference: Optional[str]
    auto_recurring: Dict[str, Any]
    raw_response: Dict[str, Any]


# ─────────────────────────────────────────────────────────────────────────────
# MercadoPago Service
# ─────────────────────────────────────────────────────────────────────────────

class MercadoPagoService:
    """
    Functional MercadoPago API integration service.

    All HTTP calls are made with httpx. Errors are wrapped in
    MercadoPagoException for clean handling in the business layer.

    Authentication: Bearer token via MERCADOPAGO_ACCESS_TOKEN in settings.

    Usage:
        service = MercadoPagoService()
        result = await service.create_preference(
            invoice_id=invoice.id,
            items=[MPItem("Plan Premium", 1, Decimal("9999.00"))],
            payer=MPPayer("Juan", "Pérez", "juan@example.com"),
        )
        redirect_url = result.checkout_url
    """

    _BASE_URL = "https://api.mercadopago.com"
    _TIMEOUT  = 20.0  # seconds

    def __init__(self) -> None:
        self._access_token = settings.MERCADOPAGO_ACCESS_TOKEN
        self._sandbox = settings.MERCADOPAGO_SANDBOX
        self._webhook_secret = settings.MERCADOPAGO_WEBHOOK_SECRET

    # ─────────────────────────────────────────────────────────────────────────
    # HTTP Client
    # ─────────────────────────────────────────────────────────────────────────

    def _get_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._BASE_URL,
            headers={
                "Authorization": f"Bearer {self._access_token}",
                "Content-Type": "application/json",
                "X-Idempotency-Key": "",  # Set per-request below
            },
            timeout=self._TIMEOUT,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # FLOW 1 — Create Payment Preference (Checkout Button / QR)
    # ─────────────────────────────────────────────────────────────────────────

    async def create_preference(
        self,
        invoice_id: UUID,
        items: List[MPItem],
        payer: MPPayer,
        back_url_success: str = "https://novafit.com/payment/success",
        back_url_failure: str = "https://novafit.com/payment/failure",
        back_url_pending: str = "https://novafit.com/payment/pending",
        expires_in_hours: int = 24,
    ) -> MPPreferenceResult:
        """
        Creates a MercadoPago Preference — the entry point for all checkout flows.

        A Preference generates:
          - `init_point`: URL for the standard checkout (web redirect)
          - `sandbox_init_point`: URL for sandbox testing

        The `external_reference` is set to our invoice UUID so that when
        MercadoPago sends a webhook notification, we can match it back to
        our internal invoice.

        Args:
            invoice_id:       Our internal Invoice UUID (becomes external_reference)
            items:            List of MPItem objects (plan, product, etc.)
            payer:            Pre-filled payer information
            back_url_success: Redirect after successful payment
            back_url_failure: Redirect after failed payment
            back_url_pending: Redirect while payment is in_process
            expires_in_hours: Preference auto-expires after this many hours

        Returns:
            MPPreferenceResult with checkout URLs

        Raises:
            MercadoPagoException: On HTTP errors or invalid response structure
        """
        expiration_date = (
            datetime.now(timezone.utc) + timedelta(hours=expires_in_hours)
        ).isoformat(timespec='milliseconds')

        payload = {
            "items": [
                {
                    "id": f"NOVAFIT-{str(invoice_id)[:8].upper()}",
                    "title": item.title,
                    "description": item.description or item.title,
                    "quantity": item.quantity,
                    "currency_id": item.currency_id,
                    "unit_price": float(item.unit_price),
                    "category_id": item.category_id,
                }
                for item in items
            ],
            "payer": {
                "name": payer.name,
                "surname": payer.surname,
                "email": payer.email,
                **(
                    {
                        "phone": {"area_code": "", "number": payer.phone_number},
                    }
                    if payer.phone_number
                    else {}
                ),
                **(
                    {
                        "identification": {
                            "type": payer.identification_type,
                            "number": payer.identification_number,
                        }
                    }
                    if payer.identification_number
                    else {}
                ),
            },
            "back_urls": {
                "success": back_url_success,
                "failure": back_url_failure,
                "pending": back_url_pending,
            },
            "auto_return": "approved",       # Auto-redirect on approved payments
            "external_reference": str(invoice_id),
            "notification_url": f"{settings.API_V1_PREFIX}/webhooks/mercadopago",
            "statement_descriptor": "NOVAFIT GYM",
            "expires": True,
            "expiration_date_to": expiration_date,
            "payment_methods": {
                "excluded_payment_methods": [],
                "excluded_payment_types": [],
                "installments": 12,          # Allow up to 12 installments
            },
            "binary_mode": False,            # Allow pending states
            "metadata": {
                "invoice_id": str(invoice_id),
                "source": "novafit_backend",
                "environment": "sandbox" if self._sandbox else "production",
            },
        }

        logger.info(
            "Creating MercadoPago preference for invoice=%s payer=%s",
            invoice_id, payer.email,
        )

        async with self._get_client() as client:
            try:
                response = await client.post(
                    "/checkout/preferences",
                    json=payload,
                    headers={"X-Idempotency-Key": str(invoice_id)},
                )
                data = self._handle_response(response, "create_preference")
            except httpx.TimeoutException as exc:
                raise MercadoPagoException(
                    f"Timeout creating preference for invoice {invoice_id}"
                ) from exc
            except httpx.ConnectError as exc:
                raise MercadoPagoException(
                    "Could not connect to MercadoPago API"
                ) from exc

        result = MPPreferenceResult(
            preference_id=data["id"],
            init_point=data["init_point"],
            sandbox_init_point=data["sandbox_init_point"],
            external_reference=data.get("external_reference", str(invoice_id)),
            date_created=data.get("date_created", ""),
            raw_response=data,
        )

        logger.info(
            "MercadoPago preference created: id=%s url=%s",
            result.preference_id,
            result.checkout_url,
        )
        return result

    # ─────────────────────────────────────────────────────────────────────────
    # FLOW 2 — Create Subscription (Preapproval)
    # ─────────────────────────────────────────────────────────────────────────

    async def create_subscription(
        self,
        membership_id: UUID,
        plan_title: str,
        amount: Decimal,
        payer_email: str,
        frequency: int = 1,
        frequency_type: str = "months",  # days | months
        transaction_amount: Optional[Decimal] = None,
    ) -> MPPreapprovalResult:
        """
        Creates a recurring auto-charge subscription (Preapproval).

        Used when a member enables `auto_renew` on their membership.
        MercadoPago will automatically charge on the next billing cycle.

        The `preapproval_id` is stored in `memberships.external_subscription_id`.

        Args:
            membership_id:        Our internal Membership UUID
            plan_title:           Display name for the subscription
            amount:               Recurring amount per cycle
            payer_email:          Member's email (must have MP account)
            frequency:            How often to charge (e.g. 1)
            frequency_type:       Unit: 'months' or 'days'
            transaction_amount:   Optional one-time setup charge

        Returns:
            MPPreapprovalResult with preapproval_id for storage
        """
        payload = {
            "reason": plan_title,
            "external_reference": str(membership_id),
            "payer_email": payer_email,
            "auto_recurring": {
                "frequency": frequency,
                "frequency_type": frequency_type,
                "transaction_amount": float(amount),
                "currency_id": "ARS",
            },
            "back_url": f"https://novafit.com/membership/{membership_id}/subscription",
            "notification_url": f"{settings.API_V1_PREFIX}/webhooks/mercadopago/subscription",
            "status": "pending",
        }

        logger.info(
            "Creating MercadoPago subscription for membership=%s plan=%r amount=%s",
            membership_id, plan_title, amount,
        )

        async with self._get_client() as client:
            response = await client.post(
                "/preapproval",
                json=payload,
                headers={"X-Idempotency-Key": str(membership_id)},
            )
            data = self._handle_response(response, "create_subscription")

        result = MPPreapprovalResult(
            preapproval_id=data["id"],
            status=data["status"],
            init_point=data["init_point"],
            external_reference=data.get("external_reference"),
            auto_recurring=data.get("auto_recurring", {}),
            raw_response=data,
        )

        logger.info(
            "MercadoPago subscription created: preapproval_id=%s status=%s",
            result.preapproval_id, result.status,
        )
        return result

    # ─────────────────────────────────────────────────────────────────────────
    # FLOW 3 — Query Payment Status
    # ─────────────────────────────────────────────────────────────────────────

    async def get_payment_status(self, payment_id: str) -> MPPaymentStatus:
        """
        Queries the current status of a specific payment by ID.

        Called after receiving a webhook notification to verify and
        confirm the payment before marking the invoice as PAID.

        Args:
            payment_id: The `mp_payment_id` from mercadopago_transactions table

        Returns:
            MPPaymentStatus with is_approved / is_pending / is_failed properties
        """
        logger.info("Querying MercadoPago payment status: payment_id=%s", payment_id)

        async with self._get_client() as client:
            response = await client.get(f"/v1/payments/{payment_id}")
            data = self._handle_response(response, "get_payment_status")

        date_approved = None
        if data.get("date_approved"):
            try:
                date_approved = datetime.fromisoformat(
                    data["date_approved"].replace("Z", "+00:00")
                )
            except (ValueError, AttributeError):
                pass

        return MPPaymentStatus(
            payment_id=str(data["id"]),
            status=data["status"],
            status_detail=data.get("status_detail", ""),
            external_reference=data.get("external_reference"),
            transaction_amount=Decimal(str(data.get("transaction_amount", 0))),
            currency_id=data.get("currency_id", "ARS"),
            payment_method_id=data.get("payment_method_id"),
            payment_type_id=data.get("payment_type_id"),
            installments=data.get("installments"),
            payer_email=data.get("payer", {}).get("email"),
            date_approved=date_approved,
            raw_response=data,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # FLOW 4 — Webhook Signature Verification
    # ─────────────────────────────────────────────────────────────────────────

    def verify_webhook_signature(
        self,
        x_signature: str,
        x_request_id: str,
        data_id: str,
    ) -> bool:
        """
        Verifies the HMAC-SHA256 signature of an incoming MercadoPago webhook.

        MercadoPago signs webhooks using the format:
            `id:<data.id>;request-id:<x-request-id>;ts:<ts>;`

        Where `ts` is extracted from `x-signature` header:
            `ts=<timestamp>,v1=<hash>`

        This prevents replay attacks and unauthorized webhook calls.

        Returns:
            True if the signature is valid, False otherwise.
        """
        try:
            # Parse ts and v1 from "ts=1704067200,v1=abc123..."
            parts = dict(part.split("=", 1) for part in x_signature.split(","))
            ts = parts.get("ts", "")
            received_hash = parts.get("v1", "")

            # Reconstruct the signed manifest
            manifest = f"id:{data_id};request-id:{x_request_id};ts:{ts};"

            # Compute expected HMAC-SHA256
            expected_hash = hmac.new(
                key=self._webhook_secret.encode("utf-8"),
                msg=manifest.encode("utf-8"),
                digestmod=hashlib.sha256,
            ).hexdigest()

            is_valid = hmac.compare_digest(expected_hash, received_hash)

            if not is_valid:
                logger.warning(
                    "MercadoPago webhook signature mismatch! "
                    "data_id=%s request_id=%s", data_id, x_request_id
                )
            return is_valid

        except Exception as exc:
            logger.error("Webhook signature verification failed: %s", exc)
            return False

    # ─────────────────────────────────────────────────────────────────────────
    # Error handling
    # ─────────────────────────────────────────────────────────────────────────

    def _handle_response(
        self, response: httpx.Response, operation: str
    ) -> Dict[str, Any]:
        """
        Centralized response handler for MercadoPago API calls.

        Logs the response and raises MercadoPagoException on errors.
        MercadoPago uses non-standard error structures, so we normalize them.
        """
        logger.debug(
            "MercadoPago %s → HTTP %d", operation, response.status_code
        )

        if response.status_code in (200, 201):
            return response.json()

        # Parse MercadoPago error body
        try:
            error_data = response.json()
            mp_error_msg = error_data.get("message", "") or error_data.get("error", "")
            mp_cause = error_data.get("cause", [])
            cause_desc = (
                mp_cause[0].get("description", "") if mp_cause else ""
            )
            detail = f"{mp_error_msg}: {cause_desc}".strip(": ")
        except Exception:
            detail = f"HTTP {response.status_code}"

        logger.error(
            "MercadoPago API error [%s]: HTTP %d — %s",
            operation, response.status_code, detail,
        )

        if response.status_code == 401:
            raise MercadoPagoException(
                "Invalid MercadoPago access token. Check MERCADOPAGO_ACCESS_TOKEN in settings."
            )
        if response.status_code == 400:
            raise MercadoPagoException(f"Bad request to MercadoPago [{operation}]: {detail}")
        if response.status_code == 404:
            raise MercadoPagoException(f"MercadoPago resource not found [{operation}]: {detail}")
        if response.status_code == 422:
            raise MercadoPagoException(f"MercadoPago validation error [{operation}]: {detail}")

        raise MercadoPagoException(
            f"MercadoPago API error [{operation}] HTTP {response.status_code}: {detail}"
        )
