"""
NovaFit Analytics Suite
========================
INTEGRACIÓN 4 — Wger REST API
================================

Sincroniza el catálogo de ejercicios desde Wger (open-source exercise DB).
Wger expone +1400 ejercicios con músculos, equipamiento y traducciones.

Flujos implementados:
  1. Full sync (primer uso / reconstrucción)
  2. Incremental sync (nuevos ejercicios desde última sync)
  3. Búsqueda de ejercicios por nombre o músculo
  4. Fetch de info de músculo por ID

Documentación: https://wger.de/api/v2/
"""

import logging
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx

from app.core.config import settings
from app.core.errors import WgerException

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WgerMuscle:
    """A muscle group from the Wger catalog."""
    id: int
    name_en: str
    is_front: bool


@dataclass
class WgerExercise:
    """A single exercise fetched from the Wger API."""
    wger_id: int
    name: str
    description_html: str
    category_id: int
    category_name: str
    language_code: str
    primary_muscles: List[WgerMuscle] = field(default_factory=list)
    secondary_muscles: List[WgerMuscle] = field(default_factory=list)
    equipment_ids: List[int] = field(default_factory=list)
    equipment_names: List[str] = field(default_factory=list)
    aliases: List[str] = field(default_factory=list)
    license_short_name: Optional[str] = None

    def is_valid_for_import(self) -> bool:
        """An exercise must have a name and a category to be importable."""
        return bool(self.name.strip()) and self.category_id is not None


@dataclass
class WgerSyncResult:
    """Result of a catalog sync operation."""
    exercises_fetched: int
    exercises_created: int
    exercises_updated: int
    exercises_skipped: int
    errors: List[str] = field(default_factory=list)
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None

    def mark_complete(self) -> None:
        self.completed_at = datetime.now(timezone.utc)

    @property
    def duration_seconds(self) -> Optional[float]:
        if self.completed_at:
            return (self.completed_at - self.started_at).total_seconds()
        return None


# ─────────────────────────────────────────────────────────────────────────────
# Wger API Service
# ─────────────────────────────────────────────────────────────────────────────

class WgerService:
    """
    Wger REST API integration for exercise catalog management.

    Wger is an open-source fitness/exercise database with:
    - 1400+ exercises in multiple languages
    - Categorized by muscle group and equipment
    - Translatable (Spanish support via language=8)

    API is public (no auth required for GET requests).
    Rate limit: ~100 req/s (self-hosted) / be gentle with public API.

    Spanish exercises: Use language=8 (Español) in API calls.

    Usage:
        service = WgerService()
        result = await service.sync_full_catalog(language_id=8)
        print(f"Imported {result.exercises_created} exercises")
    """

    _BASE_URL = "https://wger.de/api/v2"
    _LANGUAGE_SPANISH = 2   # Wger language ID (often 2 is Spanish in their DB)
    _LANGUAGE_ENGLISH = 2   # Fallback
    _PAGE_SIZE = 100         # Max exercises per page (Wger max is 100)
    _TIMEOUT = 30.0

    def __init__(self) -> None:
        # Wger Base URL can point to a self-hosted instance
        self._base_url = getattr(settings, "WGER_BASE_URL", self._BASE_URL)

    # ─────────────────────────────────────────────────────────────────────────
    # Public Methods
    # ─────────────────────────────────────────────────────────────────────────

    async def search_exercises(
        self,
        query: str,
        language_id: int = _LANGUAGE_SPANISH,
        limit: int = 20,
    ) -> List[WgerExercise]:
        """
        Searches Wger exercise catalog by name.

        Uses the Wger search endpoint which returns exercises matching
        the query in the specified language.

        Args:
            query:       Search string (e.g. "press de banca", "bench press")
            language_id: Wger language ID (8=Spanish, 2=English)
            limit:       Maximum results to return

        Returns:
            List of WgerExercise objects sorted by relevance
        """
        logger.info("Wger exercise search: query=%r language=%d", query, language_id)

        params = {
            "term": query,
            "format": "json",
        }

        async with self._get_client() as client:
            try:
                response = await client.get("/exercise/search/", params=params)
                response.raise_for_status()
            except httpx.HTTPError as exc:
                logger.error(f"Wger HTTP error during search: {exc}")
                return []
            except Exception as exc:
                logger.error(f"Wger unexpected error during search: {exc}")
                return []

        data = response.json()
        suggestions = data.get("suggestions", [])[:limit]

        exercises = []
        for suggestion in suggestions:
            exercise_data = suggestion.get("data", {})
            exercises.append(WgerExercise(
                wger_id=exercise_data.get("id", 0),
                name=suggestion.get("value", ""),
                description_html=exercise_data.get("description", ""),
                category_id=exercise_data.get("category", {}).get("id", 0),
                category_name=exercise_data.get("category", {}).get("name", ""),
                language_code="es" if language_id == self._LANGUAGE_SPANISH else "en",
                primary_muscles=[
                    WgerMuscle(
                        id=m.get("id", 0),
                        name_en=m.get("name_en", ""),
                        is_front=m.get("is_front", True),
                    )
                    for m in exercise_data.get("muscles", [])
                ],
            ))

        return exercises

    async def sync_full_catalog(
        self,
        language_id: int = _LANGUAGE_SPANISH,
        exercise_repo=None,  # AbstractExerciseRepository (injected in production)
    ) -> WgerSyncResult:
        """
        Performs a full synchronization of the Wger exercise catalog.

        Fetches ALL exercises paginated from the Wger API and upserts
        them into our local exercise_catalog table.

        This is designed to be run:
          - On first setup (via management command)
          - Periodically (e.g. weekly via cron job)

        Performance: ~1400 exercises at 100/page = 14-15 API calls
        Estimated time: ~30-60 seconds depending on network

        Args:
            language_id:   Wger language ID (8=Spanish)
            exercise_repo: Injected repository for database writes

        Returns:
            WgerSyncResult with counts and any errors encountered
        """
        result = WgerSyncResult(exercises_fetched=0, exercises_created=0,
                                exercises_updated=0, exercises_skipped=0)

        logger.info("Starting Wger full catalog sync (language=%d)…", language_id)

        try:
            all_exercises = await self._fetch_all_exercises_paginated(language_id)
            result.exercises_fetched = len(all_exercises)
            logger.info("Fetched %d exercises from Wger", len(all_exercises))
        except WgerException as exc:
            result.errors.append(str(exc))
            result.mark_complete()
            return result

        # ── Upsert into database ───────────────────────────────────────────────
        for exercise in all_exercises:
            if not exercise.is_valid_for_import():
                result.exercises_skipped += 1
                continue

            try:
                if exercise_repo:
                    created = await exercise_repo.upsert_from_wger(exercise)
                    if created:
                        result.exercises_created += 1
                    else:
                        result.exercises_updated += 1
                else:
                    # Dry-run mode: just count
                    result.exercises_created += 1

            except Exception as exc:
                error_msg = f"Failed to upsert exercise wger_id={exercise.wger_id}: {exc}"
                logger.error(error_msg)
                result.errors.append(error_msg)
                result.exercises_skipped += 1

        result.mark_complete()
        logger.info(
            "Wger sync complete: fetched=%d created=%d updated=%d skipped=%d errors=%d "
            "(%.1fs)",
            result.exercises_fetched, result.exercises_created, result.exercises_updated,
            result.exercises_skipped, len(result.errors), result.duration_seconds or 0,
        )
        return result

    async def get_exercise_detail(self, wger_exercise_id: int) -> WgerExercise:
        """
        Fetches full details for a specific Wger exercise ID.

        Used to enrich exercise records with full muscle/equipment data.
        """
        logger.debug("Fetching Wger exercise detail: id=%d", wger_exercise_id)

        async with self._get_client() as client:
            response = await client.get(
                f"/exerciseinfo/{wger_exercise_id}/",
                params={"format": "json"},
            )

        if response.status_code == 404:
            raise WgerException(f"Wger exercise ID {wger_exercise_id} not found.")
        if response.status_code != 200:
            raise WgerException(
                f"Wger exerciseinfo returned HTTP {response.status_code}"
            )

        return self._parse_exercise_info(response.json())

    async def get_muscle_list(self) -> List[WgerMuscle]:
        """Fetches the complete muscle group list from Wger."""
        async with self._get_client() as client:
            response = await client.get("/muscle/", params={"format": "json", "limit": 100})

        if response.status_code != 200:
            raise WgerException(f"Wger muscle list HTTP {response.status_code}")

        data = response.json()
        return [
            WgerMuscle(
                id=m["id"],
                name_en=m["name_en"],
                is_front=m.get("is_front", True),
            )
            for m in data.get("results", [])
        ]

    # ─────────────────────────────────────────────────────────────────────────
    # Internal
    # ─────────────────────────────────────────────────────────────────────────

    async def _fetch_all_exercises_paginated(
        self, language_id: int
    ) -> List[WgerExercise]:
        """
        Fetches all exercise pages from the Wger API.

        Wger paginates with `next` URL — we follow until `next` is null.
        """
        all_exercises: List[WgerExercise] = []
        url = "/exerciseinfo/"
        params: Dict[str, Any] = {
            "format": "json",
            "language": language_id,
            "limit": self._PAGE_SIZE,
            "offset": 0,
        }

        async with self._get_client() as client:
            while url:
                try:
                    response = await client.get(url, params=params)
                except httpx.ConnectError as exc:
                    raise WgerException(f"Cannot connect to Wger API: {exc}") from exc
                except httpx.TimeoutException as exc:
                    raise WgerException("Wger API timed out during pagination.") from exc

                if response.status_code != 200:
                    raise WgerException(
                        f"Wger pagination error: HTTP {response.status_code} at {url}"
                    )

                data = response.json()
                exercises = data.get("results", [])

                for raw_exercise in exercises:
                    try:
                        exercise = self._parse_exercise_info(raw_exercise)
                        all_exercises.append(exercise)
                    except Exception as exc:
                        logger.warning(
                            "Failed to parse Wger exercise: %s", exc
                        )

                # Follow pagination
                next_url = data.get("next")
                if next_url:
                    # Wger returns full absolute URL for next page
                    # Strip the base URL and use relative path
                    url = next_url.replace(self._base_url, "")
                    params = {}  # Params are already in the next URL
                else:
                    url = None  # Done

                logger.debug(
                    "Wger pagination: fetched %d total so far, next=%s",
                    len(all_exercises), next_url,
                )

        return all_exercises

    def _parse_exercise_info(self, data: Dict[str, Any]) -> WgerExercise:
        """Parses a Wger exerciseinfo response into a WgerExercise DTO."""
        # Get the English or first translation
        translations = data.get("translations", [])
        name = ""
        description = ""
        lang_code = "en"

        # Prefer Spanish translation; fall back to English
        for t in translations:
            if t.get("language") == self._LANGUAGE_SPANISH:
                name = t.get("name", "").strip()
                description = t.get("description", "")
                lang_code = "es"
                break

        if not name:
            for t in translations:
                if t.get("language") == self._LANGUAGE_ENGLISH:
                    name = t.get("name", "").strip()
                    description = t.get("description", "")
                    lang_code = "en"
                    break

        if not name and translations:
            name = translations[0].get("name", "").strip()
            lang_code = "unknown"

        category = data.get("category", {}) or {}
        equipment_list = data.get("equipment", []) or []
        muscles_list = data.get("muscles", []) or []
        muscles_sec_list = data.get("muscles_secondary", []) or []

        return WgerExercise(
            wger_id=data.get("id", 0),
            name=name,
            description_html=description,
            category_id=category.get("id", 0),
            category_name=category.get("name", ""),
            language_code=lang_code,
            primary_muscles=[
                WgerMuscle(
                    id=m.get("id", 0),
                    name_en=m.get("name_en", ""),
                    is_front=m.get("is_front", True),
                )
                for m in muscles_list
            ],
            secondary_muscles=[
                WgerMuscle(
                    id=m.get("id", 0),
                    name_en=m.get("name_en", ""),
                    is_front=m.get("is_front", True),
                )
                for m in muscles_sec_list
            ],
            equipment_names=[eq.get("name", "") for eq in equipment_list],
            equipment_ids=[eq.get("id", 0) for eq in equipment_list],
        )

    def _get_client(self) -> httpx.AsyncClient:
        return httpx.AsyncClient(
            base_url=self._base_url,
            headers={"Accept": "application/json"},
            timeout=self._TIMEOUT,
        )
