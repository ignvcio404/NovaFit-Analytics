import os
import httpx
from typing import List, Dict, Any, Optional
from pydantic import BaseModel

class ExerciseDBExercise(BaseModel):
    id: str
    name: str
    bodyPart: str = ""
    equipment: str = ""
    target: str = ""
    gifUrl: str = ""
    instructions: List[str] = []
    secondaryMuscles: List[str] = []

class ExerciseDBClient:
    def __init__(self):
        self.api_key = os.getenv("RAPIDAPI_KEY")
        if not self.api_key:
            raise ValueError("RAPIDAPI_KEY environment variable not set")
        
        self.base_url = "https://exercisedb.p.rapidapi.com"
        self.headers = {
            "x-rapidapi-key": self.api_key,
            "x-rapidapi-host": "exercisedb.p.rapidapi.com"
        }

    async def search_exercises(self, query: str, limit: int = 20) -> List[ExerciseDBExercise]:
        """Search exercises by name."""
        url = f"{self.base_url}/exercises/name/{query}"
        params = {"limit": limit}
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.get(url, headers=self.headers, params=params, timeout=10.0)
                response.raise_for_status()
                data = response.json()
                
                # Depending on the query and limit, we return parsed models
                results = []
                for item in data:
                    results.append(ExerciseDBExercise(**item))
                
                return results
            except httpx.HTTPStatusError as exc:
                print(f"HTTPStatusError fetching from ExerciseDB: {exc.response.text}")
                return []
            except Exception as e:
                print(f"Error fetching from ExerciseDB: {e}")
                return []
