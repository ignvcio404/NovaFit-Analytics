"""
NovaFit Analytics Suite
========================
INTEGRACIÓN 3 — WhatsApp Cloud API (Meta)
==========================================

Envío de notificaciones de WhatsApp usando la Meta Graph API.
Soporta mensajes de texto, templates aprobados y mensajes interactivos.

Mensajes enviados:
  - Confirmación de sesión completada (post-workout)
  - Alerta de semana de descarga (deload)
  - Recordatorio de pago vencido
  - Bienvenida al nuevo socio

Documentación: https://developers.facebook.com/docs/whatsapp/cloud-api
Autenticación: Meta User Access Token (permanente) o System User Token
"""

import logging
from dataclasses import dataclass
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

import httpx

from app.core.config import settings
from app.core.errors import WhatsAppException

logger = logging.getLogger(__name__)


# ─────────────────────────────────────────────────────────────────────────────
# Data Transfer Objects
# ─────────────────────────────────────────────────────────────────────────────

@dataclass
class WhatsAppSendResult:
    """Result of a WhatsApp message send operation."""
    message_id: Optional[str]
    status: str               # accepted | failed
    recipient: str
    sent_at: datetime


# ─────────────────────────────────────────────────────────────────────────────
# WhatsApp Cloud API Service
# ─────────────────────────────────────────────────────────────────────────────

class WhatsAppService:
    """
    Functional WhatsApp Cloud API (Meta Graph API) integration.

    Authentication:
      - Requires a verified Meta Business Account
      - Uses a permanent System User Access Token
      - Stored in WHATSAPP_ACCESS_TOKEN in settings

    Phone numbers:
      - All numbers must be in E.164 format (+54911XXXXXXXX for Argentina)
      - The recipient must have opted-in to receive messages
      - For Template messages: no opt-in required within 24h window

    Rate limits:
      - 250 messages per second (business tier)
      - 1000 unique contacts per day (free tier)

    Usage:
        service = WhatsAppService()
        await service.send_text_message(
            to_phone="+5491122334455",
            message="Tu sesión fue registrada exitosamente 💪"
        )
    """

    _GRAPH_API_BASE = "https://graph.facebook.com/v25.0"
    _TIMEOUT        = 15.0

    def __init__(self) -> None:
        self._access_token   = settings.WHATSAPP_ACCESS_TOKEN
        self._phone_number_id = settings.WHATSAPP_PHONE_NUMBER_ID  # From Meta dashboard

    # ─────────────────────────────────────────────────────────────────────────
    # Public Methods
    # ─────────────────────────────────────────────────────────────────────────

    async def send_text_message(
        self,
        to_phone: str,
        message: str,
        preview_url: bool = False,
    ) -> WhatsAppSendResult:
        """
        Sends a plain text WhatsApp message.

        Note: Text messages can ONLY be sent within a 24-hour customer service
        window (after the recipient last messaged us). For proactive notifications
        outside the window, use send_template_message() instead.

        Args:
            to_phone:    Recipient phone in E.164 format (+5491122334455)
            message:     Message text (max 4096 chars, supports *bold*, _italic_)
            preview_url: Generate link preview for URLs in message

        Returns:
            WhatsAppSendResult with message_id on success
        """
        to_phone = self._normalize_phone(to_phone)
        payload = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_phone,
            "type": "text",
            "text": {
                "body": message,
                "preview_url": preview_url,
            },
        }
        return await self._send(to_phone=to_phone, payload=payload)

    async def send_deload_alert(
        self,
        to_phone: str,
        member_first_name: str,
        fatigue_score: float,
        acwr: Optional[float] = None,
    ) -> WhatsAppSendResult:
        """
        Deload recommendation notification via template 'novafit_alerta_fatiga'.

        Template variables:
          {{1}} → nombre del usuario
          {{2}} → puntaje de fatiga (0-100)
          {{3}} → ratio ACWR

        Uses a pre-approved Meta template to bypass the 24h conversation
        window restriction. Messages are delivered regardless of user activity.
        """
        components = [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text": member_first_name},
                    {"type": "text", "text": f"{fatigue_score:.0f}"},
                    {"type": "text", "text": f"{acwr:.2f}" if acwr else "N/A"},
                ],
            }
        ]
        return await self.send_template_message(
            to_phone=to_phone,
            template_name="novafit_alerta_fatiga",
            template_language="es",
            components=components,
        )

    async def send_session_completion(
        self,
        to_phone: str,
        member_first_name: str,
        session_name: str,
        total_sets: int,
        volume_load_kg: float,
        avg_rpe: Optional[float] = None,
    ) -> WhatsAppSendResult:
        """
        Post-workout completion notification via template 'novafit_sesion_completada'.

        Template variables:
          {{1}} → nombre del usuario
          {{2}} → nombre de la rutina/sesion
          {{3}} → series completadas
          {{4}} → volumen total en kg

        Triggered by RoutineService after a session is successfully persisted.
        """
        components = [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text": member_first_name},
                    {"type": "text", "text": session_name},
                    {"type": "text", "text": str(total_sets)},
                    {"type": "text", "text": f"{volume_load_kg:,.0f}"},
                ],
            }
        ]
        return await self.send_template_message(
            to_phone=to_phone,
            template_name="novafit_sesion_completada",
            template_language="es",
            components=components,
        )

    async def send_payment_confirmation(
        self,
        to_phone: str,
        member_first_name: str,
        invoice_number: str,
        amount,
        plan_name: str,
    ) -> WhatsAppSendResult:
        """
        Payment confirmation via template 'novafit_pago_confirmado'.

        Template variables:
          {{1}} → nombre del usuario
          {{2}} → numero de comprobante
          {{3}} → plan contratado
          {{4}} → monto en ARS
        """
        components = [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text": member_first_name},
                    {"type": "text", "text": str(invoice_number)},
                    {"type": "text", "text": str(plan_name)},
                    {"type": "text", "text": f"{amount:,.0f}"},
                ],
            }
        ]
        return await self.send_template_message(
            to_phone=to_phone,
            template_name="novafit_pago_confirmado",
            template_language="es",
            components=components,
        )

    async def send_membership_expiry_reminder(
        self,
        to_phone: str,
        member_first_name: str,
        days_remaining: int,
        plan_name: str,
        renewal_url: str,
    ) -> WhatsAppSendResult:
        """
        Membership expiry reminder via template 'novafit_membresia_vence'.

        Template variables:
          {{1}} → nombre del usuario
          {{2}} → nombre del plan
          {{3}} → dias restantes
          {{4}} → URL de renovacion
        """
        components = [
            {
                "type": "body",
                "parameters": [
                    {"type": "text", "text": member_first_name},
                    {"type": "text", "text": str(plan_name)},
                    {"type": "text", "text": str(days_remaining)},
                    {"type": "text", "text": renewal_url},
                ],
            }
        ]
        return await self.send_template_message(
            to_phone=to_phone,
            template_name="novafit_membresia_vence",
            template_language="es",
            components=components,
        )

    async def send_template_message(
        self,
        to_phone: str,
        template_name: str,
        template_language: str = "es_AR",
        components: Optional[List[Dict[str, Any]]] = None,
    ) -> WhatsAppSendResult:
        """
        Sends a pre-approved WhatsApp Business Template message.

        Template messages bypass the 24h conversation window and are
        required for all proactive outbound notifications.

        Templates must be pre-approved in Meta Business Manager:
          https://business.facebook.com/wa/manage/message-templates/

        Args:
            to_phone:          E.164 phone number
            template_name:     Approved template name (snake_case)
            template_language: Template language code (es_AR, en_US, etc.)
            components:        Template variable substitutions

        Example components:
            [
                {
                    "type": "body",
                    "parameters": [
                        {"type": "text", "text": "Juan"},        # {{1}} → name
                        {"type": "text", "text": "Plan Premium"}, # {{2}} → plan
                    ]
                }
            ]
        """
        to_phone = self._normalize_phone(to_phone)
        payload: Dict[str, Any] = {
            "messaging_product": "whatsapp",
            "recipient_type": "individual",
            "to": to_phone,
            "type": "template",
            "template": {
                "name": template_name,
                "language": {"code": template_language},
            },
        }
        if components:
            payload["template"]["components"] = components

        return await self._send(to_phone=to_phone, payload=payload)

    async def send_plan_expiration_reminder(
        self,
        phone: str,
        days_left: int,
        member_first_name: str = "Socio",
        plan_name: str = "Plan NovaFit",
        renewal_url: str = "https://nova-fit-analytics-suite.vercel.app",
    ) -> WhatsAppSendResult:
        """
        Recordatorio de vencimiento de plan via template 'novafit_membresia_vence'.
        Alias de send_membership_expiry_reminder para compatibilidad con billing.
        """
        return await self.send_membership_expiry_reminder(
            to_phone=phone,
            member_first_name=member_first_name,
            days_remaining=days_left,
            plan_name=plan_name,
            renewal_url=renewal_url,
        )

    async def send_fatigue_alert(
        self,
        phone: str,
        user_name: str,
        fatigue_score: float = 0.0,
        acwr: Optional[float] = None,
    ) -> WhatsAppSendResult:
        """
        Alerta de fatiga via template 'novafit_alerta_fatiga'.
        Alias de send_deload_alert para compatibilidad con el notification service.

        Template variables:
          {{1}} → nombre del usuario
          {{2}} → puntaje de fatiga (0-100)
          {{3}} → ratio ACWR
        """
        return await self.send_deload_alert(
            to_phone=phone,
            member_first_name=user_name,
            fatigue_score=fatigue_score,
            acwr=acwr,
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Private / Internal
    # ─────────────────────────────────────────────────────────────────────────

    async def _send(self, to_phone: str, payload: Dict[str, Any]) -> WhatsAppSendResult:
        """
        Core method that makes the HTTP request to the WhatsApp Cloud API.

        Endpoint: POST /v21.0/{phone_number_id}/messages
        """
        url = f"{self._GRAPH_API_BASE}/{self._phone_number_id}/messages"

        logger.info(
            "Sending WhatsApp message: to=%s type=%s",
            to_phone, payload.get("type"),
        )

        async with httpx.AsyncClient(timeout=self._TIMEOUT) as client:
            try:
                response = await client.post(
                    url,
                    headers={
                        "Authorization": f"Bearer {self._access_token}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
            except httpx.ConnectError as exc:
                logger.error(f"WhatsApp Cloud API Error HTTP: {exc}")
                raise WhatsAppException(
                    f"Cannot connect to WhatsApp Cloud API: {exc}"
                ) from exc
            except httpx.TimeoutException as exc:
                logger.error(f"WhatsApp Cloud API Error HTTP: {exc}")
                raise WhatsAppException("WhatsApp Cloud API timed out.") from exc
            except httpx.HTTPError as exc:
                logger.error(f"WhatsApp Cloud API Error HTTP: {exc}")
                raise WhatsAppException(f"Error HTTP comunicando con WhatsApp: {exc}")
            except Exception as exc:
                logger.error(f"Error inesperado WhatsApp API: {exc}")
                raise WhatsAppException(f"Error inesperado enviando WhatsApp: {exc}")

        if response.status_code in (200, 201):
            data = response.json()
            messages = data.get("messages", [])
            message_id = messages[0].get("id") if messages else None

            logger.info(
                "WhatsApp message sent: to=%s message_id=%s", to_phone, message_id
            )
            return WhatsAppSendResult(
                message_id=message_id,
                status="accepted",
                recipient=to_phone,
                sent_at=datetime.now(timezone.utc),
            )

        # ── Error handling ────────────────────────────────────────────────────
        try:
            error_data = response.json()
            error_obj = error_data.get("error", {})
            error_msg = error_obj.get("message", "Unknown error")
            error_code = error_obj.get("code", 0)
            error_subcode = error_obj.get("error_subcode", 0)
        except Exception:
            error_msg = response.text[:200]
            error_code = 0
            error_subcode = 0

        logger.error(
            "WhatsApp API error: HTTP %d code=%d subcode=%d message=%s",
            response.status_code, error_code, error_subcode, error_msg,
        )

        if error_code == 131030:
            raise WhatsAppException(
                f"WhatsApp: Recipient {to_phone} is not a valid WhatsApp number."
            )
        if error_code == 131047:
            raise WhatsAppException(
                f"WhatsApp: Cannot send text message — 24h window has expired. "
                "Use a Template message instead."
            )
        if error_code in (190, 102):
            raise WhatsAppException(
                "WhatsApp: Invalid or expired access token. "
                "Regenerate in Meta Developer Console."
            )

        raise WhatsAppException(
            f"WhatsApp API error (code={error_code}): {error_msg}"
        )

    # ─────────────────────────────────────────────────────────────────────────
    # Utilities
    # ─────────────────────────────────────────────────────────────────────────

    @staticmethod
    def _normalize_phone(phone: str) -> str:
        """
        Normalizes a phone number to E.164 format.

        Examples:
          "+54 9 11 2233-4455" → "+5491122334455"
          "1122334455"         → "+541122334455"   (assumes AR)
        """
        if not phone:
            return ""
        # Remove all non-digits except leading +
        digits = "".join(c for c in phone if c.isdigit())
        if not phone.startswith("+"):
            # Default to Argentina country code
            digits = "54" + digits.lstrip("0")
        return "+" + digits
