"""
NovaFit Analytics Suite
========================
Billing Service
========================

Orchestrates business logic for memberships, invoices, and payments.
"""

import asyncio
import logging
import uuid
from datetime import datetime, timedelta
from decimal import Decimal
from typing import Optional

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database.models.administrative import (
    Invoice,
    InvoiceStatus,
    Membership,
    MembershipStatus,
    MembershipPlan,
    Transaction,
    TransactionType,
    TransactionStatus,
    PaymentGateway,
)
from app.database.models.core import User
from app.integrations.zoho_mail.service import ZohoMailService

logger = logging.getLogger(__name__)


class BillingService:
    def __init__(self, db: AsyncSession, email_service: ZohoMailService):
        self.db = db
        self.email_service = email_service

    async def cancel_pending_invoices_for_user(self, user_id: uuid.UUID) -> None:
        """
        Cancels any ISSUED or DRAFT invoices for a user.
        """
        stmt = (
            select(Invoice)
            .join(Membership)
            .where(Membership.user_id == user_id)
            .where(Invoice.status.in_([InvoiceStatus.ISSUED, InvoiceStatus.DRAFT]))
        )
        res = await self.db.execute(stmt)
        pending_invoices = res.scalars().all()
        for inv in pending_invoices:
            inv.status = InvoiceStatus.VOID
            inv.notes = "Anulado por nuevo cobro o registro manual."
        await self.db.commit()

    async def create_invoice_and_membership(
        self,
        user_id: uuid.UUID,
        plan_id: int,
        branch_id: uuid.UUID,
        amount: Decimal,
    ) -> uuid.UUID:
        """
        Creates an ISSUED invoice and a PENDING_PAYMENT membership.
        Returns the generated invoice ID.
        """
        await self.cancel_pending_invoices_for_user(user_id)
        
        invoice_id = uuid.uuid4()
        now = datetime.utcnow()

        # Sequential invoice number simulation
        invoice_number = f"INV-{str(invoice_id)[:8].upper()}"

        membership = Membership(
            id=uuid.uuid4(),
            user_id=user_id,
            plan_id=plan_id,
            branch_id=branch_id,
            status=MembershipStatus.PENDING_PAYMENT,
            start_date=now.date(),
            end_date=now.date(),  # Will be updated upon payment
        )
        self.db.add(membership)

        invoice = Invoice(
            id=invoice_id,
            membership_id=membership.id,
            branch_id=branch_id,
            invoice_number=invoice_number,
            status=InvoiceStatus.ISSUED,
            subtotal=amount,
            total=amount,
            due_date=now.date(),
        )
        self.db.add(invoice)

        await self.db.commit()
        return invoice_id

    async def get_invoice_by_id(self, invoice_id: uuid.UUID) -> Optional[Invoice]:
        stmt = select(Invoice).where(Invoice.id == invoice_id)
        result = await self.db.execute(stmt)
        return result.scalars().first()

    async def get_my_invoices(self, user_id: uuid.UUID) -> list[Invoice]:
        stmt = (
            select(Invoice)
            .join(Membership)
            .where(Membership.user_id == user_id)
            .order_by(Invoice.due_date.desc())
        )
        result = await self.db.execute(stmt)
        return list(result.scalars().all())

    async def mark_invoice_paid(
        self,
        invoice_id: uuid.UUID,
        gateway: str,
        transaction_amount: Decimal,
        gateway_payment_id: str,
        date_approved: Optional[datetime] = None,
    ) -> None:
        """
        Marks an invoice as PAID, creates a Transaction record,
        and dynamically renews the membership using plan's duration.
        """
        # 1. Fetch Invoice
        stmt_inv = select(Invoice).where(Invoice.id == invoice_id)
        res_inv = await self.db.execute(stmt_inv)
        invoice = res_inv.scalars().first()

        if not invoice:
            logger.error(f"Invoice {invoice_id} not found.")
            return

        if invoice.status == InvoiceStatus.PAID:
            logger.info(f"Invoice {invoice_id} is already marked as PAID.")
            return

        # 2. Update Invoice
        invoice.status = InvoiceStatus.PAID
        invoice.paid_at = date_approved or datetime.utcnow()

        # 3. Create Transaction
        # Map string to enum safely
        gateway_enum = PaymentGateway.MERCADOPAGO if gateway == "mercadopago" else PaymentGateway.OTHER
        transaction = Transaction(
            id=uuid.uuid4(),
            invoice_id=invoice.id,
            type=TransactionType.PAYMENT,
            status=TransactionStatus.APPROVED,
            amount=transaction_amount,
            currency_code="CLP",
            gateway=gateway_enum,
            gateway_reference=gateway_payment_id,
            processed_at=invoice.paid_at,
        )
        self.db.add(transaction)

        # 4. Fetch Membership & Plan
        stmt_mem = select(Membership).where(Membership.id == invoice.membership_id)
        res_mem = await self.db.execute(stmt_mem)
        membership = res_mem.scalars().first()

        if not membership:
            logger.error(f"Membership for Invoice {invoice_id} not found.")
            return

        stmt_plan = select(MembershipPlan).where(MembershipPlan.id == membership.plan_id)
        res_plan = await self.db.execute(stmt_plan)
        plan = res_plan.scalars().first()

        # 5. Determine Duration dynamically
        duration_days = 30  # Fallback
        if plan and getattr(plan, "duration_days", None):
            duration_days = plan.duration_days

        # 6. Update Membership Dates
        today = datetime.utcnow().date()
        if membership.end_date < today:
            membership.start_date = today
            membership.end_date = today + timedelta(days=duration_days)
        else:
            membership.end_date = membership.end_date + timedelta(days=duration_days)
        
        membership.status = MembershipStatus.ACTIVE

        # 7. Fetch User for Notification
        stmt_user = select(User).where(User.id == membership.user_id)
        res_user = await self.db.execute(stmt_user)
        user = res_user.scalars().first()

        await self.db.commit()

        # 8. Send Notification (Out of DB Transaction)
        if user and plan:
            async def _send_email_safe():
                try:
                    await self.email_service.send_payment_receipt(
                        to_email=user.email,
                        to_name=f"{user.first_name} {user.last_name}",
                        invoice_number=invoice.invoice_number,
                        plan_name=plan.name,
                        amount=float(transaction_amount)
                    )
                except Exception as e:
                    logger.error(f"Failed to dispatch email for {user.email}: {e}")
            
            asyncio.create_task(_send_email_safe())

    async def mark_invoice_failed(
        self, invoice_id: uuid.UUID, reason: str
    ) -> None:
        async with self.db.begin():
            stmt = select(Invoice).where(Invoice.id == invoice_id)
            res = await self.db.execute(stmt)
            invoice = res.scalars().first()

            if invoice and invoice.status != InvoiceStatus.PAID:
                invoice.status = InvoiceStatus.CANCELLED
                invoice.notes = f"Payment failed: {reason}"

class MembershipService:
    def __init__(self, db: AsyncSession):
        self.db = db

    async def sync_subscription_status(self, preapproval_id: str, action: Optional[str]) -> None:
        """
        Updates the membership status based on MercadoPago subscription preapproval events.
        """
        if not preapproval_id:
            return

        stmt = select(Membership).where(Membership.external_subscription_id == preapproval_id)
        res = await self.db.execute(stmt)
        membership = res.scalars().first()

        if not membership:
            logger.warning(f"Membership with external_subscription_id {preapproval_id} not found.")
            return

        if action == "cancelled":
            membership.status = MembershipStatus.CANCELLED
            membership.auto_renew = False
            logger.info(f"Membership {membership.id} cancelled due to MercadoPago subscription event.")
        
        await self.db.commit()
