import pytest
import pytest_asyncio
import asyncio
from httpx import AsyncClient, ASGITransport
from sqlalchemy.ext.asyncio import AsyncSession
from typing import AsyncGenerator

from main import app
from app.database.session import engine, get_db
from app.core.security import create_access_token
from app.database.models.core import User, Branch
from app.database.models.training import ExerciseCatalog, ExerciseCategory, DifficultyLevel

# Configure pytest-asyncio to use module-scoped event loop for fixtures
@pytest.fixture(scope="session")
def event_loop():
    loop = asyncio.get_event_loop_policy().new_event_loop()
    yield loop
    loop.close()

@pytest_asyncio.fixture(scope="function")
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Creates a transactional database session for a test.
    Rolls back the transaction after the test completes.
    """
    connection = await engine.connect()
    transaction = await connection.begin()
    session = AsyncSession(bind=connection, expire_on_commit=False)
    
    yield session
    
    await session.close()
    await transaction.rollback()
    await connection.close()


@pytest_asyncio.fixture(scope="function")
async def client(db_session: AsyncSession) -> AsyncGenerator[AsyncClient, None]:
    """
    HTTP client that overrides the get_db dependency.
    """
    def override_get_db():
        yield db_session

    app.dependency_overrides[get_db] = override_get_db
    
    async with AsyncClient(transport=ASGITransport(app=app), base_url="http://testserver") as test_client:
        yield test_client
        
    app.dependency_overrides.clear()


@pytest_asyncio.fixture(scope="function")
async def auth_headers(db_session: AsyncSession) -> dict:
    """
    Creates a test user and branch, and returns the Authorization header.
    """
    # 1. Create a Branch
    branch = Branch(name="Test Branch", code="TEST")
    db_session.add(branch)
    await db_session.flush()
    
    # 2. Create a User
    user = User(
        email="test_integration@example.com",
        username="testuser",
        password_hash="dummy_hash",
        first_name="Test",
        last_name="Integration",
        status="active",
        email_verified=True,
        branch_id=branch.id
    )
    db_session.add(user)
    await db_session.flush()
    
    # 3. Create a dummy exercise using list values or string casting to bypass Enum attribute mismatch
    category_value = list(ExerciseCategory)[0] if len(ExerciseCategory) > 0 else "strength"
    difficulty_value = list(DifficultyLevel)[0] if len(DifficultyLevel) > 0 else "beginner"

    exercise = ExerciseCatalog(
        id=1,
        name="Test Bench Press",
        category=category_value,
        difficulty=difficulty_value,
        is_custom=True
    )
    # We use merge to avoid conflicts if id=1 already exists
    await db_session.merge(exercise)
    await db_session.flush()
    
    # Generate token
    token = create_access_token(user.id, {"email": user.email, "role": "admin"})
    
    return {"Authorization": f"Bearer {token}"}