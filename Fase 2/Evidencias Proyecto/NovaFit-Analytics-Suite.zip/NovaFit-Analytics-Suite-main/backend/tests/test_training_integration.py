import pytest
from httpx import AsyncClient
from datetime import date

# Pytest expects test functions to start with "test_"
# We mark the entire module as async
pytestmark = pytest.mark.asyncio

async def test_template_and_session_flow(client: AsyncClient, auth_headers: dict):
    """
    Integration test covering:
    1. Template creation (POST /api/v1/training/templates)
    2. Instantiating a session (POST /api/v1/training/templates/{id}/instantiate)
    3. Listing sessions (GET /api/v1/training/sessions)
    """

    # 1. Create a template
    template_payload = {
        "name": "Integration Test Template",
        "description": "Full Body Test",
        "goal": "hypertrophy",
        "difficulty": "beginner",
        "estimated_duration_min": 60,
        "is_public": False,
        "exercises": [
            {
                "exercise_id": 1, # Provided by fixture
                "order_index": 1,
                "sets": 3,
                "reps_target": "10-12",
                "rest_seconds": 60
            }
        ]
    }
    
    response = await client.post("/api/v1/training/templates", json=template_payload, headers=auth_headers)
    assert response.status_code == 201, f"Failed to create template: {response.text}"
    
    template_data = response.json()
    assert template_data["name"] == "Integration Test Template"
    assert len(template_data["template_data"]) == 1
    
    template_id = template_data["id"]
    
    # 2. Instantiate a session from the template
    instantiate_payload = {
        "scheduled_date": date.today().isoformat(),
        # microcycle_id can be null or we omit it if optional
    }
    
    response = await client.post(
        f"/api/v1/training/templates/{template_id}/instantiate", 
        json=instantiate_payload, 
        headers=auth_headers
    )
    assert response.status_code == 201, f"Failed to instantiate session: {response.text}"
    
    session_data = response.json()
    assert session_data["name"] == "Integration Test Template"
    assert len(session_data["exercises"]) == 1
    
    # The exercise should have 3 sets created
    first_exercise = session_data["exercises"][0]
    assert len(first_exercise["sets"]) == 3
    
    session_id = session_data["id"]
    
    # 3. List the sessions and verify summary stats
    response = await client.get("/api/v1/training/sessions", headers=auth_headers)
    assert response.status_code == 200, f"Failed to list sessions: {response.text}"
    
    sessions_list = response.json()
    assert len(sessions_list) >= 1
    
    # Find our newly created session
    created_session = next((s for s in sessions_list if s["id"] == session_id), None)
    assert created_session is not None, "Session was not found in the list"
    
    # Check that volume_load_kg and total_sets are mapped properly
    # Since we didn't add weight/reps to the actual sets yet, volume should be 0, but total_sets should be 3
    assert created_session["total_sets"] == 3
    assert float(created_session["volume_load_kg"]) == 0.0
