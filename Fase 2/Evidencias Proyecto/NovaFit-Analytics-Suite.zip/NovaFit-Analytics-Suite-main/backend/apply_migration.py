import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text
from app.core.config import settings

async def apply():
    engine = create_async_engine(str(settings.DATABASE_URL))
    try:
        async with engine.begin() as conn:
            await conn.execute(text("ALTER TABLE invoices ADD COLUMN IF NOT EXISTS payment_link VARCHAR(512);"))
            print("Successfully added payment_link column.")
    except Exception as e:
        print(f"Error: {e}")
    finally:
        await engine.dispose()

if __name__ == "__main__":
    asyncio.run(apply())
