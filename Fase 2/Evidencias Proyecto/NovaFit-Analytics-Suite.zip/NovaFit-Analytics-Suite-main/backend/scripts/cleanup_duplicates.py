"""
Script de limpieza: elimina duplicados de muscle_groups y exercise_catalog
manteniendo solo el registro con el ID más bajo para cada nombre.
"""
import os, sys
from pathlib import Path
from dotenv import load_dotenv

if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')

env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

import psycopg2
SYNC_URL = os.getenv("DATABASE_URL", "").replace("postgresql+asyncpg://", "postgresql://")
conn = psycopg2.connect(SYNC_URL)
conn.autocommit = False
cur = conn.cursor()

try:
    print("[1] Limpiando duplicados en muscle_groups...")
    cur.execute("""
        DELETE FROM muscle_groups
        WHERE id NOT IN (
            SELECT MIN(id) FROM muscle_groups GROUP BY name
        )
    """)
    deleted_mg = cur.rowcount
    print(f"  Eliminados: {deleted_mg} registros duplicados")

    print("[2] Limpiando duplicados en exercise_catalog...")
    cur.execute("""
        DELETE FROM exercise_catalog
        WHERE id NOT IN (
            SELECT MIN(id) FROM exercise_catalog GROUP BY name_en
        )
    """)
    deleted_ex = cur.rowcount
    print(f"  Eliminados: {deleted_ex} registros duplicados")

    print("[3] Verificando exercise_muscle_groups huerfanos...")
    cur.execute("""
        DELETE FROM exercise_muscle_groups
        WHERE exercise_id NOT IN (SELECT id FROM exercise_catalog)
        OR muscle_group_id NOT IN (SELECT id FROM muscle_groups)
    """)
    print(f"  Huerfanos eliminados: {cur.rowcount}")

    conn.commit()
    print("Limpieza completada exitosamente.")

except Exception as e:
    conn.rollback()
    print(f"ERROR: {e}")
    import traceback; traceback.print_exc()
finally:
    cur.close()
    conn.close()
