import asyncio
import uuid
import datetime
import random
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database.session import AsyncSessionLocal
from app.database.models.core import User, UserStatus
from app.database.models.training import (
    RoutineSession, SessionExercise, ExerciseSet, SessionStatus, ExerciseCatalog
)
from app.core.security import hash_password

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def seed_historical_analytics():
    async with AsyncSessionLocal() as db:
        logger.info("Starting historical analytics seed for ACWR...")
        
        # 1. Ensure athlete exists
        athlete_email = "hypertrophy_athlete@example.com"
        result = await db.execute(select(User).where(User.email == athlete_email))
        athlete = result.scalar_one_or_none()
        
        if not athlete:
            athlete = User(
                first_name="Hypertrophy",
                last_name="Athlete",
                username="hypertrophy_athlete",
                email=athlete_email,
                password_hash=hash_password("hypertrophy123"),
                status=UserStatus.ACTIVE
            )
            db.add(athlete)
            await db.commit()
            await db.refresh(athlete)
            logger.info(f"Created athlete {athlete.id}")
            
        # 2. Get some exercises
        res = await db.execute(select(ExerciseCatalog).limit(3))
        exercises = res.scalars().all()
        if not exercises:
            logger.error("No exercises in catalog. Run initial db seed first.")
            return

        # 3. Generate 4 weeks of history
        today = datetime.date.today()
        start_date = today - datetime.timedelta(days=28)
        
        # Progressive overload params
        base_weight = 40.0
        weight_increment_per_week = 2.5
        
        logger.info(f"Generating 28 days of history starting from {start_date}")
        
        for day_offset in range(29):
            current_date = start_date + datetime.timedelta(days=day_offset)
            week_number = day_offset // 7
            
            # Train on Monday, Wednesday, Friday
            if current_date.weekday() not in [0, 2, 4]:
                continue
                
            session_weight = base_weight + (week_number * weight_increment_per_week)
            rpe = random.randint(7, 9)
            
            # Create Session
            started_time = datetime.datetime.combine(current_date, datetime.time(10, 0, tzinfo=datetime.timezone.utc))
            duration = random.randint(45, 90)
            completed_time = started_time + datetime.timedelta(minutes=duration)
            
            session = RoutineSession(
                user_id=athlete.id,
                name=f"Historical Session - {current_date.strftime('%A')}",
                scheduled_date=current_date,
                started_at=started_time,
                completed_at=completed_time,
                status=SessionStatus.COMPLETED,
                actual_duration_min=duration,
                perceived_effort=rpe,
                member_notes="Auto-generated historical session for ACWR calculation."
            )
            db.add(session)
            await db.commit()
            await db.refresh(session)
            
            # Add Exercises
            for order, ex_catalog in enumerate(exercises):
                sess_ex = SessionExercise(
                    session_id=session.id,
                    exercise_id=ex_catalog.id,
                    order_index=order,
                    notes="Focus on form"
                )
                db.add(sess_ex)
                await db.commit()
                await db.refresh(sess_ex)
                
                # Add Sets (3 sets per exercise)
                for set_idx in range(3):
                    ex_set = ExerciseSet(
                        session_exercise_id=sess_ex.id,
                        set_number=set_idx + 1,
                        prescribed_reps=10,
                        reps=random.randint(8, 12),
                        weight=session_weight + random.choice([0, 2.5, -2.5]),
                        is_warmup=False,
                        logged_at=started_time + datetime.timedelta(minutes=(order * 15) + (set_idx * 3))
                    )
                    db.add(ex_set)
                
            await db.commit()
            logger.info(f"Created session on {current_date} (Week {week_number + 1}) | RPE: {rpe} | Base Wt: {session_weight}")
            
        logger.info("✅ Historical analytics seed complete! Athlete has 4 weeks of progressive overload data.")

if __name__ == "__main__":
    asyncio.run(seed_historical_analytics())
