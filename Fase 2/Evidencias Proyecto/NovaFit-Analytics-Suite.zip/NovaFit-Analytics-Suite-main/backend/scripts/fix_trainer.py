import asyncio
import sys
import os

# Add backend directory to sys.path
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.future import select
from app.database.session import AsyncSessionLocal
from app.database.models.core import User, Role, UserRole

async def main():
    async with AsyncSessionLocal() as db:
        user = await db.scalar(select(User).where(User.email == "fr7944081@gmail.com"))
        if not user:
            print("User fr7944081@gmail.com not found")
            return
            
        role = await db.scalar(select(Role).where(Role.name == "trainer"))
        if not role:
            print("Role 'trainer' not found")
            return
            
        existing_role = await db.scalar(select(UserRole).where(UserRole.user_id == user.id, UserRole.role_id == role.id))
        if existing_role:
            print("Trainer role already assigned to user.")
            return
            
        user_role = UserRole(user_id=user.id, role_id=role.id)
        db.add(user_role)
        await db.commit()
        print("Successfully assigned 'trainer' role to fr7944081@gmail.com")

if __name__ == "__main__":
    asyncio.run(main())
