import asyncio
import uuid
import datetime
import random
import logging
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select

from app.database.session import AsyncSessionLocal
from app.database.models.core import User, UserStatus, Branch
from app.database.models.training import (
    RoutineTemplate, SessionExercise, ExerciseCatalog, SupplementLog,
    TrainingGoal, DifficultyLevel
)
from app.core.security import hash_password

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def seed_hypertrophy():
    async with AsyncSessionLocal() as db:
        logger.info("Starting hypertrophy and supplementation seed...")
        
        # 1. Ensure an athlete exists for testing
        athlete_email = "hypertrophy_athlete@example.com"
        result = await db.execute(select(User).where(User.email == athlete_email))
        athlete = result.scalar_one_or_none()
        
        if not athlete:
            athlete = User(
                first_name="Hypertrophy",
                last_name="Athlete",
                username="hypertrophy_athlete",
                email=athlete_email,
                password_hash=hash_password("hypertrophy123"),
                status=UserStatus.ACTIVE
            )
            db.add(athlete)
            await db.commit()
            await db.refresh(athlete)
            logger.info(f"Created athlete {athlete.id}")
            
        # 2. Add some supplement logs
        logger.info("Seeding SupplementLogs...")
        supplements = [
            ("Creatine Monohydrate", 5.0),
            ("Whey Protein", 30.0),
            ("Pre-workout", 15.0)
        ]
        
        for name, dose in supplements:
            log = SupplementLog(
                user_id=athlete.id,
                supplement_name=name,
                dose_grams=dose,
                date=datetime.date.today() - datetime.timedelta(days=random.randint(0, 10))
            )
            db.add(log)
        
        await db.commit()
        logger.info("Supplement logs seeded successfully.")

        # 3. Create a Hypertrophy RoutineTemplate if it doesn't exist
        template_name = "Hypertrophy Push/Pull/Legs"
        res = await db.execute(select(RoutineTemplate).where(RoutineTemplate.name == template_name))
        existing_template = res.scalar_one_or_none()
        
        if not existing_template:
            logger.info("Creating Hypertrophy RoutineTemplate...")
            
            # Ensure a branch exists for the template
            res_branch = await db.execute(select(Branch))
            branch = res_branch.scalar()
            if not branch:
                branch = Branch(name="Main Branch")
                db.add(branch)
                await db.commit()
                await db.refresh(branch)

            template = RoutineTemplate(
                branch_id=branch.id,
                name=template_name,
                description="A balanced 3-day split designed for maximal muscle hypertrophy.",
                estimated_duration_min=75,
                difficulty=DifficultyLevel.INTERMEDIATE,
                goal=TrainingGoal.HYPERTROPHY,
                template_data={"type": "hypertrophy", "split": "PPL"},
                is_public=True
            )
            db.add(template)
            await db.commit()
            logger.info(f"RoutineTemplate '{template_name}' created.")
        else:
            logger.info(f"RoutineTemplate '{template_name}' already exists.")

        logger.info("Seeding complete.")

if __name__ == "__main__":
    asyncio.run(seed_hypertrophy())
