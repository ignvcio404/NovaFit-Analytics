"""
NovaFit Analytics Suite — Seed Script
=======================================
Script de seeding de producción para:
  1. Grupos musculares base (muscle_groups)
  2. Catálogo de ejercicios (exercise_catalog) con video_url/thumbnail_url
  3. Linkeo ejercicio-músculo (exercise_muscle_groups)
  4. 7 Plantillas maestras de hipertrofia (routine_templates)
      · Push (Pecho/Tríceps/Hombros)
      · Pull (Espalda/Bíceps)
      · Legs (Cuádriceps/Isquiotibiales/Glúteos)
      · Full Body (Principiante)
      · Upper (Avanzado)
      · Lower (Avanzado)
      · Arnold Split — Pecho+Espalda
      · Arnold Split — Hombros+Brazos
      · Arnold Split — Piernas (Hypertrophy)

Uso:
    python backend/scripts/seed_training.py

Requiere:
    pip install asyncpg sqlalchemy psycopg2-binary python-dotenv
"""

import asyncio
import os
import sys
import uuid
from pathlib import Path

# Fix Windows console encoding
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')


from dotenv import load_dotenv

# ── Load .env ────────────────────────────────────────────────────────────────
env_path = Path(__file__).parent.parent / ".env"
load_dotenv(env_path)

DATABASE_URL = os.getenv("DATABASE_URL", "")
if not DATABASE_URL:
    print("ERROR: DATABASE_URL not found in .env")
    sys.exit(1)

# Convert asyncpg URL to psycopg2 format for synchronous psycopg2 use
# asyncpg URL: postgresql+asyncpg://...  → psycopg2: postgresql://...
SYNC_URL = DATABASE_URL.replace("postgresql+asyncpg://", "postgresql://")

import psycopg2
from psycopg2.extras import Json

print(f"Conectando a: {SYNC_URL[:60]}...")

# ── Muscle groups data ────────────────────────────────────────────────────────

MUSCLE_GROUPS = [
    {"name": "Pectoral Mayor", "name_en": "Pectoralis Major", "body_part": "Upper body"},
    {"name": "Pectoral Menor", "name_en": "Pectoralis Minor", "body_part": "Upper body"},
    {"name": "Dorsal Ancho", "name_en": "Latissimus Dorsi", "body_part": "Upper body"},
    {"name": "Trapecio", "name_en": "Trapezius", "body_part": "Upper body"},
    {"name": "Deltoides Anterior", "name_en": "Anterior Deltoid", "body_part": "Upper body"},
    {"name": "Deltoides Lateral", "name_en": "Lateral Deltoid", "body_part": "Upper body"},
    {"name": "Deltoides Posterior", "name_en": "Posterior Deltoid", "body_part": "Upper body"},
    {"name": "Bíceps Braquial", "name_en": "Biceps Brachii", "body_part": "Upper body"},
    {"name": "Tríceps Braquial", "name_en": "Triceps Brachii", "body_part": "Upper body"},
    {"name": "Cuádriceps", "name_en": "Quadriceps", "body_part": "Lower body"},
    {"name": "Isquiotibiales", "name_en": "Hamstrings", "body_part": "Lower body"},
    {"name": "Glúteo Mayor", "name_en": "Gluteus Maximus", "body_part": "Lower body"},
    {"name": "Pantorrilla (Gastrocnemio)", "name_en": "Gastrocnemius", "body_part": "Lower body"},
    {"name": "Recto Abdominal", "name_en": "Rectus Abdominis", "body_part": "Core"},
    {"name": "Oblicuos", "name_en": "Obliques", "body_part": "Core"},
    {"name": "Romboides", "name_en": "Rhomboids", "body_part": "Upper body"},
    {"name": "Serrato Anterior", "name_en": "Serratus Anterior", "body_part": "Upper body"},
]

# ── Exercises data ────────────────────────────────────────────────────────────
# video_url: YouTube embed, thumbnail_url: reliable exercise image from wger.de or similar

EXERCISES = [
    {
        "name": "Press de Banca con Barra",
        "name_en": "Barbell Bench Press",
        "description": "Ejercicio compuesto fundamental para el desarrollo del pectoral mayor.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica + banco plano",
        "video_url": "https://www.youtube.com/embed/rT7DgCr-3pg",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-4.svg",
        "primary_muscles": ["Pectoral Mayor"],
        "secondary_muscles": ["Tríceps Braquial", "Deltoides Anterior"],
    },
    {
        "name": "Press Inclinado con Mancuernas",
        "name_en": "Incline Dumbbell Press",
        "description": "Variación inclinada para enfatizar la porción superior del pectoral.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Mancuernas + banco inclinado",
        "video_url": "https://www.youtube.com/embed/8iPEnn-ltC8",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-4.svg",
        "primary_muscles": ["Pectoral Menor"],
        "secondary_muscles": ["Pectoral Mayor", "Deltoides Anterior", "Tríceps Braquial"],
    },
    {
        "name": "Aperturas con Mancuernas",
        "name_en": "Dumbbell Flyes",
        "description": "Ejercicio de aislamiento para el pectoral con énfasis en el estiramiento.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Mancuernas + banco plano",
        "video_url": "https://www.youtube.com/embed/eozdVDA78K0",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-4.svg",
        "primary_muscles": ["Pectoral Mayor"],
        "secondary_muscles": ["Deltoides Anterior"],
    },
    {
        "name": "Fondos en Paralelas",
        "name_en": "Tricep Dips",
        "description": "Ejercicio de peso corporal para tríceps y pectoral inferior.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Paralelas o banco",
        "video_url": "https://www.youtube.com/embed/2z8JmcrW-As",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-5.svg",
        "primary_muscles": ["Tríceps Braquial"],
        "secondary_muscles": ["Pectoral Mayor", "Deltoides Anterior"],
    },
    {
        "name": "Extensión de Tríceps en Polea Alta",
        "name_en": "Triceps Pushdown",
        "description": "Aislamiento de la cabeza lateral del tríceps con polea alta.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Máquina de polea",
        "video_url": "https://www.youtube.com/embed/2-LAMcpzODU",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-5.svg",
        "primary_muscles": ["Tríceps Braquial"],
        "secondary_muscles": [],
    },
    {
        "name": "Elevaciones Laterales con Mancuernas",
        "name_en": "Lateral Raises",
        "description": "Ejercicio de aislamiento para la cabeza lateral del deltoides.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Mancuernas",
        "video_url": "https://www.youtube.com/embed/3VcKaXpzqRo",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-2.svg",
        "primary_muscles": ["Deltoides Lateral"],
        "secondary_muscles": ["Deltoides Anterior"],
    },
    {
        "name": "Press Militar con Barra",
        "name_en": "Overhead Press",
        "description": "Ejercicio compuesto para el desarrollo integral del hombro.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica",
        "video_url": "https://www.youtube.com/embed/2yjwXTZQDDI",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-2.svg",
        "primary_muscles": ["Deltoides Anterior"],
        "secondary_muscles": ["Deltoides Lateral", "Tríceps Braquial"],
    },
    {
        "name": "Jalón al Pecho en Polea",
        "name_en": "Lat Pulldown",
        "description": "Ejercicio fundamental para el desarrollo del dorsal ancho.",
        "category": "compound",
        "difficulty": "beginner",
        "equipment": "Máquina de polea alta",
        "video_url": "https://www.youtube.com/embed/CAwf7n6Luuc",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-12.svg",
        "primary_muscles": ["Dorsal Ancho"],
        "secondary_muscles": ["Bíceps Braquial", "Romboides"],
    },
    {
        "name": "Remo con Barra",
        "name_en": "Barbell Row",
        "description": "Ejercicio de remo para el grosor de la espalda y el dorsal.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica",
        "video_url": "https://www.youtube.com/embed/FWJR5Ve8bnQ",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-12.svg",
        "primary_muscles": ["Dorsal Ancho"],
        "secondary_muscles": ["Trapecio", "Bíceps Braquial", "Romboides"],
    },
    {
        "name": "Remo en Máquina (Polea Baja)",
        "name_en": "Cable Seated Row",
        "description": "Remo sentado en polea baja para trabajar espalda media.",
        "category": "compound",
        "difficulty": "beginner",
        "equipment": "Máquina de polea baja",
        "video_url": "https://www.youtube.com/embed/GZbfZ033f74",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-12.svg",
        "primary_muscles": ["Romboides"],
        "secondary_muscles": ["Dorsal Ancho", "Trapecio", "Bíceps Braquial"],
    },
    {
        "name": "Curl de Bíceps con Barra",
        "name_en": "Barbell Bicep Curl",
        "description": "Movimiento básico de flexión para el bíceps braquial.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Barra EZ o recta",
        "video_url": "https://www.youtube.com/embed/kwG2ipFRgfo",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-1.svg",
        "primary_muscles": ["Bíceps Braquial"],
        "secondary_muscles": [],
    },
    {
        "name": "Curl Martillo con Mancuernas",
        "name_en": "Hammer Curl",
        "description": "Variación del curl que enfatiza el braquiorradial y el pico del bíceps.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Mancuernas",
        "video_url": "https://www.youtube.com/embed/zC3nLlEvin4",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-1.svg",
        "primary_muscles": ["Bíceps Braquial"],
        "secondary_muscles": [],
    },
    {
        "name": "Sentadilla con Barra",
        "name_en": "Barbell Back Squat",
        "description": "El rey de los ejercicios. Trabajo global del tren inferior.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica + rack",
        "video_url": "https://www.youtube.com/embed/bEv6CCg2BC8",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-10.svg",
        "primary_muscles": ["Cuádriceps"],
        "secondary_muscles": ["Glúteo Mayor", "Isquiotibiales"],
    },
    {
        "name": "Prensa de Piernas",
        "name_en": "Leg Press",
        "description": "Ejercicio de cuádriceps en máquina, menor demanda técnica que la sentadilla.",
        "category": "compound",
        "difficulty": "beginner",
        "equipment": "Máquina de prensa",
        "video_url": "https://www.youtube.com/embed/IZxyjW7MPJQ",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-10.svg",
        "primary_muscles": ["Cuádriceps"],
        "secondary_muscles": ["Glúteo Mayor"],
    },
    {
        "name": "Extensión de Cuádriceps en Máquina",
        "name_en": "Leg Extension",
        "description": "Aislamiento puro del cuádriceps en máquina.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Máquina de extensión",
        "video_url": "https://www.youtube.com/embed/YyvSfVjQeL0",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-10.svg",
        "primary_muscles": ["Cuádriceps"],
        "secondary_muscles": [],
    },
    {
        "name": "Curl de Isquiotibiales Tumbado",
        "name_en": "Lying Leg Curl",
        "description": "Flexión de rodilla en máquina para el trabajo de isquiotibiales.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Máquina de curl de piernas",
        "video_url": "https://www.youtube.com/embed/1Tq3QdYUuHs",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-11.svg",
        "primary_muscles": ["Isquiotibiales"],
        "secondary_muscles": [],
    },
    {
        "name": "Peso Muerto Rumano",
        "name_en": "Romanian Deadlift",
        "description": "Variante del peso muerto con énfasis en isquiotibiales y glúteos.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica",
        "video_url": "https://www.youtube.com/embed/JCXUYuzwNrM",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-11.svg",
        "primary_muscles": ["Isquiotibiales"],
        "secondary_muscles": ["Glúteo Mayor", "Dorsal Ancho"],
    },
    {
        "name": "Hip Thrust con Barra",
        "name_en": "Barbell Hip Thrust",
        "description": "Ejercicio estrella para el desarrollo y activación del glúteo mayor.",
        "category": "compound",
        "difficulty": "intermediate",
        "equipment": "Barra olímpica + banco",
        "video_url": "https://www.youtube.com/embed/SEdqd1n0cvg",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-8.svg",
        "primary_muscles": ["Glúteo Mayor"],
        "secondary_muscles": ["Isquiotibiales", "Cuádriceps"],
    },
    {
        "name": "Gemelos en Máquina (Standing Calf Raise)",
        "name_en": "Standing Calf Raise",
        "description": "Elevación de talones para el desarrollo del gastrocnemio.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Máquina de gemelos o rack",
        "video_url": "https://www.youtube.com/embed/gwLzBJYoWlI",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-7.svg",
        "primary_muscles": ["Pantorrilla (Gastrocnemio)"],
        "secondary_muscles": [],
    },
    {
        "name": "Dominadas (Pull-Up)",
        "name_en": "Pull-Up",
        "description": "Ejercicio de peso corporal para el dorsal ancho y bíceps.",
        "category": "compound",
        "difficulty": "advanced",
        "equipment": "Barra de dominadas",
        "video_url": "https://www.youtube.com/embed/eGo4IYlbE5g",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-12.svg",
        "primary_muscles": ["Dorsal Ancho"],
        "secondary_muscles": ["Bíceps Braquial", "Trapecio"],
    },
    {
        "name": "Face Pull en Polea",
        "name_en": "Face Pull",
        "description": "Ejercicio para el deltoides posterior y manguito rotador.",
        "category": "isolation",
        "difficulty": "beginner",
        "equipment": "Máquina de polea alta",
        "video_url": "https://www.youtube.com/embed/rep-qVOkqgk",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-9.svg",
        "primary_muscles": ["Deltoides Posterior"],
        "secondary_muscles": ["Romboides", "Trapecio"],
    },
    {
        "name": "Peso Muerto Convencional",
        "name_en": "Conventional Deadlift",
        "description": "Ejercicio compuesto total del cuerpo. Máximo reclutamiento muscular.",
        "category": "compound",
        "difficulty": "advanced",
        "equipment": "Barra olímpica",
        "video_url": "https://www.youtube.com/embed/op9kVnSso6Q",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-11.svg",
        "primary_muscles": ["Isquiotibiales"],
        "secondary_muscles": ["Glúteo Mayor", "Dorsal Ancho", "Trapecio", "Cuádriceps"],
    },
    {
        "name": "Plancha Abdominal",
        "name_en": "Plank",
        "description": "Ejercicio de estabilización del core sin carga adicional.",
        "category": "compound",
        "difficulty": "beginner",
        "equipment": "Sin equipo",
        "video_url": "https://www.youtube.com/embed/B296mZDhrP4",
        "thumbnail_url": "https://wger.de/static/images/muscles/main/muscle-6.svg",
        "primary_muscles": ["Recto Abdominal"],
        "secondary_muscles": ["Oblicuos"],
    },
]

# ── Template definitions ──────────────────────────────────────────────────────

def build_templates(exercise_map: dict) -> list:
    """
    exercise_map: { exercise_name_en -> exercise_id }
    Returns list of template dicts ready to insert.
    """
    # Helper to get exercise id safely
    def ex(name_en: str) -> int:
        eid = exercise_map.get(name_en)
        if not eid:
            print(f"  ⚠ Ejercicio no encontrado: {name_en}")
            return None
        return eid

    templates = [
        {
            "name": "PUSH — Pecho / Tríceps / Hombros",
            "description": "Sesión de empuje para el desarrollo del pectoral mayor, tríceps y deltoides. Orientada a hipertrofia con rangos de 8-15 repeticiones y descansos de 60-90 segundos.",
            "goal": "hypertrophy",
            "difficulty": "intermediate",
            "estimated_duration_min": 60,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Bench Press"),        "exercise_name": "Press de Banca con Barra",        "sets": 4, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Incline Dumbbell Press"),     "exercise_name": "Press Inclinado con Mancuernas",  "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Dumbbell Flyes"),             "exercise_name": "Aperturas con Mancuernas",        "sets": 3, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Overhead Press"),             "exercise_name": "Press Militar con Barra",          "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Lateral Raises"),             "exercise_name": "Elevaciones Laterales",           "sets": 4, "reps": "15-20", "rest_s": 45},
                {"exercise_id": ex("Tricep Dips"),                "exercise_name": "Fondos en Paralelas",             "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Triceps Pushdown"),           "exercise_name": "Extensión de Tríceps en Polea",   "sets": 3, "reps": "12-15", "rest_s": 60},
            ],
        },
        {
            "name": "PULL — Espalda / Bíceps",
            "description": "Sesión de tirón para el desarrollo del dorsal ancho, trapecio y bíceps. Combinación de jalones y remos para máximo grosor y amplitud.",
            "goal": "hypertrophy",
            "difficulty": "intermediate",
            "estimated_duration_min": 55,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Lat Pulldown"),               "exercise_name": "Jalón al Pecho en Polea",          "sets": 4, "reps": "8-12", "rest_s": 90},
                {"exercise_id": ex("Barbell Row"),                "exercise_name": "Remo con Barra",                   "sets": 4, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Cable Seated Row"),           "exercise_name": "Remo en Polea Baja",               "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Pull-Up"),                    "exercise_name": "Dominadas",                        "sets": 3, "reps": "6-10", "rest_s": 90},
                {"exercise_id": ex("Face Pull"),                  "exercise_name": "Face Pull en Polea",               "sets": 3, "reps": "15-20", "rest_s": 45},
                {"exercise_id": ex("Barbell Bicep Curl"),         "exercise_name": "Curl de Bíceps con Barra",         "sets": 3, "reps": "10-12", "rest_s": 60},
                {"exercise_id": ex("Hammer Curl"),                "exercise_name": "Curl Martillo con Mancuernas",     "sets": 3, "reps": "12-15", "rest_s": 60},
            ],
        },
        {
            "name": "LEGS — Cuádriceps / Isquiotibiales / Glúteos",
            "description": "Sesión completa de piernas con énfasis en hipertrofia de cuádriceps, isquiotibiales y glúteo mayor. Alta demanda sistémica.",
            "goal": "hypertrophy",
            "difficulty": "intermediate",
            "estimated_duration_min": 70,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Back Squat"),         "exercise_name": "Sentadilla con Barra",             "sets": 4, "reps": "8-10", "rest_s": 120},
                {"exercise_id": ex("Leg Press"),                  "exercise_name": "Prensa de Piernas",                "sets": 3, "reps": "10-15", "rest_s": 90},
                {"exercise_id": ex("Leg Extension"),              "exercise_name": "Extensión de Cuádriceps",          "sets": 3, "reps": "15-20", "rest_s": 60},
                {"exercise_id": ex("Romanian Deadlift"),          "exercise_name": "Peso Muerto Rumano",               "sets": 4, "reps": "8-12", "rest_s": 90},
                {"exercise_id": ex("Lying Leg Curl"),             "exercise_name": "Curl de Isquiotibiales",           "sets": 3, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Barbell Hip Thrust"),         "exercise_name": "Hip Thrust con Barra",             "sets": 4, "reps": "10-15", "rest_s": 75},
                {"exercise_id": ex("Standing Calf Raise"),        "exercise_name": "Gemelos en Máquina",               "sets": 4, "reps": "15-20", "rest_s": 45},
            ],
        },
        {
            "name": "FULL BODY — Hipertrofia Principiante",
            "description": "Rutina de cuerpo completo ideal para principiantes. Movimientos fundamentales con frecuencia 3x por semana.",
            "goal": "hypertrophy",
            "difficulty": "beginner",
            "estimated_duration_min": 45,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Back Squat"),         "exercise_name": "Sentadilla con Barra",             "sets": 3, "reps": "10-12", "rest_s": 90},
                {"exercise_id": ex("Barbell Bench Press"),        "exercise_name": "Press de Banca con Barra",         "sets": 3, "reps": "10-12", "rest_s": 90},
                {"exercise_id": ex("Lat Pulldown"),               "exercise_name": "Jalón al Pecho en Polea",          "sets": 3, "reps": "10-12", "rest_s": 90},
                {"exercise_id": ex("Overhead Press"),             "exercise_name": "Press Militar con Barra",          "sets": 2, "reps": "12-15", "rest_s": 75},
                {"exercise_id": ex("Romanian Deadlift"),          "exercise_name": "Peso Muerto Rumano",               "sets": 2, "reps": "12-15", "rest_s": 90},
                {"exercise_id": ex("Plank"),                      "exercise_name": "Plancha Abdominal",                "sets": 3, "reps": "30-60s", "rest_s": 45},
            ],
        },
        {
            "name": "UPPER — Fuerza Tren Superior (Avanzado)",
            "description": "Sesión de tren superior con énfasis en fuerza máxima. Rangos bajos de repeticiones, descansos largos y alta intensidad.",
            "goal": "strength",
            "difficulty": "advanced",
            "estimated_duration_min": 75,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Bench Press"),        "exercise_name": "Press de Banca con Barra",         "sets": 5, "reps": "3-5", "rest_s": 180},
                {"exercise_id": ex("Barbell Row"),                "exercise_name": "Remo con Barra",                   "sets": 5, "reps": "3-5", "rest_s": 180},
                {"exercise_id": ex("Overhead Press"),             "exercise_name": "Press Militar con Barra",          "sets": 4, "reps": "5-6", "rest_s": 150},
                {"exercise_id": ex("Pull-Up"),                    "exercise_name": "Dominadas con carga",              "sets": 4, "reps": "5-8", "rest_s": 150},
                {"exercise_id": ex("Incline Dumbbell Press"),     "exercise_name": "Press Inclinado Mancuernas",       "sets": 3, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Barbell Bicep Curl"),         "exercise_name": "Curl de Bíceps con Barra",         "sets": 3, "reps": "8-10", "rest_s": 75},
            ],
        },
        {
            "name": "LOWER — Potencia Tren Inferior (Avanzado)",
            "description": "Sesión de potencia de piernas para atletas avanzados. Incluye peso muerto convencional y sentadilla pesada.",
            "goal": "strength",
            "difficulty": "advanced",
            "estimated_duration_min": 80,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Conventional Deadlift"),      "exercise_name": "Peso Muerto Convencional",         "sets": 5, "reps": "3-5", "rest_s": 240},
                {"exercise_id": ex("Barbell Back Squat"),         "exercise_name": "Sentadilla con Barra",             "sets": 4, "reps": "4-6", "rest_s": 180},
                {"exercise_id": ex("Leg Press"),                  "exercise_name": "Prensa de Piernas",                "sets": 3, "reps": "8-10", "rest_s": 120},
                {"exercise_id": ex("Romanian Deadlift"),          "exercise_name": "Peso Muerto Rumano",               "sets": 3, "reps": "8-10", "rest_s": 120},
                {"exercise_id": ex("Barbell Hip Thrust"),         "exercise_name": "Hip Thrust con Barra",             "sets": 3, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Standing Calf Raise"),        "exercise_name": "Gemelos en Máquina",               "sets": 4, "reps": "12-15", "rest_s": 60},
            ],
        },
        {
            "name": "ARNOLD SPLIT — Pecho + Espalda",
            "description": "Día 1 del famoso Arnold Split. Combina pecho y espalda en la misma sesión para lograr un pump excepcional y mayor síntesis proteica. Alta frecuencia.",
            "goal": "hypertrophy",
            "difficulty": "advanced",
            "estimated_duration_min": 80,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Bench Press"),        "exercise_name": "Press de Banca con Barra",         "sets": 4, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Lat Pulldown"),               "exercise_name": "Jalón al Pecho en Polea",          "sets": 4, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Incline Dumbbell Press"),     "exercise_name": "Press Inclinado Mancuernas",       "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Barbell Row"),                "exercise_name": "Remo con Barra",                   "sets": 3, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Dumbbell Flyes"),             "exercise_name": "Aperturas con Mancuernas",         "sets": 3, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Pull-Up"),                    "exercise_name": "Dominadas",                        "sets": 3, "reps": "8-12", "rest_s": 75},
                {"exercise_id": ex("Cable Seated Row"),           "exercise_name": "Remo Polea Baja",                  "sets": 3, "reps": "12-15", "rest_s": 60},
            ],
        },
        {
            "name": "ARNOLD SPLIT — Hombros + Brazos",
            "description": "Día 2 del Arnold Split. Deltoides completo, bíceps y tríceps para máximo volumen en el tren superior distal.",
            "goal": "hypertrophy",
            "difficulty": "advanced",
            "estimated_duration_min": 75,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Overhead Press"),             "exercise_name": "Press Militar con Barra",          "sets": 4, "reps": "8-10", "rest_s": 90},
                {"exercise_id": ex("Lateral Raises"),             "exercise_name": "Elevaciones Laterales",            "sets": 4, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Face Pull"),                  "exercise_name": "Face Pull (Deltoides Post.)",      "sets": 3, "reps": "15-20", "rest_s": 45},
                {"exercise_id": ex("Barbell Bicep Curl"),         "exercise_name": "Curl de Bíceps con Barra",         "sets": 4, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Hammer Curl"),                "exercise_name": "Curl Martillo",                    "sets": 3, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Tricep Dips"),                "exercise_name": "Fondos en Paralelas",              "sets": 4, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Triceps Pushdown"),           "exercise_name": "Extensión Tríceps en Polea",       "sets": 3, "reps": "12-15", "rest_s": 60},
            ],
        },
        {
            "name": "ARNOLD SPLIT — Piernas (Hipertrofia)",
            "description": "Día 3 del Arnold Split. Sesión intensiva de piernas: cuádriceps, isquiotibiales, glúteos y gemelos para desarrollo integral del tren inferior.",
            "goal": "hypertrophy",
            "difficulty": "advanced",
            "estimated_duration_min": 80,
            "is_public": True,
            "template_data": [
                {"exercise_id": ex("Barbell Back Squat"),         "exercise_name": "Sentadilla con Barra",             "sets": 5, "reps": "6-8", "rest_s": 120},
                {"exercise_id": ex("Leg Press"),                  "exercise_name": "Prensa de Piernas",                "sets": 4, "reps": "10-15", "rest_s": 90},
                {"exercise_id": ex("Leg Extension"),              "exercise_name": "Extensión de Cuádriceps",          "sets": 3, "reps": "15-20", "rest_s": 60},
                {"exercise_id": ex("Romanian Deadlift"),          "exercise_name": "Peso Muerto Rumano",               "sets": 4, "reps": "8-12", "rest_s": 90},
                {"exercise_id": ex("Lying Leg Curl"),             "exercise_name": "Curl de Isquiotibiales",           "sets": 3, "reps": "12-15", "rest_s": 60},
                {"exercise_id": ex("Barbell Hip Thrust"),         "exercise_name": "Hip Thrust con Barra",             "sets": 4, "reps": "10-12", "rest_s": 75},
                {"exercise_id": ex("Standing Calf Raise"),        "exercise_name": "Gemelos en Máquina",               "sets": 5, "reps": "15-20", "rest_s": 45},
            ],
        },
    ]
    return templates


# ── Main seeding function ─────────────────────────────────────────────────────

def main():
    print("\n" + "="*60)
    print("  NovaFit Analytics Suite — Seeding Training Data")
    print("="*60)

    conn = psycopg2.connect(SYNC_URL)
    conn.autocommit = False
    cur = conn.cursor()

    try:
        # ─── 1. Get branch_id (first available branch) ───────────────────────
        print("\n[1/5] Obteniendo branch_id de la BD...")
        cur.execute("SELECT id FROM branches LIMIT 1")
        branch_row = cur.fetchone()
        if not branch_row:
            print("ERROR: No hay ninguna branch en la BD. Crea una sucursal primero.")
            return
        branch_id = branch_row[0]
        print(f"  Branch ID: {branch_id}")

        # ─── 2. Seed muscle groups ────────────────────────────────────────────
        print("\n[2/5] Seeding muscle_groups...")
        muscle_id_map = {}  # name -> id
        for mg in MUSCLE_GROUPS:
            # Upsert: insert if not exists by name
            cur.execute(
                "SELECT id FROM muscle_groups WHERE name = %s",
                (mg["name"],)
            )
            row = cur.fetchone()
            if row:
                muscle_id_map[mg["name"]] = row[0]
                print(f"  [skip] {mg['name']} ya existe (id={row[0]})")
            else:
                cur.execute(
                    """
                    INSERT INTO muscle_groups (name, name_en, body_part)
                    VALUES (%s, %s, %s)
                    RETURNING id
                    """,
                    (mg["name"], mg["name_en"], mg["body_part"])
                )
                new_id = cur.fetchone()[0]
                muscle_id_map[mg["name"]] = new_id
                print(f"  [+] {mg['name']} → id={new_id}")

        # ─── 3. Seed exercise_catalog ─────────────────────────────────────────
        print("\n[3/5] Seeding exercise_catalog...")
        exercise_id_map = {}  # name_en -> id
        for ex_data in EXERCISES:
            cur.execute(
                "SELECT id FROM exercise_catalog WHERE name_en = %s",
                (ex_data["name_en"],)
            )
            row = cur.fetchone()
            if row:
                exercise_id_map[ex_data["name_en"]] = row[0]
                print(f"  [skip] {ex_data['name_en']} ya existe (id={row[0]})")
            else:
                cur.execute(
                    """
                    INSERT INTO exercise_catalog
                      (name, name_en, description, category, difficulty, equipment, video_url, thumbnail_url, is_custom)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s, false)
                    RETURNING id
                    """,
                    (
                        ex_data["name"],
                        ex_data["name_en"],
                        ex_data["description"],
                        ex_data["category"],
                        ex_data["difficulty"],
                        ex_data["equipment"],
                        ex_data["video_url"],
                        ex_data["thumbnail_url"],
                    )
                )
                new_id = cur.fetchone()[0]
                exercise_id_map[ex_data["name_en"]] = new_id
                print(f"  [+] {ex_data['name']} → id={new_id}")

        # ─── 4. Seed exercise_muscle_groups (junction) ───────────────────────
        print("\n[4/5] Seeding exercise_muscle_groups...")
        for ex_data in EXERCISES:
            ex_id = exercise_id_map.get(ex_data["name_en"])
            if not ex_id:
                continue
            for muscle_name in ex_data.get("primary_muscles", []):
                mg_id = muscle_id_map.get(muscle_name)
                if not mg_id:
                    continue
                cur.execute(
                    """
                    INSERT INTO exercise_muscle_groups (exercise_id, muscle_group_id, is_primary)
                    VALUES (%s, %s, true)
                    ON CONFLICT DO NOTHING
                    """,
                    (ex_id, mg_id)
                )
            for muscle_name in ex_data.get("secondary_muscles", []):
                mg_id = muscle_id_map.get(muscle_name)
                if not mg_id:
                    continue
                cur.execute(
                    """
                    INSERT INTO exercise_muscle_groups (exercise_id, muscle_group_id, is_primary)
                    VALUES (%s, %s, false)
                    ON CONFLICT DO NOTHING
                    """,
                    (ex_id, mg_id)
                )
        print("  Vínculos músculo-ejercicio insertados correctamente.")

        # ─── 5. Seed routine_templates ────────────────────────────────────────
        print("\n[5/5] Seeding routine_templates...")

        # First: delete any existing 'inutile' templates (the ones with no template_data or minimal data)
        cur.execute(
            """
            DELETE FROM routine_templates
            WHERE (
                template_data IS NULL
                OR jsonb_typeof(template_data) != 'array'
                OR jsonb_array_length(template_data) < 3
            )
            RETURNING id, name
            """
        )
        deleted = cur.fetchall()
        for row in deleted:
            print(f"  [removed] Template vacia id={row[0]} '{row[1]}'")

        templates = build_templates(exercise_id_map)
        for tmpl in templates:
            # Check if exists by name
            cur.execute(
                "SELECT id FROM routine_templates WHERE name = %s",
                (tmpl["name"],)
            )
            row = cur.fetchone()
            if row:
                # Update template_data in case we improved it
                cur.execute(
                    """
                    UPDATE routine_templates
                    SET template_data = %s, description = %s, estimated_duration_min = %s
                    WHERE id = %s
                    """,
                    (Json(tmpl["template_data"]), tmpl["description"], tmpl["estimated_duration_min"], row[0])
                )
                print(f"  [updated] {tmpl['name']}")
            else:
                cur.execute(
                    """
                    INSERT INTO routine_templates
                      (branch_id, name, description, goal, difficulty, estimated_duration_min, template_data, is_public)
                    VALUES (%s, %s, %s, %s, %s, %s, %s, %s)
                    RETURNING id
                    """,
                    (
                        branch_id,
                        tmpl["name"],
                        tmpl["description"],
                        tmpl["goal"],
                        tmpl["difficulty"],
                        tmpl["estimated_duration_min"],
                        Json(tmpl["template_data"]),
                        tmpl["is_public"],
                    )
                )
                new_id = cur.fetchone()[0]
                print(f"  [+] '{tmpl['name']}' -> id={new_id}")

        conn.commit()
        print("\n" + "="*60)
        print("  SEEDING COMPLETADO EXITOSAMENTE")
        print(f"  Grupos Musculares: {len(MUSCLE_GROUPS)}")
        print(f"  Ejercicios:        {len(EXERCISES)}")
        print(f"  Plantillas:        {len(templates)}")
        print("="*60 + "\n")

    except Exception as e:
        conn.rollback()
        print(f"\n[ERROR] Rollback ejecutado. Causa: {e}")
        import traceback
        traceback.print_exc()
    finally:
        cur.close()
        conn.close()


if __name__ == "__main__":
    main()
