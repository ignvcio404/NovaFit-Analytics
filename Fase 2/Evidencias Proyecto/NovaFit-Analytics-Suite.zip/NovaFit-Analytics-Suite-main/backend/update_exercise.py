import asyncio
from sqlalchemy.ext.asyncio import create_async_engine
from sqlalchemy import text

async def main():
    engine = create_async_engine('postgresql+asyncpg://postgres.uxvyjopnmxiwfbtvnbxi:8547691Casa@aws-1-us-west-2.pooler.supabase.com:5432/postgres')
    async with engine.connect() as conn:
        await conn.execute(text("UPDATE exercise_catalog SET video_url = 'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/002511.gif' WHERE video_url IS NULL OR video_url = ''"))
        await conn.commit()
    print("Updated all empty video_url entries with placeholder GIF.")

asyncio.run(main())
