-- =============================================================================
-- NovaFit Analytics Suite — PostgreSQL DDL Script
-- Version: 1.0.0
-- Generated: 2025
-- Description: Creates all 30 normalized tables for the NovaFit platform.
--              Run this script against a clean PostgreSQL 15+ database.
--
-- Execution order respects FK dependencies.
-- Run as: psql -U novafit_admin -d novafit_db -f schema.sql
-- =============================================================================

-- ─── Extensions ───────────────────────────────────────────────────────────────
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";
CREATE EXTENSION IF NOT EXISTS "pgcrypto";

-- ─── ENUMs ────────────────────────────────────────────────────────────────────
CREATE TYPE user_status_enum         AS ENUM ('active', 'inactive', 'suspended', 'pending_verification');
CREATE TYPE audit_action_enum        AS ENUM ('create', 'read', 'update', 'delete', 'login', 'logout', 'payment', 'export');
CREATE TYPE billing_cycle_enum       AS ENUM ('monthly', 'quarterly', 'semi_annual', 'annual', 'one_time');
CREATE TYPE membership_status_enum   AS ENUM ('active', 'expired', 'frozen', 'cancelled', 'pending_payment');
CREATE TYPE invoice_status_enum      AS ENUM ('draft', 'issued', 'paid', 'partially_paid', 'overdue', 'void');
CREATE TYPE transaction_type_enum    AS ENUM ('payment', 'refund', 'chargeback', 'adjustment');
CREATE TYPE transaction_status_enum  AS ENUM ('pending', 'approved', 'rejected', 'cancelled', 'in_process', 'refunded');
CREATE TYPE payment_gateway_enum     AS ENUM ('mercadopago', 'cash', 'bank_transfer', 'other');
CREATE TYPE check_in_method_enum     AS ENUM ('qr_code', 'rfid', 'manual', 'facial');
CREATE TYPE training_goal_enum       AS ENUM ('hypertrophy', 'strength', 'endurance', 'power', 'weight_loss', 'maintenance', 'rehabilitation');
CREATE TYPE difficulty_level_enum    AS ENUM ('beginner', 'intermediate', 'advanced', 'elite');
CREATE TYPE exercise_category_enum   AS ENUM ('compound', 'isolation', 'cardio', 'mobility', 'plyometric');
CREATE TYPE session_status_enum      AS ENUM ('planned', 'in_progress', 'completed', 'skipped');
CREATE TYPE weight_unit_enum         AS ENUM ('kg', 'lb', 'bodyweight', 'band');
CREATE TYPE measurement_site_enum    AS ENUM ('chest','abdomen','thigh','triceps','subscapular','suprailiac','midaxillary','bicep','calf','waist','hip','neck','forearm','shoulder');
CREATE TYPE supplement_form_enum     AS ENUM ('powder', 'capsule', 'tablet', 'liquid', 'gel', 'bar');
CREATE TYPE dosage_unit_enum         AS ENUM ('g', 'mg', 'ml', 'capsule', 'scoop', 'IU');
CREATE TYPE fatigue_level_enum       AS ENUM ('low', 'moderate', 'high', 'critical');
CREATE TYPE alert_type_enum          AS ENUM ('deload_recommended','overtraining_risk','undertraining','membership_expiring','missed_sessions','plateau_detected','injury_risk','supplement_reminder');
CREATE TYPE alert_status_enum        AS ENUM ('pending', 'sent', 'acknowledged', 'dismissed', 'failed');


-- =============================================================================
-- MODULE 1 — CORE & SECURITY
-- =============================================================================

-- TABLE 1: branches
-- -----------------------------------------------------------------------------
CREATE TABLE branches (
    id           UUID         PRIMARY KEY DEFAULT uuid_generate_v4(),
    name         VARCHAR(120) NOT NULL,
    code         VARCHAR(10)  NOT NULL UNIQUE,
    address      VARCHAR(255),
    city         VARCHAR(100),
    country_code VARCHAR(3)   NOT NULL DEFAULT 'ARG',
    phone        VARCHAR(30),
    email        VARCHAR(180),
    timezone     VARCHAR(60)  NOT NULL DEFAULT 'America/Argentina/Buenos_Aires',
    is_active    BOOLEAN      NOT NULL DEFAULT TRUE,
    logo_url     VARCHAR(512),
    created_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at   TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
COMMENT ON TABLE  branches               IS 'Physical gym locations / franchise branches';
COMMENT ON COLUMN branches.code          IS 'Short alphanumeric code used in billing prefixes (e.g. BUE01)';
COMMENT ON COLUMN branches.country_code  IS 'ISO 3166-1 alpha-3 country code';


-- TABLE 2: roles
-- -----------------------------------------------------------------------------
CREATE TABLE roles (
    id          SERIAL       PRIMARY KEY,
    name        VARCHAR(80)  NOT NULL UNIQUE,
    description TEXT,
    is_system   BOOLEAN      NOT NULL DEFAULT FALSE,
    created_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW(),
    updated_at  TIMESTAMPTZ  NOT NULL DEFAULT NOW()
);
COMMENT ON TABLE  roles           IS 'RBAC role definitions';
COMMENT ON COLUMN roles.is_system IS 'System roles cannot be deleted';

-- Seed default roles
INSERT INTO roles (name, description, is_system) VALUES
    ('super_admin',   'Full platform access across all branches', TRUE),
    ('branch_admin',  'Full access within their assigned branch',  TRUE),
    ('trainer',       'Manage clients and training plans',         TRUE),
    ('member',        'End user — access own data only',           TRUE);


-- TABLE 3: permissions
-- -----------------------------------------------------------------------------
CREATE TABLE permissions (
    id          SERIAL      PRIMARY KEY,
    resource    VARCHAR(80) NOT NULL,
    action      VARCHAR(40) NOT NULL,
    description TEXT,
    CONSTRAINT uq_permission_resource_action UNIQUE (resource, action)
);
COMMENT ON TABLE  permissions          IS 'Granular action permissions: resource:action pairs';
COMMENT ON COLUMN permissions.resource IS 'e.g. routines, billing, users';
COMMENT ON COLUMN permissions.action   IS 'create | read | update | delete | export';


-- TABLE 4: role_permissions  (M:N junction)
-- -----------------------------------------------------------------------------
CREATE TABLE role_permissions (
    role_id       INT         NOT NULL REFERENCES roles(id)       ON DELETE CASCADE,
    permission_id INT         NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    granted_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    PRIMARY KEY (role_id, permission_id)
);
COMMENT ON TABLE role_permissions IS 'M:N grant table — implements RBAC';


-- TABLE 5: users
-- -----------------------------------------------------------------------------
CREATE TABLE users (
    id                  UUID                NOT NULL PRIMARY KEY DEFAULT uuid_generate_v4(),
    branch_id           UUID                REFERENCES branches(id) ON DELETE SET NULL,
    email               VARCHAR(254)        NOT NULL UNIQUE,
    username            VARCHAR(50)         NOT NULL UNIQUE,
    password_hash       VARCHAR(255)        NOT NULL,
    first_name          VARCHAR(80)         NOT NULL,
    last_name           VARCHAR(80)         NOT NULL,
    phone_number        VARCHAR(30),
    date_of_birth       DATE,
    avatar_url          VARCHAR(512),
    status              user_status_enum    NOT NULL DEFAULT 'pending_verification',
    email_verified      BOOLEAN             NOT NULL DEFAULT FALSE,
    phone_verified      BOOLEAN             NOT NULL DEFAULT FALSE,
    two_factor_enabled  BOOLEAN             NOT NULL DEFAULT FALSE,
    two_factor_secret   VARCHAR(64),
    last_login_at       TIMESTAMPTZ,
    last_login_ip       INET,
    created_at          TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
COMMENT ON TABLE  users              IS 'Central user entity — admins, trainers, members';
COMMENT ON COLUMN users.phone_number IS 'E.164 format — used for WhatsApp Cloud API';
COMMENT ON COLUMN users.last_login_ip IS 'PostgreSQL INET type for IP validation';


-- TABLE 6: user_roles  (M:N junction)
-- -----------------------------------------------------------------------------
CREATE TABLE user_roles (
    user_id     UUID        NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    role_id     INT         NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    assigned_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    assigned_by UUID        REFERENCES users(id) ON DELETE SET NULL,
    PRIMARY KEY (user_id, role_id)
);
COMMENT ON TABLE user_roles IS 'M:N junction — a user may hold multiple roles';


-- TABLE 7: audit_logs
-- -----------------------------------------------------------------------------
CREATE TABLE audit_logs (
    id            UUID              PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id       UUID              REFERENCES users(id)    ON DELETE SET NULL,
    branch_id     UUID              REFERENCES branches(id) ON DELETE SET NULL,
    action        audit_action_enum NOT NULL,
    resource_type VARCHAR(80)       NOT NULL,
    resource_id   VARCHAR(100),
    ip_address    INET,
    user_agent    VARCHAR(512),
    metadata      JSONB,
    occurred_at   TIMESTAMPTZ       NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_audit_logs_occurred_at  ON audit_logs(occurred_at DESC);
CREATE INDEX idx_audit_logs_user_id      ON audit_logs(user_id);
CREATE INDEX idx_audit_logs_resource     ON audit_logs(resource_type, resource_id);
COMMENT ON TABLE  audit_logs          IS 'Immutable compliance log — never UPDATE/DELETE via app';
COMMENT ON COLUMN audit_logs.metadata IS 'Arbitrary JSON payload: changed fields, request context';


-- =============================================================================
-- MODULE 2 — ADMINISTRATIVE & FINANCIAL
-- =============================================================================

-- TABLE 8: membership_plans
-- -----------------------------------------------------------------------------
CREATE TABLE membership_plans (
    id               SERIAL              PRIMARY KEY,
    branch_id        UUID                NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name             VARCHAR(120)        NOT NULL,
    description      TEXT,
    billing_cycle    billing_cycle_enum  NOT NULL,
    price            NUMERIC(10, 2)      NOT NULL,
    currency_code    VARCHAR(3)          NOT NULL DEFAULT 'ARS',
    duration_days    INT                 NOT NULL,
    max_freeze_days  INT                 NOT NULL DEFAULT 15,
    is_active        BOOLEAN             NOT NULL DEFAULT TRUE,
    features         JSONB,
    created_at       TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
COMMENT ON TABLE  membership_plans           IS 'Plan catalogue per branch';
COMMENT ON COLUMN membership_plans.features  IS '{"pool_access": true, "classes_per_week": 5}';


-- TABLE 9: memberships
-- -----------------------------------------------------------------------------
CREATE TABLE memberships (
    id                      UUID                    PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                 UUID                    NOT NULL REFERENCES users(id)            ON DELETE CASCADE,
    plan_id                 INT                     NOT NULL REFERENCES membership_plans(id) ON DELETE RESTRICT,
    branch_id               UUID                    NOT NULL REFERENCES branches(id)         ON DELETE CASCADE,
    status                  membership_status_enum  NOT NULL DEFAULT 'pending_payment',
    start_date              DATE                    NOT NULL,
    end_date                DATE                    NOT NULL,
    auto_renew              BOOLEAN                 NOT NULL DEFAULT FALSE,
    external_subscription_id VARCHAR(120),
    notes                   TEXT,
    created_at              TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN memberships.external_subscription_id IS 'MercadoPago preapproval / subscription ID';


-- TABLE 10: membership_freezes
-- -----------------------------------------------------------------------------
CREATE TABLE membership_freezes (
    id            SERIAL      PRIMARY KEY,
    membership_id UUID        NOT NULL REFERENCES memberships(id) ON DELETE CASCADE,
    requested_by  UUID        REFERENCES users(id) ON DELETE SET NULL,
    freeze_start  DATE        NOT NULL,
    freeze_end    DATE        NOT NULL,
    reason        VARCHAR(255),
    is_active     BOOLEAN     NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ NOT NULL DEFAULT NOW()
);


-- TABLE 11: invoices
-- -----------------------------------------------------------------------------
CREATE TABLE invoices (
    id              UUID                PRIMARY KEY DEFAULT uuid_generate_v4(),
    membership_id   UUID                NOT NULL REFERENCES memberships(id) ON DELETE RESTRICT,
    branch_id       UUID                NOT NULL REFERENCES branches(id)    ON DELETE RESTRICT,
    invoice_number  VARCHAR(50)         NOT NULL UNIQUE,
    status          invoice_status_enum NOT NULL DEFAULT 'draft',
    subtotal        NUMERIC(12, 2)      NOT NULL,
    tax_amount      NUMERIC(12, 2)      NOT NULL DEFAULT 0,
    discount_amount NUMERIC(12, 2)      NOT NULL DEFAULT 0,
    total           NUMERIC(12, 2)      NOT NULL,
    currency_code   VARCHAR(3)          NOT NULL DEFAULT 'ARS',
    due_date        DATE,
    paid_at         TIMESTAMPTZ,
    notes           TEXT,
    pdf_url         VARCHAR(512),
    created_at      TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN invoices.invoice_number IS 'e.g. BUE01-2025-00042';


-- TABLE 12: payment_methods
-- -----------------------------------------------------------------------------
CREATE TABLE payment_methods (
    id            SERIAL                PRIMARY KEY,
    user_id       UUID                  NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    gateway       payment_gateway_enum  NOT NULL,
    token         VARCHAR(255),
    last_four     VARCHAR(4),
    card_brand    VARCHAR(30),
    expiry_month  SMALLINT,
    expiry_year   SMALLINT,
    is_default    BOOLEAN               NOT NULL DEFAULT FALSE,
    is_active     BOOLEAN               NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
    updated_at    TIMESTAMPTZ           NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN payment_methods.token IS 'Gateway card token — NOT a raw card number';


-- TABLE 13: transactions
-- -----------------------------------------------------------------------------
CREATE TABLE transactions (
    id                UUID                    PRIMARY KEY DEFAULT uuid_generate_v4(),
    invoice_id        UUID                    NOT NULL REFERENCES invoices(id)        ON DELETE RESTRICT,
    payment_method_id INT                     REFERENCES payment_methods(id)          ON DELETE SET NULL,
    type              transaction_type_enum   NOT NULL,
    status            transaction_status_enum NOT NULL DEFAULT 'pending',
    amount            NUMERIC(12, 2)          NOT NULL,
    currency_code     VARCHAR(3)              NOT NULL DEFAULT 'ARS',
    gateway           payment_gateway_enum    NOT NULL,
    gateway_reference VARCHAR(200),
    processed_at      TIMESTAMPTZ,
    failure_reason    VARCHAR(255),
    created_at        TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN transactions.gateway_reference IS 'Gateway payment ID for reconciliation';


-- TABLE 14: mercadopago_transactions
-- -----------------------------------------------------------------------------
CREATE TABLE mercadopago_transactions (
    id                   SERIAL      PRIMARY KEY,
    transaction_id       UUID        NOT NULL UNIQUE REFERENCES transactions(id) ON DELETE CASCADE,
    mp_payment_id        VARCHAR(100),
    mp_preference_id     VARCHAR(200),
    mp_external_reference VARCHAR(200),
    mp_status            VARCHAR(50),
    mp_status_detail     VARCHAR(100),
    mp_payment_method_id VARCHAR(50),
    mp_payment_type_id   VARCHAR(50),
    mp_installments      INT,
    raw_response         JSONB,
    created_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_mp_tx_payment_id ON mercadopago_transactions(mp_payment_id);
COMMENT ON COLUMN mercadopago_transactions.raw_response IS 'Full MercadoPago API JSON for audit trail';


-- TABLE 15: attendance_records
-- -----------------------------------------------------------------------------
CREATE TABLE attendance_records (
    id         UUID                  PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id    UUID                  NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
    branch_id  UUID                  NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    check_in   TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
    check_out  TIMESTAMPTZ,
    method     check_in_method_enum  NOT NULL DEFAULT 'qr_code',
    notes      VARCHAR(255)
);
CREATE INDEX idx_attendance_user_id  ON attendance_records(user_id);
CREATE INDEX idx_attendance_check_in ON attendance_records(check_in DESC);


-- =============================================================================
-- MODULE 3 — TRAINING
-- =============================================================================

-- TABLE 16: muscle_groups
-- -----------------------------------------------------------------------------
CREATE TABLE muscle_groups (
    id              SERIAL      PRIMARY KEY,
    parent_id       INT         REFERENCES muscle_groups(id) ON DELETE SET NULL,
    name            VARCHAR(80) NOT NULL,
    name_en         VARCHAR(80),
    wger_muscle_id  INT         UNIQUE,
    body_part       VARCHAR(50)
);
COMMENT ON COLUMN muscle_groups.wger_muscle_id IS 'Wger API muscle ID for sync';


-- TABLE 17: exercise_catalog
-- -----------------------------------------------------------------------------
CREATE TABLE exercise_catalog (
    id               SERIAL                  PRIMARY KEY,
    wger_exercise_id INT                     UNIQUE,
    name             VARCHAR(120)            NOT NULL,
    name_en          VARCHAR(120),
    description      TEXT,
    instructions     JSONB,
    category         exercise_category_enum  NOT NULL,
    difficulty       difficulty_level_enum   NOT NULL DEFAULT 'intermediate',
    equipment        VARCHAR(120),
    video_url        VARCHAR(512),
    thumbnail_url    VARCHAR(512),
    is_custom        BOOLEAN                 NOT NULL DEFAULT FALSE,
    created_by       UUID                    REFERENCES users(id) ON DELETE SET NULL,
    created_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN exercise_catalog.instructions    IS 'Multilingual cues {lang_code: text}';
COMMENT ON COLUMN exercise_catalog.wger_exercise_id IS 'Wger API exercise base ID for sync';


-- TABLE 18: exercise_muscle_groups  (M:N junction)
-- -----------------------------------------------------------------------------
CREATE TABLE exercise_muscle_groups (
    exercise_id     INT     NOT NULL REFERENCES exercise_catalog(id) ON DELETE CASCADE,
    muscle_group_id INT     NOT NULL REFERENCES muscle_groups(id)    ON DELETE CASCADE,
    is_primary      BOOLEAN NOT NULL DEFAULT TRUE,
    PRIMARY KEY (exercise_id, muscle_group_id)
);
COMMENT ON COLUMN exercise_muscle_groups.is_primary IS 'TRUE = primary mover; FALSE = synergist';


-- TABLE 19: mesocycles
-- -----------------------------------------------------------------------------
CREATE TABLE mesocycles (
    id                   UUID                  PRIMARY KEY DEFAULT uuid_generate_v4(),
    trainer_id           UUID                  REFERENCES users(id)    ON DELETE SET NULL,
    member_id            UUID                  NOT NULL REFERENCES users(id)    ON DELETE CASCADE,
    branch_id            UUID                  NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name                 VARCHAR(150)          NOT NULL,
    goal                 training_goal_enum    NOT NULL,
    difficulty           difficulty_level_enum NOT NULL,
    start_date           DATE                  NOT NULL,
    end_date             DATE                  NOT NULL,
    total_weeks          INT                   NOT NULL,
    deload_week_interval INT                   NOT NULL DEFAULT 4,
    notes                TEXT,
    is_active            BOOLEAN               NOT NULL DEFAULT TRUE,
    created_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW(),
    updated_at           TIMESTAMPTZ           NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN mesocycles.deload_week_interval IS 'Every N weeks a deload microcycle is inserted';


-- TABLE 20: microcycles
-- -----------------------------------------------------------------------------
CREATE TABLE microcycles (
    id                    SERIAL          PRIMARY KEY,
    mesocycle_id          UUID            NOT NULL REFERENCES mesocycles(id) ON DELETE CASCADE,
    week_number           SMALLINT        NOT NULL CHECK (week_number >= 1),
    week_start_date       DATE            NOT NULL,
    week_end_date         DATE            NOT NULL,
    is_deload             BOOLEAN         NOT NULL DEFAULT FALSE,
    target_volume_sets    INT,
    target_intensity_pct  NUMERIC(5, 2),
    notes                 TEXT,
    created_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ     NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN microcycles.is_deload            IS 'Programmed or auto-detected recovery week';
COMMENT ON COLUMN microcycles.target_intensity_pct IS '% of 1-Rep Max (e.g. 75.00 = 75%)';


-- TABLE 21: routine_templates
-- -----------------------------------------------------------------------------
CREATE TABLE routine_templates (
    id                      SERIAL                  PRIMARY KEY,
    created_by              UUID                    REFERENCES users(id)    ON DELETE SET NULL,
    branch_id               UUID                    NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    name                    VARCHAR(150)            NOT NULL,
    description             TEXT,
    goal                    training_goal_enum      NOT NULL,
    difficulty              difficulty_level_enum   NOT NULL,
    estimated_duration_min  INT,
    template_data           JSONB,
    is_public               BOOLEAN                 NOT NULL DEFAULT FALSE,
    created_at              TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at              TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN routine_templates.template_data IS '[{"exercise_id": 12, "sets": 4, "reps": "8-10", "rest_s": 90}]';


-- TABLE 22: routine_sessions
-- -----------------------------------------------------------------------------
CREATE TABLE routine_sessions (
    id                  UUID                PRIMARY KEY DEFAULT uuid_generate_v4(),
    microcycle_id       INT                 REFERENCES microcycles(id)       ON DELETE SET NULL,
    template_id         INT                 REFERENCES routine_templates(id) ON DELETE SET NULL,
    user_id             UUID                NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    name                VARCHAR(150)        NOT NULL,
    scheduled_date      DATE                NOT NULL,
    started_at          TIMESTAMPTZ,
    completed_at        TIMESTAMPTZ,
    actual_duration_min INT,
    status              session_status_enum NOT NULL DEFAULT 'planned',
    perceived_effort    SMALLINT            CHECK (perceived_effort BETWEEN 1 AND 10),
    trainer_notes       TEXT,
    member_notes        TEXT,
    created_at          TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_routine_sessions_user_id ON routine_sessions(user_id);
COMMENT ON COLUMN routine_sessions.perceived_effort IS 'Overall session RPE 1-10';


-- TABLE 23: session_exercises
-- -----------------------------------------------------------------------------
CREATE TABLE session_exercises (
    id              SERIAL      PRIMARY KEY,
    session_id      UUID        NOT NULL REFERENCES routine_sessions(id)  ON DELETE CASCADE,
    exercise_id     INT         NOT NULL REFERENCES exercise_catalog(id) ON DELETE RESTRICT,
    order_index     SMALLINT    NOT NULL,
    superset_group  SMALLINT,
    notes           VARCHAR(255)
);
CREATE INDEX idx_session_exercises_session_id ON session_exercises(session_id);
COMMENT ON COLUMN session_exercises.superset_group IS 'Same superset_group = performed as superset';


-- TABLE 24: exercise_sets
-- -----------------------------------------------------------------------------
CREATE TABLE exercise_sets (
    id                    SERIAL            PRIMARY KEY,
    session_exercise_id   INT               NOT NULL REFERENCES session_exercises(id) ON DELETE CASCADE,
    set_number            SMALLINT          NOT NULL CHECK (set_number >= 1),
    prescribed_reps       SMALLINT,
    prescribed_weight_kg  NUMERIC(6, 2),
    reps                  SMALLINT,
    weight                NUMERIC(7, 2),
    weight_unit           weight_unit_enum  NOT NULL DEFAULT 'kg',
    rpe                   NUMERIC(3, 1)     CHECK (rpe BETWEEN 1 AND 10),
    rest_seconds          INT,
    duration_seconds      INT,
    is_warmup             BOOLEAN           NOT NULL DEFAULT FALSE,
    is_failure            BOOLEAN           NOT NULL DEFAULT FALSE,
    notes                 VARCHAR(255),
    logged_at             TIMESTAMPTZ       NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_exercise_sets_session_exercise_id ON exercise_sets(session_exercise_id);
COMMENT ON COLUMN exercise_sets.rpe          IS 'Borg modified RPE scale 1.0 to 10.0';
COMMENT ON COLUMN exercise_sets.is_failure   IS 'Did member reach muscular failure?';


-- =============================================================================
-- MODULE 4 — BIOMETRY & ANALYTICS
-- =============================================================================

-- TABLE 25: weight_history
-- -----------------------------------------------------------------------------
CREATE TABLE weight_history (
    id             SERIAL         PRIMARY KEY,
    user_id        UUID           NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    measured_at    TIMESTAMPTZ    NOT NULL DEFAULT NOW(),
    weight_kg      NUMERIC(5, 2)  NOT NULL CHECK (weight_kg > 0),
    body_fat_pct   NUMERIC(4, 1)  CHECK (body_fat_pct BETWEEN 3 AND 70),
    muscle_mass_kg NUMERIC(5, 2),
    hydration_pct  NUMERIC(4, 1),
    is_fasted      BOOLEAN        NOT NULL DEFAULT TRUE,
    notes          VARCHAR(255)
);
CREATE INDEX idx_weight_history_user_id ON weight_history(user_id, measured_at DESC);


-- TABLE 26: anthropometric_measurements
-- -----------------------------------------------------------------------------
CREATE TABLE anthropometric_measurements (
    id               SERIAL                  PRIMARY KEY,
    user_id          UUID                    NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    measured_by      UUID                    REFERENCES users(id) ON DELETE SET NULL,
    session_date     DATE                    NOT NULL,
    measurement_site measurement_site_enum   NOT NULL,
    value_mm         NUMERIC(5, 1),
    value_cm         NUMERIC(6, 1),
    notes            VARCHAR(255),
    created_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at       TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    CONSTRAINT ck_anthropometric_has_value CHECK (value_mm IS NOT NULL OR value_cm IS NOT NULL)
);
CREATE INDEX idx_anthro_user_id ON anthropometric_measurements(user_id, session_date DESC);


-- TABLE 27: supplement_catalog
-- -----------------------------------------------------------------------------
CREATE TABLE supplement_catalog (
    id                     SERIAL                  PRIMARY KEY,
    name                   VARCHAR(120)            NOT NULL UNIQUE,
    common_name            VARCHAR(120),
    description            TEXT,
    form                   supplement_form_enum,
    default_dosage_unit    dosage_unit_enum,
    recommended_daily_dose NUMERIC(7, 2),
    evidence_level         CHAR(1)                 CHECK (evidence_level IN ('A','B','C','D')),
    notes                  TEXT,
    created_at             TIMESTAMPTZ             NOT NULL DEFAULT NOW(),
    updated_at             TIMESTAMPTZ             NOT NULL DEFAULT NOW()
);
COMMENT ON COLUMN supplement_catalog.evidence_level IS 'Evidence tier: A | B | C | D';

-- Seed common supplements
INSERT INTO supplement_catalog (name, common_name, evidence_level, form, default_dosage_unit, recommended_daily_dose) VALUES
    ('Creatine Monohydrate', 'Creatine',   'A', 'powder',  'g',      5.00),
    ('Whey Protein Isolate', 'Whey',       'A', 'powder',  'g',      30.00),
    ('Caffeine Anhydrous',   'Caffeine',   'A', 'capsule', 'mg',     200.00),
    ('Beta-Alanine',         'Beta-Alanine','B','powder',  'g',      3.20),
    ('L-Citrulline',         'Citrulline', 'B', 'powder',  'g',      6.00),
    ('Omega-3 Fish Oil',     'Omega-3',    'A', 'capsule', 'mg',     2000.00),
    ('Vitamin D3',           'Vitamin D',  'A', 'capsule', 'IU',     2000.00),
    ('Magnesium Glycinate',  'Magnesium',  'B', 'tablet',  'mg',     400.00);


-- TABLE 28: supplement_consumption
-- -----------------------------------------------------------------------------
CREATE TABLE supplement_consumption (
    id             SERIAL           PRIMARY KEY,
    user_id        UUID             NOT NULL REFERENCES users(id)             ON DELETE CASCADE,
    supplement_id  INT              NOT NULL REFERENCES supplement_catalog(id) ON DELETE RESTRICT,
    session_id     UUID             REFERENCES routine_sessions(id)           ON DELETE SET NULL,
    consumed_at    TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
    dosage         NUMERIC(7, 2)    NOT NULL,
    dosage_unit    dosage_unit_enum NOT NULL,
    timing         VARCHAR(20),
    notes          VARCHAR(255)
);
CREATE INDEX idx_supplement_cons_user_id ON supplement_consumption(user_id, consumed_at DESC);
COMMENT ON COLUMN supplement_consumption.timing IS 'pre | intra | post | morning | evening | night';


-- TABLE 29: fatigue_indicators
-- -----------------------------------------------------------------------------
CREATE TABLE fatigue_indicators (
    id                    SERIAL              PRIMARY KEY,
    user_id               UUID                NOT NULL REFERENCES users(id)       ON DELETE CASCADE,
    microcycle_id         INT                 REFERENCES microcycles(id)          ON DELETE SET NULL,
    week_start_date       DATE                NOT NULL,
    week_end_date         DATE                NOT NULL,
    sessions_planned      INT                 NOT NULL DEFAULT 0,
    sessions_completed    INT                 NOT NULL DEFAULT 0,
    total_sets            INT                 NOT NULL DEFAULT 0,
    total_reps            INT                 NOT NULL DEFAULT 0,
    volume_load_kg        NUMERIC(12, 2)      NOT NULL DEFAULT 0,
    avg_rpe               NUMERIC(3, 1),
    max_rpe               NUMERIC(3, 1),
    failure_sets_count    INT                 NOT NULL DEFAULT 0,
    acute_workload        NUMERIC(10, 2),
    chronic_workload      NUMERIC(10, 2),
    acwr                  NUMERIC(5, 3),
    fatigue_score         NUMERIC(5, 2)       CHECK (fatigue_score BETWEEN 0 AND 100),
    fatigue_level         fatigue_level_enum,
    deload_recommended    BOOLEAN             NOT NULL DEFAULT FALSE,
    algorithm_version     VARCHAR(20)         NOT NULL DEFAULT '1.0.0',
    computation_metadata  JSONB,
    created_at            TIMESTAMPTZ         NOT NULL DEFAULT NOW(),
    updated_at            TIMESTAMPTZ         NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_fatigue_user_id       ON fatigue_indicators(user_id, week_start_date DESC);
CREATE INDEX idx_fatigue_deload_flag   ON fatigue_indicators(deload_recommended) WHERE deload_recommended = TRUE;
COMMENT ON COLUMN fatigue_indicators.acwr             IS 'Acute:Chronic Workload Ratio — target 0.8-1.3; >1.5 = injury risk';
COMMENT ON COLUMN fatigue_indicators.algorithm_version IS 'FatigueService version for reproducibility';


-- TABLE 30: predictive_alerts
-- -----------------------------------------------------------------------------
CREATE TABLE predictive_alerts (
    id                       UUID             PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id                  UUID             NOT NULL REFERENCES users(id)             ON DELETE CASCADE,
    triggered_by_fatigue_id  INT              REFERENCES fatigue_indicators(id)         ON DELETE SET NULL,
    alert_type               alert_type_enum  NOT NULL,
    title                    VARCHAR(200)     NOT NULL,
    message                  TEXT             NOT NULL,
    payload                  JSONB,
    status                   alert_status_enum NOT NULL DEFAULT 'pending',
    sent_in_app              BOOLEAN          NOT NULL DEFAULT FALSE,
    sent_via_email           BOOLEAN          NOT NULL DEFAULT FALSE,
    sent_via_whatsapp        BOOLEAN          NOT NULL DEFAULT FALSE,
    email_sent_at            TIMESTAMPTZ,
    whatsapp_sent_at         TIMESTAMPTZ,
    acknowledged_at          TIMESTAMPTZ,
    created_at               TIMESTAMPTZ      NOT NULL DEFAULT NOW(),
    updated_at               TIMESTAMPTZ      NOT NULL DEFAULT NOW()
);
CREATE INDEX idx_predictive_alerts_user_id    ON predictive_alerts(user_id, created_at DESC);
CREATE INDEX idx_predictive_alerts_status     ON predictive_alerts(status) WHERE status = 'pending';
COMMENT ON COLUMN predictive_alerts.payload          IS 'Structured context: {"fatigue_score": 82, "acwr": 1.6}';
COMMENT ON COLUMN predictive_alerts.sent_via_email   IS 'Dispatched via Zoho Mail API integration';
COMMENT ON COLUMN predictive_alerts.sent_via_whatsapp IS 'Dispatched via WhatsApp Cloud API integration';


-- =============================================================================
-- TRIGGERS — Auto-update `updated_at` columns
-- =============================================================================

CREATE OR REPLACE FUNCTION update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Apply trigger to all tables with updated_at
DO $$
DECLARE
    t TEXT;
BEGIN
    FOR t IN SELECT unnest(ARRAY[
        'branches', 'roles', 'users',
        'membership_plans', 'memberships', 'membership_freezes',
        'invoices', 'payment_methods', 'transactions', 'mercadopago_transactions',
        'exercise_catalog', 'mesocycles', 'microcycles',
        'routine_templates', 'routine_sessions',
        'supplement_catalog',
        'anthropometric_measurements',
        'fatigue_indicators', 'predictive_alerts'
    ])
    LOOP
        EXECUTE format(
            'CREATE TRIGGER trg_%s_updated_at
             BEFORE UPDATE ON %I
             FOR EACH ROW EXECUTE FUNCTION update_updated_at_column();',
            t, t
        );
    END LOOP;
END;
$$ LANGUAGE plpgsql;


-- =============================================================================
-- TRIGGER — Prevent UPDATE/DELETE on audit_logs
-- =============================================================================

CREATE OR REPLACE FUNCTION prevent_audit_log_mutation()
RETURNS TRIGGER AS $$
BEGIN
    RAISE EXCEPTION 'audit_logs rows are immutable — UPDATE/DELETE is forbidden.';
    RETURN NULL;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER trg_audit_logs_immutable
BEFORE UPDATE OR DELETE ON audit_logs
FOR EACH ROW EXECUTE FUNCTION prevent_audit_log_mutation();
