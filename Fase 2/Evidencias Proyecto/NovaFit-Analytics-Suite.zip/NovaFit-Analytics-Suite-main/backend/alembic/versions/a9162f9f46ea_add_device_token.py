"""add_device_token

Revision ID: a9162f9f46ea
Revises: a5ad937b3ad0
Create Date: 2026-08-19 03:38:23.527623

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = 'a9162f9f46ea'
down_revision: Union[str, Sequence[str], None] = 'a5ad937b3ad0'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.add_column('users', sa.Column('device_token', sa.String(length=255), nullable=True, comment='Expo push notification token'))


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_column('users', 'device_token')
