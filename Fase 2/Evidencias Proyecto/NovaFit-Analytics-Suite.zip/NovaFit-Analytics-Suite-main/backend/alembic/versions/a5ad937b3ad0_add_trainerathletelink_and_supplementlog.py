"""Add TrainerAthleteLink and SupplementLog

Revision ID: a5ad937b3ad0
Revises: 3b835c27e126
Create Date: 2026-08-05 17:06:51.228070

"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


# revision identifiers, used by Alembic.
revision: str = 'a5ad937b3ad0'
down_revision: Union[str, Sequence[str], None] = '3b835c27e126'
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    """Upgrade schema."""
    op.create_table('trainer_athlete_link',
        sa.Column('id', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('trainer_id', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('athlete_id', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('status', sa.Enum('pending', 'active', name='link_status_enum'), server_default='pending', nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['athlete_id'], ['users.id'], ondelete='CASCADE'),
        sa.ForeignKeyConstraint(['trainer_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_trainer_athlete_link_athlete_id'), 'trainer_athlete_link', ['athlete_id'], unique=False)
    op.create_index(op.f('ix_trainer_athlete_link_trainer_id'), 'trainer_athlete_link', ['trainer_id'], unique=False)
    op.create_index('uq_athlete_active_trainer', 'trainer_athlete_link', ['athlete_id'], unique=True, postgresql_where=sa.text("status = 'active'"))

    op.create_table('supplement_logs',
        sa.Column('id', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('user_id', sa.UUID(as_uuid=True), nullable=False),
        sa.Column('supplement_name', sa.String(length=150), nullable=False),
        sa.Column('dose_grams', sa.Numeric(precision=7, scale=2), nullable=False),
        sa.Column('date', sa.Date(), nullable=False),
        sa.Column('created_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.Column('updated_at', sa.DateTime(timezone=True), server_default=sa.text('now()'), nullable=False),
        sa.ForeignKeyConstraint(['user_id'], ['users.id'], ondelete='CASCADE'),
        sa.PrimaryKeyConstraint('id')
    )
    op.create_index(op.f('ix_supplement_logs_user_id'), 'supplement_logs', ['user_id'], unique=False)


def downgrade() -> None:
    """Downgrade schema."""
    op.drop_index(op.f('ix_supplement_logs_user_id'), table_name='supplement_logs')
    op.drop_table('supplement_logs')
    
    op.drop_index('uq_athlete_active_trainer', table_name='trainer_athlete_link', postgresql_where=sa.text("status = 'active'"))
    op.drop_index(op.f('ix_trainer_athlete_link_trainer_id'), table_name='trainer_athlete_link')
    op.drop_index(op.f('ix_trainer_athlete_link_athlete_id'), table_name='trainer_athlete_link')
    op.drop_table('trainer_athlete_link')
    op.execute("DROP TYPE IF EXISTS link_status_enum")
