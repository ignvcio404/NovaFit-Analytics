"""
NovaFit Analytics Suite — Backend
===================================
Application entry point (FastAPI).
"""

from contextlib import asynccontextmanager

import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.trustedhost import TrustedHostMiddleware

from app.api.v1.router import api_router
from app.api.middleware import AuditMiddleware
from app.core.config import settings
from app.core.exceptions import register_exception_handlers
from app.database.session import engine
from app.database.models import Base
from fastapi.responses import JSONResponse
import logging

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Manage startup / shutdown lifecycle."""
    # Startup: create tables if not exist (use Alembic in production)
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    # Shutdown: dispose engine connection pool
    await engine.dispose()


def create_app() -> FastAPI:
    app = FastAPI(
        title=settings.PROJECT_NAME,
        version=settings.API_VERSION,
        description="NovaFit Analytics Suite — Enterprise Fitness SaaS API",
        lifespan=lifespan,
    )

    # ── Middleware ─────────────────────────────────────────────────────────────
    cors_origins = list(settings.ALLOWED_ORIGINS)
    cors_origins.extend([
        "https://nova-fit-analytics-suite.vercel.app",
        "http://localhost:5173",
        "http://localhost:3000",
    ])

    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )
    import os
    allowed_hosts = list(settings.ALLOWED_HOSTS)
    # Allow testing hosts and Render domains behind reverse proxy
    allowed_hosts.extend([
        "testserver", 
        "localhost", 
        "127.0.0.1", 
        "novafit-analytics-suite.onrender.com",
        "*.onrender.com",
        "*"
    ])
        
    app.add_middleware(TrustedHostMiddleware, allowed_hosts=list(set(allowed_hosts)))

    # Add audit logging middleware
    app.add_middleware(AuditMiddleware)

    @app.middleware("http")
    async def global_catch_all_middleware(request, call_next):
        try:
            return await call_next(request)
        except Exception as exc:
            logger.error(f"Unhandled exception in middleware: {exc}", exc_info=True)
            response = JSONResponse(
                status_code=500,
                content={
                    "success": False,
                    "error": {
                        "code": "INTERNAL_SERVER_ERROR",
                        "message": "Ocurrió un error inesperado. Por favor, intenta de nuevo.",
                    }
                }
            )
            origin = request.headers.get("origin")
            if origin:
                response.headers["Access-Control-Allow-Origin"] = origin
                response.headers["Access-Control-Allow-Credentials"] = "true"
            return response

    # ── Routes ─────────────────────────────────────────────────────────────────
    app.include_router(api_router, prefix=settings.API_V1_PREFIX)

    # ── Health check (used by ServerWakeUp button and Render) ──────────────────
    from datetime import datetime, timezone

    @app.get("/health", tags=["Health"], include_in_schema=True)
    async def health_check():
        """
        Lightweight liveness probe.
        Used by:
          - Render health checks
          - Frontend ServerWakeUp component to wake the server from sleep
        """
        return {
            "status": "ok",
            "service": settings.PROJECT_NAME,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

    # ── Exception handlers ─────────────────────────────────────────────────────
    register_exception_handlers(app)

    return app


app = create_app()

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
